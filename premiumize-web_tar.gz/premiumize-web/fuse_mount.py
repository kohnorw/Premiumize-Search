"""
Premiumize virtual filesystem using FUSE.

Directory structure:
  /docker/premiumize-web/mnt/
    <torrent name>/
      <filename>.mkv   ← virtual file, reads via live HTTP range requests

CDN URLs are never stored — directdl is called fresh with a 30-min cache.
"""

import errno
import logging
import os
import re
import stat
import threading
import time

import requests

log = logging.getLogger(__name__)

DIRECTDL_TTL   = 1800  # hard expiry of a cached directdl result (30 min)
REFRESH_MARGIN = 300   # start a background refresh once within 5 min of expiry

READ_TIMEOUT       = 30   # per-request timeout for a CDN range read
READ_MAX_ATTEMPTS  = 4    # total tries for one read before giving up with EIO
READ_BACKOFF_BASE  = 0.4  # seconds; backoff grows base*1, base*2, ... (capped)
READ_BACKOFF_CAP   = 2.0  # seconds; never sleep longer than this between tries

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")


def _safe_name(name: str) -> str:
    """Sanitize torrent name for use as a filesystem directory name."""
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"


def build_name_map(transfer_manager) -> dict:
    """
    Single source of truth for {dir_name: hash} as exposed in the mount.

    Both the FUSE layer and the web-UI symlink builder use this so a symlink
    target always matches the directory the mount actually serves — including
    the duplicate-name suffix rule.
    """
    result = {}
    for h in transfer_manager.streamable_hashes():
        t = transfer_manager.get_transfer(h)
        name = _safe_name(t.get("name") or h) if t else h
        # Handle duplicate names by appending hash suffix
        if name in result:
            name = f"{name}_{h[:8]}"
        result[name] = h
    return result


def dir_name_for_hash(transfer_manager, hash_: str):
    """Return the exact mount directory name for a hash, or None if not streamable."""
    for nm, h in build_name_map(transfer_manager).items():
        if h == hash_:
            return nm
    return None


class PremiumizeFS(Operations):
    def __init__(self, transfer_manager):
        self._tm    = transfer_manager
        self._now   = time.time()
        self._lock  = threading.Lock()
        # Cache: hash → (files: list[dict], expires_at: float)
        self._cache: dict[str, tuple[list, float]] = {}
        # Hashes with an in-flight background refresh (de-dupes refresh-ahead)
        self._refreshing: set = set()

    # ── name ↔ hash mapping ───────────────────────────────────────────────────

    def _get_name_map(self) -> dict:
        """Returns {safe_name: hash} for all streamable transfers."""
        return build_name_map(self._tm)

    def _name_to_hash(self, dirname: str):
        return self._get_name_map().get(dirname)

    # ── directdl cache ────────────────────────────────────────────────────────

    def _get_files(self, hash_: str, force: bool = False) -> list:
        now = time.time()
        if not force:
            with self._lock:
                cached = self._cache.get(hash_)
            if cached:
                files, expires_at = cached
                if now < expires_at - REFRESH_MARGIN:
                    return files                       # comfortably fresh
                if now < expires_at:
                    # Inside the margin: links are still valid, but renew them in
                    # the background so the next read already has fresh ones and
                    # never has to block on a synchronous directdl call.
                    self._spawn_refresh(hash_)
                    return files
                # hard-expired → fall through to a synchronous fetch

        # force=True propagates to the app-level directdl cache too, so a fresh
        # CDN URL is actually fetched instead of being shadowed by a still-valid
        # entry in the lower cache layer.
        files = self._tm.get_files(hash_, force=force)
        if files:
            with self._lock:
                self._cache[hash_] = (files, now + DIRECTDL_TTL)

        return files

    def _spawn_refresh(self, hash_: str):
        """Background re-mint of directdl links so active streams stay seamless."""
        with self._lock:
            if hash_ in self._refreshing:
                return
            self._refreshing.add(hash_)

        def _do():
            try:
                files = self._tm.get_files(hash_, force=True)
                if files:
                    with self._lock:
                        self._cache[hash_] = (files, time.time() + DIRECTDL_TTL)
            except Exception:
                log.warning(f"[{hash_[:8]}] background refresh failed", exc_info=True)
            finally:
                with self._lock:
                    self._refreshing.discard(hash_)

        threading.Thread(target=_do, daemon=True).start()

    def _invalidate(self, hash_: str):
        with self._lock:
            self._cache.pop(hash_, None)

    # ── path helpers ──────────────────────────────────────────────────────────

    def _parse_path(self, path):
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None, None, None
        dirname = parts[0]
        filename = "/".join(parts[1:]) if len(parts) > 1 else None
        hash_ = self._name_to_hash(dirname)
        return dirname, filename, hash_

    def _find_file(self, hash_: str, filename: str, force: bool = False):
        """
        Match filename against file list.
        FIX: also compare against basename of path so nested paths
        like 'ShowName/ShowName.S01E01.mkv' resolve correctly.
        """
        for f in self._get_files(hash_, force=force):
            f_name = f.get("name", "")
            f_base = os.path.basename(f.get("path", "") or f_name)
            if f_name == filename or f_base == filename:
                return f
        return None

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        base = {
            "st_uid":   os.getuid(),
            "st_gid":   os.getgid(),
            "st_atime": self._now,
            "st_mtime": self._now,
            "st_ctime": self._now,
            "st_nlink": 2,
        }

        if path == "/":
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        dirname, filename, hash_ = self._parse_path(path)

        if not filename:
            if hash_ is not None:
                return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            raise FuseOSError(errno.ENOENT)

        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        return {
            **base,
            "st_mode":  stat.S_IFREG | 0o444,
            "st_nlink": 1,
            "st_size":  int(f.get("size", 0)),
        }

    def readdir(self, path, fh):
        yield "."
        yield ".."

        if path == "/":
            for name in self._get_name_map().keys():
                yield name
            return

        dirname, _, hash_ = self._parse_path(path)
        if hash_:
            for f in self._get_files(hash_):
                # FIX: always yield the basename so FUSE never sees a slash in
                # a filename (FUSE treats '/' as a path separator and rejects it)
                raw = f.get("name", "") or f.get("path", "")
                name = os.path.basename(raw) if raw else raw
                if name:
                    yield name

    def open(self, path, flags):
        dirname, filename, hash_ = self._parse_path(path)
        if not filename or hash_ is None or not self._find_file(hash_, filename):
            raise FuseOSError(errno.ENOENT)
        return 0

    def read(self, path, size, offset, fh):
        dirname, filename, hash_ = self._parse_path(path)
        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        cdn_url = f.get("link", "")
        if not cdn_url:
            raise FuseOSError(errno.EIO)

        end     = offset + size - 1
        headers = {"Range": f"bytes={offset}-{end}"}

        # Bounded retry so a transient blip (timeout, dropped connection, CDN 5xx,
        # or a just-expired link) pauses the stream briefly instead of returning
        # EIO and killing playback. A 403/410 forces a one-time link re-mint;
        # network/5xx errors back off and retry on the same (or refreshed) link.
        last_err  = None
        refreshed = False
        for attempt in range(READ_MAX_ATTEMPTS):
            try:
                r = requests.get(cdn_url, headers=headers,
                                 timeout=READ_TIMEOUT, stream=True)
            except requests.RequestException as e:
                last_err = e
                log.warning(f"FUSE read network error {path} "
                            f"(try {attempt + 1}/{READ_MAX_ATTEMPTS}): {e}")
                self._read_backoff(attempt)
                continue

            try:
                status = r.status_code

                if status in (200, 206):
                    return r.content

                if status in (403, 410):
                    if not refreshed:
                        log.info(f"CDN URL expired for {dirname}/{filename} — refreshing")
                        self._invalidate(hash_)
                        # force=True punches through BOTH cache layers so we don't
                        # get handed back the same expired URL.
                        f = self._find_file(hash_, filename, force=True)
                        new_url = f.get("link", "") if f else ""
                        refreshed = True
                        if new_url:
                            cdn_url = new_url
                            continue  # retry immediately with the fresh link
                    last_err = f"status {status} (after refresh)" if refreshed else f"status {status}"
                    break  # expired and refresh didn't help → stop

                if status in (429, 500, 502, 503, 504):
                    last_err = f"status {status}"
                    log.warning(f"FUSE read transient {status} {path} "
                                f"(try {attempt + 1}/{READ_MAX_ATTEMPTS})")
                    self._read_backoff(attempt)
                    continue

                # Any other status is treated as non-retryable.
                last_err = f"status {status}"
                log.warning(f"FUSE read got {status} for {path}")
                break
            finally:
                r.close()

        log.warning(f"FUSE read failed for {path} after "
                    f"{READ_MAX_ATTEMPTS} tries: {last_err}")
        raise FuseOSError(errno.EIO)

    @staticmethod
    def _read_backoff(attempt: int):
        time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))

    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


def mount(mountpoint: str, transfer_manager, foreground=True):
    if not FUSE_AVAILABLE:
        log.error("fusepy not installed — cannot mount")
        return
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"Mounting Premiumize FS at {mountpoint}")
    FUSE(
        PremiumizeFS(transfer_manager),
        mountpoint,
        nothreads=False,
        foreground=foreground,
        allow_other=True,
        nonempty=True,
        ro=True,
    )

#!/usr/bin/env python3
"""
Premiumize FUSE mount — runs on the HOST, not inside Docker.

Talks to the Flask app via HTTP to get file listings and stream data.
Mount appears at MOUNTPOINT and is visible to Plex, Sonarr, Radarr, etc.

Usage:
    pip3 install fusepy requests
    python3 fuse_host.py

Environment variables:
    FLASK_URL       URL of the Flask app (default: http://localhost:5000)
    MOUNTPOINT      Where to mount (default: /docker/premiumize-web/mnt)
    REFRESH_SECS    How often to refresh file listings (default: 30)
"""

import errno
import logging
import os
import signal
import stat
import subprocess
import sys
import threading
import time

import requests

logging.basicConfig(level=logging.INFO, format="%(asctime)s [FUSE] %(message)s")
log = logging.getLogger(__name__)

FLASK_URL    = os.environ.get("FLASK_URL",   "http://localhost:5000")
MOUNTPOINT   = os.environ.get("MOUNTPOINT",  "/docker/premiumize-web/mnt")
REFRESH_SECS = int(os.environ.get("REFRESH_SECS", "30"))
CACHE_TTL    = 1800  # 30 min CDN URL cache

try:
    from fuse import FUSE, FuseOSError, Operations
except ImportError:
    print("fusepy not installed. Run: pip3 install fusepy")
    sys.exit(1)


class PremiumizeHostFS(Operations):
    def __init__(self):
        self._now        = time.time()
        self._lock       = threading.Lock()
        # {hash: (files, expires_at)}
        self._file_cache: dict = {}
        # {hash: name} — polled from Flask
        self._transfers: dict  = {}
        self._refresh()
        self._start_poller()

    # ── Flask API calls ───────────────────────────────────────────────────────

    def _refresh(self):
        """Poll Flask for current streamable transfers."""
        try:
            r = requests.get(f"{FLASK_URL}/api/transfers", timeout=10)
            if r.status_code == 200:
                data = r.json()
                with self._lock:
                    self._transfers = {t["hash"]: t["name"] for t in data.get("transfers", [])}
        except Exception as e:
            log.warning(f"Refresh failed: {e}")

    def _get_files(self, hash_: str) -> list:
        """Get file list for a hash, using cache."""
        now = time.time()
        with self._lock:
            cached = self._file_cache.get(hash_)
            if cached and cached[1] > now:
                return cached[0]

        name = self._transfers.get(hash_, hash_)
        try:
            r = requests.post(
                f"{FLASK_URL}/api/links",
                json={"hash": hash_, "name": name},
                timeout=15,
            )
            if r.status_code == 200:
                files = r.json().get("links", [])
                with self._lock:
                    self._file_cache[hash_] = (files, now + CACHE_TTL)
                return files
        except Exception as e:
            log.warning(f"get_files({hash_[:8]}) failed: {e}")

        return []

    def _invalidate(self, hash_: str):
        with self._lock:
            self._file_cache.pop(hash_, None)

    def _start_poller(self):
        def loop():
            while True:
                time.sleep(REFRESH_SECS)
                self._refresh()
        threading.Thread(target=loop, daemon=True).start()

    # ── path helpers ──────────────────────────────────────────────────────────

    def _parse(self, path):
        parts = [p for p in path.split("/") if p]
        if not parts:      return None, None
        if len(parts) == 1: return parts[0], None
        return parts[0], "/".join(parts[1:])

    def _find_file(self, hash_, filename):
        for f in self._get_files(hash_):
            if f.get("name") == filename or f.get("path", "").endswith(filename):
                return f
        return None

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        base = {
            "st_uid":   os.getuid(),
            "st_gid":   os.getgid(),
            "st_atime": self._now,
            "st_mtime": self._now,
            "st_ctime": self._now,
            "st_nlink": 2,
        }

        if path == "/":
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        hash_, filename = self._parse(path)

        if not filename:
            with self._lock:
                known = hash_ in self._transfers
            if known:
                return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        return {
            **base,
            "st_mode":  stat.S_IFREG | 0o444,
            "st_nlink": 1,
            "st_size":  int(f.get("size", 0)),
        }

    def readdir(self, path, fh):
        yield "."
        yield ".."

        if path == "/":
            with self._lock:
                hashes = list(self._transfers.keys())
            for h in hashes:
                yield h
            return

        hash_, _ = self._parse(path)
        for f in self._get_files(hash_ or ""):
            yield f.get("name", "")

    def open(self, path, flags):
        hash_, filename = self._parse(path)
        if not filename or not self._find_file(hash_, filename):
            raise FuseOSError(errno.ENOENT)
        return 0

    def read(self, path, size, offset, fh):
        hash_, filename = self._parse(path)
        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        # Use the proxy stream URL from Flask
        stream_url = f.get("stream_url", "")
        if not stream_url:
            raise FuseOSError(errno.EIO)

        url = f"{FLASK_URL}{stream_url}"
        end = offset + size - 1
        headers = {"Range": f"bytes={offset}-{end}"}

        try:
            r = requests.get(url, headers=headers, timeout=30, stream=True)

            # Expired — invalidate and retry
            if r.status_code in (403, 410):
                log.info(f"Link expired for {hash_[:8]}/{filename} — refreshing")
                self._invalidate(hash_)
                f = self._find_file(hash_, filename)
                if not f:
                    raise FuseOSError(errno.EIO)
                stream_url = f.get("stream_url", "")
                url = f"{FLASK_URL}{stream_url}"
                r = requests.get(url, headers=headers, timeout=30, stream=True)

            if r.status_code not in (200, 206):
                log.warning(f"Read {path} got {r.status_code}")
                raise FuseOSError(errno.EIO)

            return r.content

        except requests.RequestException as e:
            log.warning(f"Read error {path}: {e}")
            raise FuseOSError(errno.EIO)

    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


def unmount():
    try:
        subprocess.run(["fusermount", "-uz", MOUNTPOINT],
                       check=False, capture_output=True)
    except FileNotFoundError:
        subprocess.run(["umount", "-l", MOUNTPOINT],
                       check=False, capture_output=True)
    log.info(f"Unmounted {MOUNTPOINT}")


def main():
    os.makedirs(MOUNTPOINT, exist_ok=True)

    # Unmount any stale mount
    unmount()

    def shutdown(sig, frame):
        log.info("Shutting down...")
        unmount()
        sys.exit(0)

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)

    log.info(f"Mounting at {MOUNTPOINT} (Flask: {FLASK_URL})")
    FUSE(
        PremiumizeHostFS(),
        MOUNTPOINT,
        nothreads=False,
        foreground=True,
        allow_other=True,
        nonempty=True,
        ro=True,
    )


if __name__ == "__main__":
    main()

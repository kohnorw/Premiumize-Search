#!/bin/bash
#
# setup.sh — run once on the host before first deploy (or after a fresh install).
# Sets up the shared bind-mount that allows FUSE to propagate from the container
# to the host, and persists it across reboots via /etc/rc.local.
#
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Run as root: sudo ./setup.sh" >&2
    exit 1
fi

SHARE_ROOT="/docker/premiumize-web"

echo "==> Creating $SHARE_ROOT..."
mkdir -p "$SHARE_ROOT"

echo "==> Marking $SHARE_ROOT as rshared..."
mountpoint -q "$SHARE_ROOT" || mount --bind "$SHARE_ROOT" "$SHARE_ROOT"
mount --make-rshared "$SHARE_ROOT"

echo "==> Persisting across reboots via /etc/rc.local..."
RC=/etc/rc.local
MARKER="# premiumize-web rshared"

if ! grep -q "$MARKER" "$RC" 2>/dev/null; then
    # Create rc.local if it doesn't exist
    if [ ! -f "$RC" ]; then
        echo '#!/bin/bash' > "$RC"
        echo 'exit 0' >> "$RC"
    fi
    # Insert before the final exit 0 (or append)
    if grep -q '^exit 0' "$RC"; then
        sed -i "/^exit 0/i $MARKER\nmount --bind $SHARE_ROOT $SHARE_ROOT 2>/dev/null || true\nmount --make-rshared $SHARE_ROOT" "$RC"
    else
        printf '\n%s\nmount --bind %s %s 2>/dev/null || true\nmount --make-rshared %s\n' \
            "$MARKER" "$SHARE_ROOT" "$SHARE_ROOT" "$SHARE_ROOT" >> "$RC"
    fi
    chmod +x "$RC"
    echo "==> Added to $RC"
else
    echo "==> Already in $RC — skipping"
fi

echo ""
echo "==> Done. Now deploy the container:"
echo "      cd $SHARE_ROOT && docker compose up -d --build"

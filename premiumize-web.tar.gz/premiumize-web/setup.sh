#!/bin/bash
#
# setup.sh — run once on the host before first deploy.
# Creates a systemd unit that marks /docker/premiumize-web as rshared
# BEFORE Docker starts, so FUSE mounts propagate from container to host.
#
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Run as root: sudo ./setup.sh" >&2
    exit 1
fi

SHARE_ROOT="/docker/premiumize-web"
UNIT="premiumize-web-rshared.service"

echo "==> Creating $SHARE_ROOT..."
mkdir -p "$SHARE_ROOT"

echo "==> Applying rshared now..."
mountpoint -q "$SHARE_ROOT" || mount --bind "$SHARE_ROOT" "$SHARE_ROOT"
mount --make-rshared "$SHARE_ROOT"

echo "==> Installing systemd unit $UNIT..."
cat > /etc/systemd/system/$UNIT << UNIT
[Unit]
Description=Mark /docker/premiumize-web as rshared for FUSE propagation
DefaultDependencies=no
Before=docker.service
After=local-fs.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c 'mountpoint -q $SHARE_ROOT || mount --bind $SHARE_ROOT $SHARE_ROOT'
ExecStart=/bin/mount --make-rshared $SHARE_ROOT

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now $UNIT

echo ""
echo "==> Done. Verify:"
echo "      findmnt $SHARE_ROOT   # should show 'shared' in OPTIONS"
echo ""
echo "==> Now deploy:"
echo "      cd $SHARE_ROOT && docker compose up -d --build"

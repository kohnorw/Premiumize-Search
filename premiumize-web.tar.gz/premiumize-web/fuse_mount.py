"""
Premiumize virtual filesystem using FUSE.

Directory structure:
  /docker/premiumize-web/mnt/
    <torrent name>/
      <filename>.mkv   ← virtual file, reads via live HTTP range requests

CDN URLs are never stored — directdl is called fresh with a 30-min cache.

Read-ahead / block cache:
  Reads are satisfied from an in-memory LRU block cache.  When a block is
  missing the fetcher downloads a configurable chunk (default 8 MB) so the
  *next* sequential read is already waiting in RAM.  This eliminates the
  cold-start stall Plex experiences on first play, because the buffer primes
  far ahead of what the player has consumed.
"""

import errno
import logging
import os
import re
import stat
import threading
import time
from collections import OrderedDict

import requests

log = logging.getLogger(__name__)

# ── directdl cache timings ────────────────────────────────────────────────────
DIRECTDL_TTL   = 1800   # hard expiry of a cached directdl result (30 min)
REFRESH_MARGIN = 300    # start a background refresh once within 5 min of expiry

# ── HTTP retry parameters ─────────────────────────────────────────────────────
READ_TIMEOUT       = 30    # per-request timeout for a CDN range read (seconds)
READ_MAX_ATTEMPTS  = 4     # total tries for one read before giving up with EIO
READ_BACKOFF_BASE  = 0.4   # seconds; backoff grows base*1, base*2, ...
READ_BACKOFF_CAP   = 2.0   # never sleep longer than this between retries

# ── read-ahead / block cache (tunable via env vars) ───────────────────────────
# FUSE_READAHEAD_MB  – how many MB to pre-fetch per block (default 8 MB)
# FUSE_CACHE_BLOCKS  – max number of blocks kept in the LRU (default 16)
# FUSE_PREFETCH      – "true"/"false" to enable/disable (default true)
_RA_MB   = int(os.environ.get("FUSE_READAHEAD_MB",  "8"))
_CACHE_N = int(os.environ.get("FUSE_CACHE_BLOCKS", "16"))
_PREFETCH_ENABLED = os.environ.get("FUSE_PREFETCH", "true").lower() != "false"

BLOCK_SIZE = _RA_MB * 1024 * 1024   # bytes per cached block

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")


def _safe_name(name: str) -> str:
    """Sanitize torrent name for use as a filesystem directory name."""
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"


def build_name_map(transfer_manager) -> dict:
    """
    Single source of truth for {dir_name: hash} as exposed in the mount.

    Both the FUSE layer and the web-UI symlink builder use this so a symlink
    target always matches the directory the mount actually serves — including
    the duplicate-name suffix rule.
    """
    result = {}
    for h in transfer_manager.streamable_hashes():
        t = transfer_manager.get_transfer(h)
        name = _safe_name(t.get("name") or h) if t else h
        if name in result:
            name = f"{name}_{h[:8]}"
        result[name] = h
    return result


def dir_name_for_hash(transfer_manager, hash_: str):
    """Return the exact mount directory name for a hash, or None if not streamable."""
    for nm, h in build_name_map(transfer_manager).items():
        if h == hash_:
            return nm
    return None


# ── LRU block cache ───────────────────────────────────────────────────────────

class _BlockCache:
    """
    Thread-safe LRU cache keyed by (cdn_url, block_index).
    Each entry holds the raw bytes for that BLOCK_SIZE-aligned slice of the file.
    """

    def __init__(self, max_blocks: int):
        self._max   = max_blocks
        self._lock  = threading.Lock()
        self._store: OrderedDict = OrderedDict()   # key → bytes

    def get(self, key):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
            else:
                self._store[key] = data
                while len(self._store) > self._max:
                    self._store.popitem(last=False)

    def invalidate_url(self, cdn_url: str):
        """Drop all blocks for a given CDN URL (called when URL is refreshed)."""
        with self._lock:
            stale = [k for k in self._store if k[0] == cdn_url]
            for k in stale:
                del self._store[k]

    @property
    def size(self):
        with self._lock:
            return len(self._store)


_block_cache = _BlockCache(_CACHE_N)


class PremiumizeFS(Operations):
    def __init__(self, transfer_manager):
        self._tm    = transfer_manager
        self._now   = time.time()
        self._lock  = threading.Lock()
        # Cache: hash → (files: list[dict], expires_at: float)
        self._cache: dict[str, tuple[list, float]] = {}
        # Hashes with an in-flight background refresh
        self._refreshing: set = set()
        # Tracks blocks currently being fetched to avoid duplicate downloads
        self._fetching: set = set()
        self._fetch_lock = threading.Lock()

    # ── name ↔ hash mapping ───────────────────────────────────────────────────

    def _get_name_map(self) -> dict:
        return build_name_map(self._tm)

    def _name_to_hash(self, dirname: str):
        return self._get_name_map().get(dirname)

    # ── directdl cache ────────────────────────────────────────────────────────

    def _get_files(self, hash_: str, force: bool = False) -> list:
        now = time.time()
        if not force:
            with self._lock:
                cached = self._cache.get(hash_)
            if cached:
                files, expires_at = cached
                if now < expires_at - REFRESH_MARGIN:
                    return files
                if now < expires_at:
                    self._spawn_refresh(hash_)
                    return files

        files = self._tm.get_files(hash_, force=force)
        if files:
            with self._lock:
                self._cache[hash_] = (files, now + DIRECTDL_TTL)
        return files

    def _spawn_refresh(self, hash_: str):
        with self._lock:
            if hash_ in self._refreshing:
                return
            self._refreshing.add(hash_)

        def _do():
            try:
                files = self._tm.get_files(hash_, force=True)
                if files:
                    with self._lock:
                        self._cache[hash_] = (files, time.time() + DIRECTDL_TTL)
            except Exception:
                log.warning(f"[{hash_[:8]}] background refresh failed", exc_info=True)
            finally:
                with self._lock:
                    self._refreshing.discard(hash_)

        threading.Thread(target=_do, daemon=True).start()

    def _invalidate(self, hash_: str):
        with self._lock:
            self._cache.pop(hash_, None)

    # ── path helpers ──────────────────────────────────────────────────────────

    def _parse_path(self, path):
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None, None, None
        dirname  = parts[0]
        filename = "/".join(parts[1:]) if len(parts) > 1 else None
        hash_    = self._name_to_hash(dirname)
        return dirname, filename, hash_

    def _find_file(self, hash_: str, filename: str, force: bool = False):
        for f in self._get_files(hash_, force=force):
            f_name = f.get("name", "")
            f_base = os.path.basename(f.get("path", "") or f_name)
            if f_name == filename or f_base == filename:
                return f
        return None

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        base = {
            "st_uid":   os.getuid(),
            "st_gid":   os.getgid(),
            "st_atime": self._now,
            "st_mtime": self._now,
            "st_ctime": self._now,
            "st_nlink": 2,
        }

        if path == "/":
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        dirname, filename, hash_ = self._parse_path(path)

        if not filename:
            if hash_ is not None:
                return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            raise FuseOSError(errno.ENOENT)

        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        return {
            **base,
            "st_mode":  stat.S_IFREG | 0o444,
            "st_nlink": 1,
            "st_size":  int(f.get("size", 0)),
        }

    def readdir(self, path, fh):
        yield "."
        yield ".."

        if path == "/":
            for name in self._get_name_map().keys():
                yield name
            return

        dirname, _, hash_ = self._parse_path(path)
        if hash_:
            for f in self._get_files(hash_):
                raw  = f.get("name", "") or f.get("path", "")
                name = os.path.basename(raw) if raw else raw
                if name:
                    yield name

    def open(self, path, flags):
        dirname, filename, hash_ = self._parse_path(path)
        if not filename or hash_ is None or not self._find_file(hash_, filename):
            raise FuseOSError(errno.ENOENT)
        # Warm the first block in the background so it's ready when Plex reads
        if _PREFETCH_ENABLED:
            f = self._find_file(hash_, filename)
            if f and f.get("link"):
                self._prefetch_block(f["link"], 0, int(f.get("size", 0)))
        return 0

    # ── block-cache read ──────────────────────────────────────────────────────

    def _block_key(self, cdn_url: str, block_idx: int):
        return (cdn_url, block_idx)

    def _fetch_block(self, cdn_url: str, block_idx: int,
                     file_size: int, force_url: str = None) -> bytes | None:
        """
        Download the block at block_idx from cdn_url (or force_url if provided).
        Returns the raw bytes or None on failure.
        """
        url     = force_url or cdn_url
        start   = block_idx * BLOCK_SIZE
        end     = min(start + BLOCK_SIZE - 1, file_size - 1) if file_size else start + BLOCK_SIZE - 1
        headers = {"Range": f"bytes={start}-{end}"}

        last_err  = None
        refreshed = False

        for attempt in range(READ_MAX_ATTEMPTS):
            try:
                r = requests.get(url, headers=headers,
                                 timeout=READ_TIMEOUT, stream=True)
            except requests.RequestException as e:
                last_err = e
                log.warning(f"Block fetch network error (try {attempt+1}): {e}")
                self._read_backoff(attempt)
                continue

            try:
                status = r.status_code
                if status in (200, 206):
                    data = r.content
                    _block_cache.put(self._block_key(cdn_url, block_idx), data)
                    return data

                if status in (403, 410) and not refreshed:
                    log.info(f"CDN URL expired (block {block_idx}) — will use refreshed URL next")
                    refreshed = True
                    last_err  = f"status {status} (expired)"
                    break

                if status in (429, 500, 502, 503, 504):
                    last_err = f"status {status}"
                    self._read_backoff(attempt)
                    continue

                last_err = f"status {status}"
                break
            finally:
                r.close()

        log.warning(f"Block fetch failed after {READ_MAX_ATTEMPTS} tries: {last_err}")
        return None

    def _prefetch_block(self, cdn_url: str, block_idx: int, file_size: int):
        """Fetch a block in the background if not already cached/fetching."""
        key = self._block_key(cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with self._fetch_lock:
            if key in self._fetching:
                return
            self._fetching.add(key)

        def _do():
            try:
                self._fetch_block(cdn_url, block_idx, file_size)
            finally:
                with self._fetch_lock:
                    self._fetching.discard(key)

        threading.Thread(target=_do, daemon=True).start()

    def read(self, path, size, offset, fh):
        dirname, filename, hash_ = self._parse_path(path)
        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        cdn_url   = f.get("link", "")
        file_size = int(f.get("size", 0))
        if not cdn_url:
            raise FuseOSError(errno.EIO)

        block_idx = offset // BLOCK_SIZE

        # Try to serve from cache first
        cached = _block_cache.get(self._block_key(cdn_url, block_idx))

        if cached is None:
            # Cache miss — fetch synchronously
            cached = self._fetch_block(cdn_url, block_idx, file_size)

            # If URL might be expired, try a one-shot refresh
            if cached is None:
                log.info(f"Block miss for {dirname}/{filename} block {block_idx} — refreshing URL")
                self._invalidate(hash_)
                f2 = self._find_file(hash_, filename, force=True)
                if f2:
                    new_url = f2.get("link", "")
                    if new_url and new_url != cdn_url:
                        _block_cache.invalidate_url(cdn_url)
                        cdn_url = new_url
                        cached  = self._fetch_block(cdn_url, block_idx, file_size,
                                                    force_url=new_url)

            if cached is None:
                log.warning(f"FUSE read failed for {path} block {block_idx}")
                raise FuseOSError(errno.EIO)

        # Pre-fetch the next block(s) in the background
        if _PREFETCH_ENABLED and file_size:
            next_blocks = 2  # pre-fetch 2 blocks ahead (~16 MB default)
            for ahead in range(1, next_blocks + 1):
                nb = block_idx + ahead
                nb_start = nb * BLOCK_SIZE
                if nb_start < file_size:
                    self._prefetch_block(cdn_url, nb, file_size)

        # Slice the block to satisfy the exact requested range
        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        return cached[slice_offset: slice_offset + size]

    @staticmethod
    def _read_backoff(attempt: int):
        time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))

    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


def mount(mountpoint: str, transfer_manager, foreground=True):
    if not FUSE_AVAILABLE:
        log.error("fusepy not installed — cannot mount")
        return
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"Mounting Premiumize FS at {mountpoint} "
             f"(block={BLOCK_SIZE//1024//1024}MB, cache={_CACHE_N} blocks, "
             f"prefetch={'on' if _PREFETCH_ENABLED else 'off'})")
    FUSE(
        PremiumizeFS(transfer_manager),
        mountpoint,
        nothreads=False,
        foreground=foreground,
        allow_other=True,
        nonempty=True,
        ro=True,
    )

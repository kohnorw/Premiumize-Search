"""
Premiumize virtual filesystem using FUSE.

Directory structure:
  /docker/premiumize-web/mnt/
    <torrent name>/
      <filename>.mkv   ← virtual file, reads via live HTTP range requests

CDN URLs are never stored — directdl is called fresh with a 30-min cache.

Performance:
  - Name map (hash→dirname) cached with a short TTL so DB is not hit per stat
  - Stat results cached so repeated getattr calls return instantly
  - Block read-ahead: fetches BLOCK_SIZE bytes per CDN request, cached in RAM
    and optionally on disk, with background pre-fetch of upcoming blocks
  - FUSE kernel attr/entry timeouts set so the kernel caches stat results itself
"""

import errno
import hashlib
import logging
import os
import re
import stat
import threading
import time
from collections import OrderedDict

import requests

log = logging.getLogger(__name__)

# ── directdl cache timings ────────────────────────────────────────────────────
DIRECTDL_TTL   = 172800  # 48 hours — CDN URLs are long-lived; avoid unnecessary directdl calls
REFRESH_MARGIN = 3600    # start background refresh only 1 hour before expiry

# ── HTTP retry parameters ─────────────────────────────────────────────────────
READ_TIMEOUT       = int(os.environ.get("FUSE_READ_TIMEOUT", "30"))  # configurable, default 30s
READ_MAX_ATTEMPTS  = 5     # more retries for 4K files on slow CDN
READ_BACKOFF_BASE  = 0.5
READ_BACKOFF_CAP   = 4.0

# ── read-ahead / block cache (tunable via env vars) ───────────────────────────
# FUSE_READAHEAD_MB  – MB to pre-fetch per block (default 8)
# FUSE_CACHE_BLOCKS  – max blocks in LRU (default 16)
# FUSE_PREFETCH      – enable background pre-fetch (default true)
# FUSE_CACHE_DIR     – directory for persistent on-disk block cache
_RA_MB            = int(os.environ.get("FUSE_READAHEAD_MB",  "32"))   # was 8
_CACHE_N          = int(os.environ.get("FUSE_CACHE_BLOCKS", "64"))   # was 16 — 64×32MB = 2GB
_PREFETCH_ENABLED = os.environ.get("FUSE_PREFETCH", "true").lower() != "false"
_CACHE_DIR        = os.environ.get("FUSE_CACHE_DIR", "/docker/premiumize-web/cache").strip()
_VIDEO_ONLY       = os.environ.get("FUSE_VIDEO_ONLY", "true").lower() != "false"

BLOCK_SIZE = _RA_MB * 1024 * 1024

# How many blocks to pre-fetch ahead of current read position.
# Calculated from read_ahead size / block size, minimum 2, maximum 32.
def _prefetch_blocks() -> int:
    read_ahead = _parse_size_simple(os.environ.get("FUSE_READ_AHEAD", "500MB"), 500 * 1024 * 1024)
    return max(2, min(32, read_ahead // BLOCK_SIZE))

def _parse_size_simple(val: str, default: int) -> int:
    if not val:
        return default
    val = val.strip().upper().replace(' ', '')
    units = {'TB': 1024**4, 'GB': 1024**3, 'MB': 1024**2, 'KB': 1024, 'B': 1}
    for suffix, mult in sorted(units.items(), key=lambda x: -len(x[0])):
        if val.endswith(suffix):
            try:
                return int(float(val[:-len(suffix)]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

_READ_AHEAD_BYTES = _parse_size_simple(os.environ.get("FUSE_READ_AHEAD", "500MB"), 500 * 1024 * 1024)

VIDEO_EXTENSIONS = {
    ".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
    ".wmv", ".flv", ".webm", ".m2ts", ".mpg", ".mpeg",
}

EXTRA_PATTERNS = re.compile(
    r'(?i)(^|\b)(sample|trailer|featurette|behind.the.scenes|'
    r'deleted.scene|interview|short|scene|extra)s?(\b|$)'
)

def _is_video(filename: str) -> bool:
    return os.path.splitext(filename)[1].lower() in VIDEO_EXTENSIONS

def _is_extra(filename: str) -> bool:
    """Return True if the filename looks like a sample or extra."""
    name = os.path.splitext(filename)[0]
    return bool(EXTRA_PATTERNS.search(name))

def _include_file(filename: str) -> bool:
    """Return True if this file should be visible in the FUSE mount."""
    if not _VIDEO_ONLY:
        return True
    return _is_video(filename) and not _is_extra(filename)

# ── in-memory TTLs for hot-path caches ───────────────────────────────────────
NAME_MAP_TTL  = 60    # seconds to cache the hash→dirname map (avoids DB hit per stat)
STAT_CACHE_TTL = 300  # 5 min — stat rarely changes, longer = fewer kernel→FUSE round trips
# FUSE kernel-side timeouts — kept high so Plex reuses its dentry/attr cache.
# Plex rescans via its own scheduler, not via kernel cache expiry.
KERNEL_ATTR_TIMEOUT  = 300.0  # 5 min — Plex won't re-stat every file on each browse
KERNEL_ENTRY_TIMEOUT = 300.0  # 5 min — directory entries stay valid in kernel dentry cache
# Parallel workers for pre-warming the directdl file cache on subdir listing
DIRECTDL_WORKERS = int(os.environ.get("FUSE_DIRECTDL_WORKERS", "8"))

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")


def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"


import re as _re

from name_match import _SERIES_RE, _4K_RE

# Whether 4K folders are enabled — toggled via Settings UI
_4K_FOLDERS_ENABLED = False

# Running FUSE filesystem instance — set when mount starts, used for cache invalidation
_pfs = None

# ── Classification overrides shared ref ──────────────────────────────────────
# app.py pushes the live overrides dict here so FUSE threads never need to
# import from app (which re-executes app.py and hits signal.signal on non-main threads).
_overrides: dict = {}
_re_nonalnum = re.compile(r'[^a-z0-9]')

def _override_key(name: str) -> str:
    return _re_nonalnum.sub('', (name or '').lower())

def _category_subdir(name: str, category: str = "", kind: str = "") -> str:
    # Tier 1: manual override (user-set in UI) — read from module-level dict, no import
    key = _override_key(name)
    if key in _overrides:
        is_series = _overrides[key]["kind"] == "series"
        if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
            return "series4k" if is_series else "movies4k"
        return "series" if is_series else "movies"

    # Tier 2: stored kind from DB (classified from actual file paths — ground truth)
    if kind in ("series", "movie"):
        is_series = kind == "series"
        if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
            return "series4k" if is_series else "movies4k"
        return "series" if is_series else "movies"

    # Tier 3: name pattern matching (fallback for transfers with no files yet)
    is_series = bool(_SERIES_RE.search(name or ""))
    cat = (category or "").lower()
    if not is_series:
        is_series = any(k in cat for k in ("sonarr", "tv", "series", "show"))

    if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
        return "series4k" if is_series else "movies4k"
    return "series" if is_series else "movies"


def build_name_map(transfer_manager) -> dict:
    """
    Returns {subdir/safe_name: hash} for all streamable transfers.
    e.g. {'movies/The.Batman.2022': 'abc123', 'series/Breaking.Bad.S01E01': 'def456'}
    """
    result = {}
    try:
        from name_match import classify_from_files as _clf
        _clf_available = True
    except Exception:
        _clf_available = False

    try:
        hashes = transfer_manager.streamable_hashes()
    except Exception as e:
        log.warning(f"build_name_map: streamable_hashes failed: {e}")
        return result

    for h in hashes:
        try:
            t = transfer_manager.get_transfer(h)
            if not t:
                continue
            stored_kind = t.get("kind", "")

            # If kind not yet stored, try to classify from FUSE file cache (no API call)
            if not stored_kind and _clf_available and _pfs is not None:
                cached = _pfs._file_cache.get(h)
                if cached:
                    files, _ = cached
                    try:
                        inferred = _clf(files)
                        if inferred:
                            stored_kind = inferred
                            try:
                                transfer_manager._set(h, kind=inferred)
                            except Exception:
                                pass
                    except Exception:
                        pass

            base   = _safe_name(t.get("name") or h)
            subdir = _category_subdir(t.get("name") or "", t.get("category", ""),
                                      kind=stored_kind)
            key    = f"{subdir}/{base}"
            if key in result:
                key = f"{subdir}/{base}_{h[:8]}"
            result[key] = h
        except Exception as e:
            log.warning(f"build_name_map: error for hash {h[:8]}: {e}")
            continue

    return result


def dir_name_for_hash(transfer_manager, hash_: str):
    for nm, h in build_name_map(transfer_manager).items():
        if h == hash_:
            return nm
    return None


# ── disk block path helper ────────────────────────────────────────────────────

def _disk_block_path(cache_dir: str, cdn_url: str, block_idx: int) -> str:
    url_hash = hashlib.sha256(cdn_url.encode()).hexdigest()[:16]
    return os.path.join(cache_dir, url_hash, f"{block_idx}.bin")


# ── LRU block cache ───────────────────────────────────────────────────────────

class _BlockCache:
    def __init__(self, max_blocks: int, cache_dir: str = ""):
        self._max       = max_blocks
        self._cache_dir = cache_dir
        self._lock      = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        if self._cache_dir:
            cdn_url, block_idx = key
            path = _disk_block_path(self._cache_dir, cdn_url, block_idx)
            try:
                with open(path, "rb") as f:
                    data = f.read()
                self.put(key, data)
                return data
            except (FileNotFoundError, OSError):
                pass
        return None

    def put(self, key, data: bytes):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
            else:
                self._store[key] = data
                while len(self._store) > self._max:
                    self._store.popitem(last=False)
        if self._cache_dir:
            cdn_url, block_idx = key
            path = _disk_block_path(self._cache_dir, cdn_url, block_idx)
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                tmp = path + ".tmp"
                with open(tmp, "wb") as f:
                    f.write(data)
                os.replace(tmp, path)
            except OSError as e:
                log.debug(f"Disk cache write failed: {e}")

    def invalidate_url(self, cdn_url: str):
        with self._lock:
            stale = [k for k in self._store if k[0] == cdn_url]
            for k in stale:
                del self._store[k]
        if self._cache_dir:
            url_hash = hashlib.sha256(cdn_url.encode()).hexdigest()[:16]
            url_dir  = os.path.join(self._cache_dir, url_hash)
            try:
                import shutil
                shutil.rmtree(url_dir, ignore_errors=True)
            except OSError:
                pass

    @property
    def size(self):
        with self._lock:
            return len(self._store)


_block_cache = _BlockCache(_CACHE_N, _CACHE_DIR)

class PremiumizeFS(Operations):
    def __init__(self, transfer_manager):
        self._tm   = transfer_manager
        self._now  = time.time()
        self._lock = threading.Lock()

        # directdl cache: hash → (files, expires_at)
        self._file_cache: dict[str, tuple[list, float]] = {}
        self._refreshing: set = set()

        # block fetch dedup
        self._fetching:    set = set()
        self._fetch_lock   = threading.Lock()

        # ── file handle counter ───────────────────────────────────────────────
        # open() allocates a unique integer handle returned to the kernel.
        # release() is called when the file is closed (no data needed beyond fh).
        self._fh_counter: int = 0
        self._fh_lock = threading.Lock()

        # ── hot-path caches ───────────────────────────────────────────────────
        # Name map cache — avoids a DB query on every getattr/readdir call
        self._name_map:         dict  = {}
        self._name_map_expires: float = 0.0
        self._name_map_lock           = threading.Lock()

        # Stat cache — (stat_dict, expires_at) keyed by path
        self._stat_cache: dict[str, tuple[dict, float]] = {}
        self._stat_lock                                  = threading.Lock()

    # ── name map (cached) ─────────────────────────────────────────────────────

    def _get_name_map(self) -> dict:
        now = time.time()
        with self._name_map_lock:
            if now < self._name_map_expires:
                return self._name_map
        nm = build_name_map(self._tm)
        with self._name_map_lock:
            self._name_map         = nm
            self._name_map_expires = now + NAME_MAP_TTL
        return nm

    def _invalidate_name_map(self):
        with self._name_map_lock:
            self._name_map_expires = 0.0

    # ── stat cache ────────────────────────────────────────────────────────────

    def _stat_get(self, path: str):
        now = time.time()
        with self._stat_lock:
            entry = self._stat_cache.get(path)
            if entry and now < entry[1]:
                return entry[0]
        return None

    def _stat_put(self, path: str, st: dict):
        expires = time.time() + STAT_CACHE_TTL
        with self._stat_lock:
            self._stat_cache[path] = (st, expires)

    def _stat_invalidate(self, path: str):
        with self._stat_lock:
            self._stat_cache.pop(path, None)

    def _stat_invalidate_all(self):
        """Clear the entire stat cache — called after Import Completed so FUSE
        re-serves fresh stats on the next Plex poll.  Because mtime and size are
        unchanged, Plex will not re-analyse any file; it will simply confirm the
        stat matches what it already recorded and move on."""
        with self._stat_lock:
            self._stat_cache.clear()

    # ── directdl cache ────────────────────────────────────────────────────────

    def _get_files(self, hash_: str, force: bool = False) -> list:
        now = time.time()
        if not force:
            with self._lock:
                cached = self._file_cache.get(hash_)
            if cached:
                files, expires_at = cached
                if now < expires_at - REFRESH_MARGIN:
                    return files
                if now < expires_at:
                    self._spawn_refresh(hash_)
                    return files
        files = self._tm.get_files(hash_, force=force)
        if files:
            with self._lock:
                self._file_cache[hash_] = (files, now + DIRECTDL_TTL)
        return files

    def _spawn_refresh(self, hash_: str):
        with self._lock:
            if hash_ in self._refreshing:
                return
            self._refreshing.add(hash_)

        def _do():
            try:
                files = self._tm.get_files(hash_, force=True)
                if files:
                    with self._lock:
                        self._file_cache[hash_] = (files, time.time() + DIRECTDL_TTL)
            except Exception:
                log.warning(f"[{hash_[:8]}] background refresh failed", exc_info=True)
            finally:
                with self._lock:
                    self._refreshing.discard(hash_)

        threading.Thread(target=_do, daemon=True).start()

    def _invalidate_files(self, hash_: str):
        with self._lock:
            self._file_cache.pop(hash_, None)

    def _prewarm_parallel(self, hashes: list, block: bool = False):
        """Fetch directdl file lists for multiple hashes in parallel.

        If block=True, waits for all fetches to complete (used at mount time).
        If block=False, fires them in the background (used during subdir listing).
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _fetch_one(h):
            if h in self._file_cache:
                files, exp = self._file_cache[h]
                if time.time() < exp:
                    return  # already warm
            files = self._tm.get_files(h)
            if files:
                with self._lock:
                    self._file_cache[h] = (files, time.time() + DIRECTDL_TTL)

        pool = ThreadPoolExecutor(max_workers=DIRECTDL_WORKERS,
                                  thread_name_prefix="fuse-prewarm")
        futures = [pool.submit(_fetch_one, h) for h in hashes]
        pool.shutdown(wait=block)
        if not block:
            # Log errors in the background without blocking readdir
            def _log_errors():
                for f in as_completed(futures):
                    try:
                        f.result()
                    except Exception as e:
                        log.debug(f"[prewarm] fetch error: {e}")
            threading.Thread(target=_log_errors, daemon=True).start()

    # ── path helpers ──────────────────────────────────────────────────────────

    def _parse_path(self, path):
        """
        Parse a path into (subdir, dirname, filename, hash_).
        Paths are: /                       → root
                   /movies                 → subdir listing
                   /series                 → subdir listing
                   /movies/<name>          → torrent dir
                   /movies/<name>/<file>   → file
        """
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None, None, None, None
        if parts[0] in ("movies", "series", "movies4k", "series4k"):
            subdir  = parts[0]
            dirname = parts[1] if len(parts) > 1 else None
            filename = "/".join(parts[2:]) if len(parts) > 2 else None
        else:
            # Legacy flat path — treat as movies
            subdir   = None
            dirname  = parts[0]
            filename = "/".join(parts[1:]) if len(parts) > 1 else None

        if dirname is None:
            return subdir, None, None, None

        # Look up hash via subdir/dirname key
        key   = f"{subdir}/{dirname}" if subdir else dirname
        hash_ = self._get_name_map().get(key)
        return subdir, dirname, filename, hash_

    def _find_file(self, hash_: str, filename: str, force: bool = False):
        for f in self._get_files(hash_, force=force):
            f_name = f.get("name", "")
            f_base = os.path.basename(f.get("path", "") or f_name)
            if f_name == filename or f_base == filename:
                return f
        return None

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        try:
            return self._getattr_safe(path)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"getattr({path}): unexpected error: {e}", exc_info=True)
            raise FuseOSError(errno.ENOENT)

    def _getattr_safe(self, path):
        cached_st = self._stat_get(path)
        if cached_st is not None:
            return cached_st

        base = {
            "st_uid":   os.getuid(),
            "st_gid":   os.getgid(),
            "st_atime": self._now,
            "st_mtime": self._now,
            "st_ctime": self._now,
            "st_nlink": 2,
        }

        # Root
        if path == "/":
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st)
            return st

        # /movies, /series, /movies4k, /series4k
        _valid = {"/movies", "/series"}
        if _4K_FOLDERS_ENABLED:
            _valid |= {"/movies4k", "/series4k"}
        if path in _valid:
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st)
            return st

        subdir, dirname, filename, hash_ = self._parse_path(path)

        # /movies/<name> or /series/<name>
        if not filename:
            if hash_ is not None:
                st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
                self._stat_put(path, st)
                return st
            raise FuseOSError(errno.ENOENT)

        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        # .nfo companion file — served from memory, zero CDN hits
        if filename.lower().endswith(".nfo"):
            video_name = os.path.splitext(filename)[0]
            for f in self._get_files(hash_):
                raw  = f.get("name", "") or f.get("path", "")
                name = os.path.basename(raw) if raw else raw
                if os.path.splitext(name)[0] == video_name and _include_file(name):
                    nfo = self._nfo_content(hash_, name)
                    nfo_size = len(nfo) if nfo else 256
                    st = {**base, "st_mode": stat.S_IFREG | 0o444,
                          "st_nlink": 1, "st_size": nfo_size}
                    self._stat_put(path, st)
                    return st
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        # Reject non-video/extra files when video_only is enabled
        if not _include_file(filename):
            raise FuseOSError(errno.ENOENT)

        file_size = int(float(f.get("size", 0) or 0))

        # Don't expose the file until we have a confirmed size — this prevents
        # Plex from scanning a zero-size file and caching a bogus duration
        if file_size == 0:
            raise FuseOSError(errno.ENOENT)

        st = {
            **base,
            "st_mode":  stat.S_IFREG | 0o444,
            "st_nlink": 1,
            "st_size":  file_size,
        }
        self._stat_put(path, st)
        return st

    def readdir(self, path, fh):
        try:
            return self._readdir_safe(path)
        except Exception as e:
            log.error(f"readdir({path}): {e}", exc_info=True)
            return [".", ".."]

    def _readdir_safe(self, path):
        entries = [".", ".."]

        # Root — yield subdirs
        if path == "/":
            entries += ["movies", "series"]
            if _4K_FOLDERS_ENABLED:
                entries += ["movies4k", "series4k"]
            return entries

        # Subdir listing — /movies or /series
        valid_subdirs = ["/movies", "/series"]
        if _4K_FOLDERS_ENABLED:
            valid_subdirs += ["/movies4k", "/series4k"]
        if path in valid_subdirs:
            subdir = path.lstrip("/")
            nm     = self._get_name_map()
            names  = []
            hashes = []
            for key in nm.keys():
                if key.startswith(subdir + "/"):
                    names.append(key[len(subdir) + 1:])
                    hashes.append(nm[key])
            # Pre-warm file caches in parallel
            uncached = [h for h in hashes if h not in self._file_cache
                        or time.time() >= self._file_cache[h][1]]
            if uncached:
                self._prewarm_parallel(uncached)
            entries += names
            return entries

        # /movies/<name> or /series/<name> — yield video files + companion NFOs
        subdir, dirname, _, hash_ = self._parse_path(path)
        if hash_:
            try:
                files = self._get_files(hash_)
            except Exception:
                files = []
            for f in files:
                raw  = f.get("name", "") or f.get("path", "")
                name = os.path.basename(raw) if raw else raw
                if not name:
                    continue
                try:
                    size = int(float(f.get("size", 0) or 0))
                except (ValueError, TypeError):
                    size = 0
                if _include_file(name) and size > 0:
                    entries.append(name)
                    # Yield companion NFO — getattr/read will handle it from memory
                    entries.append(os.path.splitext(name)[0] + ".nfo")

        return entries

    def _nfo_content(self, hash_: str, filename: str) -> bytes | None:
        """Generate NFO content — TMDB lookup with filename-parse fallback."""
        try:
            import tmdb as _tmdb
            return _tmdb.nfo_for_file(filename).encode("utf-8")
        except Exception:
            pass
        # Fallback: filename-only NFO
        try:
            from qbt_mock import _parse_stub_meta, _make_nfo_content
            meta = _parse_stub_meta(filename)
            return _make_nfo_content(meta).encode("utf-8")
        except Exception:
            return None

    def open(self, path, flags):
        try:
            subdir, dirname, filename, hash_ = self._parse_path(path)
            if not filename or hash_ is None:
                raise FuseOSError(errno.ENOENT)
            # NFOs are virtual — always openable if they stat OK
            if filename.lower().endswith(".nfo"):
                return 0
            f = self._find_file(hash_, filename)
            if not f or int(float(f.get("size", 0) or 0)) == 0:
                raise FuseOSError(errno.ENOENT)
            # Allocate a unique file handle
            with self._fh_lock:
                self._fh_counter += 1
                fh = self._fh_counter
            return fh
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"open({path}): {e}")
            raise FuseOSError(errno.ENOENT)

    def release(self, path, fh):
        return 0

    # ── block-cache read ──────────────────────────────────────────────────────

    def _block_key(self, cdn_url: str, block_idx: int):
        return (cdn_url, block_idx)

    def _fetch_block(self, cdn_url: str, block_idx: int,
                     file_size: int, force_url: str = None) -> bytes | None:
        url     = force_url or cdn_url
        start   = block_idx * BLOCK_SIZE
        end     = min(start + BLOCK_SIZE - 1, file_size - 1) if file_size else start + BLOCK_SIZE - 1
        headers = {"Range": f"bytes={start}-{end}"}

        last_err = None

        for attempt in range(READ_MAX_ATTEMPTS):
            try:
                r = requests.get(url, headers=headers,
                                 timeout=READ_TIMEOUT, stream=True)
            except requests.RequestException as e:
                last_err = e
                log.warning(f"Block fetch network error (try {attempt+1}): {e}")
                self._read_backoff(attempt)
                continue

            try:
                status = r.status_code
                if status in (200, 206):
                    data = r.content
                    _block_cache.put(self._block_key(cdn_url, block_idx), data)
                    return data
                if status in (403, 410):
                    # CDN URL expired — return None immediately so caller refreshes
                    log.info(f"CDN URL expired (block {block_idx}, status {status})")
                    return None
                if status in (429, 500, 502, 503, 504):
                    last_err = f"status {status}"
                    self._read_backoff(attempt)
                    continue
                last_err = f"status {status}"
                break
            finally:
                r.close()

        log.warning(f"Block fetch failed after {READ_MAX_ATTEMPTS} tries: {last_err}")
        return None

    def _refresh_cdn_url(self, hash_: str, filename: str, old_url: str) -> str | None:
        """Refresh a single expired CDN URL via the transfer manager.
        Writes the new URL back to the DB so it persists across restarts.
        Only called when an actual playback read returns 403/410 — never
        called proactively, so it never burns Fair Use points unnecessarily.
        """
        new_url = self._tm.refresh_cdn_url(hash_, filename)
        if new_url and new_url != old_url:
            # Invalidate stale block cache entries for the old URL
            _block_cache.invalidate_url(old_url)
            # Also refresh in-memory FUSE file cache
            self._invalidate_files(hash_)
            log.info(f"CDN URL refreshed for {filename}")
            return new_url
        return old_url

    def _prefetch_block(self, cdn_url: str, block_idx: int, file_size: int):
        key = self._block_key(cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with self._fetch_lock:
            if key in self._fetching:
                return
            self._fetching.add(key)

        def _do():
            try:
                self._fetch_block(cdn_url, block_idx, file_size)
            finally:
                with self._fetch_lock:
                    self._fetching.discard(key)

        threading.Thread(target=_do, daemon=True).start()

    def read(self, path, size, offset, fh):
        try:
            return self._read_safe(path, size, offset, fh)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"read({path}): unexpected error: {e}", exc_info=True)
            raise FuseOSError(errno.EIO)

    def _read_safe(self, path, size, offset, fh=0):
        subdir, dirname, filename, hash_ = self._parse_path(path)
        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        # NFO files are served entirely from memory — zero CDN / API hits
        if filename.lower().endswith(".nfo"):
            video_name = os.path.splitext(filename)[0]
            for f in self._get_files(hash_):
                raw  = f.get("name", "") or f.get("path", "")
                name = os.path.basename(raw) if raw else raw
                if os.path.splitext(name)[0] == video_name and _include_file(name):
                    nfo = self._nfo_content(hash_, name)
                    if nfo:
                        return nfo[offset:offset + size]
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        cdn_url   = f.get("link", "")
        file_size = int(float(f.get("size", 0) or 0))
        if not cdn_url:
            raise FuseOSError(errno.EIO)

        block_idx = offset // BLOCK_SIZE
        cached    = _block_cache.get(self._block_key(cdn_url, block_idx))

        if cached is None:
            cached = self._fetch_block(cdn_url, block_idx, file_size)

            if cached is None:
                # URL expired — refresh and retry
                new_url = self._refresh_cdn_url(hash_, filename, cdn_url)
                if new_url and new_url != cdn_url:
                    cdn_url = new_url
                    cached  = self._fetch_block(cdn_url, block_idx, file_size)

            if cached is None:
                log.warning(f"FUSE read failed for {path} block {block_idx}")
                raise FuseOSError(errno.EIO)

        # Pre-fetch ahead based on read_ahead size setting
        if _PREFETCH_ENABLED and file_size:
            ahead_blocks = max(2, min(32, _READ_AHEAD_BYTES // BLOCK_SIZE))
            for ahead in range(1, ahead_blocks + 1):
                nb = block_idx + ahead
                if nb * BLOCK_SIZE < file_size:
                    self._prefetch_block(cdn_url, nb, file_size)

        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        chunk = cached[slice_offset: slice_offset + size]

        # Handle reads that cross a block boundary — fetch the next block and
        # append the needed bytes. Without this, Plex gets a short read at every
        # block boundary which it reports as "unexpected failure before end of file".
        bytes_remaining = size - len(chunk)
        next_block_idx  = block_idx + 1
        while bytes_remaining > 0 and next_block_idx * BLOCK_SIZE < file_size:
            next_cached = _block_cache.get(self._block_key(cdn_url, next_block_idx))
            if next_cached is None:
                next_cached = self._fetch_block(cdn_url, next_block_idx, file_size)
                if next_cached is None:
                    break  # return what we have; do not raise so Plex can retry
            chunk += next_cached[:bytes_remaining]
            bytes_remaining -= len(next_cached[:bytes_remaining])
            next_block_idx  += 1

        return chunk

    @staticmethod
    def _read_backoff(attempt: int):
        time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))

    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


def mount(mountpoint: str, transfer_manager, foreground=True):
    if not FUSE_AVAILABLE:
        log.error("fusepy not installed — cannot mount")
        return
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"Mounting Premiumize FS at {mountpoint} "
             f"(block={BLOCK_SIZE//1024//1024}MB, cache={_CACHE_N} blocks, "
             f"prefetch={'on' if _PREFETCH_ENABLED else 'off'})")
    global _pfs
    _pfs = PremiumizeFS(transfer_manager)

    # Pre-warm the file cache for all streamable transfers in parallel.
    # This means the first Plex scan after a restart hits memory, not the network.
    try:
        hashes = transfer_manager.streamable_hashes()
        if hashes:
            log.info(f"[FUSE] Pre-warming directdl cache for {len(hashes)} transfers…")
            _pfs._prewarm_parallel(hashes, block=False)
    except Exception as e:
        log.warning(f"[FUSE] Startup pre-warm failed: {e}")
    try:
        FUSE(
            _pfs,
            mountpoint,
            nothreads=False,      # multi-threaded — required for parallel 4K reads from Plex
            foreground=foreground,
            allow_other=True,
            nonempty=True,
            ro=True,
            attr_timeout=KERNEL_ATTR_TIMEOUT,
            entry_timeout=KERNEL_ENTRY_TIMEOUT,
            negative_timeout=10.0,
        )
    except Exception as e:
        log.error(f"FUSE mount exited with exception: {e}", exc_info=True)
        raise
    log.info("FUSE mount exited cleanly")

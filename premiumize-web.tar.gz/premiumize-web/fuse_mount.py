"""
Premiumize virtual filesystem using FUSE.

Directory structure:
  /docker/premiumize-web/mnt/
    <torrent name>/
      <filename>.mkv   ← virtual file, reads via live HTTP range requests

CDN URLs are never stored — directdl is called fresh with a 30-min cache.

Performance:
  - Name map (hash→dirname) cached with a short TTL so DB is not hit per stat
  - Stat results cached so repeated getattr calls return instantly
  - Block read-ahead: fetches BLOCK_SIZE bytes per CDN request, cached in RAM
    and optionally on disk, with background pre-fetch of upcoming blocks
  - FUSE kernel attr/entry timeouts set so the kernel caches stat results itself
"""

import errno
import hashlib
import logging
import os
import re
import stat
import threading
import time
from collections import OrderedDict

import requests

log = logging.getLogger(__name__)

# ── directdl cache timings ────────────────────────────────────────────────────
DIRECTDL_TTL   = 21600  # 6 hours — Premiumize CDN URLs are valid well beyond 30 min
REFRESH_MARGIN = 1800   # start background refresh 30 min before expiry

# ── HTTP retry parameters ─────────────────────────────────────────────────────
READ_TIMEOUT       = int(os.environ.get("FUSE_READ_TIMEOUT", "30"))  # configurable, default 30s
READ_MAX_ATTEMPTS  = 5     # more retries for 4K files on slow CDN
READ_BACKOFF_BASE  = 0.5
READ_BACKOFF_CAP   = 4.0

# ── read-ahead / block cache (tunable via env vars) ───────────────────────────
# FUSE_READAHEAD_MB  – MB to pre-fetch per block (default 8)
# FUSE_CACHE_BLOCKS  – max blocks in LRU (default 16)
# FUSE_PREFETCH      – enable background pre-fetch (default true)
# FUSE_CACHE_DIR     – directory for persistent on-disk block cache
_RA_MB            = int(os.environ.get("FUSE_READAHEAD_MB",  "32"))   # was 8
_CACHE_N          = int(os.environ.get("FUSE_CACHE_BLOCKS", "64"))   # was 16 — 64×32MB = 2GB
_PREFETCH_ENABLED = os.environ.get("FUSE_PREFETCH", "true").lower() != "false"
_CACHE_DIR        = os.environ.get("FUSE_CACHE_DIR", "/docker/premiumize-web/cache").strip()
_VIDEO_ONLY       = os.environ.get("FUSE_VIDEO_ONLY", "true").lower() != "false"

BLOCK_SIZE = _RA_MB * 1024 * 1024

# How many blocks to pre-fetch ahead of current read position.
# Calculated from read_ahead size / block size, minimum 2, maximum 32.
def _prefetch_blocks() -> int:
    read_ahead = _parse_size_simple(os.environ.get("FUSE_READ_AHEAD", "500MB"), 500 * 1024 * 1024)
    return max(2, min(32, read_ahead // BLOCK_SIZE))

def _parse_size_simple(val: str, default: int) -> int:
    if not val:
        return default
    val = val.strip().upper().replace(' ', '')
    units = {'TB': 1024**4, 'GB': 1024**3, 'MB': 1024**2, 'KB': 1024, 'B': 1}
    for suffix, mult in sorted(units.items(), key=lambda x: -len(x[0])):
        if val.endswith(suffix):
            try:
                return int(float(val[:-len(suffix)]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

_READ_AHEAD_BYTES = _parse_size_simple(os.environ.get("FUSE_READ_AHEAD", "500MB"), 500 * 1024 * 1024)

VIDEO_EXTENSIONS = {
    ".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
    ".wmv", ".flv", ".webm", ".m2ts", ".mpg", ".mpeg",
}

EXTRA_PATTERNS = re.compile(
    r'(?i)(^|\b)(sample|trailer|featurette|behind.the.scenes|'
    r'deleted.scene|interview|short|scene|extra)s?(\b|$)'
)

def _is_video(filename: str) -> bool:
    return os.path.splitext(filename)[1].lower() in VIDEO_EXTENSIONS

def _is_extra(filename: str) -> bool:
    """Return True if the filename looks like a sample or extra."""
    name = os.path.splitext(filename)[0]
    return bool(EXTRA_PATTERNS.search(name))

def _include_file(filename: str) -> bool:
    """Return True if this file should be visible in the FUSE mount."""
    if not _VIDEO_ONLY:
        return True
    return _is_video(filename) and not _is_extra(filename)

# ── in-memory TTLs for hot-path caches ───────────────────────────────────────
NAME_MAP_TTL  = 60    # seconds to cache the hash→dirname map (avoids DB hit per stat)
STAT_CACHE_TTL = 60   # seconds — longer so repeated stats on same files are instant
# FUSE kernel-side timeouts — kept short so new files appear in Plex quickly.
# Lower values mean more kernel→FUSE calls but faster visibility of new content.
KERNEL_ATTR_TIMEOUT  = 1.0   # was 30 — new file sizes visible within 1s
KERNEL_ENTRY_TIMEOUT = 1.0   # was 30 — new directory entries visible within 1s

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")


def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"


import re as _re

from name_match import _SERIES_RE, _4K_RE

# Whether 4K folders are enabled — toggled via Settings UI
_4K_FOLDERS_ENABLED = False

# Running FUSE filesystem instance — set when mount starts, used for cache invalidation
_pfs = None

def _category_subdir(name: str, category: str = "") -> str:
    # Tier 1: check manual overrides (saved in config)
    try:
        import re as _re_ov
        from app import _get_overrides, _override_key
        ov = _get_overrides()
        key = _override_key(name)
        if key in ov:
            is_series = ov[key]["kind"] == "series"
            if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
                return "series4k" if is_series else "movies4k"
            return "series" if is_series else "movies"
    except Exception:
        pass

    # Tier 2: name pattern matching
    is_series = bool(_SERIES_RE.search(name or ""))
    cat = (category or "").lower()
    if not is_series:
        is_series = any(k in cat for k in ("sonarr", "tv", "series", "show"))

    if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
        return "series4k" if is_series else "movies4k"
    return "series" if is_series else "movies"


def build_name_map(transfer_manager) -> dict:
    """
    Returns {subdir/safe_name: hash} for all streamable transfers.
    e.g. {'movies/The.Batman.2022': 'abc123', 'series/Breaking.Bad.S01E01': 'def456'}
    """
    result = {}
    for h in transfer_manager.streamable_hashes():
        t = transfer_manager.get_transfer(h)
        if not t:
            continue
        base   = _safe_name(t.get("name") or h)
        subdir = _category_subdir(t.get("name") or "", t.get("category", ""))
        key    = f"{subdir}/{base}"
        if key in result:
            key = f"{subdir}/{base}_{h[:8]}"
        result[key] = h
    return result


def dir_name_for_hash(transfer_manager, hash_: str):
    for nm, h in build_name_map(transfer_manager).items():
        if h == hash_:
            return nm
    return None


# ── disk block path helper ────────────────────────────────────────────────────

def _disk_block_path(cache_dir: str, cdn_url: str, block_idx: int) -> str:
    url_hash = hashlib.sha256(cdn_url.encode()).hexdigest()[:16]
    return os.path.join(cache_dir, url_hash, f"{block_idx}.bin")


# ── LRU block cache ───────────────────────────────────────────────────────────

class _BlockCache:
    def __init__(self, max_blocks: int, cache_dir: str = ""):
        self._max       = max_blocks
        self._cache_dir = cache_dir
        self._lock      = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        if self._cache_dir:
            cdn_url, block_idx = key
            path = _disk_block_path(self._cache_dir, cdn_url, block_idx)
            try:
                with open(path, "rb") as f:
                    data = f.read()
                self.put(key, data)
                return data
            except (FileNotFoundError, OSError):
                pass
        return None

    def put(self, key, data: bytes):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
            else:
                self._store[key] = data
                while len(self._store) > self._max:
                    self._store.popitem(last=False)
        if self._cache_dir:
            cdn_url, block_idx = key
            path = _disk_block_path(self._cache_dir, cdn_url, block_idx)
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                tmp = path + ".tmp"
                with open(tmp, "wb") as f:
                    f.write(data)
                os.replace(tmp, path)
            except OSError as e:
                log.debug(f"Disk cache write failed: {e}")

    def invalidate_url(self, cdn_url: str):
        with self._lock:
            stale = [k for k in self._store if k[0] == cdn_url]
            for k in stale:
                del self._store[k]
        if self._cache_dir:
            url_hash = hashlib.sha256(cdn_url.encode()).hexdigest()[:16]
            url_dir  = os.path.join(self._cache_dir, url_hash)
            try:
                import shutil
                shutil.rmtree(url_dir, ignore_errors=True)
            except OSError:
                pass

    @property
    def size(self):
        with self._lock:
            return len(self._store)


_block_cache = _BlockCache(_CACHE_N, _CACHE_DIR)


class PremiumizeFS(Operations):
    def __init__(self, transfer_manager):
        self._tm   = transfer_manager
        self._now  = time.time()
        self._lock = threading.Lock()

        # directdl cache: hash → (files, expires_at)
        self._file_cache: dict[str, tuple[list, float]] = {}
        self._refreshing: set = set()

        # block fetch dedup
        self._fetching:    set = set()
        self._fetch_lock   = threading.Lock()

        # ── hot-path caches ───────────────────────────────────────────────────
        # Name map cache — avoids a DB query on every getattr/readdir call
        self._name_map:         dict  = {}
        self._name_map_expires: float = 0.0
        self._name_map_lock           = threading.Lock()

        # Stat cache — (stat_dict, expires_at) keyed by path
        self._stat_cache: dict[str, tuple[dict, float]] = {}
        self._stat_lock                                  = threading.Lock()

    # ── name map (cached) ─────────────────────────────────────────────────────

    def _get_name_map(self) -> dict:
        now = time.time()
        with self._name_map_lock:
            if now < self._name_map_expires:
                return self._name_map
        nm = build_name_map(self._tm)
        with self._name_map_lock:
            self._name_map         = nm
            self._name_map_expires = now + NAME_MAP_TTL
        return nm

    def _invalidate_name_map(self):
        with self._name_map_lock:
            self._name_map_expires = 0.0

    # ── stat cache ────────────────────────────────────────────────────────────

    def _stat_get(self, path: str):
        now = time.time()
        with self._stat_lock:
            entry = self._stat_cache.get(path)
            if entry and now < entry[1]:
                return entry[0]
        return None

    def _stat_put(self, path: str, st: dict):
        expires = time.time() + STAT_CACHE_TTL
        with self._stat_lock:
            self._stat_cache[path] = (st, expires)

    def _stat_invalidate(self, path: str):
        with self._stat_lock:
            self._stat_cache.pop(path, None)

    # ── directdl cache ────────────────────────────────────────────────────────

    def _get_files(self, hash_: str, force: bool = False) -> list:
        now = time.time()
        if not force:
            with self._lock:
                cached = self._file_cache.get(hash_)
            if cached:
                files, expires_at = cached
                if now < expires_at - REFRESH_MARGIN:
                    return files
                if now < expires_at:
                    self._spawn_refresh(hash_)
                    return files
        files = self._tm.get_files(hash_, force=force)
        if files:
            with self._lock:
                self._file_cache[hash_] = (files, now + DIRECTDL_TTL)
        return files

    def _spawn_refresh(self, hash_: str):
        with self._lock:
            if hash_ in self._refreshing:
                return
            self._refreshing.add(hash_)

        def _do():
            try:
                files = self._tm.get_files(hash_, force=True)
                if files:
                    with self._lock:
                        self._file_cache[hash_] = (files, time.time() + DIRECTDL_TTL)
            except Exception:
                log.warning(f"[{hash_[:8]}] background refresh failed", exc_info=True)
            finally:
                with self._lock:
                    self._refreshing.discard(hash_)

        threading.Thread(target=_do, daemon=True).start()

    def _invalidate_files(self, hash_: str):
        with self._lock:
            self._file_cache.pop(hash_, None)

    # ── path helpers ──────────────────────────────────────────────────────────

    def _parse_path(self, path):
        """
        Parse a path into (subdir, dirname, filename, hash_).
        Paths are: /                       → root
                   /movies                 → subdir listing
                   /series                 → subdir listing
                   /movies/<name>          → torrent dir
                   /movies/<name>/<file>   → file
        """
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None, None, None, None
        if parts[0] in ("movies", "series", "movies4k", "series4k"):
            subdir  = parts[0]
            dirname = parts[1] if len(parts) > 1 else None
            filename = "/".join(parts[2:]) if len(parts) > 2 else None
        else:
            # Legacy flat path — treat as movies
            subdir   = None
            dirname  = parts[0]
            filename = "/".join(parts[1:]) if len(parts) > 1 else None

        if dirname is None:
            return subdir, None, None, None

        # Look up hash via subdir/dirname key
        key   = f"{subdir}/{dirname}" if subdir else dirname
        hash_ = self._get_name_map().get(key)
        return subdir, dirname, filename, hash_

    def _find_file(self, hash_: str, filename: str, force: bool = False):
        for f in self._get_files(hash_, force=force):
            f_name = f.get("name", "")
            f_base = os.path.basename(f.get("path", "") or f_name)
            if f_name == filename or f_base == filename:
                return f
        return None

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        cached_st = self._stat_get(path)
        if cached_st is not None:
            return cached_st

        base = {
            "st_uid":   os.getuid(),
            "st_gid":   os.getgid(),
            "st_atime": self._now,
            "st_mtime": self._now,
            "st_ctime": self._now,
            "st_nlink": 2,
        }

        # Root
        if path == "/":
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st)
            return st

        # /movies, /series, /movies4k, /series4k
        _valid = {"/movies", "/series"}
        if _4K_FOLDERS_ENABLED:
            _valid |= {"/movies4k", "/series4k"}
        if path in _valid:
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st)
            return st

        subdir, dirname, filename, hash_ = self._parse_path(path)

        # /movies/<name> or /series/<name>
        if not filename:
            if hash_ is not None:
                st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
                self._stat_put(path, st)
                return st
            raise FuseOSError(errno.ENOENT)

        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        # Reject non-video/extra files when video_only is enabled
        if not _include_file(filename):
            raise FuseOSError(errno.ENOENT)

        file_size = int(float(f.get("size", 0) or 0))

        # Don't expose the file until we have a confirmed size — this prevents
        # Plex from scanning a zero-size file and caching a bogus duration
        if file_size == 0:
            raise FuseOSError(errno.ENOENT)

        st = {
            **base,
            "st_mode":  stat.S_IFREG | 0o444,
            "st_nlink": 1,
            "st_size":  file_size,
        }
        # Size is guaranteed > 0 here, safe to cache
        self._stat_put(path, st)
        return st

    def readdir(self, path, fh):
        yield "."
        yield ".."

        # Root — yield subdirs
        if path == "/":
            yield "movies"
            yield "series"
            if _4K_FOLDERS_ENABLED:
                yield "movies4k"
                yield "series4k"
            return

        # Subdir listing
        valid_subdirs = ["/movies", "/series"]
        if _4K_FOLDERS_ENABLED:
            valid_subdirs += ["/movies4k", "/series4k"]
        if path in valid_subdirs:
            subdir = path.lstrip("/")
            for key in self._get_name_map().keys():
                if key.startswith(subdir + "/"):
                    yield key[len(subdir) + 1:]
            return

        # /movies/<name> or /series/<name> — yield files
        # Only yield files with a confirmed size so Plex never scans a zero-size file
        subdir, dirname, _, hash_ = self._parse_path(path)
        if hash_:
            threading.Thread(
                target=self._get_files, args=(hash_,), daemon=True
            ).start()
            for f in self._get_files(hash_):
                raw  = f.get("name", "") or f.get("path", "")
                name = os.path.basename(raw) if raw else raw
                if name and _include_file(name) and int(float(f.get("size", 0) or 0)) > 0:
                    yield name

    def open(self, path, flags):
        subdir, dirname, filename, hash_ = self._parse_path(path)
        if not filename or hash_ is None:
            raise FuseOSError(errno.ENOENT)
        f = self._find_file(hash_, filename)
        if not f or int(float(f.get("size", 0) or 0)) == 0:
            raise FuseOSError(errno.ENOENT)
        if _PREFETCH_ENABLED and f.get("link"):
            self._prefetch_block(f["link"], 0, int(float(f.get("size", 0))))
        return 0

    # ── block-cache read ──────────────────────────────────────────────────────

    def _block_key(self, cdn_url: str, block_idx: int):
        return (cdn_url, block_idx)

    def _fetch_block(self, cdn_url: str, block_idx: int,
                     file_size: int, force_url: str = None) -> bytes | None:
        url     = force_url or cdn_url
        start   = block_idx * BLOCK_SIZE
        end     = min(start + BLOCK_SIZE - 1, file_size - 1) if file_size else start + BLOCK_SIZE - 1
        headers = {"Range": f"bytes={start}-{end}"}

        last_err = None

        for attempt in range(READ_MAX_ATTEMPTS):
            try:
                r = requests.get(url, headers=headers,
                                 timeout=READ_TIMEOUT, stream=True)
            except requests.RequestException as e:
                last_err = e
                log.warning(f"Block fetch network error (try {attempt+1}): {e}")
                self._read_backoff(attempt)
                continue

            try:
                status = r.status_code
                if status in (200, 206):
                    data = r.content
                    _block_cache.put(self._block_key(cdn_url, block_idx), data)
                    return data
                if status in (403, 410):
                    # CDN URL expired — return None immediately so caller refreshes
                    log.info(f"CDN URL expired (block {block_idx}, status {status})")
                    return None
                if status in (429, 500, 502, 503, 504):
                    last_err = f"status {status}"
                    self._read_backoff(attempt)
                    continue
                last_err = f"status {status}"
                break
            finally:
                r.close()

        log.warning(f"Block fetch failed after {READ_MAX_ATTEMPTS} tries: {last_err}")
        return None

    def _refresh_cdn_url(self, hash_: str, filename: str, old_url: str) -> str | None:
        """Force-refresh the directdl cache and return the new CDN URL."""
        self._invalidate_files(hash_)
        f2 = self._find_file(hash_, filename, force=True)
        if not f2:
            return None
        new_url = f2.get("link", "")
        if new_url and new_url != old_url:
            _block_cache.invalidate_url(old_url)
            log.info(f"CDN URL refreshed for {filename}")
            return new_url
        return old_url

    def _prefetch_block(self, cdn_url: str, block_idx: int, file_size: int):
        key = self._block_key(cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with self._fetch_lock:
            if key in self._fetching:
                return
            self._fetching.add(key)

        def _do():
            try:
                self._fetch_block(cdn_url, block_idx, file_size)
            finally:
                with self._fetch_lock:
                    self._fetching.discard(key)

        threading.Thread(target=_do, daemon=True).start()

    def read(self, path, size, offset, fh):
        subdir, dirname, filename, hash_ = self._parse_path(path)
        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        cdn_url   = f.get("link", "")
        file_size = int(float(f.get("size", 0) or 0))
        if not cdn_url:
            raise FuseOSError(errno.EIO)

        block_idx = offset // BLOCK_SIZE
        cached    = _block_cache.get(self._block_key(cdn_url, block_idx))

        if cached is None:
            cached = self._fetch_block(cdn_url, block_idx, file_size)

            if cached is None:
                # URL expired — refresh and retry
                new_url = self._refresh_cdn_url(hash_, filename, cdn_url)
                if new_url and new_url != cdn_url:
                    cdn_url = new_url
                    cached  = self._fetch_block(cdn_url, block_idx, file_size)

            if cached is None:
                log.warning(f"FUSE read failed for {path} block {block_idx}")
                raise FuseOSError(errno.EIO)

        # Pre-fetch ahead based on read_ahead size setting
        if _PREFETCH_ENABLED and file_size:
            ahead_blocks = max(2, min(32, _READ_AHEAD_BYTES // BLOCK_SIZE))
            for ahead in range(1, ahead_blocks + 1):
                nb = block_idx + ahead
                if nb * BLOCK_SIZE < file_size:
                    self._prefetch_block(cdn_url, nb, file_size)

        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        chunk = cached[slice_offset: slice_offset + size]

        # Handle reads that cross a block boundary — fetch the next block and
        # append the needed bytes. Without this, Plex gets a short read at every
        # block boundary which it reports as "unexpected failure before end of file".
        bytes_remaining = size - len(chunk)
        next_block_idx  = block_idx + 1
        while bytes_remaining > 0 and next_block_idx * BLOCK_SIZE < file_size:
            next_cached = _block_cache.get(self._block_key(cdn_url, next_block_idx))
            if next_cached is None:
                next_cached = self._fetch_block(cdn_url, next_block_idx, file_size)
                if next_cached is None:
                    break  # return what we have; do not raise so Plex can retry
            chunk += next_cached[:bytes_remaining]
            bytes_remaining -= len(next_cached[:bytes_remaining])
            next_block_idx  += 1

        return chunk

    @staticmethod
    def _read_backoff(attempt: int):
        time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))

    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


def mount(mountpoint: str, transfer_manager, foreground=True):
    if not FUSE_AVAILABLE:
        log.error("fusepy not installed — cannot mount")
        return
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"Mounting Premiumize FS at {mountpoint} "
             f"(block={BLOCK_SIZE//1024//1024}MB, cache={_CACHE_N} blocks, "
             f"prefetch={'on' if _PREFETCH_ENABLED else 'off'})")
    global _pfs
    _pfs = PremiumizeFS(transfer_manager)
    try:
        FUSE(
            _pfs,
            mountpoint,
            nothreads=False,      # multi-threaded — required for parallel 4K reads from Plex
            foreground=foreground,
            allow_other=True,
            nonempty=True,
            ro=True,
            attr_timeout=KERNEL_ATTR_TIMEOUT,
            entry_timeout=KERNEL_ENTRY_TIMEOUT,
            negative_timeout=10.0,
        )
    except Exception as e:
        log.error(f"FUSE mount exited with exception: {e}", exc_info=True)
        raise
    log.info("FUSE mount exited cleanly")

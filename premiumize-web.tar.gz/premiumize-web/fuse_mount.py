"""
Premiumize virtual filesystem using FUSE.

Directory structure:
  /mnt/premiumize/
    <torrent_hash>/
      <filename>.mkv   ← virtual file, reads via live HTTP range requests

CDN URLs expire, so we never store them. Instead we call directdl fresh
and cache the response in memory for DIRECTDL_TTL seconds. On cache miss
or expiry we call directdl again to get fresh URLs.
"""

import errno
import logging
import os
import stat
import threading
import time

import requests

log = logging.getLogger(__name__)

DIRECTDL_TTL = 1800  # refresh directdl links every 30 minutes

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")


class PremiumizeFS(Operations):
    def __init__(self, transfer_manager):
        self._tm    = transfer_manager
        self._now   = time.time()
        self._lock  = threading.Lock()
        # Cache: hash → (files: list[dict], expires_at: float)
        self._cache: dict[str, tuple[list, float]] = {}

    # ── directdl cache ────────────────────────────────────────────────────────

    def _get_files(self, hash_: str) -> list:
        """Return fresh file list, using in-memory cache to avoid hammering API."""
        now = time.time()
        with self._lock:
            cached = self._cache.get(hash_)
            if cached and cached[1] > now:
                return cached[0]

        # Cache miss or expired — fetch fresh from transfer manager
        # (which calls directdl with a live API call)
        files = self._tm.get_files(hash_)
        if files:
            with self._lock:
                self._cache[hash_] = (files, now + DIRECTDL_TTL)

        return files

    def _invalidate(self, hash_: str):
        with self._lock:
            self._cache.pop(hash_, None)

    # ── path helpers ──────────────────────────────────────────────────────────

    def _parse_path(self, path):
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None, None
        if len(parts) == 1:
            return parts[0], None
        return parts[0], "/".join(parts[1:])

    def _find_file(self, hash_: str, filename: str):
        for f in self._get_files(hash_):
            if f.get("name") == filename or f.get("path", "").endswith(filename):
                return f
        return None

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        base = {
            "st_uid":   os.getuid(),
            "st_gid":   os.getgid(),
            "st_atime": self._now,
            "st_mtime": self._now,
            "st_ctime": self._now,
            "st_nlink": 2,
        }

        if path == "/":
            return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}

        hash_, filename = self._parse_path(path)

        if not filename:
            if hash_ in self._tm.streamable_hashes():
                return {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        return {
            **base,
            "st_mode":  stat.S_IFREG | 0o444,
            "st_nlink": 1,
            "st_size":  int(f.get("size", 0)),
        }

    def readdir(self, path, fh):
        yield "."
        yield ".."

        if path == "/":
            for h in self._tm.streamable_hashes():
                yield h
            return

        hash_, _ = self._parse_path(path)
        for f in self._get_files(hash_ or ""):
            yield f.get("name", "")

    def open(self, path, flags):
        hash_, filename = self._parse_path(path)
        if not filename or not self._find_file(hash_, filename):
            raise FuseOSError(errno.ENOENT)
        return 0

    def read(self, path, size, offset, fh):
        hash_, filename = self._parse_path(path)
        f = self._find_file(hash_, filename)

        if not f:
            raise FuseOSError(errno.ENOENT)

        cdn_url = f.get("link", "")
        if not cdn_url:
            raise FuseOSError(errno.EIO)

        end     = offset + size - 1
        headers = {"Range": f"bytes={offset}-{end}"}

        try:
            r = requests.get(cdn_url, headers=headers, timeout=30, stream=True)

            # If 403/410 the URL has expired — invalidate cache and retry once
            if r.status_code in (403, 410):
                log.info(f"CDN URL expired for {hash_[:8]}/{filename} — refreshing")
                self._invalidate(hash_)
                f = self._find_file(hash_, filename)
                if not f:
                    raise FuseOSError(errno.EIO)
                cdn_url = f.get("link", "")
                r = requests.get(cdn_url, headers=headers, timeout=30, stream=True)

            if r.status_code not in (200, 206):
                log.warning(f"FUSE read got {r.status_code} for {path}")
                raise FuseOSError(errno.EIO)

            return r.content

        except requests.RequestException as e:
            log.warning(f"FUSE read error for {path}: {e}")
            raise FuseOSError(errno.EIO)

    # Write ops — read-only filesystem
    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


def mount(mountpoint: str, transfer_manager, foreground=True):
    if not FUSE_AVAILABLE:
        log.error("fusepy not installed — cannot mount")
        return
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"Mounting Premiumize FS at {mountpoint}")
    FUSE(
        PremiumizeFS(transfer_manager),
        mountpoint,
        nothreads=False,
        foreground=foreground,
        allow_other=True,
        nonempty=True,
        ro=True,
    )

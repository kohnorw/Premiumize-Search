import os
import re
import json
import secrets
import threading
import time
import urllib.parse
import requests
from collections import defaultdict
from datetime import datetime, timezone
from xml.sax.saxutils import escape as xml_escape
from flask import Flask, request, jsonify, render_template, Response

app = Flask(__name__)

# ── stream token cache ────────────────────────────────────────────────────────
# Tokens map to (hash, filename) — NOT a CDN URL.
# The proxy resolves a fresh CDN URL on every request via the directdl cache,
# so links never go stale regardless of how long VLC has been open.

_stream_tokens: dict = {}  # token → (hash, filename)

def _make_stream_token(hash_: str, filename: str) -> str:
    # Reuse existing token for the same file if one exists
    for tok, (h, f) in _stream_tokens.items():
        if h == hash_ and f == filename:
            return tok
    token = secrets.token_urlsafe(32)
    _stream_tokens[token] = (hash_, filename)
    return token

# ── directdl cache ────────────────────────────────────────────────────────────
# Shared cache so the stream proxy doesn't call directdl on every chunk read.
# TTL matches the FUSE layer (30 min). Automatically refreshed on expiry.

_DIRECTDL_TTL   = 1800  # 30 minutes
_directdl_cache: dict = {}  # hash → (files: list, expires_at: float)
_directdl_lock  = threading.Lock()

def _get_directdl(hash_: str, name: str) -> list:
    """Return directdl file list, refreshing from Premiumize if stale."""
    now = time.time()
    with _directdl_lock:
        cached = _directdl_cache.get(hash_)
        if cached and cached[1] > now:
            return cached[0]
    # Cache miss or expired — fetch fresh
    files = _directdl_for_manager_raw(hash_, name)
    if files:
        with _directdl_lock:
            _directdl_cache[hash_] = (files, now + _DIRECTDL_TTL)
    return files

# ── persistent config ─────────────────────────────────────────────────────────

CONFIG_PATH = os.environ.get("CONFIG_PATH", "/app/config.json")
_config_lock = threading.Lock()

def _load_config() -> dict:
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except Exception:
        return {}

def _save_config(cfg: dict):
    os.makedirs(os.path.dirname(CONFIG_PATH) or ".", exist_ok=True)
    with _config_lock:
        with open(CONFIG_PATH, "w") as f:
            json.dump(cfg, f, indent=2)

def get_prowlarr_config() -> dict:
    saved = _load_config().get("prowlarr", {})
    # Env vars take precedence if set, otherwise fall back to saved config
    return {
        "url":     PROWLARR_URL or saved.get("url", ""),
        "api_key": PROWLARR_KEY or saved.get("api_key", ""),
        "from_env": bool(PROWLARR_URL or PROWLARR_KEY),
    }

def save_prowlarr_config(url: str, api_key: str):
    cfg = _load_config()
    cfg["prowlarr"] = {"url": url.rstrip("/"), "api_key": api_key}
    _save_config(cfg)

# ── static config ─────────────────────────────────────────────────────────────

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

PM_BASE          = "https://www.premiumize.me/api"
PM_CACHE         = f"{PM_BASE}/cache/check"
PM_DIRECTDL      = f"{PM_BASE}/transfer/directdl"
PM_TRANSFER      = f"{PM_BASE}/transfer/create"
PM_TRANSFER_LIST = f"{PM_BASE}/transfer/list"
PM_ACCOUNT       = f"{PM_BASE}/account/info"

PM_API_KEY     = os.environ.get("PREMIUMIZE_API_KEY", "")
TORZNAB_APIKEY = os.environ.get("TORZNAB_APIKEY", "changeme")
PROWLARR_URL   = os.environ.get("PROWLARR_URL", "")
PROWLARR_KEY   = os.environ.get("PROWLARR_API_KEY", "")

# Torznab rate limit: requests per window
TORZNAB_RATE_LIMIT  = int(os.environ.get("TORZNAB_RATE_LIMIT", "60"))   # max requests
TORZNAB_RATE_WINDOW = int(os.environ.get("TORZNAB_RATE_WINDOW", "60"))  # per N seconds

# ── torznab rate limiter (sliding window per IP) ──────────────────────────────

_rate_lock = threading.Lock()
_rate_data: dict[str, list] = defaultdict(list)  # ip -> [timestamps]

def _check_rate_limit(ip: str) -> tuple[bool, int, int, int]:
    """Returns (allowed, limit, remaining, reset_ts)"""
    now = time.time()
    window_start = now - TORZNAB_RATE_WINDOW
    with _rate_lock:
        hits = [t for t in _rate_data[ip] if t > window_start]
        remaining = max(0, TORZNAB_RATE_LIMIT - len(hits))
        reset_ts = int(now + TORZNAB_RATE_WINDOW)
        if remaining == 0:
            return False, TORZNAB_RATE_LIMIT, 0, reset_ts
        hits.append(now)
        _rate_data[ip] = hits
        return True, TORZNAB_RATE_LIMIT, remaining - 1, reset_ts

def _rate_headers(limit: int, remaining: int, reset_ts: int) -> dict:
    return {
        "X-RateLimit-Limit":     str(limit),
        "X-RateLimit-Remaining": str(remaining),
        "X-RateLimit-Reset":     str(reset_ts),
    }

# ── category maps ─────────────────────────────────────────────────────────────

def tpb_to_newznab(tpb_cat, name=""):
    name_up = name.upper()
    if re.search(r'S\d{2}E\d{2}|SEASON\s+\d+|\bS\d{2}\b', name_up):
        return 5000
    try:
        c = int(tpb_cat)
    except Exception:
        return 8000
    if 200 <= c < 300: return 2000
    if 500 <= c < 600: return 5000
    if 300 <= c < 400: return 3000
    return 8000

# ── helpers ───────────────────────────────────────────────────────────────────

QUALITY_PATTERNS = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE
)

def fmt_size(b):
    try: return int(b)
    except Exception: return 0

def fmt_size_str(b):
    try: b = int(b)
    except Exception: return "?"
    if b > 1_000_000_000: return f"{b/1_000_000_000:.2f} GB"
    if b > 1_000_000:     return f"{b/1_000_000:.0f} MB"
    if b > 1_000:         return f"{b/1_000:.0f} KB"
    return f"{b} B"

def _sanitize(query):
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()

def parse_query(raw):
    quality = QUALITY_PATTERNS.findall(raw)
    search_raw = QUALITY_PATTERNS.sub('', raw).strip()
    season, episode = None, None
    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        search_raw = re.sub(r'\bseason\s+\d+\b', f'S{season:02d}', search_raw, flags=re.IGNORECASE)
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return ' '.join(search_raw.split()).strip(), season, episode, quality

def strip_season(query):
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', '', query, flags=re.IGNORECASE)
    return ' '.join(t.split())

def filter_by_season(torrents, season, episode):
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        if episode is not None and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out

def filter_by_quality(torrents, quality):
    if not quality:
        return torrents
    out = []
    for t in torrents:
        name_up = t.get("name", "").upper()
        for q in quality:
            if q.upper().rstrip('P') in name_up:
                out.append(t)
                break
    return out if out else torrents

# ── TPB fetch ─────────────────────────────────────────────────────────────────

def _fetch_tpb(query, limit=40):
    queries = [query]
    sanitized = _sanitize(query)
    if sanitized.lower() != query.lower():
        queries.append(sanitized)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = requests.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict)
                    and x.get("info_hash")
                    and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
                ]
                if valid:
                    return valid[:limit]
            except Exception:
                continue
    return []

# ── Prowlarr fetch ────────────────────────────────────────────────────────────

def _fetch_prowlarr(query: str, season=None, episode=None, limit=40) -> list:
    """Search Prowlarr and return normalised torrent dicts."""
    cfg = get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"):
        return []

    base = cfg["url"]
    key  = cfg["api_key"]

    # Build query string
    q = query
    if season is not None:
        q = f"{query} S{season:02d}"
        if episode is not None:
            q += f"E{episode:02d}"

    params = {
        "query":      q,
        "indexerIds": -2,     # all torrent indexers
        "categories": [2000, 5000, 8000],
        "type":       "search",
        "limit":      limit,
    }

    try:
        r = requests.get(
            f"{base}/api/v1/search",
            headers={"X-Api-Key": key},
            params=params,
            timeout=20,
        )
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        app.logger.warning(f"Prowlarr search failed: {e}")
        return []

    results = []
    for item in data:
        info_hash = (item.get("infoHash") or "").lower()
        if not info_hash or not re.fullmatch(r'[0-9a-fA-F]{40}', info_hash):
            continue
        results.append({
            "info_hash": info_hash,
            "name":      item.get("title", "Unknown"),
            "size":      item.get("size", 0),
            "seeders":   item.get("seeders", 0) or 0,
            "leechers":  item.get("leechers", 0) or 0,
            "category":  item.get("categories", [{}])[0].get("id", 8000) if item.get("categories") else 8000,
            "indexer":   item.get("indexer", ""),
        })

    return results

# ── Premiumize helpers ────────────────────────────────────────────────────────

def _make_magnet(torrent):
    h    = torrent["info_hash"].lower()
    name = urllib.parse.quote(torrent.get("name", ""), safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={name}"

def pm_headers(api_key):
    return {"Authorization": f"Bearer {api_key}"}

def check_cache_pm(api_key, torrents):
    if not torrents:
        return {}
    hashes = [t["info_hash"].lower() for t in torrents]
    headers = {**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"}
    try:
        r = requests.post(
            PM_CACHE,
            headers=headers,
            data=urllib.parse.urlencode([("items[]", h) for h in hashes]),
            timeout=15,
        )
        r.raise_for_status()
        data = r.json()
    except Exception:
        return {}
    if data.get("status") != "success":
        return {}
    responses = data.get("response", [])
    return {h: bool(responses[i]) if i < len(responses) else False
            for i, h in enumerate(hashes)}

# ── unified search ────────────────────────────────────────────────────────────

def do_search(query, season=None, episode=None, quality=None, limit=40, pm_key=None):
    # Try Prowlarr first, fall back to TPB
    prowlarr_cfg = get_prowlarr_config()
    if prowlarr_cfg.get("url") and prowlarr_cfg.get("api_key"):
        torrents = _fetch_prowlarr(query, season, episode, limit)
        source = "prowlarr"
    else:
        torrents = []
        source = "tpb"

    if not torrents:
        torrents = _fetch_tpb(query, limit)
        source = "tpb"
        if not torrents and season is not None:
            fallback = strip_season(query)
            if fallback and fallback.lower() != query.lower():
                torrents = _fetch_tpb(fallback, limit * 2)

    if not torrents:
        return []

    if source == "tpb":
        torrents = filter_by_season(torrents, season, episode)
        if not torrents and season is not None:
            torrents = _fetch_tpb(query, limit)
        if quality:
            torrents = filter_by_quality(torrents, quality)

    ready_map = check_cache_pm(pm_key, torrents) if pm_key else {}

    results = []
    seen = set()
    for t in torrents:
        h = t["info_hash"].lower()
        if h in seen:
            continue
        seen.add(h)
        cat = t.get("category", 8000)
        # Normalise TPB category numbers to newznab IDs
        if isinstance(cat, int) and cat < 1000:
            cat = tpb_to_newznab(cat, t.get("name", ""))
        results.append({
            "hash":     h,
            "name":     t.get("name", "Unknown"),
            "size":     fmt_size(t.get("size", 0)),
            "size_str": fmt_size_str(t.get("size", 0)),
            "seeders":  int(t.get("seeders", 0) or 0),
            "leechers": int(t.get("leechers", 0) or 0),
            "category": cat,
            "cached":   ready_map.get(h, False),
            "indexer":  t.get("indexer", "TPB"),
        })

    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results

# ── Torznab XML ───────────────────────────────────────────────────────────────

def torznab_caps():
    return '''<?xml version="1.0" encoding="UTF-8"?>
<caps>
  <server title="Premiumize Indexer" />
  <limits default="40" max="100"/>
  <searching>
    <search available="yes" supportedParams="q"/>
    <tv-search available="yes" supportedParams="q,season,ep"/>
    <movie-search available="yes" supportedParams="q"/>
  </searching>
  <categories>
    <category id="2000" name="Movies">
      <subcat id="2040" name="Movies/HD"/>
      <subcat id="2045" name="Movies/UHD"/>
      <subcat id="2030" name="Movies/SD"/>
      <subcat id="2050" name="Movies/BluRay"/>
    </category>
    <category id="5000" name="TV">
      <subcat id="5040" name="TV/HD"/>
      <subcat id="5045" name="TV/UHD"/>
      <subcat id="5030" name="TV/SD"/>
      <subcat id="5010" name="TV/WEB-DL"/>
    </category>
    <category id="8000" name="Other"/>
  </categories>
</caps>'''

def torznab_results(results, query=""):
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items = []
    for r in results:
        magnet = f"magnet:?xt=urn:btih:{r['hash']}&dn={urllib.parse.quote(r['name'], safe='')}"
        cached_attr = '<torznab:attr name="cached" value="1"/>' if r.get("cached") else ''
        items.append(f"""    <item>
      <title>{xml_escape(r['name'])}</title>
      <guid>{xml_escape(magnet)}</guid>
      <link>{xml_escape(magnet)}</link>
      <pubDate>{now}</pubDate>
      <size>{r['size']}</size>
      <enclosure url="{xml_escape(magnet)}" length="{r['size']}" type="application/x-bittorrent"/>
      <torznab:attr name="magneturl" value="{xml_escape(magnet)}"/>
      <torznab:attr name="infohash" value="{r['hash']}"/>
      <torznab:attr name="seeders" value="{r['seeders']}"/>
      <torznab:attr name="leechers" value="{r['leechers']}"/>
      <torznab:attr name="size" value="{r['size']}"/>
      <torznab:attr name="category" value="{r['category']}"/>
      {cached_attr}
    </item>""")
    items_xml = "\n".join(items)
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <channel>
    <title>Premiumize Indexer</title>
    <description>TPB/Prowlarr via Premiumize cache check</description>
    <link>http://localhost</link>
    <language>en-US</language>
    <pubDate>{now}</pubDate>
    <response xmlns="urn:newznab:api" offset="0" total="{len(results)}"/>
{items_xml}
  </channel>
</rss>'''

def xml_error(code, description, extra_headers=None):
    r = Response(
        f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="{code}" description="{xml_escape(description)}"/>''',
        mimetype="application/xml", status=400
    )
    if extra_headers:
        for k, v in extra_headers.items():
            r.headers[k] = v
    return r

# ── routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

# Torznab — with rate limiting
@app.route("/torznab")
@app.route("/torznab/api")
def torznab():
    t = request.args.get("t", "").lower()

    # Caps is always public — Prowlarr probes it without a key
    if t == "caps":
        return Response(torznab_caps(), mimetype="application/xml")

    # API key check for all other requests
    apikey = request.args.get("apikey", "") or request.headers.get("X-Api-Key", "")
    if TORZNAB_APIKEY and apikey != TORZNAB_APIKEY:
        return xml_error(100, "Invalid API key")

    # Rate limit by IP
    ip = request.headers.get("X-Forwarded-For", request.remote_addr).split(",")[0].strip()
    allowed, limit, remaining, reset_ts = _check_rate_limit(ip)
    rh = _rate_headers(limit, remaining, reset_ts)

    if not allowed:
        retry_after = reset_ts - int(time.time())
        r = Response(
            f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="429" description="Rate limit exceeded. Retry after {retry_after}s"/>''',
            mimetype="application/xml", status=429,
            headers={**rh, "Retry-After": str(retry_after)},
        )
        return r

    if t in ("search", "tvsearch", "movie"):
        q      = request.args.get("q", "").strip()
        season = request.args.get("season", "").strip()
        ep     = request.args.get("ep", "").strip()
        cat    = request.args.get("cat", "").strip()

        app.logger.info(f"Torznab {t}: q={q!r} season={season!r} ep={ep!r} cat={cat!r}")

        query = q
        parsed_s, parsed_ep = None, None
        if season:
            try:
                parsed_s = int(season)
                query = f"{q} S{parsed_s:02d}" if q else f"S{parsed_s:02d}"
                if ep:
                    parsed_ep = int(ep)
                    query += f"E{parsed_ep:02d}"
            except ValueError:
                pass

        # Empty query — return a generic browse feed so Prowlarr doesn't error
        if not query:
            raw = _fetch_tpb("1080p", 40)
            fb_results = []
            for ti in raw:
                h = ti["info_hash"].lower()
                fb_results.append({
                    "hash":     h,
                    "name":     ti.get("name", "Unknown"),
                    "size":     fmt_size(ti.get("size", 0)),
                    "size_str": fmt_size_str(ti.get("size", 0)),
                    "seeders":  int(ti.get("seeders", 0) or 0),
                    "leechers": int(ti.get("leechers", 0) or 0),
                    "category": tpb_to_newznab(ti.get("category", 0), ti.get("name", "")),
                    "cached":   False,
                    "indexer":  "TPB",
                })
            resp = Response(torznab_results(fb_results, ""), mimetype="application/xml")
            for k, v in rh.items():
                resp.headers[k] = v
            return resp

        parsed_q, ps, pe, quality = parse_query(query)
        parsed_s = parsed_s or ps
        parsed_ep = parsed_ep or pe

        results = do_search(parsed_q, parsed_s, parsed_ep, quality, limit=40, pm_key=PM_API_KEY)

        if cat and cat != "0":
            requested = [int(c) for c in cat.split(",") if c.strip().isdigit() and c.strip() != "0"]
            if requested:
                filtered = [r for r in results if any(
                    r["category"] == rc or r["category"] // 1000 == rc // 1000
                    for rc in requested
                )]
                if filtered:
                    results = filtered

        resp = Response(torznab_results(results, q), mimetype="application/xml")
        for k, v in rh.items():
            resp.headers[k] = v
        return resp

    app.logger.warning(f"Unknown torznab function: {t!r}")
    return xml_error(202, f"Unknown function: {t}", rh)

# Web UI — search
@app.route("/api/search", methods=["POST"])
def search():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or PM_API_KEY
    query   = data.get("query", "").strip()

    if not api_key:
        return jsonify({"error": "API key required"}), 400
    if not query:
        return jsonify({"error": "Query required"}), 400

    parsed_q, season, episode, quality = parse_query(query)
    results = do_search(parsed_q, season, episode, quality, limit=40, pm_key=api_key)

    return jsonify({
        "results": [{**r, "size": r["size_str"]} for r in results],
        "total":   len(results),
        "source":  "prowlarr" if get_prowlarr_config().get("url") else "tpb",
    })

# Web UI — add to transfer manager (cached → FUSE instantly, uncached → download then FUSE)
@app.route("/api/add", methods=["POST"])
def add():
    data      = request.json or {}
    hash_     = data.get("hash", "").strip().lower()
    name      = data.get("name", "").strip()
    is_cached = data.get("cached", None)  # passed from frontend search results

    if not hash_:
        return jsonify({"error": "hash required"}), 400

    # If frontend already knows it's cached, skip the redundant API cache check
    # and set state directly so it appears in the FUSE mount immediately
    if is_cached is True:
        import time as _time
        existing = _transfer_manager.get_transfer(hash_)
        if not existing:
            _transfer_manager._set(hash_, name=name, state="cached",
                                   added_at=_time.time())
        elif existing["state"] not in ("cached", "complete"):
            _transfer_manager._set(hash_, state="cached")
        t = _transfer_manager.get_transfer(hash_)
    else:
        t = _transfer_manager.add(hash_, name)

    return jsonify({
        "name":  t.get("name", name) if t else name,
        "hash":  hash_,
        "state": t.get("state") if t else "queued",
    })

# Web UI — direct links for play/download
@app.route("/api/links", methods=["POST"])
def get_links():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or PM_API_KEY
    hash_   = data.get("hash", "").strip().lower()
    name    = data.get("name", "").strip()

    if not api_key or not hash_:
        return jsonify({"error": "api_key and hash required"}), 400

    magnet = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
    try:
        r = requests.post(
            PM_DIRECTDL,
            headers={**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"src": magnet}),
            timeout=30,
        )
        r.raise_for_status()
        data_r = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    if data_r.get("status") != "success":
        return jsonify({"error": data_r.get("message", "Could not generate links")}), 400

    content = data_r.get("content", [])
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}

    links = []
    for item in content:
        path = item.get("path", "")
        file_name = path.split("/")[-1] if "/" in path else path
        ext = os.path.splitext(file_name)[1].lower()
        cdn_url = item.get("link", "")
        token = _make_stream_token(hash_, file_name) if cdn_url else ""
        links.append({
            "name":       file_name or path,
            "path":       path,
            "link":       cdn_url,
            "size":       item.get("size", 0),
            "is_video":   ext in video_exts,
            "stream_url": f"/api/stream/{token}" if token else "",
        })

    if not links:
        return jsonify({"error": "No files found for this magnet"}), 404

    return jsonify({"links": links})

# Streaming proxy — resolves a fresh CDN URL on every request via the
# directdl cache, so links never go stale no matter how long VLC has been open.
@app.route("/api/stream/<token>")
def stream_proxy(token):
    entry = _stream_tokens.get(token)
    if not entry:
        return jsonify({"error": "Invalid stream token"}), 404

    hash_, filename = entry

    def _resolve_cdn():
        files = _get_directdl(hash_, filename)
        for f in files:
            if f.get("name") == filename or f.get("path", "").endswith(filename):
                return f.get("link")
        return None

    cdn_url = _resolve_cdn()
    if not cdn_url:
        return jsonify({"error": "File not found"}), 404

    headers = {}
    if "Range" in request.headers:
        headers["Range"] = request.headers["Range"]

    try:
        upstream = requests.get(cdn_url, headers=headers, stream=True, timeout=30)
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    # CDN URL expired — invalidate cache and retry once with fresh URL
    if upstream.status_code in (403, 410):
        with _directdl_lock:
            _directdl_cache.pop(hash_, None)
        cdn_url = _resolve_cdn()
        if not cdn_url:
            return jsonify({"error": "Could not refresh CDN link"}), 502
        try:
            upstream = requests.get(cdn_url, headers=headers, stream=True, timeout=30)
        except requests.RequestException as e:
            return jsonify({"error": str(e)}), 502

    ext = os.path.splitext(filename)[1].lower()
    mime_map = {
        ".mp4": "video/mp4", ".mkv": "video/x-matroska",
        ".avi": "video/x-msvideo", ".mov": "video/quicktime",
        ".m4v": "video/mp4", ".ts": "video/mp2t",
        ".webm": "video/webm", ".wmv": "video/x-ms-wmv",
    }
    content_type = upstream.headers.get("Content-Type") or mime_map.get(ext, "application/octet-stream")

    resp_headers = {
        "Content-Type":  content_type,
        "Accept-Ranges": upstream.headers.get("Accept-Ranges", "bytes"),
    }
    if "Content-Length" in upstream.headers:
        resp_headers["Content-Length"] = upstream.headers["Content-Length"]
    if "Content-Range" in upstream.headers:
        resp_headers["Content-Range"] = upstream.headers["Content-Range"]

    def generate():
        for chunk in upstream.iter_content(chunk_size=1024 * 256):
            yield chunk

    return Response(generate(), status=upstream.status_code, headers=resp_headers)

# Transfer status polling
@app.route("/api/transfer/status", methods=["POST"])
def transfer_status():
    data        = request.json or {}
    api_key     = data.get("api_key", "").strip() or PM_API_KEY
    transfer_id = data.get("transfer_id", "").strip()

    if not api_key or not transfer_id:
        return jsonify({"error": "api_key and transfer_id required"}), 400

    try:
        r = requests.get(PM_TRANSFER_LIST, headers=pm_headers(api_key), timeout=15)
        r.raise_for_status()
        data_r = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    if data_r.get("status") != "success":
        return jsonify({"error": data_r.get("message", "Failed to get transfer list")}), 400

    for t in data_r.get("transfers", []):
        if str(t.get("id")) == str(transfer_id):
            return jsonify({
                "status":   t.get("status"),
                "progress": t.get("progress", 0),
                "message":  t.get("message", ""),
                "file_id":  t.get("file_id"),
            })

    return jsonify({"error": "Transfer not found"}), 404

# Frontend config — tells the UI what's already set server-side
@app.route("/api/config")
def get_config():
    return jsonify({
        "has_pm_key":       bool(PM_API_KEY),
        "has_prowlarr_env": bool(PROWLARR_URL or PROWLARR_KEY),
    })

# Account info
@app.route("/api/account", methods=["POST"])
def account():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or PM_API_KEY
    if not api_key:
        return jsonify({"error": "API key required"}), 400
    try:
        r = requests.get(PM_ACCOUNT, headers=pm_headers(api_key), timeout=10)
        r.raise_for_status()
        d = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502
    if d.get("status") != "success":
        return jsonify({"error": d.get("message", "Authentication failed")}), 401
    premium_until = d.get("premium_until")
    is_premium = bool(premium_until and premium_until > datetime.now(timezone.utc).timestamp())
    return jsonify({
        "customer_id":   d.get("customer_id"),
        "is_premium":    is_premium,
        "premium_until": premium_until,
        "limit_used":    d.get("limit_used", 0),
    })

# ── Prowlarr config endpoints ─────────────────────────────────────────────────

@app.route("/api/prowlarr/config", methods=["GET"])
def prowlarr_config_get():
    cfg = get_prowlarr_config()
    return jsonify({
        "url":        cfg.get("url", ""),
        "api_key":    cfg.get("api_key", ""),
        "configured": bool(cfg.get("url") and cfg.get("api_key")),
        "from_env":   cfg.get("from_env", False),
    })

@app.route("/api/prowlarr/config", methods=["POST"])
def prowlarr_config_save():
    data    = request.json or {}
    url     = data.get("url", "").strip()
    api_key = data.get("api_key", "").strip()

    if not url or not api_key:
        return jsonify({"error": "url and api_key required"}), 400

    # Test the connection
    try:
        r = requests.get(
            f"{url.rstrip('/')}/api/v1/indexer",
            headers={"X-Api-Key": api_key},
            timeout=10,
        )
        r.raise_for_status()
        indexers = r.json()
    except requests.RequestException as e:
        return jsonify({"error": f"Could not connect to Prowlarr: {e}"}), 400

    save_prowlarr_config(url, api_key)

    torrent_indexers = [i for i in indexers if i.get("protocol") == "torrent"]
    return jsonify({
        "ok": True,
        "indexer_count": len(torrent_indexers),
        "indexers": [{"id": i["id"], "name": i["name"]} for i in torrent_indexers],
    })

@app.route("/api/prowlarr/config", methods=["DELETE"])
def prowlarr_config_delete():
    cfg = _load_config()
    cfg.pop("prowlarr", None)
    _save_config(cfg)
    return jsonify({"ok": True})

@app.route("/api/prowlarr/indexers", methods=["GET"])
def prowlarr_indexers():
    cfg = get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"):
        return jsonify({"error": "Prowlarr not configured"}), 400
    try:
        r = requests.get(
            f"{cfg['url']}/api/v1/indexer",
            headers={"X-Api-Key": cfg["api_key"]},
            timeout=10,
        )
        r.raise_for_status()
        indexers = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    torrent_indexers = [i for i in indexers if i.get("protocol") == "torrent"]
    return jsonify({
        "indexers": [{"id": i["id"], "name": i["name"], "enabled": i.get("enableAutomaticSearch", True)} for i in torrent_indexers]
    })

MOUNTPOINT     = os.environ.get("FUSE_MOUNTPOINT", "/mnt/premiumize")

# ── directdl helpers ──────────────────────────────────────────────────────────

def _directdl_for_manager_raw(hash_: str, name: str) -> list:
    """Raw directdl call — always hits Premiumize API. Use _get_directdl instead."""
    api_key = PM_API_KEY
    if not api_key:
        return []
    magnet     = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}
    try:
        r = requests.post(
            PM_DIRECTDL,
            headers={**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"src": magnet}),
            timeout=30,
        )
        r.raise_for_status()
        data_r = r.json()
    except Exception:
        return []
    if data_r.get("status") != "success":
        return []
    files = []
    for item in data_r.get("content", []):
        path      = item.get("path", "")
        file_name = path.split("/")[-1] if "/" in path else path
        ext       = os.path.splitext(file_name)[1].lower()
        cdn_url   = item.get("link", "")
        token     = _make_stream_token(hash_, file_name) if cdn_url else ""
        files.append({
            "name":       file_name or path,
            "path":       path,
            "link":       cdn_url,
            "size":       item.get("size", 0),
            "is_video":   ext in video_exts,
            "stream_url": f"/api/stream/{token}" if token else "",
        })
    return files

def _directdl_for_manager(hash_: str, name: str) -> list:
    """Cached wrapper — used by transfer manager and FUSE mount."""
    return _get_directdl(hash_, name)

# ── transfer manager ──────────────────────────────────────────────────────────

from transfer_manager import TransferManager

_transfer_manager = TransferManager(
    pm_api_key_fn  = lambda: PM_API_KEY,
    directdl_fn    = _directdl_for_manager,
    cache_check_fn = lambda torrents: check_cache_pm(PM_API_KEY, torrents),
)

# ── qBittorrent mock blueprint ────────────────────────────────────────────────

import qbt_mock
qbt_mock.init(_transfer_manager)
qbt_mock.MOUNTPOINT = MOUNTPOINT
app.register_blueprint(qbt_mock.qbt)

# ── FUSE mount ────────────────────────────────────────────────────────────────

import signal
import subprocess

def _unmount_fuse():
    """Unmount cleanly — try fusermount first, fall back to umount."""
    try:
        subprocess.run(["fusermount", "-uz", MOUNTPOINT], check=False, capture_output=True)
    except FileNotFoundError:
        subprocess.run(["umount", "-l", MOUNTPOINT], check=False, capture_output=True)
    app.logger.info(f"FUSE unmounted {MOUNTPOINT}")

def _start_fuse():
    import traceback
    try:
        from fuse_mount import mount, FUSE_AVAILABLE
    except Exception as e:
        print(f"[FUSE] import failed: {e}", flush=True)
        traceback.print_exc()
        return

    if not FUSE_AVAILABLE:
        print("[FUSE] fusepy not installed — disabled", flush=True)
        return

    print(f"[FUSE] unmounting stale mount at {MOUNTPOINT}", flush=True)
    _unmount_fuse()

    print(f"[FUSE] mounting at {MOUNTPOINT}", flush=True)
    try:
        mount(MOUNTPOINT, _transfer_manager, foreground=True)
        print("[FUSE] mount exited", flush=True)
    except Exception as e:
        print(f"[FUSE] mount failed: {e}", flush=True)
        traceback.print_exc()

def _shutdown(signum, frame):
    app.logger.info("Shutting down — unmounting FUSE")
    _unmount_fuse()
    raise SystemExit(0)

# Register signal handlers so FUSE is unmounted on SIGTERM (docker stop) and SIGINT
signal.signal(signal.SIGTERM, _shutdown)
signal.signal(signal.SIGINT, _shutdown)

if os.environ.get("ENABLE_FUSE", "true").lower() == "true":
    threading.Thread(target=_start_fuse, daemon=True).start()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
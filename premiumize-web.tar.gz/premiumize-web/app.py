import os
import re
import json
import secrets
import threading
import time
import urllib.parse
import requests
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from xml.sax.saxutils import escape as xml_escape
from flask import Flask, request, jsonify, render_template, Response

app = Flask(__name__)

# ── Auto-import thread pool ───────────────────────────────────────────────────
# Limits concurrent auto-import jobs to avoid exhausting OS thread limit.
# Jobs queue when all workers are busy — they don't get dropped.
_import_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="auto-import")

# ── stream token cache ────────────────────────────────────────────────────────
# Tokens map to (hash, filename) — NOT a CDN URL.
# The proxy resolves a fresh CDN URL on every request via the directdl cache,
# so links never go stale regardless of how long VLC has been open.

import hmac

# Secret key for signing tokens — generated once per process lifetime.
# Tokens are deterministic per (hash, filename) so they survive restarts as long
# as the same secret is used. We store it in config so it persists across restarts.
def _get_token_secret() -> str:
    cfg = _load_config()
    if "token_secret" not in cfg:
        cfg["token_secret"] = secrets.token_hex(32)
        _save_config(cfg)
    return cfg["token_secret"]

_TOKEN_SECRET: str = ""

def _make_stream_token(hash_: str, filename: str) -> str:
    """Generate a deterministic token for (hash, filename) — survives restarts."""
    global _TOKEN_SECRET
    if not _TOKEN_SECRET:
        _TOKEN_SECRET = _get_token_secret()
    payload = f"{hash_}:{filename}"
    return hmac.new(_TOKEN_SECRET.encode(), payload.encode(), "sha256").hexdigest()

def _verify_stream_token(token: str, hash_: str, filename: str) -> bool:
    expected = _make_stream_token(hash_, filename)
    return hmac.compare_digest(token, expected)

# ── directdl cache ────────────────────────────────────────────────────────────
# Shared cache so the stream proxy doesn't call directdl on every chunk read.
# TTL matches the FUSE layer (30 min). Automatically refreshed on expiry.

_DIRECTDL_TTL    = 172800  # 48 hours — CDN URLs are long-lived; minimise directdl API calls
_DIRECTDL_MARGIN = 300   # refresh in the background once within 5 min of expiry
_directdl_cache: dict = {}  # hash → (files: list, expires_at: float)
_directdl_lock  = threading.Lock()
_directdl_refreshing: set = set()  # hashes with an in-flight background refresh


def _spawn_directdl_refresh(hash_: str, name: str) -> None:
    """Re-mint CDN links in the background so an active stream never blocks."""
    with _directdl_lock:
        if hash_ in _directdl_refreshing:
            return
        _directdl_refreshing.add(hash_)

    def _do():
        try:
            files = _directdl_for_manager_raw(hash_, name)
            if files:
                with _directdl_lock:
                    _directdl_cache[hash_] = (files, time.time() + _DIRECTDL_TTL)
        except Exception:
            app.logger.warning(f"[directdl {hash_[:8]}] background refresh failed")
        finally:
            with _directdl_lock:
                _directdl_refreshing.discard(hash_)

    _import_pool.submit(_do)


def _get_directdl(hash_: str, name: str, force: bool = False) -> list:
    """
    Return directdl file list, refreshing from Premiumize as needed.

    - force=True bypasses the cache and overwrites it with a fresh result —
      used when a CDN URL has been observed to expire (403/410).
    - Otherwise this is stale-while-revalidate: a fresh entry is returned
      directly; an entry inside the refresh margin is returned immediately while
      a background thread re-mints the links, so reads never wait on the network.
    """
    now = time.time()
    if not force:
        with _directdl_lock:
            cached = _directdl_cache.get(hash_)
        if cached:
            files, expires_at = cached
            if now < expires_at - _DIRECTDL_MARGIN:
                return files                      # comfortably fresh
            if now < expires_at:
                _spawn_directdl_refresh(hash_, name)  # refresh ahead of expiry
                return files                      # current link is still valid
            # hard-expired → fall through to a synchronous fetch
    # Cache miss, expired, or forced — fetch fresh
    files = _directdl_for_manager_raw(hash_, name)
    if files:
        with _directdl_lock:
            _directdl_cache[hash_] = (files, now + _DIRECTDL_TTL)
    return files

# ── persistent config ─────────────────────────────────────────────────────────

CONFIG_PATH = os.environ.get("CONFIG_PATH", "/app/config.json")
_config_lock = threading.Lock()
_config_cache: dict | None = None   # in-memory copy, None = not yet loaded

def _load_config() -> dict:
    global _config_cache
    if _config_cache is not None:
        return _config_cache
    try:
        with open(CONFIG_PATH) as f:
            _config_cache = json.load(f)
    except Exception:
        _config_cache = {}
    return _config_cache

def _save_config(cfg: dict):
    global _config_cache
    os.makedirs(os.path.dirname(CONFIG_PATH) or ".", exist_ok=True)
    with _config_lock:
        _config_cache = cfg          # update cache before write
        with open(CONFIG_PATH, "w") as f:
            json.dump(cfg, f, indent=2)

def get_prowlarr_config() -> dict:
    saved = _load_config().get("prowlarr", {})
    # Env vars take precedence if set, otherwise fall back to saved config
    return {
        "url":     PROWLARR_URL or saved.get("url", ""),
        "api_key": PROWLARR_KEY or saved.get("api_key", ""),
        "from_env": bool(PROWLARR_URL or PROWLARR_KEY),
    }

def save_prowlarr_config(url: str, api_key: str):
    url = url.strip().rstrip("/")
    if url and not url.startswith(("http://", "https://")):
        url = "http://" + url
    cfg = _load_config()
    cfg["prowlarr"] = {"url": url, "api_key": api_key}
    _save_config(cfg)

# ── static config ─────────────────────────────────────────────────────────────

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

PM_BASE          = "https://www.premiumize.me/api"
PM_CACHE         = f"{PM_BASE}/cache/check"
PM_DIRECTDL      = f"{PM_BASE}/transfer/directdl"
PM_TRANSFER      = f"{PM_BASE}/transfer/create"
PM_TRANSFER_LIST = f"{PM_BASE}/transfer/list"
PM_ACCOUNT       = f"{PM_BASE}/account/info"

PM_API_KEY_ENV = os.environ.get("PREMIUMIZE_API_KEY", "")
TORZNAB_APIKEY = os.environ.get("TORZNAB_APIKEY", "changeme")
PROWLARR_URL   = os.environ.get("PROWLARR_URL", "")
PROWLARR_KEY   = os.environ.get("PROWLARR_API_KEY", "")

def get_pm_api_key() -> str:
    """Return PM API key — env var takes precedence, then saved config."""
    if PM_API_KEY_ENV:
        return PM_API_KEY_ENV
    return _load_config().get("pm_api_key", "")

def save_pm_api_key(key: str):
    cfg = _load_config()
    cfg["pm_api_key"] = key
    _save_config(cfg)

# Module-level alias kept for backwards compat with code that reads PM_API_KEY directly.
# Use get_pm_api_key() wherever the key is needed so it picks up saved values.
PM_API_KEY = property(get_pm_api_key) if False else get_pm_api_key()

# Torznab rate limit: requests per window
TORZNAB_RATE_LIMIT  = int(os.environ.get("TORZNAB_RATE_LIMIT", "60"))   # max requests
TORZNAB_RATE_WINDOW = int(os.environ.get("TORZNAB_RATE_WINDOW", "60"))  # per N seconds

# ── torznab rate limiter (sliding window per IP) ──────────────────────────────

_rate_lock = threading.Lock()
_rate_data: dict[str, list] = defaultdict(list)  # ip -> [timestamps]

def _check_rate_limit(ip: str) -> tuple[bool, int, int, int]:
    """Returns (allowed, limit, remaining, reset_ts)"""
    now = time.time()
    window_start = now - TORZNAB_RATE_WINDOW
    with _rate_lock:
        hits = [t for t in _rate_data[ip] if t > window_start]
        remaining = max(0, TORZNAB_RATE_LIMIT - len(hits))
        reset_ts = int(now + TORZNAB_RATE_WINDOW)
        if remaining == 0:
            return False, TORZNAB_RATE_LIMIT, 0, reset_ts
        hits.append(now)
        _rate_data[ip] = hits
        return True, TORZNAB_RATE_LIMIT, remaining - 1, reset_ts

def _rate_headers(limit: int, remaining: int, reset_ts: int) -> dict:
    return {
        "X-RateLimit-Limit":     str(limit),
        "X-RateLimit-Remaining": str(remaining),
        "X-RateLimit-Reset":     str(reset_ts),
    }

# ── category maps ─────────────────────────────────────────────────────────────

def tpb_to_newznab(tpb_cat, name=""):
    name_up = name.upper()
    if re.search(r'S\d{2}E\d{2}|SEASON\s+\d+|\bS\d{2}\b', name_up):
        return 5000
    try:
        c = int(tpb_cat)
    except Exception:
        return 8000
    if 200 <= c < 300: return 2000
    if 500 <= c < 600: return 5000
    if 300 <= c < 400: return 3000
    return 8000

# ── helpers ───────────────────────────────────────────────────────────────────

QUALITY_PATTERNS = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE
)

def fmt_size(b):
    try: return int(b)
    except Exception: return 0

def fmt_size_str(b):
    try: b = int(b)
    except Exception: return "?"
    if b > 1_000_000_000: return f"{b/1_000_000_000:.2f} GB"
    if b > 1_000_000:     return f"{b/1_000_000:.0f} MB"
    if b > 1_000:         return f"{b/1_000:.0f} KB"
    return f"{b} B"

def _sanitize(query):
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()

def parse_query(raw):
    quality = QUALITY_PATTERNS.findall(raw)
    search_raw = QUALITY_PATTERNS.sub('', raw).strip()
    season, episode = None, None
    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        search_raw = re.sub(r'\bseason\s+\d+\b', f'S{season:02d}', search_raw, flags=re.IGNORECASE)
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return ' '.join(search_raw.split()).strip(), season, episode, quality

def strip_season(query):
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', '', query, flags=re.IGNORECASE)
    return ' '.join(t.split())

def filter_by_season(torrents, season, episode):
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        if episode is not None and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out

def filter_by_quality(torrents, quality):
    if not quality:
        return torrents
    out = []
    for t in torrents:
        name_up = t.get("name", "").upper()
        for q in quality:
            if q.upper().rstrip('P') in name_up:
                out.append(t)
                break
    return out if out else torrents

# ── TPB fetch ─────────────────────────────────────────────────────────────────

def _fetch_tpb(query, limit=40):
    queries = [query]
    sanitized = _sanitize(query)
    if sanitized.lower() != query.lower():
        queries.append(sanitized)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = requests.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict)
                    and x.get("info_hash")
                    and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
                ]
                if valid:
                    return valid[:limit]
            except Exception:
                continue
    return []

# ── Prowlarr fetch ────────────────────────────────────────────────────────────

def _fetch_prowlarr(query: str, season=None, episode=None, limit=40) -> list:
    """Search Prowlarr and return normalised torrent dicts."""
    cfg = get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"):
        return []

    base = cfg["url"]
    key  = cfg["api_key"]

    # Build query string. Strip any season/episode token the caller may already
    # have baked into `query` before re-adding the canonical one, so we never
    # emit a doubled term like "Spongebob S15 S15".
    q = query
    if season is not None:
        q_base = strip_season(query)
        q = f"{q_base} S{season:02d}" if q_base else f"S{season:02d}"
        if episode is not None:
            q += f"E{episode:02d}"
        q = " ".join(q.split())

    params = {
        "query":      q,
        "indexerIds": -2,     # all torrent indexers
        "categories": [2000, 5000, 8000],
        "type":       "search",
        "limit":      limit,
    }

    try:
        r = requests.get(
            f"{base}/api/v1/search",
            headers={"X-Api-Key": key},
            params=params,
            timeout=20,
        )
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        app.logger.warning(f"Prowlarr search failed: {e}")
        return []

    def _extract_hash(item: dict) -> str:
        """Return a 40-char hex info_hash from the result, trying multiple fields."""
        # 1. Direct infoHash field (ideal case)
        h = (item.get("infoHash") or "").lower().strip()
        if re.fullmatch(r'[0-9a-fA-F]{40}', h):
            return h

        # 2. Scan all URL-like fields for a hash in any position:
        #    - magnet: btih:<hash>
        #    - https://site.com/<HASH>/title  (e.g. TorrentDownload guid)
        #    - base32 btih variant
        for field in ("magnetUrl", "downloadUrl", "guid"):
            val = item.get(field) or ""
            # btih: prefix (magnets)
            m = re.search(r'btih:([0-9a-fA-F]{40})', val, re.IGNORECASE)
            if m:
                return m.group(1).lower()
            # bare 40-char hex segment anywhere in the URL path/query
            m = re.search(r'(?<![0-9a-fA-F])([0-9a-fA-F]{40})(?![0-9a-fA-F])', val)
            if m:
                return m.group(1).lower()
            # base32 btih (32 uppercase chars)
            m32 = re.search(r'btih:([A-Z2-7]{32})', val, re.IGNORECASE)
            if m32:
                try:
                    import base64
                    raw = base64.b32decode(m32.group(1).upper())
                    candidate = raw.hex()
                    if re.fullmatch(r'[0-9a-f]{40}', candidate):
                        return candidate
                except Exception:
                    pass

        return ""

    def _prowlarr_category(item: dict) -> int:
        """
        Map a Prowlarr result to a top-level newznab category (2000/5000/8000).

        Prowlarr often returns subcategory IDs like 5030, 5040, 2040, etc.
        The category filter uses integer division (cat // 1000) to match, but
        the raw sub-ID must still be a recognised newznab ID range.
        We also fall back to name-based detection when the categories list is
        missing or contains an unrecognised ID (e.g. 0 from showRSS).
        """
        cats = item.get("categories") or []
        name = item.get("title", "")

        for c in cats:
            cid = c.get("id", 0) if isinstance(c, dict) else int(c or 0)
            if 2000 <= cid < 3000:
                return cid   # Movies (sub or parent — filter uses // 1000)
            if 5000 <= cid < 6000:
                return cid   # TV
            if 8000 <= cid < 9000:
                return cid   # Other

        # No usable newznab ID — infer from title
        if re.search(r'\bS\d{1,2}(?:E\d{1,2})?\b|\bSeason\s*\d+\b|\b\d{1,2}x\d{2}\b', name, re.IGNORECASE):
            return 5000
        return 8000

    results = []
    skipped = 0
    for item in data:
        info_hash = _extract_hash(item)
        if not info_hash:
            skipped += 1
            continue
        # Extract tracker list from the original magnet guid if present,
        # so downstream clients with DHT disabled can still use the magnet.
        trackers = []
        guid_val = item.get("guid") or ""
        if "btih:" in guid_val.lower():
            trackers = re.findall(r'[&?]tr=([^&]+)', guid_val)
        # Also check magnetUrl
        mag_val = item.get("magnetUrl") or ""
        if "btih:" in mag_val.lower() and not trackers:
            trackers = re.findall(r'[&?]tr=([^&]+)', mag_val)

        results.append({
            "info_hash": info_hash,
            "name":      item.get("title", "Unknown"),
            "size":      item.get("size", 0),
            "seeders":   item.get("seeders", 0) or 0,
            "leechers":  item.get("leechers", 0) or 0,
            "category":  _prowlarr_category(item),
            "indexer":   item.get("indexer", ""),
            "trackers":  trackers,
        })

    if skipped:
        app.logger.debug(f"Prowlarr: skipped {skipped} results with no extractable hash")

    return results

# ── Premiumize helpers ────────────────────────────────────────────────────────

def _make_magnet(torrent):
    h    = torrent["info_hash"].lower()
    name = urllib.parse.quote(torrent.get("name", ""), safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={name}"

def pm_headers(api_key):
    return {"Authorization": f"Bearer {api_key}"}

def check_cache_pm(api_key, torrents):
    if not torrents:
        return {}
    hashes = [t["info_hash"].lower() for t in torrents]
    headers = {**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"}
    try:
        r = requests.post(
            PM_CACHE,
            headers=headers,
            data=urllib.parse.urlencode([("items[]", h) for h in hashes]),
            timeout=15,
        )
        r.raise_for_status()
        data = r.json()
    except Exception:
        return {}
    if data.get("status") != "success":
        return {}
    responses = data.get("response", [])
    return {h: bool(responses[i]) if i < len(responses) else False
            for i, h in enumerate(hashes)}

# ── unified search ────────────────────────────────────────────────────────────

def do_search(query, season=None, episode=None, quality=None, limit=40, pm_key=None):
    # Try Prowlarr first, fall back to TPB
    prowlarr_cfg = get_prowlarr_config()
    if prowlarr_cfg.get("url") and prowlarr_cfg.get("api_key"):
        torrents = _fetch_prowlarr(query, season, episode, limit)
        source = "prowlarr"
    else:
        torrents = []
        source = "tpb"

    if not torrents:
        torrents = _fetch_tpb(query, limit)
        source = "tpb"
        if not torrents and season is not None:
            fallback = strip_season(query)
            if fallback and fallback.lower() != query.lower():
                torrents = _fetch_tpb(fallback, limit * 2)

    if not torrents:
        return []

    if source == "tpb":
        torrents = filter_by_season(torrents, season, episode)
        if not torrents and season is not None:
            torrents = _fetch_tpb(query, limit)
        if quality:
            torrents = filter_by_quality(torrents, quality)

    ready_map = check_cache_pm(pm_key, torrents) if pm_key else {}

    results = []
    seen = set()
    for t in torrents:
        h = t["info_hash"].lower()
        if h in seen:
            continue
        seen.add(h)
        cat = t.get("category", 8000)
        # Normalise TPB category numbers to newznab IDs
        if isinstance(cat, int) and cat < 1000:
            cat = tpb_to_newznab(cat, t.get("name", ""))
        results.append({
            "hash":     h,
            "name":     t.get("name", "Unknown"),
            "size":     fmt_size(t.get("size", 0)),
            "size_str": fmt_size_str(t.get("size", 0)),
            "seeders":  int(t.get("seeders", 0) or 0),
            "leechers": int(t.get("leechers", 0) or 0),
            "category": cat,
            "cached":   ready_map.get(h, False),
            "indexer":  t.get("indexer", "TPB"),
            "trackers": t.get("trackers", []),
        })

    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results

# ── Torznab XML ───────────────────────────────────────────────────────────────

def torznab_caps():
    return '''<?xml version="1.0" encoding="UTF-8"?>
<caps>
  <server title="Premiumize Indexer" />
  <limits default="40" max="100"/>
  <searching>
    <search available="yes" supportedParams="q"/>
    <tv-search available="yes" supportedParams="q,season,ep"/>
    <movie-search available="yes" supportedParams="q"/>
  </searching>
  <categories>
    <category id="2000" name="Movies">
      <subcat id="2010" name="Movies/Foreign"/>
      <subcat id="2020" name="Movies/Other"/>
      <subcat id="2030" name="Movies/SD"/>
      <subcat id="2040" name="Movies/HD"/>
      <subcat id="2045" name="Movies/UHD"/>
      <subcat id="2050" name="Movies/BluRay"/>
      <subcat id="2060" name="Movies/3D"/>
      <subcat id="2070" name="Movies/DVD"/>
      <subcat id="2080" name="Movies/WEB-DL"/>
    </category>
    <category id="5000" name="TV">
      <subcat id="5040" name="TV/HD"/>
      <subcat id="5045" name="TV/UHD"/>
      <subcat id="5030" name="TV/SD"/>
      <subcat id="5010" name="TV/WEB-DL"/>
    </category>
    <category id="8000" name="Other"/>
  </categories>
</caps>'''

# Well-known public trackers appended to every magnet as a fallback so
# clients with DHT disabled can still connect. Indexer-supplied trackers
# (from the Prowlarr result) are prepended and take precedence.
_FALLBACK_TRACKERS = [
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.tracker.cl:1337/announce",
    "udp://tracker.openbittorrent.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce",
    "udp://explodie.org:6969/announce",
]

def torznab_results(results, query=""):
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items = []
    for r in results:
        # Build magnet with trackers so clients with DHT disabled can use it
        trackers = r.get("trackers") or []
        all_trackers = list(dict.fromkeys(trackers + _FALLBACK_TRACKERS))  # dedup, indexer first
        tr_params = "".join(f"&tr={urllib.parse.quote(t, safe='')}" for t in all_trackers)
        magnet = f"magnet:?xt=urn:btih:{r['hash']}&dn={urllib.parse.quote(r['name'], safe='')}{tr_params}"
        cached_attr = '<torznab:attr name="cached" value="1"/>' if r.get("cached") else ''
        items.append(f"""    <item>
      <title>{xml_escape(r['name'])}</title>
      <guid>{xml_escape(magnet)}</guid>
      <link>{xml_escape(magnet)}</link>
      <pubDate>{now}</pubDate>
      <size>{r['size']}</size>
      <enclosure url="{xml_escape(magnet)}" length="{r['size']}" type="application/x-bittorrent"/>
      <torznab:attr name="magneturl" value="{xml_escape(magnet)}"/>
      <torznab:attr name="infohash" value="{r['hash']}"/>
      <torznab:attr name="seeders" value="{r['seeders']}"/>
      <torznab:attr name="leechers" value="{r['leechers']}"/>
      <torznab:attr name="size" value="{r['size']}"/>
      <torznab:attr name="category" value="{r['category']}"/>
      {cached_attr}
    </item>""")
    items_xml = "\n".join(items)
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <channel>
    <title>Premiumize Indexer</title>
    <description>TPB/Prowlarr via Premiumize cache check</description>
    <link>http://localhost</link>
    <language>en-US</language>
    <pubDate>{now}</pubDate>
    <response xmlns="urn:newznab:api" offset="0" total="{len(results)}"/>
{items_xml}
  </channel>
</rss>'''

def xml_error(code, description, extra_headers=None):
    r = Response(
        f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="{code}" description="{xml_escape(description)}"/>''',
        mimetype="application/xml", status=400
    )
    if extra_headers:
        for k, v in extra_headers.items():
            r.headers[k] = v
    return r

# ── routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    resp = render_template("index.html")
    from flask import make_response
    r = make_response(resp)
    r.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    return r

# Torznab — with rate limiting
@app.route("/torznab")
@app.route("/torznab/api")
def torznab():
    t = request.args.get("t", "").lower()

    # Caps is always public — Prowlarr probes it without a key
    if t == "caps":
        return Response(torznab_caps(), mimetype="application/xml")

    # API key check for all other requests
    apikey = request.args.get("apikey", "") or request.headers.get("X-Api-Key", "")
    if TORZNAB_APIKEY and apikey != TORZNAB_APIKEY:
        return xml_error(100, "Invalid API key")

    # Rate limit by IP
    ip = request.headers.get("X-Forwarded-For", request.remote_addr).split(",")[0].strip()
    allowed, limit, remaining, reset_ts = _check_rate_limit(ip)
    rh = _rate_headers(limit, remaining, reset_ts)

    if not allowed:
        retry_after = reset_ts - int(time.time())
        r = Response(
            f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="429" description="Rate limit exceeded. Retry after {retry_after}s"/>''',
            mimetype="application/xml", status=429,
            headers={**rh, "Retry-After": str(retry_after)},
        )
        return r

    if t in ("search", "tvsearch", "movie"):
        q      = request.args.get("q", "").strip()
        season = request.args.get("season", "").strip()
        ep     = request.args.get("ep", "").strip()
        cat    = request.args.get("cat", "").strip()

        app.logger.info(f"Torznab {t}: q={q!r} season={season!r} ep={ep!r} cat={cat!r}")

        # Parse season/ep from the explicit Torznab params (sent by Sonarr/Radarr).
        # Do NOT bake them into the query string — _fetch_prowlarr rebuilds the
        # query itself, and parse_query below also extracts them from q.
        # Baking them in first caused doubled tokens like "SpongeBob S15 S15".
        parsed_s, parsed_ep = None, None
        if season:
            try:
                parsed_s = int(season)
                if ep:
                    parsed_ep = int(ep)
            except ValueError:
                pass
        query = q  # raw title only; season/ep passed as separate numeric params

        # Empty query — return cached library items for the requested category.
        # This satisfies Radarr/Sonarr connection tests and browse calls.
        # Falls back to TPB if the library is empty so the connection test passes.
        if not query:
            all_transfers = _transfer_manager.all_transfers()
            streamable    = [t for t in all_transfers if t["state"] in ("cached", "complete")]
            fb_results    = []
            for t in streamable:
                h    = t["hash"]
                name = t.get("name") or h
                is_series = bool(re.search(
                    r'\bS\d{1,2}(?:E\d{1,2})?\b|\bSeason\s*\d+\b|\b\d{1,2}x\d{2}\b',
                    name, re.IGNORECASE))
                item_cat = 5000 if is_series else 2000
                fb_results.append({
                    "hash":     h,
                    "name":     name,
                    "size":     0,
                    "size_str": "",
                    "seeders":  1,
                    "leechers": 0,
                    "category": item_cat,
                    "cached":   True,
                    "indexer":  "premiumize",
                    "trackers": [],  # fallback trackers added by torznab_results
                })

            # Filter by requested category
            if cat and cat != "0":
                requested = [int(c) for c in cat.split(",") if c.strip().isdigit() and c.strip() != "0"]
                if requested:
                    filtered = [r for r in fb_results if any(
                        r["category"] == rc or r["category"] // 1000 == rc // 1000
                        for rc in requested
                    )]
                    if filtered:
                        fb_results = filtered

            # Fall back to TPB if library is empty or category filter left nothing
            if not fb_results:
                raw = _fetch_tpb("1080p", 20)
                for ti in raw:
                    h       = ti["info_hash"].lower()
                    ti_cat  = tpb_to_newznab(ti.get("category", 0), ti.get("name", ""))
                    fb_results.append({
                        "hash":     h,
                        "name":     ti.get("name", "Unknown"),
                        "size":     fmt_size(ti.get("size", 0)),
                        "size_str": fmt_size_str(ti.get("size", 0)),
                        "seeders":  int(ti.get("seeders", 0) or 0),
                        "leechers": int(ti.get("leechers", 0) or 0),
                        "category": ti_cat,
                        "cached":   False,
                        "indexer":  "TPB",
                    })

            resp = Response(torznab_results(fb_results, ""), mimetype="application/xml")
            for k, v in rh.items():
                resp.headers[k] = v
            return resp

        parsed_q, ps, pe, quality = parse_query(query)
        parsed_s = parsed_s or ps
        parsed_ep = parsed_ep or pe

        results = do_search(parsed_q, parsed_s, parsed_ep, quality, limit=40, pm_key=get_pm_api_key())

        # Filter to cached-only if explicitly enabled in config (default: off)
        # When enabled AND there are cached results, restrict to cached only.
        # We intentionally do NOT fall back silently — if cached_only is on and
        # nothing is cached, return everything so Prowlarr doesn't think the
        # indexer is broken. The UI toggle should be used deliberately.
        if _load_config().get("torznab_cached_only", False):
            cached = [r for r in results if r.get("cached")]
            if cached:
                results = cached
            else:
                app.logger.debug("torznab_cached_only enabled but no cached results — returning all")

        if cat and cat != "0":
            requested = [int(c) for c in cat.split(",") if c.strip().isdigit() and c.strip() != "0"]
            if requested:
                filtered = [r for r in results if any(
                    r["category"] == rc or r["category"] // 1000 == rc // 1000
                    for rc in requested
                )]
                if filtered:
                    results = filtered

        resp = Response(torznab_results(results, q), mimetype="application/xml")
        for k, v in rh.items():
            resp.headers[k] = v
        return resp

    app.logger.warning(f"Unknown torznab function: {t!r}")
    return xml_error(202, f"Unknown function: {t}", rh)

# Web UI — search
@app.route("/api/search", methods=["POST"])
def search():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_pm_api_key()
    query   = data.get("query", "").strip()

    if not api_key:
        return jsonify({"error": "API key required"}), 400
    if not query:
        return jsonify({"error": "Query required"}), 400

    parsed_q, season, episode, quality = parse_query(query)
    results = do_search(parsed_q, season, episode, quality, limit=40, pm_key=api_key)

    return jsonify({
        "results": [{**r, "size": r["size_str"]} for r in results],
        "total":   len(results),
        "source":  "prowlarr" if get_prowlarr_config().get("url") else "tpb",
    })

# Web UI — add to transfer manager (cached → FUSE instantly, uncached → download then FUSE)
@app.route("/api/add", methods=["POST"])
def add():
    data      = request.json or {}
    hash_     = data.get("hash", "").strip().lower()
    name      = data.get("name", "").strip()
    is_cached = data.get("cached", None)  # passed from frontend search results

    if not hash_:
        return jsonify({"error": "hash required"}), 400

    # If frontend already knows it's cached, write the state directly so it
    # appears in the FUSE mount immediately without an extra round-trip to the
    # Premiumize cache-check API.
    # FIX: always persist the real human-readable name so the FUSE directory
    # gets a proper title instead of the raw hash. Also use _set only for the
    # state transition so we don't race with the poller on existing entries.
    if is_cached is True:
        existing = _transfer_manager.get_transfer(hash_)
        if not existing:
            _transfer_manager._set(hash_, name=name or hash_, state="cached",
                                   added_at=time.time())
        else:
            # Always update name if we now have a better one
            updates = {}
            if name and existing.get("name") in (None, "", existing["hash"]):
                updates["name"] = name
            if existing["state"] not in ("cached", "complete"):
                updates["state"] = "cached"
            if updates:
                _transfer_manager._set(hash_, **updates)
        t = _transfer_manager.get_transfer(hash_)
    else:
        t = _transfer_manager.add(hash_, name)

    # ── Auto-import into Radarr/Sonarr ────────────────────────────────────────
    # Fire-and-forget in background so the response returns immediately.
    # Determines 4K vs HD from the name, picks the right instance, and
    # adds the movie/series if not already present, then creates a fake file.
    def _auto_import_to_arr(hash_: str, name: str):
        try:
            instances = _get_sync_config().get("instances", [])
            if not instances:
                return

            from qbt_mock import (_make_fake_file, _pick_fake_filename,
                                   _safe_name, _RES_PATTERNS)

            # Detect 4K from name
            is_4k = bool(next((p for _, p in _RES_PATTERNS
                                if _.startswith("2") and p.search(name)), None))

            # Detect series from name using the shared name_match module
            from name_match import is_series as _is_series
            is_series = _is_series(name)

            # Pick matching instances:
            # - type must match (radarr/sonarr)
            # - quality="any" instances accept both HD and 4K
            # - quality="4k" instances only get 4K content
            # - quality="hd" instances only get HD content
            arr_type     = "sonarr" if is_series else "radarr"
            quality_tier = "4k" if is_4k else "hd"

            targets = [i for i in instances
                       if i.get("type") == arr_type
                       and i.get("quality", "hd") in (quality_tier, "any")
                       and i.get("url") and i.get("key")]

            if not targets:
                return

            import requests as _req_mod

            for inst in targets:
                base_url = inst["url"].rstrip("/")
                api_key  = inst["key"]
                headers  = {"X-Api-Key": api_key, "Content-Type": "application/json"}

                try:
                    # Get quality profile and root folder
                    qp_resp = _req_mod.get(f"{base_url}/api/v3/qualityProfile",
                                           headers=headers, timeout=8).json()
                    quality_id = qp_resp[0]["id"] if isinstance(qp_resp, list) and qp_resp else 1

                    rf_resp = _req_mod.get(f"{base_url}/api/v3/rootFolder",
                                           headers=headers, timeout=8).json()
                    root_path = rf_resp[0]["path"].rstrip("/") if isinstance(rf_resp, list) and rf_resp else (
                        "/tv" if is_series else "/movies")

                    if is_series:
                        # Extract series name — strip episode/season info and quality tags
                        # Handle patterns like:
                        #   Friends.S10E01.1080p           → "Friends"
                        #   Friends (1994) Season 1-10     → "Friends"
                        #   BEEF S02E01 1080p WEB          → "BEEF"
                        #   The.Bear.S03E01.720p.WEB       → "The Bear"
                        #   Abbott.Elementary.S02.Complete → "Abbott Elementary"
                        series_raw = name
                        # Replace dots/underscores between words with spaces FIRST
                        # (only between word chars, not things like "S01.E01")
                        series_raw = _re.sub(r'(?<=[A-Za-z0-9])\.(?=[A-Za-z0-9])', ' ', series_raw)
                        series_raw = series_raw.replace('_', ' ')
                        # Strip multi-season range: S01-S10, S01-S09, etc.
                        series_raw = _re.sub(r'\bS\d{1,2}[-–]\s*S?\d{1,2}\b.*', '', series_raw, flags=_re.IGNORECASE)
                        # Strip Season N-N range
                        series_raw = _re.sub(r'\bSeason\s*\d+[-–]\d+\b.*', '', series_raw, flags=_re.IGNORECASE)
                        # Strip SxxExx or Season N or Sxx (season-only marker)
                        series_raw = _re.sub(r'\bS\d{1,2}(?:E\d{1,3}(?:[-–]E?\d{1,3})?)?\b.*', '', series_raw, flags=_re.IGNORECASE)
                        series_raw = _re.sub(r'\bSeason\s*\d+\b.*', '', series_raw, flags=_re.IGNORECASE)
                        # Grab year if present (before quality strip swallows it)
                        series_year = None
                        m_year = _re.search(r'\((\d{4})\)', series_raw)
                        if m_year:
                            series_year = m_year.group(1)
                            series_raw = series_raw[:m_year.start()] + series_raw[m_year.end():]
                        if not series_year:
                            m_yr2 = _re.search(r'\b(19|20)(\d{2})\b', series_raw)
                            if m_yr2:
                                series_year = m_yr2.group(0).strip()
                                series_raw = series_raw[:m_yr2.start()] + series_raw[m_yr2.end():]
                        # Strip quality/codec tags and everything after
                        series_raw = _re.sub(
                            r'\b(2160[ip]?|1080[ip]?|720[ip]?|480[ip]?|576[ip]?|4k|uhd|hdr|hdr10|'
                            r'bluray|blu[-\s]?ray|web[-\s]?dl|webrip|hdtv|x264|x265|hevc|avc|'
                            r'h264|h265|10bit|remux|proper|repack|complete|extended|theatrical)\b.*',
                            '', series_raw, flags=_re.IGNORECASE
                        )
                        series_raw = series_raw.strip(' -–')

                        # Check if already in Sonarr — match by normalized title
                        def _norm_title(s):
                            return _re.sub(r'[^a-z0-9]', '', (s or '').lower())

                        existing_series = _req_mod.get(f"{base_url}/api/v3/series",
                                                        headers=headers, timeout=10).json()
                        existing_series = existing_series if isinstance(existing_series, list) else []
                        existing_norm   = {_norm_title(s.get("title") or ""): s
                                           for s in existing_series}

                        series_id   = None
                        series_norm = _norm_title(series_raw)

                        # Check existing library — try exact, then with year, then substring
                        if series_norm in existing_norm:
                            series_id = existing_norm[series_norm].get("id")
                        elif series_year:
                            norm_with_year = _norm_title(f"{series_raw} {series_year}")
                            if norm_with_year in existing_norm:
                                series_id = existing_norm[norm_with_year].get("id")
                        if not series_id:
                            # Substring match — handles "Abbott Elementary" matching
                            # "Abbott Elementary (2021)" stored in Sonarr
                            for norm_key, s_obj in existing_norm.items():
                                if series_norm in norm_key or norm_key in series_norm:
                                    series_id = s_obj.get("id")
                                    app.logger.info(f"[auto-import] Fuzzy match: '{series_raw}' → '{s_obj.get('title')}'")
                                    break
                        else:
                            # Search TVDB via Sonarr — include year for precision
                            search_term = f"{series_raw} {series_year}" if series_year else series_raw
                            search = _req_mod.get(f"{base_url}/api/v3/series/lookup",
                                                   headers=headers,
                                                   params={"term": search_term}, timeout=10)
                            results = search.json() if search.ok and isinstance(search.json(), list) else []

                            # Pick the result whose title most closely matches our extracted name.
                            # Prefer exact normalized match, then starts-with, then first result.
                            best = None
                            for r in results:
                                r_norm = _norm_title(r.get("title") or "")
                                if r_norm == series_norm:
                                    best = r
                                    break
                            if not best:
                                for r in results:
                                    r_norm = _norm_title(r.get("title") or "")
                                    if r_norm.startswith(series_norm) or series_norm.startswith(r_norm):
                                        best = r
                                        break
                            if not best and results:
                                # Last resort: check if the series year matches
                                if series_year:
                                    for r in results:
                                        if str(r.get("year") or "") == series_year:
                                            best = r
                                            break
                                if not best:
                                    best = results[0]

                            if best:
                                matched_title = best.get("title", series_raw)
                                app.logger.info(f"[auto-import] Matched '{series_raw}' → '{matched_title}'")
                                best["qualityProfileId"] = quality_id
                                best["rootFolderPath"]   = root_path
                                best["monitored"]        = True
                                best["monitorNewItems"]  = "all"
                                best["seasonFolder"]     = True
                                best["addOptions"]       = {"searchForMissingEpisodes": False,
                                                             "monitor": "future"}
                                resp = _req_mod.post(f"{base_url}/api/v3/series",
                                                     headers=headers, json=best, timeout=10)
                                if resp.status_code in (200, 201):
                                    series_id = resp.json().get("id")
                                    app.logger.info(f"[auto-import] Added series to {inst['name']}: {matched_title}")
                                elif resp.status_code == 400 and "already" in resp.text.lower():
                                    # Race — already exists, find it
                                    for s in existing_series:
                                        if _norm_title(s.get("title") or "") == _norm_title(matched_title):
                                            series_id = s.get("id")
                                            break

                        # Create fake file(s) and trigger Sonarr rescan.
                        # For season packs: create one file per episode so Sonarr
                        # can import each episode individually.
                        t_cat = inst.get("category") or "sonarr"
                        _transfer_manager._set(hash_, state="cached", category=t_cat, imported=0)
                        try:
                            real_files = _transfer_manager.get_files(hash_) or []
                        except Exception:
                            real_files = []

                        import re as _re2
                        # Detect season pack: has season but no episode number
                        ep_match     = _re2.search(r'S(\d{1,2})E(\d{1,3})', name, _re2.IGNORECASE)
                        season_match = _re2.search(r'S(\d{1,2})\b(?!E)', name, _re2.IGNORECASE)
                        is_season_pack = bool(season_match and not ep_match)

                        if is_season_pack and series_id:
                            season_num = int(season_match.group(1))
                            # Fetch episodes for this season from Sonarr
                            try:
                                eps_resp = _req_mod.get(f"{base_url}/api/v3/episode",
                                                         headers=headers,
                                                         params={"seriesId": series_id,
                                                                 "seasonNumber": season_num},
                                                         timeout=15)
                                season_eps = eps_resp.json() if eps_resp.ok and isinstance(eps_resp.json(), list) else []
                            except Exception:
                                season_eps = []

                            from qbt_mock import _detect_resolution as _det_res
                            res_tag = _det_res(name)
                            folder_name = _safe_name(name)
                            for ep in season_eps:
                                ep_num = ep.get("episodeNumber")
                                if not ep_num:
                                    continue
                                ep_filename = (f"{series_raw}.S{season_num:02d}E{ep_num:02d}"
                                               f".WEBRip-{res_tag}.mkv")
                                _make_fake_file(t_cat, folder_name, ep_filename, real_files)
                            app.logger.info(f"[auto-import] Created {len(season_eps)} episode stubs for S{season_num:02d}")
                        else:
                            # Single episode or no series_id — create one fake file
                            fake_fn = _pick_fake_filename(name, real_files)
                            _make_fake_file(t_cat, _safe_name(name), fake_fn, real_files)

                        if series_id:
                            try:
                                _req_mod.post(f"{base_url}/api/v3/command",
                                              headers=headers,
                                              json={"name": "RescanSeries", "seriesId": series_id},
                                              timeout=10)
                                app.logger.info(f"[auto-import] RescanSeries triggered for seriesId={series_id}")
                            except Exception as e:
                                app.logger.warning(f"[auto-import] RescanSeries failed: {e}")

                    else:
                        # Radarr — extract clean movie title + year
                        def _extract_movie_title_year(raw):
                            """Return (clean_title, year_str|None) from a release name."""
                            n = (raw or "").replace(".", " ").replace("_", " ")
                            # Find year (4-digit 19xx/20xx) — not at position 0
                            m_yr = _re.search(r"(?<!\d)(19|20)(\d{2})(?!\d)", n)
                            if m_yr:
                                yr = m_yr.group(0)
                                title = n[:m_yr.start()].strip(" -–")
                            else:
                                yr = None
                                # Strip quality/codec tags from end instead
                                title = _re.sub(
                                    r"\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|bluray|blu-ray|"
                                    r"web-?dl|webrip|hdtv|x264|x265|hevc|avc|remux|proper|repack"
                                    r"|10bit|extended|theatrical|directors\.cut|unrated)\b.*",
                                    "", n, flags=_re.IGNORECASE
                                ).strip(" -–")
                            # Collapse multiple spaces
                            title = _re.sub(r"\s+", " ", title).strip()
                            return title, yr

                        clean, movie_year = _extract_movie_title_year(name)

                        def _norm_title(s):
                            return _re.sub(r"[^a-z0-9]", "", (s or "").lower())

                        # Check if already in Radarr
                        existing_movies = _req_mod.get(f"{base_url}/api/v3/movie",
                                                        headers=headers, timeout=10).json()
                        existing_movies = existing_movies if isinstance(existing_movies, list) else []

                        movie_id = None
                        norm_clean = _norm_title(clean)
                        # Match by normalised title (and optionally year)
                        for m in existing_movies:
                            m_norm = _norm_title(m.get("title") or "")
                            yr_match = (not movie_year or str(m.get("year") or "") == movie_year)
                            if m_norm == norm_clean and yr_match:
                                movie_id = m.get("id")
                                break
                        if not movie_id:
                            # Looser match without year constraint
                            for m in existing_movies:
                                if _norm_title(m.get("title") or "") == norm_clean:
                                    movie_id = m.get("id")
                                    break

                        if not movie_id:
                            # Not in Radarr yet — search TMDB via Radarr
                            search_term = f"{clean} {movie_year}" if movie_year else clean
                            search = _req_mod.get(f"{base_url}/api/v3/movie/lookup",
                                                   headers=headers,
                                                   params={"term": search_term}, timeout=10)
                            results = search.json() if search.ok and isinstance(search.json(), list) else []
                            # Pick best result: prefer title+year exact match, then title match
                            best = None
                            for r in results:
                                if (_norm_title(r.get("title") or "") == norm_clean and
                                        (not movie_year or str(r.get("year") or "") == movie_year)):
                                    best = r
                                    break
                            if not best:
                                for r in results:
                                    if _norm_title(r.get("title") or "") == norm_clean:
                                        best = r
                                        break
                            if not best and results:
                                best = results[0]

                            if best:
                                matched_title = best.get("title", clean)
                                app.logger.info(f"[auto-import] Movie match '{clean}' → '{matched_title}'")
                                best["qualityProfileId"] = quality_id
                                best["rootFolderPath"]   = root_path
                                best["monitored"]        = False  # file provided — no need to search
                                best["addOptions"]       = {"searchForMovie": False}
                                resp = _req_mod.post(f"{base_url}/api/v3/movie",
                                                     headers=headers, json=best, timeout=10)
                                if resp.status_code in (200, 201):
                                    movie_id = resp.json().get("id")
                                    app.logger.info(f"[auto-import] Added movie to {inst['name']}: {matched_title}")
                                elif resp.status_code == 400 and "already" in resp.text.lower():
                                    for m in existing_movies:
                                        if _norm_title(m.get("title") or "") == _norm_title(matched_title):
                                            movie_id = m.get("id")
                                            break

                        # Create fake file and trigger rescan
                        t_cat = inst.get("category") or "radarr"
                        _transfer_manager._set(hash_, state="cached", category=t_cat, imported=0)
                        try:
                            real_files = _transfer_manager.get_files(hash_) or []
                        except Exception:
                            real_files = []
                        fake_fn = _pick_fake_filename(name, real_files)
                        _make_fake_file(t_cat, _safe_name(name), fake_fn, real_files)
                        if movie_id:
                            try:
                                _req_mod.post(f"{base_url}/api/v3/command",
                                              headers=headers,
                                              json={"name": "RescanMovie", "movieId": movie_id},
                                              timeout=10)
                            except Exception:
                                pass

                except Exception as e:
                    app.logger.warning(f"[auto-import] Error for {inst.get('name')}: {e}")

        except Exception as e:
            app.logger.warning(f"[auto-import] Outer error: {e}")

    _import_pool.submit(_auto_import_to_arr, hash_, name)

    return jsonify({
        "name":  t.get("name", name) if t else name,
        "hash":  hash_,
        "state": t.get("state") if t else "queued",
    })

# Web UI — direct links for play/download
@app.route("/api/links", methods=["POST"])
def get_links():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_pm_api_key()
    hash_   = data.get("hash", "").strip().lower()
    name    = data.get("name", "").strip()

    if not api_key or not hash_:
        return jsonify({"error": "api_key and hash required"}), 400

    magnet = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
    try:
        r = requests.post(
            PM_DIRECTDL,
            headers={**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"src": magnet}),
            timeout=30,
        )
        r.raise_for_status()
        data_r = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    if data_r.get("status") != "success":
        return jsonify({"error": data_r.get("message", "Could not generate links")}), 400

    content = data_r.get("content", [])
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}

    links = []
    for item in content:
        path = item.get("path", "")
        file_name = path.split("/")[-1] if "/" in path else path
        ext = os.path.splitext(file_name)[1].lower()
        cdn_url = item.get("link", "")
        token = _make_stream_token(hash_, file_name) if cdn_url else ""
        links.append({
            "name":       file_name or path,
            "path":       path,
            "link":       cdn_url,
            "size":       int(float(item.get("size", 0) or 0)),
            "is_video":   ext in video_exts,
            "stream_url": f"/api/stream/{token}?h={hash_}&f={urllib.parse.quote(file_name)}" if token else "",
        })

    if not links:
        return jsonify({"error": "No files found for this magnet"}), 404

    return jsonify({"links": links})

# Streaming proxy — resolves a fresh CDN URL on every request via the
# directdl cache, so links never go stale no matter how long VLC has been open.
@app.route("/api/stream/<token>")
def stream_proxy(token):
    # Token encodes hash and filename as query params, verified by HMAC
    hash_     = request.args.get("h", "").strip().lower()
    filename  = request.args.get("f", "").strip()

    if not hash_ or not filename:
        return jsonify({"error": "Missing parameters"}), 400

    if not _verify_stream_token(token, hash_, filename):
        return jsonify({"error": "Invalid stream token"}), 403

    def _resolve_cdn():
        files = _get_directdl(hash_, filename)
        for f in files:
            if f.get("name") == filename or f.get("path", "").endswith(filename):
                return f.get("link")
        return None

    cdn_url = _resolve_cdn()
    if not cdn_url:
        return jsonify({"error": "File not found"}), 404

    headers = {}
    if "Range" in request.headers:
        headers["Range"] = request.headers["Range"]

    try:
        upstream = requests.get(cdn_url, headers=headers, stream=True, timeout=30)
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    # CDN URL expired — invalidate cache and retry once with fresh URL
    if upstream.status_code in (403, 410):
        with _directdl_lock:
            _directdl_cache.pop(hash_, None)
        cdn_url = _resolve_cdn()
        if not cdn_url:
            return jsonify({"error": "Could not refresh CDN link"}), 502
        try:
            upstream = requests.get(cdn_url, headers=headers, stream=True, timeout=30)
        except requests.RequestException as e:
            return jsonify({"error": str(e)}), 502

    ext = os.path.splitext(filename)[1].lower()
    mime_map = {
        ".mp4": "video/mp4", ".mkv": "video/x-matroska",
        ".avi": "video/x-msvideo", ".mov": "video/quicktime",
        ".m4v": "video/mp4", ".ts": "video/mp2t",
        ".webm": "video/webm", ".wmv": "video/x-ms-wmv",
    }
    content_type = upstream.headers.get("Content-Type") or mime_map.get(ext, "application/octet-stream")

    resp_headers = {
        "Content-Type":  content_type,
        "Accept-Ranges": upstream.headers.get("Accept-Ranges", "bytes"),
    }
    if "Content-Length" in upstream.headers:
        resp_headers["Content-Length"] = upstream.headers["Content-Length"]
    if "Content-Range" in upstream.headers:
        resp_headers["Content-Range"] = upstream.headers["Content-Range"]

    def generate():
        for chunk in upstream.iter_content(chunk_size=1024 * 256):
            yield chunk

    return Response(generate(), status=upstream.status_code, headers=resp_headers)

# List streamable transfers — used by the Library tab
@app.route("/api/transfers")
def list_transfers():
    transfers = _transfer_manager.all_transfers()
    return jsonify({"transfers": [
        {"hash": t["hash"], "name": t["name"] or t["hash"],
         "state": t["state"], "kind": t.get("kind") or "",
         "category": t.get("category") or ""}
        for t in transfers
    ]})

# ── Classification overrides ──────────────────────────────────────────────────
# Stored in config as {"classification_overrides": {"<name_key>": {...}, ...}}
# _overrides_cache is the live in-memory copy — no disk read needed at call time.

_overrides_cache: dict | None = None   # None = not yet loaded

def _get_overrides() -> dict:
    global _overrides_cache
    if _overrides_cache is not None:
        return _overrides_cache
    _overrides_cache = _load_config().get("classification_overrides", {})
    return _overrides_cache

_RE_NONALNUM = re.compile(r'[^a-z0-9]')

def _override_key(name: str) -> str:
    """Normalised key: lowercase alphanumeric only."""
    return _RE_NONALNUM.sub('', (name or '').lower())

@app.route("/api/overrides", methods=["GET"])
def overrides_get():
    return jsonify(_get_overrides())

@app.route("/api/overrides", methods=["POST"])
def overrides_set():
    global _overrides_cache
    data = request.get_json(force=True) or {}
    name  = (data.get("name") or "").strip()
    kind  = data.get("kind", "")   # "movie" | "series" | "" (clear)
    if not name:
        return jsonify({"error": "name required"}), 400
    key = _override_key(name)
    cfg = _load_config()
    ov  = cfg.setdefault("classification_overrides", {})
    if kind in ("movie", "series"):
        ov[key] = {"kind": kind, "label": name}
    else:
        ov.pop(key, None)
    _overrides_cache = ov   # update in-memory cache immediately
    _save_config(cfg)

    # Invalidate the FUSE name map so the item moves folders immediately
    try:
        import fuse_mount as fm
        if fm._pfs is not None:
            fm._pfs._invalidate_name_map()
    except Exception:
        pass

    return jsonify({"ok": True, "key": key, "kind": kind})

# Remove a transfer
@app.route("/api/remove", methods=["POST"])
def remove_transfer():
    data  = request.json or {}
    hash_ = data.get("hash", "").strip().lower()
    if not hash_:
        return jsonify({"error": "hash required"}), 400
    _transfer_manager.delete(hash_)
    return jsonify({"ok": True})

# ── Backup / Restore ──────────────────────────────────────────────────────────

@app.route("/api/backup", methods=["GET"])
def backup_transfers():
    """Export all cached transfers as a JSON file download."""
    transfers = _transfer_manager.all_transfers()
    cached = [
        {
            "hash":     t["hash"],
            "name":     t.get("name") or t["hash"],
            "category": t.get("category") or "",
            "added_at": t.get("added_at") or 0,
        }
        for t in transfers
        if t.get("state") in ("cached", "complete")
    ]
    ts = int(time.time())
    resp = Response(
        json.dumps(cached, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="premiumize-backup-{ts}.json"'},
    )
    return resp

@app.route("/api/restore", methods=["POST"])
def restore_transfers():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    try:
        data = json.load(request.files["file"])
    except Exception as e:
        return jsonify({"error": f"Invalid JSON: {e}"}), 400

    if not isinstance(data, list):
        return jsonify({"error": "Expected a JSON array"}), 400

    def generate():
        imported = 0
        skipped  = 0
        errors   = 0
        total    = len(data)

        # Pre-validate all hashes and names first
        items = []
        for item in data:
            hash_ = (item.get("hash") or "").strip().lower()
            if not hash_ or not re.fullmatch(r'[0-9a-f]{40}', hash_):
                continue
            name = (item.get("name") or item.get("filename") or hash_).strip()
            if "." in os.path.basename(name):
                base = os.path.splitext(name)[0]
                if base:
                    name = base
            items.append({
                "hash":     hash_,
                "name":     name,
                "category": item.get("category", "").strip(),
                "added_at": float(item.get("added_at") or time.time()),
            })

        errors = len(data) - len(items)  # invalid hash entries

        # Batch cache-check all hashes against Premiumize (100 per call)
        cached_set = set()
        batch_size = 100
        yield json.dumps({"type": "progress", "current": 0, "total": total,
                          "status": "checking", "name": "Checking Premiumize cache…"}) + "\n"
        for b in range(0, len(items), batch_size):
            batch = items[b:b + batch_size]
            try:
                result = _transfer_manager._cache_fn([{"info_hash": x["hash"]} for x in batch])
                for hash_, is_cached in result.items():
                    if is_cached:
                        cached_set.add(hash_)
            except Exception as e:
                app.logger.warning(f"Cache check batch error: {e}")
            time.sleep(0.2)  # small pause between batch API calls

        for i, item in enumerate(items):
            hash_    = item["hash"]
            name     = item["name"]
            category = item["category"]
            added_at = item["added_at"]

            try:
                existing = _transfer_manager.get_transfer(hash_)
                if existing:
                    if existing.get("name") in (None, "", hash_) and name != hash_:
                        _transfer_manager._set(hash_, name=name)
                    skipped += 1
                    yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                      "status": "skipped", "name": name}) + "\n"
                    continue

                if hash_ not in cached_set:
                    skipped += 1
                    yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                      "status": "skipped", "name": f"{name} (not on Premiumize)"}) + "\n"
                    continue

                _transfer_manager._set(hash_, name=name, state="cached",
                                       category=category, added_at=added_at)
                imported += 1
                yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                  "status": "imported", "name": name}) + "\n"
                time.sleep(0.05)

            except Exception as e:
                errors += 1
                yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                  "status": "error", "name": name}) + "\n"
                app.logger.warning(f"Restore error: {e}")

        app.logger.info(f"Restore: {imported} imported, {skipped} skipped, {errors} errors")
        yield json.dumps({"type": "done", "imported": imported,
                          "skipped": skipped, "errors": errors, "total": total}) + "\n"

    return Response(generate(), mimetype="application/x-ndjson",
                    headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"})



# ── Config backup / restore ───────────────────────────────────────────────────

@app.route("/api/config/export", methods=["GET"])
def config_export():
    """Download the full config.json as a file.
    Includes the active PM API key even if it came from an env var,
    so the backup is self-contained and can be restored without env vars.
    """
    import datetime
    cfg = _load_config()
    # Always include the active PM API key so the backup is complete.
    # If it came from an env var it won't be in config.json — add it explicitly.
    active_key = get_pm_api_key()
    if active_key and not cfg.get("pm_api_key"):
        cfg = dict(cfg)           # don't mutate the cache
        cfg["pm_api_key"] = active_key
    ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")
    return Response(
        json.dumps(cfg, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="premiumize-config-{ts}.json"'},
    )

@app.route("/api/config/import", methods=["POST"])
def config_import():
    """Restore config.json from an uploaded file. Merges into current config."""
    global _config_cache, _overrides_cache
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    try:
        uploaded = json.load(request.files["file"])
    except Exception as e:
        return jsonify({"error": f"Invalid JSON: {e}"}), 400
    if not isinstance(uploaded, dict):
        return jsonify({"error": "Expected a JSON object"}), 400

    mode = request.args.get("mode", "merge")  # "merge" or "replace"
    if mode == "replace":
        new_cfg = uploaded
    else:
        # Merge: uploaded keys win, existing keys not in upload are kept
        new_cfg = {**_load_config(), **uploaded}

    _save_config(new_cfg)
    # Invalidate caches so new values take effect immediately
    _config_cache    = new_cfg
    _overrides_cache = new_cfg.get("classification_overrides", {})

    # Re-apply FUSE settings if they changed
    try:
        import fuse_mount as fm
        _apply_fuse_settings(_get_fuse_settings())
        if fm._pfs is not None:
            fm._pfs._invalidate_name_map()
    except Exception:
        pass

    return jsonify({"ok": True, "mode": mode, "keys": list(new_cfg.keys())})


# Transfer status polling
@app.route("/api/transfer/status", methods=["POST"])
def transfer_status():
    data        = request.json or {}
    api_key     = data.get("api_key", "").strip() or get_pm_api_key()
    transfer_id = data.get("transfer_id", "").strip()

    if not api_key or not transfer_id:
        return jsonify({"error": "api_key and transfer_id required"}), 400

    try:
        r = requests.get(PM_TRANSFER_LIST, headers=pm_headers(api_key), timeout=15)
        r.raise_for_status()
        data_r = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    if data_r.get("status") != "success":
        return jsonify({"error": data_r.get("message", "Failed to get transfer list")}), 400

    for t in data_r.get("transfers", []):
        if str(t.get("id")) == str(transfer_id):
            return jsonify({
                "status":   t.get("status"),
                "progress": t.get("progress", 0),
                "message":  t.get("message", ""),
                "file_id":  t.get("file_id"),
            })

    return jsonify({"error": "Transfer not found"}), 404

# Frontend config — tells the UI what's already set server-side
@app.route("/api/config")
def get_config():
    return jsonify({
        "has_pm_key":       bool(get_pm_api_key()),
        "has_prowlarr_env": bool(PROWLARR_URL or PROWLARR_KEY),
    })

@app.route("/api/config/pm_key", methods=["POST"])
def save_pm_key():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip()
    if not api_key:
        return jsonify({"error": "api_key required"}), 400
    # Verify it works before saving
    try:
        r = requests.get(PM_ACCOUNT, headers=pm_headers(api_key), timeout=10)
        r.raise_for_status()
        d = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502
    if d.get("status") != "success":
        return jsonify({"error": d.get("message", "Authentication failed")}), 401
    save_pm_api_key(api_key)
    # Flush the directdl cache so FUSE re-fetches with the new key
    with _directdl_lock:
        _directdl_cache.clear()
    app.logger.info("PM API key saved and directdl cache flushed")
    return jsonify({"ok": True})

# Account info
@app.route("/api/account", methods=["POST"])
def account():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_pm_api_key()
    if not api_key:
        return jsonify({"error": "API key required"}), 400
    try:
        r = requests.get(PM_ACCOUNT, headers=pm_headers(api_key), timeout=10)
        r.raise_for_status()
        d = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502
    if d.get("status") != "success":
        return jsonify({"error": d.get("message", "Authentication failed")}), 401
    premium_until = d.get("premium_until")
    is_premium = bool(premium_until and premium_until > datetime.now(timezone.utc).timestamp())
    return jsonify({
        "customer_id":   d.get("customer_id"),
        "is_premium":    is_premium,
        "premium_until": premium_until,
        "limit_used":    d.get("limit_used", 0),
    })

# ── Prowlarr config endpoints ─────────────────────────────────────────────────

@app.route("/api/torznab/cached-only", methods=["GET"])
def get_torznab_cached_only():
    return jsonify({"cached_only": _load_config().get("torznab_cached_only", False)})

@app.route("/api/torznab/cached-only", methods=["POST"])
def set_torznab_cached_only():
    data = request.json or {}
    val  = bool(data.get("cached_only", True))
    cfg  = _load_config()
    cfg["torznab_cached_only"] = val
    _save_config(cfg)
    return jsonify({"ok": True, "cached_only": val})

@app.route("/api/prowlarr/config", methods=["GET"])
def prowlarr_config_get():
    cfg = get_prowlarr_config()
    return jsonify({
        "url":        cfg.get("url", ""),
        "api_key":    cfg.get("api_key", ""),
        "configured": bool(cfg.get("url") and cfg.get("api_key")),
        "from_env":   cfg.get("from_env", False),
    })

@app.route("/api/prowlarr/config", methods=["POST"])
def prowlarr_config_save():
    data    = request.json or {}
    url     = data.get("url", "").strip()
    api_key = data.get("api_key", "").strip()

    if not url or not api_key:
        return jsonify({"error": "url and api_key required"}), 400

    # Test the connection
    try:
        r = requests.get(
            f"{url.rstrip('/')}/api/v1/indexer",
            headers={"X-Api-Key": api_key},
            timeout=10,
        )
        r.raise_for_status()
        indexers = r.json()
    except requests.RequestException as e:
        return jsonify({"error": f"Could not connect to Prowlarr: {e}"}), 400

    save_prowlarr_config(url, api_key)

    torrent_indexers = [i for i in indexers if i.get("protocol") == "torrent"]
    return jsonify({
        "ok": True,
        "indexer_count": len(torrent_indexers),
        "indexers": [{"id": i["id"], "name": i["name"]} for i in torrent_indexers],
    })

@app.route("/api/prowlarr/config", methods=["DELETE"])
def prowlarr_config_delete():
    cfg = _load_config()
    cfg.pop("prowlarr", None)
    _save_config(cfg)
    return jsonify({"ok": True})

# ── Mount Configuration endpoints ────────────────────────────────────────────

def _parse_size(val: str, default: int) -> int:
    """Parse human size string like '8MB', '500MB', '30GB', '1TB' to bytes."""
    if not val:
        return default
    val = val.strip().upper().replace(' ', '')
    units = {'B': 1, 'KB': 1024, 'MB': 1024**2, 'GB': 1024**3, 'TB': 1024**4}
    for suffix, mult in sorted(units.items(), key=lambda x: -len(x[0])):
        if val.endswith(suffix):
            try:
                return int(float(val[:-len(suffix)]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

def _parse_duration(val: str, default: int) -> int:
    """Parse duration string like '24h', '20m', '10s', '1d' to seconds."""
    if not val:
        return default
    val = val.strip().lower()
    units = {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
    for suffix, mult in units.items():
        if val.endswith(suffix):
            try:
                return int(float(val[:-1]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

def _fmt_size(b: int) -> str:
    for unit in ['TB', 'GB', 'MB', 'KB']:
        div = {'TB': 1024**4, 'GB': 1024**3, 'MB': 1024**2, 'KB': 1024}[unit]
        if b >= div:
            return f"{b/div:.1f} {unit}"
    return f"{b} B"

def _disk_used_bytes(path: str) -> int:
    """Return total bytes used by all files under path."""
    total = 0
    try:
        for dirpath, _, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(dirpath, f))
                except OSError:
                    pass
    except OSError:
        pass
    return total

def _enforce_disk_cache(cache_dir: str, max_bytes: int):
    """Delete oldest cache blocks until total disk usage is under max_bytes."""
    if not cache_dir or max_bytes <= 0:
        return
    # Collect all .bin files with their mtime
    files = []
    try:
        for dirpath, _, filenames in os.walk(cache_dir):
            for f in filenames:
                if f.endswith('.bin'):
                    p = os.path.join(dirpath, f)
                    try:
                        files.append((os.path.getmtime(p), os.path.getsize(p), p))
                    except OSError:
                        pass
    except OSError:
        return
    files.sort()  # oldest first
    total = sum(s for _, s, _ in files)
    for mtime, size, path in files:
        if total <= max_bytes:
            break
        try:
            os.remove(path)
            total -= size
        except OSError:
            pass

def _expire_disk_cache(cache_dir: str, max_age_seconds: int):
    """Remove cache blocks older than max_age_seconds."""
    if not cache_dir or max_age_seconds <= 0:
        return
    cutoff = time.time() - max_age_seconds
    try:
        for dirpath, _, filenames in os.walk(cache_dir):
            for f in filenames:
                if f.endswith('.bin'):
                    p = os.path.join(dirpath, f)
                    try:
                        if os.path.getmtime(p) < cutoff:
                            os.remove(p)
                    except OSError:
                        pass
    except OSError:
        pass

def _get_fuse_settings() -> dict:
    saved = _load_config().get("fuse", {})
    return {
        "cache_dir":       saved.get("cache_dir",       os.environ.get("FUSE_CACHE_DIR", "/docker/premiumize-web/cache")),
        "disk_cache_size": saved.get("disk_cache_size", "30GB"),
        "buffer_memory":   saved.get("buffer_memory",   "512MB"),
        "cache_expiry":    saved.get("cache_expiry",    "24h"),
        "cache_cleanup":   saved.get("cache_cleanup",   "20m"),
        "chunk_size":      saved.get("chunk_size",      "8MB"),
        "read_ahead":      saved.get("read_ahead",      "500MB"),
        "daemon_timeout":  saved.get("daemon_timeout",  "10s"),
        "uid":             saved.get("uid",             None),
        "gid":             saved.get("gid",             None),
        "umask":           saved.get("umask",           "022"),
        "prefetch":        saved.get("prefetch",        True),
        "video_only":      saved.get("video_only",      True),
        "enable_4k_folders": saved.get("enable_4k_folders", False),
    }

def _save_fuse_settings(settings: dict):
    cfg = _load_config()
    cfg["fuse"] = settings
    _save_config(cfg)

def _apply_fuse_settings(s: dict):
    """Apply settings live to the running fuse_mount module."""
    import fuse_mount as fm
    chunk_bytes  = _parse_size(s.get("chunk_size",    "8MB"),   8 * 1024 * 1024)
    buffer_bytes = _parse_size(s.get("buffer_memory", "512MB"), 512 * 1024 * 1024)
    cache_dir    = s.get("cache_dir", "") or ""

    # Number of in-memory blocks = buffer / chunk
    cache_blocks = max(4, buffer_bytes // chunk_bytes) if chunk_bytes else 16

    fm.BLOCK_SIZE        = chunk_bytes
    fm._RA_MB            = chunk_bytes // (1024 * 1024)
    fm._CACHE_N          = cache_blocks
    fm._PREFETCH_ENABLED = bool(s.get("prefetch", True))
    fm._CACHE_DIR        = cache_dir
    fm._VIDEO_ONLY       = bool(s.get("video_only", True))
    fm._4K_FOLDERS_ENABLED = bool(s.get("enable_4k_folders", False))
    # Invalidate the name map immediately so the new folder structure
    # takes effect on the next FUSE readdir without waiting for TTL expiry
    try:
        from fuse_mount import _pfs
        if _pfs is not None:
            _pfs._invalidate_name_map()
    except Exception:
        pass
    fm._READ_AHEAD_BYTES = _parse_size(s.get("read_ahead", "500MB"), 500 * 1024 * 1024)
    fm._block_cache      = fm._BlockCache(cache_blocks, cache_dir)

    # UID/GID/umask — apply to os module so getattr returns correct values
    uid = s.get("uid")
    gid = s.get("gid")
    if uid is not None:
        try:
            os.setuid(int(uid))
        except (PermissionError, AttributeError):
            pass
    if gid is not None:
        try:
            os.setgid(int(gid))
        except (PermissionError, AttributeError):
            pass
    umask = s.get("umask", "022")
    try:
        os.umask(int(umask, 8))
    except (ValueError, TypeError):
        pass

# Background cache cleanup thread
_cleanup_stop  = threading.Event()
_cleanup_thread = None

def _start_cache_cleanup():
    global _cleanup_thread
    if _cleanup_thread and _cleanup_thread.is_alive():
        _cleanup_stop.set()
        _cleanup_thread.join(timeout=2)
    _cleanup_stop.clear()

    def _loop():
        while not _cleanup_stop.wait(timeout=1):
            s          = _get_fuse_settings()
            interval   = _parse_duration(s.get("cache_cleanup", "20m"), 1200)
            cache_dir  = s.get("cache_dir", "")
            max_bytes  = _parse_size(s.get("disk_cache_size", "30GB"), 30 * 1024**3)
            max_age    = _parse_duration(s.get("cache_expiry", "24h"), 86400)
            _cleanup_stop.wait(timeout=interval)
            if _cleanup_stop.is_set():
                break
            if cache_dir:
                _expire_disk_cache(cache_dir, max_age)
                _enforce_disk_cache(cache_dir, max_bytes)

    _cleanup_thread = threading.Thread(target=_loop, daemon=True)
    _cleanup_thread.start()

_start_cache_cleanup()

@app.route("/api/fuse/settings", methods=["GET"])
def fuse_settings_get():
    import fuse_mount as fm
    s = _get_fuse_settings()
    cache_dir   = s.get("cache_dir", "")
    disk_used   = _disk_used_bytes(cache_dir) if cache_dir else 0
    buffer_bytes = _parse_size(s.get("buffer_memory", "512MB"), 512 * 1024 * 1024)
    return jsonify({
        **s,
        "live_chunk_size":  _fmt_size(fm.BLOCK_SIZE),
        "live_buffer_mb":   fm.BLOCK_SIZE * fm._CACHE_N // (1024 * 1024),
        "live_disk_used":   _fmt_size(disk_used),
        "live_prefetch":    fm._PREFETCH_ENABLED,
        "cached_blocks":    fm._block_cache.size,
    })

@app.route("/api/fuse/4k-enabled", methods=["GET"])
def fuse_4k_enabled():
    """Lightweight endpoint — just returns whether 4K folders are enabled."""
    return jsonify({"enabled": bool(_get_fuse_settings().get("enable_4k_folders", False))})

@app.route("/api/fuse/settings", methods=["POST"])
def fuse_settings_save():
    data = request.json or {}
    s = {
        "cache_dir":       data.get("cache_dir",       "").strip(),
        "disk_cache_size": data.get("disk_cache_size", "30GB").strip(),
        "buffer_memory":   data.get("buffer_memory",   "512MB").strip(),
        "cache_expiry":    data.get("cache_expiry",    "24h").strip(),
        "cache_cleanup":   data.get("cache_cleanup",   "20m").strip(),
        "chunk_size":      data.get("chunk_size",      "8MB").strip(),
        "read_ahead":      data.get("read_ahead",      "500MB").strip(),
        "daemon_timeout":  data.get("daemon_timeout",  "10s").strip(),
        "uid":             data.get("uid"),
        "gid":             data.get("gid"),
        "umask":           data.get("umask",           "022").strip(),
        "prefetch":        bool(data.get("prefetch",        True)),
        "video_only":      bool(data.get("video_only",      True)),
        "enable_4k_folders": bool(data.get("enable_4k_folders", False)),
    }
    _save_fuse_settings(s)
    _apply_fuse_settings(s)
    _start_cache_cleanup()  # restart with new interval
    app.logger.info(f"Mount config updated: chunk={s['chunk_size']} buffer={s['buffer_memory']} "
                    f"disk={s['disk_cache_size']} expiry={s['cache_expiry']}")
    return jsonify({"ok": True})

@app.route("/api/fuse/cache/clear", methods=["POST"])
def fuse_cache_clear():
    import fuse_mount as fm
    import shutil
    fm._block_cache = fm._BlockCache(fm._CACHE_N, fm._CACHE_DIR)
    cache_dir = fm._CACHE_DIR
    if cache_dir and os.path.isdir(cache_dir):
        try:
            shutil.rmtree(cache_dir)
            os.makedirs(cache_dir, exist_ok=True)
        except OSError as e:
            return jsonify({"error": str(e)}), 500
    return jsonify({"ok": True, "message": "Cache cleared"})

# ── Plex settings ──────────────────────────────────────────────────────────────

@app.route("/api/plex/config", methods=["GET"])
def plex_config_get():
    cfg = _load_config().get("plex", {})
    return jsonify({
        "url":              cfg.get("url", ""),
        "token":            cfg.get("token", ""),
        "movies_section":   cfg.get("movies_section", "1"),
        "tv_section":       cfg.get("tv_section", "2"),
        "debounce_seconds": cfg.get("debounce_seconds", 30),
    })

@app.route("/api/plex/config", methods=["POST"])
def plex_config_save():
    data = request.get_json(force=True) or {}
    cfg  = _load_config()
    cfg["plex"] = {
        "url":              (data.get("url") or "").strip().rstrip("/"),
        "token":            (data.get("token") or "").strip(),
        "movies_section":   str(data.get("movies_section") or "1").strip(),
        "tv_section":       str(data.get("tv_section") or "2").strip(),
        "debounce_seconds": max(5, int(data.get("debounce_seconds") or 30)),
    }
    _save_config(cfg)
    return jsonify({"ok": True})

@app.route("/api/plex/test", methods=["POST"])
def plex_test():
    """Test Plex connectivity and return available library sections."""
    data  = request.get_json(force=True) or {}
    url   = (data.get("url") or "").strip().rstrip("/")
    token = (data.get("token") or "").strip()
    if not url or not token:
        return jsonify({"error": "url and token required"}), 400
    try:
        r = requests.get(
            f"{url}/library/sections",
            headers={"X-Plex-Token": token, "Accept": "application/json"},
            timeout=8,
        )
        if r.status_code == 401:
            return jsonify({"error": "Invalid token"}), 401
        r.raise_for_status()
        sections = []
        data_r = r.json()
        for s in data_r.get("MediaContainer", {}).get("Directory", []):
            sections.append({
                "key":   s.get("key"),
                "title": s.get("title"),
                "type":  s.get("type"),
            })
        return jsonify({"ok": True, "sections": sections})
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

@app.route("/api/plex/scan", methods=["POST"])
def plex_scan():
    """Trigger an immediate Plex library scan."""
    data    = request.get_json(force=True) or {}
    section = data.get("section", "")   # optional specific section
    cfg     = _load_config().get("plex", {})
    url     = (os.environ.get("PLEX_URL") or cfg.get("url") or "").rstrip("/")
    token   = os.environ.get("PLEX_TOKEN") or cfg.get("token") or ""
    if not url or not token:
        return jsonify({"error": "Plex not configured"}), 400
    sections = [section] if section else [
        cfg.get("movies_section", "1"),
        cfg.get("tv_section", "2"),
    ]
    triggered = []
    errors    = []
    for sec in sections:
        if not sec:
            continue
        try:
            r = requests.get(
                f"{url}/library/sections/{sec}/refresh?X-Plex-Token={token}",
                timeout=8,
            )
            if r.status_code in (200, 204):
                triggered.append(sec)
            else:
                errors.append(f"section {sec}: HTTP {r.status_code}")
        except requests.RequestException as e:
            errors.append(f"section {sec}: {e}")
    return jsonify({"ok": not errors, "triggered": triggered, "errors": errors})

@app.route("/api/fuse/prewarm", methods=["POST"])
def fuse_prewarm():
    """Pre-warm the FUSE directdl file cache for all streamable transfers."""
    try:
        import fuse_mount as fm
        if fm._pfs is None:
            return jsonify({"error": "FUSE not mounted"}), 503
        hashes = _transfer_manager.streamable_hashes()
        if not hashes:
            return jsonify({"ok": True, "warmed": 0, "message": "No transfers to warm"})
        now    = __import__("time").time()
        cold   = [h for h in hashes if h not in fm._pfs._file_cache
                  or now >= fm._pfs._file_cache[h][1]]
        fm._pfs._prewarm_parallel(cold, block=False)
        return jsonify({
            "ok":      True,
            "total":   len(hashes),
            "warmed":  len(cold),
            "already_warm": len(hashes) - len(cold),
        })
    except Exception as e:
        app.logger.warning(f"[prewarm] {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/transfers/classify", methods=["POST"])
def classify_transfers():
    """Backfill kind='movie'|'series' for all transfers that don't have it yet.
    Uses actual file paths from directdl — the ground truth source."""
    from name_match import classify_from_files
    import fuse_mount as fm

    hashes    = _transfer_manager.streamable_hashes()
    updated   = 0
    skipped   = 0
    no_files  = 0

    for h in hashes:
        t = _transfer_manager.get_transfer(h)
        if not t:
            continue
        if t.get("kind") in ("movie", "series"):
            skipped += 1
            continue
        # Try from FUSE file cache first (fast, no network)
        files = None
        if fm._pfs is not None:
            cached = fm._pfs._file_cache.get(h)
            if cached:
                files, _ = cached
        # Fall back to fetching from Premiumize
        if not files:
            try:
                files = _transfer_manager.get_files(h) or []
            except Exception:
                files = []
        if not files:
            no_files += 1
            continue
        kind = classify_from_files(files)
        if kind:
            _transfer_manager._set(h, kind=kind)
            updated += 1

    # Invalidate FUSE name map so reclassified items move to correct folder
    try:
        if fm._pfs is not None:
            fm._pfs._invalidate_name_map()
    except Exception:
        pass

    return jsonify({
        "ok":       True,
        "updated":  updated,
        "skipped":  skipped,
        "no_files": no_files,
        "total":    len(hashes),
    })

@app.route("/api/prowlarr/indexers", methods=["GET"])
def prowlarr_indexers():
    cfg = get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"):
        return jsonify({"error": "Prowlarr not configured"}), 400
    try:
        r = requests.get(
            f"{cfg['url']}/api/v1/indexer",
            headers={"X-Api-Key": cfg["api_key"]},
            timeout=10,
        )
        r.raise_for_status()
        indexers = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    torrent_indexers = [i for i in indexers if i.get("protocol") == "torrent"]
    return jsonify({
        "indexers": [{"id": i["id"], "name": i["name"], "enabled": i.get("enableAutomaticSearch", True)} for i in torrent_indexers]
    })

MOUNTPOINT = os.environ.get("FUSE_MOUNTPOINT", "/docker/premiumize-web/mnt")

# ── directdl helpers ──────────────────────────────────────────────────────────

def _directdl_for_manager_raw(hash_: str, name: str) -> list:
    """Raw directdl call — always hits Premiumize API. Use _get_directdl instead."""
    api_key = get_pm_api_key()
    if not api_key:
        return []
    magnet     = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}
    try:
        r = requests.post(
            PM_DIRECTDL,
            headers={**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"src": magnet}),
            timeout=30,
        )
        r.raise_for_status()
        data_r = r.json()
    except Exception:
        return []
    if data_r.get("status") != "success":
        return []
    files = []
    for item in data_r.get("content", []):
        path      = item.get("path", "")
        file_name = path.split("/")[-1] if "/" in path else path
        ext       = os.path.splitext(file_name)[1].lower()
        cdn_url   = item.get("link", "")
        token     = _make_stream_token(hash_, file_name) if cdn_url else ""
        files.append({
            "name":       file_name or path,
            "path":       path,
            "link":       cdn_url,
            "size":       int(float(item.get("size", 0) or 0)),
            "is_video":   ext in video_exts,
            "stream_url": f"/api/stream/{token}?h={hash_}&f={urllib.parse.quote(file_name)}" if token else "",
        })
    return files

def _directdl_for_manager(hash_: str, name: str, force: bool = False) -> list:
    """Cached wrapper — used by transfer manager and FUSE mount."""
    return _get_directdl(hash_, name, force=force)

# ── transfer manager ──────────────────────────────────────────────────────────

from transfer_manager import TransferManager, SymlinkManager

_transfer_manager = TransferManager(
    pm_api_key_fn  = lambda: get_pm_api_key(),
    directdl_fn    = _directdl_for_manager,
    cache_check_fn = lambda torrents: check_cache_pm(get_pm_api_key(), torrents),
)

# ── Symlink manager ───────────────────────────────────────────────────────────

_symlink_manager = SymlinkManager(_transfer_manager)

# Run a reconciliation sync on startup in a background thread so we do not
# block the Flask startup while the FUSE mount is still initialising.
def _sync_symlinks_delayed(delay: int = 15):
    """Wait for FUSE to be ready then sync symlinks."""
    import threading, time
    def _do():
        time.sleep(delay)
        try:
            _symlink_manager.sync(_transfer_manager)
        except Exception as e:
            app.logger.warning(f"Startup symlink sync failed: {e}")
    _import_pool.submit(_do)

_sync_symlinks_delayed()

# ── qBittorrent mock blueprint ────────────────────────────────────────────────

import qbt_mock
qbt_mock.init(_transfer_manager)
qbt_mock.MOUNTPOINT = MOUNTPOINT
app.register_blueprint(qbt_mock.qbt)

# ── FUSE mount ────────────────────────────────────────────────────────────────

import signal
import subprocess

def _unmount_fuse():
    """Unmount cleanly — try fusermount first, fall back to lazy umount."""
    try:
        subprocess.run(["fusermount", "-uz", MOUNTPOINT], check=False, capture_output=True)
    except FileNotFoundError:
        pass
    subprocess.run(["umount", "-l", MOUNTPOINT], check=False, capture_output=True)
    app.logger.info(f"FUSE unmounted {MOUNTPOINT}")


def _clear_stale_mount():
    """
    Tear down any stale/broken FUSE mount left over from a previous run.
    Handles both the normal 'mountpoint exists' case and the broken
    'Transport endpoint is not connected' case.
    """
    for attempt in range(15):
        # Check if still mounted
        r = subprocess.run(["mountpoint", "-q", MOUNTPOINT], capture_output=True)
        if r.returncode != 0:
            # Double-check for broken transport endpoint
            ls = subprocess.run(["ls", MOUNTPOINT], capture_output=True, text=True)
            if "Transport endpoint" not in (ls.stderr or ""):
                return  # clean
        print(f"[FUSE] clearing stale mount (attempt {attempt + 1})...", flush=True)
        subprocess.run(["fusermount", "-uz", MOUNTPOINT], capture_output=True)
        subprocess.run(["umount", "-l",   MOUNTPOINT], capture_output=True)
        time.sleep(0.3)
    print("[FUSE] WARNING: could not fully clear stale mount", flush=True)


_fuse_shutdown = threading.Event()

def _start_fuse():
    import traceback
    import signal as _signal
    try:
        from fuse_mount import mount, FUSE_AVAILABLE
    except Exception as e:
        print(f"[FUSE] import failed: {e}", flush=True)
        traceback.print_exc()
        return

    if not FUSE_AVAILABLE:
        print("[FUSE] fusepy not installed — disabled", flush=True)
        return

    # Block signals in this thread — Flask's main thread handles them.
    try:
        _signal.pthread_sigmask(_signal.SIG_BLOCK,
                                {_signal.SIGTERM, _signal.SIGINT, _signal.SIGHUP})
    except (AttributeError, OSError):
        pass

    consecutive_failures = 0
    while not _fuse_shutdown.is_set():
        _clear_stale_mount()
        print(f"[FUSE] mounting at {MOUNTPOINT}", flush=True)
        try:
            mount(MOUNTPOINT, _transfer_manager, foreground=True)
            if _fuse_shutdown.is_set():
                print("[FUSE] mount exited — shutdown requested, not remounting", flush=True)
                break
            print("[FUSE] mount exited — remounting in 2s...", flush=True)
            consecutive_failures = 0
        except Exception as e:
            consecutive_failures += 1
            print(f"[FUSE] mount failed ({consecutive_failures}): {e}", flush=True)
            traceback.print_exc()

        wait = min(2 * consecutive_failures, 30)
        _fuse_shutdown.wait(timeout=max(wait, 2))

    print("[FUSE] thread exited", flush=True)


def _shutdown(signum, frame):
    print("[shutdown] signal received — unmounting FUSE gracefully", flush=True)
    _fuse_shutdown.set()
    # Give fusermount a chance to exit cleanly first
    subprocess.run(["fusermount", "-uz", MOUNTPOINT], capture_output=True)
    time.sleep(0.5)
    # Force if still mounted
    subprocess.run(["umount", "-l", MOUNTPOINT], capture_output=True)
    print("[shutdown] FUSE unmounted", flush=True)
    raise SystemExit(0)

# Register signal handlers so FUSE is unmounted on SIGTERM (docker stop) and SIGINT
signal.signal(signal.SIGTERM, _shutdown)
signal.signal(signal.SIGINT, _shutdown)

# ── Sync API ──────────────────────────────────────────────────────────────────

def _get_sync_config() -> dict:
    cfg = _load_config().get("sync", {})
    return {"instances": cfg.get("instances", [])}

@app.route("/api/sync/config", methods=["GET"])
def sync_config_get():
    return jsonify(_get_sync_config())

@app.route("/api/sync/config", methods=["POST"])
def sync_config_save():
    data = request.get_json(force=True) or {}
    cfg  = _load_config()
    instances = data.get("instances", [])
    # Sanitise
    for inst in instances:
        inst["url"] = (inst.get("url") or "").rstrip("/")
    cfg["sync"] = {"instances": instances}
    _save_config(cfg)
    return jsonify({"ok": True})

@app.route("/api/downloads/clear", methods=["POST"])
def downloads_clear():
    """Delete all subfolders under DOWNLOADS_ROOT (fake import files)."""
    import shutil
    from qbt_mock import DOWNLOADS_ROOT
    removed = 0
    errors  = []
    try:
        if not os.path.isdir(DOWNLOADS_ROOT):
            return jsonify({"ok": True, "removed": 0, "message": "Downloads folder does not exist."})
        for cat_dir in os.scandir(DOWNLOADS_ROOT):
            if not cat_dir.is_dir():
                continue
            for entry in os.scandir(cat_dir.path):
                if entry.is_dir():
                    try:
                        shutil.rmtree(entry.path)
                        removed += 1
                    except Exception as e:
                        errors.append(str(e))
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500
    return jsonify({"ok": True, "removed": removed,
                    "message": f"Removed {removed} folder(s)." + (f" {len(errors)} error(s)." if errors else "")})

@app.route("/api/downloads/clear-config", methods=["GET"])
def downloads_clear_config_get():
    cfg = _load_config().get("downloads_clear", {})
    return jsonify({"interval_hours": cfg.get("interval_hours", 0)})

@app.route("/api/downloads/clear-config", methods=["POST"])
def downloads_clear_config_save():
    data = request.get_json(force=True) or {}
    hours = int(data.get("interval_hours", 0))
    cfg = _load_config()
    cfg["downloads_clear"] = {"interval_hours": max(0, hours)}
    _save_config(cfg)
    _restart_downloads_clear_timer()
    return jsonify({"ok": True, "interval_hours": max(0, hours)})

# ── Downloads auto-clear timer ─────────────────────────────────────────────────

_downloads_clear_stop  = threading.Event()
_downloads_clear_thread = None

def _do_clear_downloads():
    """Actually delete all stub folders — same logic as the API endpoint."""
    import shutil
    from qbt_mock import DOWNLOADS_ROOT
    removed = 0
    try:
        if os.path.isdir(DOWNLOADS_ROOT):
            for cat_dir in os.scandir(DOWNLOADS_ROOT):
                if not cat_dir.is_dir():
                    continue
                for entry in os.scandir(cat_dir.path):
                    if entry.is_dir():
                        try:
                            shutil.rmtree(entry.path)
                            removed += 1
                        except Exception:
                            pass
    except Exception:
        pass
    app.logger.info(f"[downloads-clear-timer] Auto-cleared {removed} folder(s)")
    return removed

def _restart_downloads_clear_timer():
    global _downloads_clear_thread
    _downloads_clear_stop.set()
    if _downloads_clear_thread and _downloads_clear_thread.is_alive():
        _downloads_clear_thread.join(timeout=2)
    _downloads_clear_stop.clear()

    hours = _load_config().get("downloads_clear", {}).get("interval_hours", 0)
    if not hours or hours <= 0:
        return  # disabled

    def _loop():
        while not _downloads_clear_stop.wait(timeout=hours * 3600):
            _do_clear_downloads()

    _downloads_clear_thread = threading.Thread(target=_loop, daemon=True)
    _downloads_clear_thread.start()
    app.logger.info(f"[downloads-clear-timer] Started — interval: {hours}h")

# Start the timer on app load
_restart_downloads_clear_timer()

# ── Auto-backup timer ──────────────────────────────────────────────────────────

BACKUP_DIR = os.path.join(os.path.dirname(CONFIG_PATH), "backups")

@app.route("/api/backup-config", methods=["GET"])
def backup_config_get():
    cfg = _load_config().get("auto_backup", {})
    return jsonify({
        "interval_days": cfg.get("interval_days", 0),
        "keep_count":    cfg.get("keep_count", 5),
        "last_backup":   cfg.get("last_backup", None),
    })

@app.route("/api/backup-config", methods=["POST"])
def backup_config_save():
    data = request.get_json(force=True) or {}
    days  = max(0, int(data.get("interval_days", 0)))
    keep  = max(1, int(data.get("keep_count", 5)))
    cfg   = _load_config()
    cfg.setdefault("auto_backup", {}).update({"interval_days": days, "keep_count": keep})
    _save_config(cfg)
    _restart_backup_timer()
    return jsonify({"ok": True, "interval_days": days, "keep_count": keep})

@app.route("/api/backup-config/run", methods=["POST"])
def backup_config_run():
    """Trigger an immediate backup."""
    path = _do_auto_backup()
    return jsonify({"ok": bool(path), "path": path or ""})

_backup_stop   = threading.Event()
_backup_thread = None

def _do_auto_backup() -> str | None:
    """Write a dated backup JSON to BACKUP_DIR. Returns the file path."""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        transfers = _transfer_manager.all_transfers()
        cached = [
            {
                "hash":     t["hash"],
                "name":     t.get("name") or t["hash"],
                "category": t.get("category") or "",
                "added_at": t.get("added_at") or 0,
            }
            for t in transfers
            if t.get("state") in ("cached", "complete")
        ]
        import datetime
        ts   = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")
        path = os.path.join(BACKUP_DIR, f"premiumize-backup-{ts}.json")
        with open(path, "w") as f:
            json.dump(cached, f, indent=2)

        # Also save a config snapshot alongside the transfer backup
        cfg_snapshot = dict(_load_config())
        active_key = get_pm_api_key()
        if active_key and not cfg_snapshot.get("pm_api_key"):
            cfg_snapshot["pm_api_key"] = active_key
        cfg_path = os.path.join(BACKUP_DIR, f"premiumize-config-{ts}.json")
        with open(cfg_path, "w") as f:
            json.dump(cfg_snapshot, f, indent=2)

        # Keep only the configured number of most recent backups (default 5)
        keep = _load_config().get("auto_backup", {}).get("keep_count", 5)
        for prefix in ("premiumize-backup-", "premiumize-config-"):
            all_backups = sorted(
                [os.path.join(BACKUP_DIR, fn) for fn in os.listdir(BACKUP_DIR)
                 if fn.startswith(prefix) and fn.endswith(".json")]
            )
            for old in all_backups[:-keep]:
                try:
                    os.remove(old)
                    app.logger.info(f"[auto-backup] Deleted old backup: {os.path.basename(old)}")
                except OSError:
                    pass

        # Record last backup time in config
        cfg = _load_config()
        cfg.setdefault("auto_backup", {})["last_backup"] = ts
        _save_config(cfg)

        app.logger.info(f"[auto-backup] Saved {len(cached)} transfers + config → {BACKUP_DIR}")
        return path
    except Exception as e:
        app.logger.warning(f"[auto-backup] Failed: {e}")
        return None

def _restart_backup_timer():
    global _backup_thread
    _backup_stop.set()
    if _backup_thread and _backup_thread.is_alive():
        _backup_thread.join(timeout=2)
    _backup_stop.clear()

    days = _load_config().get("auto_backup", {}).get("interval_days", 0)
    if not days or days <= 0:
        return

    def _loop():
        while not _backup_stop.wait(timeout=days * 86400):
            _do_auto_backup()

    _backup_thread = threading.Thread(target=_loop, daemon=True)
    _backup_thread.start()
    app.logger.info(f"[auto-backup] Started — interval: {days}d")

_restart_backup_timer()

@app.route("/api/sync/run", methods=["POST"])
def sync_run():
    """
    SSE stream — Full or Partial sync between FUSE mount and Radarr/Sonarr.

    New design: write fake files DIRECTLY into the Arr root folder (the
    configured movie/TV library path), then trigger a folder rescan.
    No TMDB/TVDB lookups.  No qBittorrent mock round-trip.

    Full sync
    ─────────
    1. Scan FUSE mount for the selected folder (movies / series / etc.)
    2. Wipe every .mkv stub we previously wrote into the Arr root folder
    3. Set ALL existing Arr items to monitored=True
    4. For each FUSE item:
       a. Build folder name  →  <root>/<Title> (Year)/
       b. Write fake .mkv stub directly into that folder
       c. Trigger RescanMovie / RefreshSeries + RescanSeries
    5. Report counts

    Partial sync
    ────────────
    1. Scan FUSE mount
    2. For each FUSE item:
       a. Check whether our stub already exists in the Arr root folder
       b. If missing → write stub + trigger rescan
       c. If present → skip
    """
    import re as _re, os as _os, shutil as _shutil, stat as _stat_mod
    from fuse_mount import build_name_map
    from qbt_mock  import _pick_fake_filename, _safe_name, _detect_resolution, DOWNLOADS_ROOT
    import requests as _req

    data     = request.get_json(force=True) or {}
    folder   = data.get("folder",   "movies")   # movies | series | movies4k | series4k
    arr      = data.get("arr",      "radarr")   # radarr | sonarr
    mode     = data.get("mode",     "partial")  # full | partial
    base_url = data.get("arr_url",  "").rstrip("/")
    api_key  = data.get("arr_key",  "")
    arr_name = data.get("arr_name", arr.title())
    arr_root = data.get("arr_root", "").strip().rstrip("/")  # user-configured root override

    def _headers():
        return {"X-Api-Key": api_key, "Content-Type": "application/json"}

    def sse(log=None, pct=None, status=None, done=False, error=False):
        obj = {}
        if log    is not None: obj["log"]    = log
        if pct    is not None: obj["pct"]    = pct
        if status is not None: obj["status"] = status
        if done:
            obj["done"]  = True
            obj["error"] = error
        return f"data: {json.dumps(obj)}\n\n"

    # ── stub helpers ──────────────────────────────────────────────────────────

    _STUB_MARKER = ".premiumize-stub"   # suffix we add so we can identify our files

    def _write_stub(dest_folder: str, filename: str, real_files: list) -> str:
        """Write a fake MKV stub directly into dest_folder/filename.
        Also writes a .nfo alongside so Plex reads metadata instead of probing
        the file via MediaInfo (which would hit Premiumize's API).
        Returns the full path of the written file."""
        _os.makedirs(dest_folder, exist_ok=True)
        try:
            _os.chmod(dest_folder, 0o777)
        except OSError:
            pass
        fpath = _os.path.join(dest_folder, filename)
        if _os.path.exists(fpath):
            _os.utime(fpath, None)
            # Ensure NFO exists even for already-present stubs
            from qbt_mock import write_nfo as _write_nfo
            _write_nfo(fpath)
            return fpath
        # Write video stub
        res      = _detect_resolution(filename)
        stub_src = _os.path.join(_os.path.dirname(__file__), "stubs", f"{res}.mkv")
        if not _os.path.exists(stub_src):
            stub_src = _os.path.join(_os.path.dirname(__file__), "stubs", "1080p.mkv")
        if _os.path.exists(stub_src):
            _shutil.copy2(stub_src, fpath)
        else:
            open(fpath, "wb").close()
        try:
            _os.chmod(fpath, 0o666)
        except OSError:
            pass
        # Write NFO alongside the stub
        from qbt_mock import write_nfo as _write_nfo
        _write_nfo(fpath)
        return fpath

    def _arr_folder_name(transfer_name: str, arr_type: str) -> str:
        """Build the Arr-style folder name from the transfer name.
        Radarr: 'Movie Title (Year)'
        Sonarr: 'Series Name'
        """
        n = transfer_name.replace(".", " ").replace("_", " ")
        # Strip resolution/codec junk
        n = _re.sub(
            r"\b(2160p?|1080p?|720p?|480p?|576p?|4k|uhd|hdr|bluray|blu-ray|web-?dl|"
            r"webrip|hdtv|x264|x265|hevc|remux|proper|repack|10bit|avc|dts|"
            r"dd5|aac|ac3|atmos|truehd|h\.?26[45]|hevc|complete|nordic|multi)\b.*",
            "", n, flags=_re.IGNORECASE
        ).strip(" -–")
        n = _re.sub(r"\s+", " ", n).strip()
        return n

    def _wipe_stubs(root: str):
        """Delete all stub .mkv files (< 10 MB) and their companion .nfo files."""
        removed = 0
        if not _os.path.isdir(root):
            return 0
        for dirpath, dirnames, filenames in _os.walk(root):
            for fn in filenames:
                fpath = _os.path.join(dirpath, fn)
                ext   = fn.lower().rsplit('.', 1)[-1] if '.' in fn else ''
                try:
                    if ext == 'mkv' and _os.path.getsize(fpath) < 10 * 1024 * 1024:
                        _os.remove(fpath)
                        removed += 1
                        # Remove companion NFO
                        nfo = _os.path.splitext(fpath)[0] + ".nfo"
                        if _os.path.exists(nfo):
                            _os.remove(nfo)
                        # Remove parent folder if now empty
                        parent = _os.path.dirname(fpath)
                        if parent != root and not _os.listdir(parent):
                            _shutil.rmtree(parent, ignore_errors=True)
                    elif ext == 'nfo':
                        # Orphaned NFO (stub already removed) — clean it up
                        mkv = _os.path.splitext(fpath)[0] + ".mkv"
                        if not _os.path.exists(mkv):
                            _os.remove(fpath)
                except OSError:
                    pass
        return removed

    def generate():
        if not base_url or not api_key:
            yield sse(log="❌ Missing URL or API key.", done=True, error=True)
            return

        # ── Step 1: connect + get root folder ─────────────────────────────────
        yield sse(log=f"Connecting to {arr_name} at {base_url}…", pct=2, status="Connecting…")
        try:
            ping = _req.get(f"{base_url}/api/v3/system/status", headers=_headers(), timeout=8)
            if ping.status_code not in (200, 201):
                yield sse(log=f"❌ {arr_name} returned HTTP {ping.status_code}.", done=True, error=True)
                return
            yield sse(log=f"Connected to {arr_name} v{ping.json().get('version','?')}", pct=5)
        except Exception as e:
            yield sse(log=f"❌ Cannot reach {arr_name}: {e}", done=True, error=True)
            return

        try:
            rf = _req.get(f"{base_url}/api/v3/rootFolder", headers=_headers(), timeout=8).json()
            auto_root = rf[0]["path"].rstrip("/") if rf else "/movies"
        except Exception as e:
            yield sse(log=f"⚠ Could not get root folder: {e} — using /movies")
            auto_root = "/movies"

        if arr_root:
            root_path = arr_root
            yield sse(log=f"Root folder: {root_path} (configured)", pct=8)
        else:
            root_path = auto_root
            yield sse(log=f"Root folder: {root_path} (auto-detected)", pct=8)

        # ── Step 2: scan FUSE mount ────────────────────────────────────────────
        yield sse(log=f"Scanning FUSE /{folder}…", pct=10, status="Scanning…")
        name_map   = build_name_map(_transfer_manager)
        fuse_items = {}   # folder_name → transfer dict
        for key, hash_ in name_map.items():
            parts = key.split("/", 1)
            if parts[0] != folder or len(parts) < 2:
                continue
            t = _transfer_manager.get_transfer(hash_)
            if t:
                fuse_items[parts[1]] = t

        if not fuse_items:
            available = list({k.split("/")[0] for k in name_map.keys()})
            yield sse(log=f"⚠ No items in /{folder}. Available: {available or ['(empty)']}", done=True)
            return
        yield sse(log=f"Found {len(fuse_items)} items in /{folder}", pct=14)

        # ── Step 3 (full only): wipe existing stubs + set library monitored ────
        if mode == "full":
            yield sse(log="Full sync: wiping existing stubs…", pct=16, status="Wiping stubs…")
            removed = _wipe_stubs(root_path)
            yield sse(log=f"  Removed {removed} stub file(s) from {root_path}")

            # Set all existing Arr items to monitored=True
            yield sse(log="Setting existing library items to monitored…", pct=20)
            endpoint = "movie" if arr == "radarr" else "series"
            try:
                existing = _req.get(f"{base_url}/api/v3/{endpoint}",
                                    headers=_headers(), timeout=15).json()
                bulk_monitored = 0
                for item in existing:
                    if not item.get("monitored"):
                        item["monitored"] = True
                        try:
                            _req.put(f"{base_url}/api/v3/{endpoint}/{item['id']}",
                                     headers=_headers(), json=item, timeout=8)
                            bulk_monitored += 1
                        except Exception:
                            pass
                if bulk_monitored:
                    yield sse(log=f"  Set {bulk_monitored} item(s) to monitored")
            except Exception as e:
                yield sse(log=f"⚠ Could not update library: {e}")

        # ── Step 4: write stubs + trigger rescans ──────────────────────────────
        yield sse(log=f"Processing {len(fuse_items)} items…", pct=24, status="Writing stubs…")
        added = imported = skipped = errors = 0
        total = len(fuse_items)

        for i, (item_name, transfer) in enumerate(fuse_items.items()):
            pct    = 24 + int(72 * (i + 1) / max(total, 1))
            t_name = transfer.get("name") or item_name
            t_hash = transfer.get("hash", "")

            try:
                # Build Arr folder name and filename
                folder_label = _arr_folder_name(t_name, arr)
                dest_dir     = _os.path.join(root_path, folder_label)

                # Get real files for filename selection
                try:
                    real_files = _transfer_manager.get_files(t_hash) or []
                except Exception:
                    real_files = []

                if arr == "sonarr":
                    # For series: detect season pack vs single episode
                    ep_match     = _re.search(r'S(\d{1,2})E(\d{1,3})', t_name, _re.IGNORECASE)
                    season_match = _re.search(r'S(\d{1,2})\b(?!E)',     t_name, _re.IGNORECASE)
                    is_pack      = bool(season_match and not ep_match)

                    if is_pack:
                        season_num  = int(season_match.group(1))
                        season_dir  = _os.path.join(dest_dir, f"Season {season_num:02d}")
                        res_tag     = _detect_resolution(t_name)
                        stub_count  = 0

                        # Try to get episode list from Sonarr
                        series_id = None
                        try:
                            s_resp = _req.get(f"{base_url}/api/v3/series/lookup",
                                              headers=_headers(),
                                              params={"term": folder_label}, timeout=10)
                            results = s_resp.json() if s_resp.ok else []
                            if results:
                                # Find in existing library
                                lib_resp = _req.get(f"{base_url}/api/v3/series",
                                                    headers=_headers(), timeout=10).json()
                                norm_fl  = _re.sub(r"[^a-z0-9]", "", folder_label.lower())
                                for s in lib_resp:
                                    if _re.sub(r"[^a-z0-9]", "", (s.get("title") or "").lower()) == norm_fl:
                                        series_id = s["id"]
                                        break
                        except Exception:
                            pass

                        eps_written = set()
                        if series_id:
                            try:
                                eps = _req.get(f"{base_url}/api/v3/episode",
                                               headers=_headers(),
                                               params={"seriesId": series_id,
                                                       "seasonNumber": season_num},
                                               timeout=10).json()
                                for ep in (eps if isinstance(eps, list) else []):
                                    ep_num = ep.get("episodeNumber")
                                    if not ep_num:
                                        continue
                                    ep_fn = (f"{folder_label} S{season_num:02d}E{ep_num:02d}"
                                             f".WEBRip-{res_tag}.mkv")
                                    _write_stub(season_dir, ep_fn, real_files)
                                    eps_written.add(ep_num)
                                    stub_count += 1
                            except Exception:
                                pass

                        if not stub_count:
                            # No Sonarr data — write single season stub
                            ep_fn = f"{folder_label} S{season_num:02d}.WEBRip-{res_tag}.mkv"
                            _write_stub(season_dir, ep_fn, real_files)
                            stub_count = 1

                        # Trigger rescan
                        if series_id:
                            try:
                                _req.post(f"{base_url}/api/v3/command",
                                          headers=_headers(),
                                          json={"name": "RescanSeries", "seriesId": series_id},
                                          timeout=8)
                            except Exception:
                                pass
                        yield sse(log=f"  ✓ {folder_label} S{season_num:02d} — {stub_count} stubs", pct=pct)
                        imported += stub_count
                    else:
                        # Single episode
                        fake_fn = _pick_fake_filename(t_name, real_files)
                        if ep_match:
                            sn = int(ep_match.group(1))
                            dest_dir = _os.path.join(dest_dir, f"Season {sn:02d}")

                        stub_path = _os.path.join(dest_dir, fake_fn)
                        if mode == "partial" and _os.path.exists(stub_path):
                            skipped += 1
                            continue

                        _write_stub(dest_dir, fake_fn, real_files)

                        # Trigger RescanSeries
                        try:
                            norm_fl  = _re.sub(r"[^a-z0-9]", "", folder_label.lower())
                            lib_resp = _req.get(f"{base_url}/api/v3/series",
                                                headers=_headers(), timeout=10).json()
                            for s in (lib_resp if isinstance(lib_resp, list) else []):
                                if _re.sub(r"[^a-z0-9]", "", (s.get("title") or "").lower()) == norm_fl:
                                    _req.post(f"{base_url}/api/v3/command",
                                              headers=_headers(),
                                              json={"name": "RescanSeries", "seriesId": s["id"]},
                                              timeout=8)
                                    break
                        except Exception:
                            pass

                        imported += 1
                        yield sse(log=f"  ✓ {folder_label}", pct=pct)

                else:
                    # Radarr — single movie stub
                    fake_fn   = _pick_fake_filename(t_name, real_files)
                    stub_path = _os.path.join(dest_dir, fake_fn)

                    if mode == "partial" and _os.path.exists(stub_path):
                        skipped += 1
                        continue

                    _write_stub(dest_dir, fake_fn, real_files)

                    # Trigger RescanMovie (find movie by folder name)
                    try:
                        norm_fl  = _re.sub(r"[^a-z0-9]", "", folder_label.lower())
                        lib_resp = _req.get(f"{base_url}/api/v3/movie",
                                            headers=_headers(), timeout=10).json()
                        for m in (lib_resp if isinstance(lib_resp, list) else []):
                            if _re.sub(r"[^a-z0-9]", "", (m.get("title") or "").lower()) == norm_fl:
                                _req.post(f"{base_url}/api/v3/command",
                                          headers=_headers(),
                                          json={"name": "RescanMovie", "movieId": m["id"]},
                                          timeout=8)
                                break
                    except Exception:
                        pass

                    imported += 1
                    yield sse(log=f"  ✓ {folder_label}", pct=pct)

            except Exception as e:
                yield sse(log=f"  ❌ {item_name[:60]}: {e}")
                errors += 1

        yield sse(
            log=f"\n✅ Sync complete. Written: {imported}  Skipped: {skipped}  Errors: {errors}",
            pct=100, status="Done", done=True
        )

    from flask import stream_with_context
    return app.response_class(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"}
    )




if os.environ.get("ENABLE_FUSE", "true").lower() == "true":
    # Apply any saved mount config before starting FUSE
    _apply_fuse_settings(_get_fuse_settings())
    t = threading.Thread(target=_start_fuse, daemon=False)
    t.start()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))

    # Raise the process fd limit so select() doesn't hit its 1024-fd ceiling.
    import resource
    try:
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = min(hard, 65536)
        if soft < target:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
            app.logger.info(f"Raised RLIMIT_NOFILE {soft} → {target}")
    except Exception as e:
        app.logger.warning(f"Could not raise fd limit: {e}")

    # Werkzeug server with a hard cap on concurrent request threads.
    from werkzeug.serving import make_server as _make_server
    max_threads = int(os.environ.get("SERVER_THREADS", "16"))
    _thread_sem = threading.Semaphore(max_threads)

    _srv = _make_server("0.0.0.0", port, app, threaded=True)
    _orig_process_request = _srv.process_request

    def _capped_process_request(request, client_address):
        if _thread_sem.acquire(blocking=False):
            def _run():
                try:
                    _srv.finish_request(request, client_address)
                except Exception:
                    _srv.handle_error(request, client_address)
                finally:
                    _srv.shutdown_request(request)
                    _thread_sem.release()
            t = threading.Thread(target=_run, daemon=True)
            t.start()
        else:
            # All slots busy — serve synchronously rather than drop the request
            try:
                _srv.finish_request(request, client_address)
            except Exception:
                _srv.handle_error(request, client_address)
            finally:
                _srv.shutdown_request(request)

    _srv.process_request = _capped_process_request
    app.logger.info(f"Starting server on :{port} (max {max_threads} threads)")
    _srv.serve_forever()

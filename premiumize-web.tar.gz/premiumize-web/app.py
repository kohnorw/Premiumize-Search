import os
import re
import json
import secrets
import threading
import time
import urllib.parse
import requests
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from xml.sax.saxutils import escape as xml_escape
from flask import Flask, request, jsonify, render_template, Response
import logging
import sys

app = Flask(__name__)

# Docker-friendly logging: make Premiumize Web app logs visible in `docker logs`.
logging.basicConfig(stream=sys.stdout, level=logging.INFO, format="[%(asctime)s] %(levelname)s in %(name)s: %(message)s", force=True)
app.logger.setLevel(logging.INFO)

def _pw_log(msg: str) -> None:
    """Deployment log helper. Avoid duplicate stdout spam."""
    try:
        app.logger.warning(msg)
    except Exception:
        pass

# ── Auto-import thread pool ───────────────────────────────────────────────────
# Limits concurrent auto-import jobs to avoid exhausting OS thread limit.
# Jobs queue when all workers are busy — they don't get dropped.
_import_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="auto-import")

# ── stream token cache ────────────────────────────────────────────────────────
# Tokens map to (hash, filename) — NOT a CDN URL.
# The proxy resolves a fresh CDN URL on every request via the directdl cache,
# so links never go stale regardless of how long VLC has been open.

import hmac

# Secret key for signing tokens — generated once per process lifetime.
# Tokens are deterministic per (hash, filename) so they survive restarts as long
# as the same secret is used. We store it in config so it persists across restarts.
def _get_token_secret() -> str:
    cfg = _load_config()
    if "token_secret" not in cfg:
        cfg["token_secret"] = secrets.token_hex(32)
        _save_config(cfg)
    return cfg["token_secret"]

# _make_stream_token lives in transfer_manager to avoid circular import
# (prewarm threads import transfer_manager which would re-execute app.py)
from transfer_manager import _make_stream_token

def _verify_stream_token(token: str, hash_: str, filename: str) -> bool:
    expected = _make_stream_token(hash_, filename)
    return hmac.compare_digest(token, expected)

# ── directdl cache ────────────────────────────────────────────────────────────
# Shared cache so the stream proxy doesn't call directdl on every chunk read.
# TTL matches the FUSE layer (30 min). Automatically refreshed on expiry.

_DIRECTDL_TTL    = 172800  # 48 hours — CDN URLs are long-lived; minimise directdl API calls
_DIRECTDL_MARGIN = 300   # refresh in the background once within 5 min of expiry
_directdl_cache: dict = {}  # hash → (files: list, expires_at: float)
_directdl_lock  = threading.Lock()
_directdl_refreshing: set = set()  # hashes with an in-flight background refresh


def _spawn_directdl_refresh(hash_: str, name: str) -> None:
    """Re-mint CDN links in the background so an active stream never blocks."""
    with _directdl_lock:
        if hash_ in _directdl_refreshing:
            return
        _directdl_refreshing.add(hash_)

    def _do():
        try:
            files = _directdl_for_manager_raw(hash_, name)
            if files:
                with _directdl_lock:
                    _directdl_cache[hash_] = (files, time.time() + _DIRECTDL_TTL)
        except Exception:
            app.logger.warning(f"[directdl {hash_[:8]}] background refresh failed")
        finally:
            with _directdl_lock:
                _directdl_refreshing.discard(hash_)

    _import_pool.submit(_do)


def _get_directdl(hash_: str, name: str, force: bool = False) -> list:
    """
    Return directdl file list, refreshing from Premiumize as needed.

    - force=True bypasses the cache and overwrites it with a fresh result —
      used when a CDN URL has been observed to expire (403/410).
    - Otherwise this is stale-while-revalidate: a fresh entry is returned
      directly; an entry inside the refresh margin is returned immediately while
      a background thread re-mints the links, so reads never wait on the network.
    """
    now = time.time()
    if not force:
        with _directdl_lock:
            cached = _directdl_cache.get(hash_)
        if cached:
            files, expires_at = cached
            if now < expires_at - _DIRECTDL_MARGIN:
                return files                      # comfortably fresh
            if now < expires_at:
                _spawn_directdl_refresh(hash_, name)  # refresh ahead of expiry
                return files                      # current link is still valid
            # hard-expired → fall through to a synchronous fetch
    # Cache miss, expired, or forced — fetch fresh
    files = _directdl_for_manager_raw(hash_, name)
    if files:
        with _directdl_lock:
            _directdl_cache[hash_] = (files, now + _DIRECTDL_TTL)
    return files

# ── persistent config ─────────────────────────────────────────────────────────

CONFIG_PATH = os.environ.get("CONFIG_PATH", "/app/config.json")
_config_lock = threading.Lock()
_config_cache: dict | None = None   # in-memory copy, None = not yet loaded

def _load_config() -> dict:
    global _config_cache
    if _config_cache is not None:
        return _config_cache
    try:
        with open(CONFIG_PATH) as f:
            _config_cache = json.load(f)
    except Exception:
        _config_cache = {}
    return _config_cache

def _save_config(cfg: dict):
    global _config_cache
    os.makedirs(os.path.dirname(CONFIG_PATH) or ".", exist_ok=True)
    with _config_lock:
        _config_cache = cfg          # update cache before write
        with open(CONFIG_PATH, "w") as f:
            json.dump(cfg, f, indent=2)

def get_prowlarr_config() -> dict:
    saved = _load_config().get("prowlarr", {})
    # Env vars take precedence if set, otherwise fall back to saved config
    return {
        "url":     PROWLARR_URL or saved.get("url", ""),
        "api_key": PROWLARR_KEY or saved.get("api_key", ""),
        "from_env": bool(PROWLARR_URL or PROWLARR_KEY),
    }

def save_prowlarr_config(url: str, api_key: str):
    url = url.strip().rstrip("/")
    if url and not url.startswith(("http://", "https://")):
        url = "http://" + url
    cfg = _load_config()
    cfg["prowlarr"] = {"url": url, "api_key": api_key}
    _save_config(cfg)

# ── static config ─────────────────────────────────────────────────────────────

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

PM_BASE          = "https://www.premiumize.me/api"
PM_CACHE         = f"{PM_BASE}/cache/check"
PM_DIRECTDL      = f"{PM_BASE}/transfer/directdl"
PM_TRANSFER      = f"{PM_BASE}/transfer/create"
PM_TRANSFER_LIST = f"{PM_BASE}/transfer/list"
PM_ACCOUNT       = f"{PM_BASE}/account/info"

PM_API_KEY_ENV = os.environ.get("PREMIUMIZE_API_KEY", "")
TORZNAB_APIKEY = os.environ.get("TORZNAB_APIKEY", "changeme")
PROWLARR_URL   = os.environ.get("PROWLARR_URL", "")
PROWLARR_KEY   = os.environ.get("PROWLARR_API_KEY", "")

def get_pm_api_key() -> str:
    """Return PM API key — env var takes precedence, then saved config."""
    if PM_API_KEY_ENV:
        return PM_API_KEY_ENV
    return _load_config().get("pm_api_key", "")

def save_pm_api_key(key: str):
    cfg = _load_config()
    cfg["pm_api_key"] = key
    _save_config(cfg)


# Torznab rate limit: requests per window
TORZNAB_RATE_LIMIT  = int(os.environ.get("TORZNAB_RATE_LIMIT", "60"))   # max requests
TORZNAB_RATE_WINDOW = int(os.environ.get("TORZNAB_RATE_WINDOW", "60"))  # per N seconds

# ── torznab rate limiter (sliding window per IP) ──────────────────────────────

_rate_lock = threading.Lock()
_rate_data: dict[str, list] = defaultdict(list)  # ip -> [timestamps]

def _check_rate_limit(ip: str) -> tuple[bool, int, int, int]:
    """Returns (allowed, limit, remaining, reset_ts)"""
    now = time.time()
    window_start = now - TORZNAB_RATE_WINDOW
    with _rate_lock:
        hits = [t for t in _rate_data[ip] if t > window_start]
        remaining = max(0, TORZNAB_RATE_LIMIT - len(hits))
        reset_ts = int(now + TORZNAB_RATE_WINDOW)
        if remaining == 0:
            return False, TORZNAB_RATE_LIMIT, 0, reset_ts
        hits.append(now)
        _rate_data[ip] = hits
        return True, TORZNAB_RATE_LIMIT, remaining - 1, reset_ts

def _rate_headers(limit: int, remaining: int, reset_ts: int) -> dict:
    return {
        "X-RateLimit-Limit":     str(limit),
        "X-RateLimit-Remaining": str(remaining),
        "X-RateLimit-Reset":     str(reset_ts),
    }

# ── category maps ─────────────────────────────────────────────────────────────

def tpb_to_newznab(tpb_cat, name=""):
    name_up = name.upper()
    if re.search(r'S\d{2}E\d{2}|SEASON\s+\d+|\bS\d{2}\b', name_up):
        return 5000
    try:
        c = int(tpb_cat)
    except Exception:
        return 8000
    if 200 <= c < 300: return 2000
    if 500 <= c < 600: return 5000
    if 300 <= c < 400: return 3000
    return 8000


def normalize_newznab_category(cat, name=""):
    """Return a safe integer Newznab/Torznab category for filtering/XML."""
    try:
        c = int(cat or 0)
    except Exception:
        c = 0

    # TPB-style categories are 3-digit values; convert those to Newznab.
    if 0 < c < 1000:
        return tpb_to_newznab(c, name)

    # Keep valid Newznab category IDs/subcategory IDs.
    if c >= 1000:
        return c

    return 8000

# ── helpers ───────────────────────────────────────────────────────────────────

QUALITY_PATTERNS = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE
)

def fmt_size(b):
    try: return int(b)
    except Exception: return 0

def fmt_size_str(b):
    try: b = int(b)
    except Exception: return "?"
    if b > 1_000_000_000: return f"{b/1_000_000_000:.2f} GB"
    if b > 1_000_000:     return f"{b/1_000_000:.0f} MB"
    if b > 1_000:         return f"{b/1_000:.0f} KB"
    return f"{b} B"

def _sanitize(query):
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()

def parse_query(raw):
    quality = QUALITY_PATTERNS.findall(raw)
    search_raw = QUALITY_PATTERNS.sub('', raw).strip()
    season, episode = None, None
    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        search_raw = re.sub(r'\bseason\s+\d+\b', f'S{season:02d}', search_raw, flags=re.IGNORECASE)
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return ' '.join(search_raw.split()).strip(), season, episode, quality

def strip_season(query):
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', '', query, flags=re.IGNORECASE)
    return ' '.join(t.split())

def filter_by_season(torrents, season, episode):
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        if episode is not None and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out

def filter_by_quality(torrents, quality):
    if not quality:
        return torrents
    out = []
    for t in torrents:
        name_up = t.get("name", "").upper()
        for q in quality:
            if q.upper().rstrip('P') in name_up:
                out.append(t)
                break
    return out if out else torrents

# ── TPB fetch ─────────────────────────────────────────────────────────────────

def _fetch_tpb(query, limit=40):
    queries = [query]
    sanitized = _sanitize(query)
    if sanitized.lower() != query.lower():
        queries.append(sanitized)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = requests.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict)
                    and x.get("info_hash")
                    and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
                ]
                if valid:
                    return valid[:limit]
            except Exception:
                continue
    return []

# ── Prowlarr fetch ────────────────────────────────────────────────────────────

def _fetch_prowlarr(query: str, season=None, episode=None, limit=40) -> list:
    """Search Prowlarr and return normalised torrent dicts."""
    cfg = get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"):
        return []

    base = cfg["url"]
    key  = cfg["api_key"]

    # Build query string. Strip any season/episode token the caller may already
    # have baked into `query` before re-adding the canonical one, so we never
    # emit a doubled term like "Spongebob S15 S15".
    q = query
    if season is not None:
        q_base = strip_season(query)
        q = f"{q_base} S{season:02d}" if q_base else f"S{season:02d}"
        if episode is not None:
            q += f"E{episode:02d}"
        q = " ".join(q.split())

    params = {
        "query":      q,
        "indexerIds": -2,     # all torrent indexers
        "categories": [2000, 5000, 8000],
        "type":       "search",
        "limit":      limit,
    }

    try:
        r = requests.get(
            f"{base}/api/v1/search",
            headers={"X-Api-Key": key},
            params=params,
            timeout=20,
        )
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        app.logger.warning(f"Prowlarr search failed: {e}")
        return []

    def _extract_hash(item: dict) -> str:
        """Return a 40-char hex info_hash from the result, trying multiple fields."""
        # 1. Direct infoHash field (ideal case)
        h = (item.get("infoHash") or "").lower().strip()
        if re.fullmatch(r'[0-9a-fA-F]{40}', h):
            return h

        # 2. Scan all URL-like fields for a hash in any position:
        #    - magnet: btih:<hash>
        #    - https://site.com/<HASH>/title  (e.g. TorrentDownload guid)
        #    - base32 btih variant
        for field in ("magnetUrl", "downloadUrl", "guid"):
            val = item.get(field) or ""
            # btih: prefix (magnets)
            m = re.search(r'btih:([0-9a-fA-F]{40})', val, re.IGNORECASE)
            if m:
                return m.group(1).lower()
            # bare 40-char hex segment anywhere in the URL path/query
            m = re.search(r'(?<![0-9a-fA-F])([0-9a-fA-F]{40})(?![0-9a-fA-F])', val)
            if m:
                return m.group(1).lower()
            # base32 btih (32 uppercase chars)
            m32 = re.search(r'btih:([A-Z2-7]{32})', val, re.IGNORECASE)
            if m32:
                try:
                    import base64
                    raw = base64.b32decode(m32.group(1).upper())
                    candidate = raw.hex()
                    if re.fullmatch(r'[0-9a-f]{40}', candidate):
                        return candidate
                except Exception:
                    pass

        return ""

    def _prowlarr_category(item: dict) -> int:
        """
        Map a Prowlarr result to a top-level newznab category (2000/5000/8000).

        Prowlarr often returns subcategory IDs like 5030, 5040, 2040, etc.
        The category filter uses integer division (cat // 1000) to match, but
        the raw sub-ID must still be a recognised newznab ID range.
        We also fall back to name-based detection when the categories list is
        missing or contains an unrecognised ID (e.g. 0 from showRSS).
        """
        cats = item.get("categories") or []
        name = item.get("title", "")

        for c in cats:
            raw_cid = c.get("id", 0) if isinstance(c, dict) else c
            try:
                cid = int(raw_cid or 0)
            except Exception:
                continue
            if 2000 <= cid < 3000:
                return cid   # Movies (sub or parent — filter uses // 1000)
            if 5000 <= cid < 6000:
                return cid   # TV
            if 8000 <= cid < 9000:
                return cid   # Other

        # No usable newznab ID — infer from title
        if re.search(r'\bS\d{1,2}(?:E\d{1,2})?\b|\bSeason\s*\d+\b|\b\d{1,2}x\d{2}\b', name, re.IGNORECASE):
            return 5000
        return 8000

    results = []
    skipped = 0
    for item in data:
        info_hash = _extract_hash(item)
        if not info_hash:
            skipped += 1
            continue
        # Extract tracker list from the original magnet guid if present,
        # so downstream clients with DHT disabled can still use the magnet.
        trackers = []
        guid_val = item.get("guid") or ""
        if "btih:" in guid_val.lower():
            trackers = re.findall(r'[&?]tr=([^&]+)', guid_val)
        # Also check magnetUrl
        mag_val = item.get("magnetUrl") or ""
        if "btih:" in mag_val.lower() and not trackers:
            trackers = re.findall(r'[&?]tr=([^&]+)', mag_val)

        results.append({
            "info_hash": info_hash,
            "name":      item.get("title", "Unknown"),
            "size":      item.get("size", 0),
            "seeders":   item.get("seeders", 0) or 0,
            "leechers":  item.get("leechers", 0) or 0,
            "category":  _prowlarr_category(item),
            "indexer":   item.get("indexer", ""),
            "trackers":  trackers,
        })

    if skipped:
        app.logger.debug(f"Prowlarr: skipped {skipped} results with no extractable hash")

    return results

# ── Premiumize helpers ────────────────────────────────────────────────────────

def _make_magnet(torrent):
    h    = torrent["info_hash"].lower()
    name = urllib.parse.quote(torrent.get("name", ""), safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={name}"

def pm_headers(api_key):
    return {"Authorization": f"Bearer {api_key}"}

def check_cache_pm(api_key, torrents):
    if not torrents:
        return {}
    hashes = [t["info_hash"].lower() for t in torrents]
    headers = {**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"}
    try:
        from transfer_manager import _pm_api_acquire
        _pm_api_acquire()
        r = requests.post(
            PM_CACHE,
            headers=headers,
            data=urllib.parse.urlencode([("items[]", h) for h in hashes]),
            timeout=15,
        )
        r.raise_for_status()
        data = r.json()
    except Exception:
        return {}
    if data.get("status") != "success":
        return {}
    responses = data.get("response", [])
    return {h: bool(responses[i]) if i < len(responses) else False
            for i, h in enumerate(hashes)}

# ── unified search ────────────────────────────────────────────────────────────

def do_search(query, season=None, episode=None, quality=None, limit=40, pm_key=None):
    # Try Prowlarr first, fall back to TPB
    prowlarr_cfg = get_prowlarr_config()
    if prowlarr_cfg.get("url") and prowlarr_cfg.get("api_key"):
        torrents = _fetch_prowlarr(query, season, episode, limit)
        source = "prowlarr"
    else:
        torrents = []
        source = "tpb"

    if not torrents:
        torrents = _fetch_tpb(query, limit)
        source = "tpb"
        if not torrents and season is not None:
            fallback = strip_season(query)
            if fallback and fallback.lower() != query.lower():
                torrents = _fetch_tpb(fallback, limit * 2)

    if not torrents:
        return []

    if source == "tpb":
        torrents = filter_by_season(torrents, season, episode)
        if not torrents and season is not None:
            torrents = _fetch_tpb(query, limit)
        if quality:
            torrents = filter_by_quality(torrents, quality)

    ready_map = check_cache_pm(pm_key, torrents) if pm_key else {}

    results = []
    seen = set()
    for t in torrents:
        h = t["info_hash"].lower()
        if h in seen:
            continue
        seen.add(h)
        cat = normalize_newznab_category(t.get("category", 8000), t.get("name", ""))
        results.append({
            "hash":     h,
            "name":     t.get("name", "Unknown"),
            "size":     fmt_size(t.get("size", 0)),
            "size_str": fmt_size_str(t.get("size", 0)),
            "seeders":  int(t.get("seeders", 0) or 0),
            "leechers": int(t.get("leechers", 0) or 0),
            "category": cat,
            "cached":   ready_map.get(h, False),
            "indexer":  t.get("indexer", "TPB"),
            "trackers": t.get("trackers", []),
        })

    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results

# ── Torznab XML ───────────────────────────────────────────────────────────────

def torznab_caps():
    return '''<?xml version="1.0" encoding="UTF-8"?>
<caps>
  <server title="Premiumize Indexer" />
  <limits default="40" max="100"/>
  <searching>
    <search available="yes" supportedParams="q"/>
    <tv-search available="yes" supportedParams="q,season,ep"/>
    <movie-search available="yes" supportedParams="q"/>
  </searching>
  <categories>
    <category id="2000" name="Movies">
      <subcat id="2010" name="Movies/Foreign"/>
      <subcat id="2020" name="Movies/Other"/>
      <subcat id="2030" name="Movies/SD"/>
      <subcat id="2040" name="Movies/HD"/>
      <subcat id="2045" name="Movies/UHD"/>
      <subcat id="2050" name="Movies/BluRay"/>
      <subcat id="2060" name="Movies/3D"/>
      <subcat id="2070" name="Movies/DVD"/>
      <subcat id="2080" name="Movies/WEB-DL"/>
    </category>
    <category id="5000" name="TV">
      <subcat id="5040" name="TV/HD"/>
      <subcat id="5045" name="TV/UHD"/>
      <subcat id="5030" name="TV/SD"/>
      <subcat id="5010" name="TV/WEB-DL"/>
    </category>
    <category id="8000" name="Other"/>
  </categories>
</caps>'''

# Well-known public trackers appended to every magnet as a fallback so
# clients with DHT disabled can still connect. Indexer-supplied trackers
# (from the Prowlarr result) are prepended and take precedence.
_FALLBACK_TRACKERS = [
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.tracker.cl:1337/announce",
    "udp://tracker.openbittorrent.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce",
    "udp://explodie.org:6969/announce",
]

def torznab_results(results, query=""):
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items = []
    for r in results:
        # Build magnet with trackers so clients with DHT disabled can use it
        trackers = r.get("trackers") or []
        all_trackers = list(dict.fromkeys(trackers + _FALLBACK_TRACKERS))  # dedup, indexer first
        tr_params = "".join(f"&tr={urllib.parse.quote(t, safe='')}" for t in all_trackers)
        magnet = f"magnet:?xt=urn:btih:{r['hash']}&dn={urllib.parse.quote(r['name'], safe='')}{tr_params}"
        cached_attr = '<torznab:attr name="cached" value="1"/>' if r.get("cached") else ''
        # Use the transfer's added_at timestamp as pubDate so Sonarr/Radarr can
        # correctly identify new items in RSS polls. Using "now" for everything
        # means Sonarr can't distinguish new from old items.
        added_at = r.get("added_at") or 0
        if added_at:
            pub_date = datetime.fromtimestamp(float(added_at), tz=timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
        else:
            pub_date = now
        items.append(f"""    <item>
      <title>{xml_escape(r['name'])}</title>
      <guid>{xml_escape(magnet)}</guid>
      <link>{xml_escape(magnet)}</link>
      <pubDate>{pub_date}</pubDate>
      <size>{r['size']}</size>
      <enclosure url="{xml_escape(magnet)}" length="{r['size']}" type="application/x-bittorrent"/>
      <torznab:attr name="magneturl" value="{xml_escape(magnet)}"/>
      <torznab:attr name="infohash" value="{r['hash']}"/>
      <torznab:attr name="seeders" value="{r['seeders']}"/>
      <torznab:attr name="leechers" value="{r['leechers']}"/>
      <torznab:attr name="size" value="{r['size']}"/>
      <torznab:attr name="category" value="{normalize_newznab_category(r.get('category'), r.get('name', ''))}"/>
      {cached_attr}
    </item>""")
    items_xml = "\n".join(items)
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <channel>
    <title>Premiumize Indexer</title>
    <description>TPB/Prowlarr via Premiumize cache check</description>
    <link>http://localhost</link>
    <language>en-US</language>
    <pubDate>{now}</pubDate>
    <response xmlns="urn:newznab:api" offset="0" total="{len(results)}"/>
{items_xml}
  </channel>
</rss>'''

def xml_error(code, description, extra_headers=None):
    r = Response(
        f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="{code}" description="{xml_escape(description)}"/>''',
        mimetype="application/xml", status=400
    )
    if extra_headers:
        for k, v in extra_headers.items():
            r.headers[k] = v
    return r

# ── routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    resp = render_template("index.html")
    from flask import make_response
    r = make_response(resp)
    r.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    return r

# Torznab — with rate limiting
@app.route("/torznab")
@app.route("/torznab/api")
def torznab():
    t = request.args.get("t", "").lower()

    # Caps is always public — Prowlarr probes it without a key
    if t == "caps":
        return Response(torznab_caps(), mimetype="application/xml")

    # API key check for all other requests
    apikey = request.args.get("apikey", "") or request.headers.get("X-Api-Key", "")
    if TORZNAB_APIKEY and apikey != TORZNAB_APIKEY:
        return xml_error(100, "Invalid API key")

    # Rate limit by IP
    ip = request.headers.get("X-Forwarded-For", request.remote_addr).split(",")[0].strip()
    allowed, limit, remaining, reset_ts = _check_rate_limit(ip)
    rh = _rate_headers(limit, remaining, reset_ts)

    if not allowed:
        retry_after = reset_ts - int(time.time())
        r = Response(
            f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="429" description="Rate limit exceeded. Retry after {retry_after}s"/>''',
            mimetype="application/xml", status=429,
            headers={**rh, "Retry-After": str(retry_after)},
        )
        return r

    if t in ("search", "tvsearch", "movie"):
        q      = request.args.get("q", "").strip()
        season = request.args.get("season", "").strip()
        ep     = request.args.get("ep", "").strip()
        cat    = request.args.get("cat", "").strip()

        app.logger.info(f"Torznab {t}: q={q!r} season={season!r} ep={ep!r} cat={cat!r}")

        # Parse season/ep from the explicit Torznab params (sent by Sonarr/Radarr).
        # Do NOT bake them into the query string — _fetch_prowlarr rebuilds the
        # query itself, and parse_query below also extracts them from q.
        # Baking them in first caused doubled tokens like "SpongeBob S15 S15".
        parsed_s, parsed_ep = None, None
        if season:
            try:
                parsed_s = int(season)
                if ep:
                    parsed_ep = int(ep)
            except ValueError:
                pass
        query = q  # raw title only; season/ep passed as separate numeric params

        # Empty query — return cached library items for the requested category.
        # This satisfies Radarr/Sonarr connection tests and browse calls.
        # Falls back to TPB if the library is empty so the connection test passes.
        if not query:
            all_transfers = _transfer_manager.all_transfers()
            streamable    = [t for t in all_transfers if t["state"] in ("cached", "complete")]
            fb_results    = []
            for t in streamable:
                h    = t["hash"]
                name = t.get("name") or h
                is_series = bool(re.search(
                    r'\bS\d{1,2}(?:E\d{1,2})?\b|\bSeason\s*\d+\b|\b\d{1,2}x\d{2}\b',
                    name, re.IGNORECASE))
                item_cat = 5000 if is_series else 2000
                fb_results.append({
                    "hash":     h,
                    "name":     name,
                    "size":     0,
                    "size_str": "",
                    "seeders":  1,
                    "leechers": 0,
                    "category": item_cat,
                    "cached":   True,
                    "indexer":  "premiumize",
                    "trackers": [],  # fallback trackers added by torznab_results
                    "added_at": t.get("added_at") or 0,
                })

            # Filter by requested category
            if cat and cat != "0":
                requested = [int(c) for c in cat.split(",") if c.strip().isdigit() and c.strip() != "0"]
                if requested:
                    filtered = [r for r in fb_results if any(
                        (normalize_newznab_category(r.get("category")) == rc)
                        or (normalize_newznab_category(r.get("category")) // 1000 == rc // 1000)
                        for rc in requested
                    )]
                    if filtered:
                        fb_results = filtered

            # Fall back to TPB if library is empty or category filter left nothing
            if not fb_results:
                raw = _fetch_tpb("1080p", 20)
                for ti in raw:
                    h       = ti["info_hash"].lower()
                    ti_cat  = tpb_to_newznab(ti.get("category", 0), ti.get("name", ""))
                    fb_results.append({
                        "hash":     h,
                        "name":     ti.get("name", "Unknown"),
                        "size":     fmt_size(ti.get("size", 0)),
                        "size_str": fmt_size_str(ti.get("size", 0)),
                        "seeders":  int(ti.get("seeders", 0) or 0),
                        "leechers": int(ti.get("leechers", 0) or 0),
                        "category": ti_cat,
                        "cached":   False,
                        "indexer":  "TPB",
                    })

            # Sort newest first so Sonarr's RSS cutoff works correctly
            fb_results.sort(key=lambda x: float(x.get("added_at") or 0), reverse=True)
            resp = Response(torznab_results(fb_results, ""), mimetype="application/xml")
            for k, v in rh.items():
                resp.headers[k] = v
            return resp

        parsed_q, ps, pe, quality = parse_query(query)
        parsed_s = parsed_s or ps
        parsed_ep = parsed_ep or pe

        results = do_search(parsed_q, parsed_s, parsed_ep, quality, limit=40, pm_key=get_pm_api_key())

        # Filter to cached-only if explicitly enabled in config (default: off)
        # When enabled AND there are cached results, restrict to cached only.
        # We intentionally do NOT fall back silently — if cached_only is on and
        # nothing is cached, return everything so Prowlarr doesn't think the
        # indexer is broken. The UI toggle should be used deliberately.
        if _load_config().get("torznab_cached_only", False):
            cached = [r for r in results if r.get("cached")]
            if cached:
                results = cached
            else:
                app.logger.debug("torznab_cached_only enabled but no cached results — returning all")

        if cat and cat != "0":
            requested = [int(c) for c in cat.split(",") if c.strip().isdigit() and c.strip() != "0"]
            if requested:
                filtered = [r for r in results if any(
                    (normalize_newznab_category(r.get("category")) == rc)
                    or (normalize_newznab_category(r.get("category")) // 1000 == rc // 1000)
                    for rc in requested
                )]
                if filtered:
                    results = filtered

        resp = Response(torznab_results(results, q), mimetype="application/xml")
        for k, v in rh.items():
            resp.headers[k] = v
        return resp

    app.logger.warning(f"Unknown torznab function: {t!r}")
    return xml_error(202, f"Unknown function: {t}", rh)

# Web UI — single hash cache check (used by the magnet/hash checker in the Search tab)
@app.route("/api/cache-check", methods=["POST"])
def cache_check():
    data     = request.json or {}
    api_key  = data.get("api_key", "").strip() or get_pm_api_key()
    hash_    = data.get("hash", "").strip().lower()
    dn_hint  = (data.get("dn") or "").strip()   # optional dn= hint from magnet

    if not api_key:
        return jsonify({"error": "API key required"}), 400
    if not hash_:
        return jsonify({"error": "hash required"}), 400

    result = check_cache_pm(api_key, [{"info_hash": hash_}])
    cached = bool(result.get(hash_, False))

    # Try to resolve the real torrent name from Premiumize.
    # directdl returns content[].path which starts with the torrent folder name.
    # We extract the top-level component — that is the torrent name Premiumize knows.
    resolved_name = dn_hint or ""
    if not resolved_name:
        try:
            magnet  = f"magnet:?xt=urn:btih:{hash_}"
            r_dl = requests.post(
                PM_DIRECTDL,
                headers={**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
                data=urllib.parse.urlencode({"src": magnet}),
                timeout=15,
            )
            if r_dl.ok:
                dl_data = r_dl.json()
                if dl_data.get("status") == "success":
                    # content[].path looks like "Show Name/Season 1/ep.mkv"
                    # The torrent name is the common top-level folder, or the
                    # filename itself for single-file torrents.
                    paths = [item.get("path", "") for item in dl_data.get("content", []) if item.get("path")]
                    if paths:
                        tops = [p.split("/")[0] for p in paths]
                        # If all files share the same top-level folder, that IS the name
                        if len(set(tops)) == 1 and "/" in paths[0]:
                            resolved_name = tops[0]
                        else:
                            # Single-file torrent or mixed — use longest common prefix
                            # or just strip the extension from the first filename
                            first = tops[0]
                            base, ext = os.path.splitext(first)
                            resolved_name = base if ext else first
        except Exception:
            pass

    return jsonify({"hash": hash_, "cached": cached, "name": resolved_name})


# Web UI — search
@app.route("/api/search", methods=["POST"])
def search():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_pm_api_key()
    query   = data.get("query", "").strip()

    if not api_key:
        return jsonify({"error": "API key required"}), 400
    if not query:
        return jsonify({"error": "Query required"}), 400

    parsed_q, season, episode, quality = parse_query(query)
    results = do_search(parsed_q, season, episode, quality, limit=40, pm_key=api_key)

    return jsonify({
        "results": [{**r, "size": r["size_str"]} for r in results],
        "total":   len(results),
        "source":  "prowlarr" if get_prowlarr_config().get("url") else "tpb",
    })

# Web UI — add to transfer manager (cached → FUSE instantly, uncached → download then FUSE)
@app.route("/api/add", methods=["POST"])
def add():
    data      = request.json or {}
    hash_     = data.get("hash", "").strip().lower()
    name      = data.get("name", "").strip()
    is_cached = data.get("cached", None)  # passed from frontend search results

    if not hash_:
        return jsonify({"error": "hash required"}), 400

    # If frontend already knows it's cached, write the state directly so it
    # appears in the FUSE mount immediately without an extra round-trip to the
    # Premiumize cache-check API.
    # FIX: always persist the real human-readable name so the FUSE directory
    # gets a proper title instead of the raw hash. Also use _set only for the
    # state transition so we don't race with the poller on existing entries.
    if is_cached is True:
        existing = _transfer_manager.get_transfer(hash_)
        if not existing:
            _transfer_manager._set(hash_, name=name or hash_, state="cached",
                                   added_at=time.time())
        else:
            # Always update name if we now have a better one
            updates = {}
            if name and existing.get("name") in (None, "", existing["hash"]):
                updates["name"] = name
            if existing["state"] not in ("cached", "complete"):
                updates["state"] = "cached"
            if updates:
                _transfer_manager._set(hash_, **updates)
        t = _transfer_manager.get_transfer(hash_)
    else:
        t = _transfer_manager.add(hash_, name)

    # FUSE serves stable stub files by default. Plex should discover stubs through
    # Sonarr/Radarr imports, and playback unlocks only the requested file.
    # No Plex watcher/path-scan is triggered here.

    # ── Auto-import into Radarr/Sonarr ────────────────────────────────────────
    # Fire-and-forget in background so the response returns immediately.
    # Determines 4K vs HD from the name, picks the right instance, and
    # adds the movie/series if not already present, then creates a fake file.
    def _queue_plex_exact_scan(kind: str, folder_name: str, name: str = "", category: str = ""):
        """Queue a Plex path refresh for exactly this movie/show folder.

        Uses _category_subdir to resolve the correct subdir (movies/series/movies4k/series4k)
        so 4K releases scan the right folder instead of always hitting /movies or /series.
        """
        try:
            from transfer_manager import _plex
            from fuse_mount import _category_subdir
            cfg = _load_config().get("plex", {})
            if cfg.get("scan_exact_item", True) is False:
                return
            # Derive subdir the same way FUSE does so the path matches exactly
            subdir = _category_subdir(name or folder_name, category, kind=kind)
            app.logger.warning(f"[plex-add] queued exact scan subdir={subdir} folder={folder_name}")
            _plex.notify_ready(subdir, folder_name)
        except Exception as e:
            app.logger.warning(f"[plex-add] queue failed: {e}")

    def _auto_import_to_arr(hash_: str, name: str):
        try:
            instances = _get_sync_config().get("instances", [])
            if not instances:
                return

            import re as _re
            from qbt_mock import (_make_fake_file, _pick_fake_filename,
                                   _safe_name, _RES_PATTERNS)

            # Detect 4K from name
            is_4k = bool(next((p for _, p in _RES_PATTERNS
                                if _.startswith("2") and p.search(name)), None))

            # Detect series from name using the shared name_match module
            from name_match import is_series as _is_series
            is_series = _is_series(name)

            # Pick matching instances:
            # - type must match (radarr/sonarr)
            # - quality="any" instances accept both HD and 4K
            # - quality="4k" instances only get 4K content
            # - quality="hd" instances only get HD content
            arr_type     = "sonarr" if is_series else "radarr"
            quality_tier = "4k" if is_4k else "hd"

            targets = [i for i in instances
                       if i.get("type") == arr_type
                       and i.get("quality", "hd") in (quality_tier, "any")
                       and i.get("url") and i.get("key")]

            if not targets:
                return

            import requests as _req_mod

            for inst in targets:
                base_url = inst["url"].rstrip("/")
                api_key  = inst["key"]
                headers  = {"X-Api-Key": api_key, "Content-Type": "application/json"}

                try:
                    # Get quality profile and root folder
                    qp_resp = _req_mod.get(f"{base_url}/api/v3/qualityProfile",
                                           headers=headers, timeout=8).json()
                    quality_id = qp_resp[0]["id"] if isinstance(qp_resp, list) and qp_resp else 1

                    rf_resp = _req_mod.get(f"{base_url}/api/v3/rootFolder",
                                           headers=headers, timeout=8).json()
                    root_path = rf_resp[0]["path"].rstrip("/") if isinstance(rf_resp, list) and rf_resp else (
                        "/tv" if is_series else "/movies")

                    if is_series:
                        # Extract series name — strip episode/season info and quality tags
                        # Handle patterns like:
                        #   Friends.S10E01.1080p           → "Friends"
                        #   Friends (1994) Season 1-10     → "Friends"
                        #   BEEF S02E01 1080p WEB          → "BEEF"
                        #   The.Bear.S03E01.720p.WEB       → "The Bear"
                        #   Abbott.Elementary.S02.Complete → "Abbott Elementary"
                        series_raw = name
                        # Replace dots/underscores between words with spaces FIRST
                        # (only between word chars, not things like "S01.E01")
                        series_raw = _re.sub(r'(?<=[A-Za-z0-9])\.(?=[A-Za-z0-9])', ' ', series_raw)
                        series_raw = series_raw.replace('_', ' ')
                        # Strip multi-season range: S01-S10, S01-S09, etc.
                        series_raw = _re.sub(r'\bS\d{1,2}[-–]\s*S?\d{1,2}\b.*', '', series_raw, flags=_re.IGNORECASE)
                        # Strip Season N-N range
                        series_raw = _re.sub(r'\bSeason\s*\d+[-–]\d+\b.*', '', series_raw, flags=_re.IGNORECASE)
                        # Strip SxxExx or Season N or Sxx (season-only marker)
                        series_raw = _re.sub(r'\bS\d{1,2}(?:E\d{1,3}(?:[-–]E?\d{1,3})?)?\b.*', '', series_raw, flags=_re.IGNORECASE)
                        series_raw = _re.sub(r'\bSeason\s*\d+\b.*', '', series_raw, flags=_re.IGNORECASE)
                        # Grab year if present (before quality strip swallows it)
                        series_year = None
                        m_year = _re.search(r'\((\d{4})\)', series_raw)
                        if m_year:
                            series_year = m_year.group(1)
                            series_raw = series_raw[:m_year.start()] + series_raw[m_year.end():]
                        if not series_year:
                            m_yr2 = _re.search(r'\b(19|20)(\d{2})\b', series_raw)
                            if m_yr2:
                                series_year = m_yr2.group(0).strip()
                                series_raw = series_raw[:m_yr2.start()] + series_raw[m_yr2.end():]
                        # Strip quality/codec tags and everything after
                        series_raw = _re.sub(
                            r'\b(2160[ip]?|1080[ip]?|720[ip]?|480[ip]?|576[ip]?|4k|uhd|hdr|hdr10|'
                            r'bluray|blu[-\s]?ray|web[-\s]?dl|webrip|hdtv|x264|x265|hevc|avc|'
                            r'h264|h265|10bit|remux|proper|repack|complete|extended|theatrical)\b.*',
                            '', series_raw, flags=_re.IGNORECASE
                        )
                        series_raw = series_raw.strip(' -–')

                        # Check if already in Sonarr — match by normalized title
                        def _norm_title(s):
                            return _re.sub(r'[^a-z0-9]', '', (s or '').lower())

                        existing_series = _req_mod.get(f"{base_url}/api/v3/series",
                                                        headers=headers, timeout=10).json()
                        existing_series = existing_series if isinstance(existing_series, list) else []
                        existing_norm   = {_norm_title(s.get("title") or ""): s
                                           for s in existing_series}

                        series_id    = None
                        series_title = None   # canonical Sonarr title — used for stub filenames
                        series_norm  = _norm_title(series_raw)

                        # Check existing library — try exact, then with year, then substring
                        if series_norm in existing_norm:
                            series_id    = existing_norm[series_norm].get("id")
                            series_title = existing_norm[series_norm].get("title")
                        elif series_year:
                            norm_with_year = _norm_title(f"{series_raw} {series_year}")
                            if norm_with_year in existing_norm:
                                series_id    = existing_norm[norm_with_year].get("id")
                                series_title = existing_norm[norm_with_year].get("title")
                        if not series_id:
                            # Substring match — handles "Abbott Elementary" matching
                            # "Abbott Elementary (2021)" stored in Sonarr
                            for norm_key, s_obj in existing_norm.items():
                                if series_norm in norm_key or norm_key in series_norm:
                                    series_id    = s_obj.get("id")
                                    series_title = s_obj.get("title")
                                    app.logger.info(f"[auto-import] Fuzzy match: '{series_raw}' → '{s_obj.get('title')}'")
                                    break
                        if not series_id:
                            # Search TVDB via Sonarr — include year for precision
                            search_term = f"{series_raw} {series_year}" if series_year else series_raw
                            search = _req_mod.get(f"{base_url}/api/v3/series/lookup",
                                                   headers=headers,
                                                   params={"term": search_term}, timeout=10)
                            results = search.json() if search.ok and isinstance(search.json(), list) else []

                            # Pick the result whose title most closely matches our extracted name.
                            # Prefer exact normalized match, then starts-with, then first result.
                            best = None
                            for r in results:
                                r_norm = _norm_title(r.get("title") or "")
                                if r_norm == series_norm:
                                    best = r
                                    break
                            if not best:
                                for r in results:
                                    r_norm = _norm_title(r.get("title") or "")
                                    if r_norm.startswith(series_norm) or series_norm.startswith(r_norm):
                                        best = r
                                        break
                            if not best and results:
                                # Last resort: check if the series year matches
                                if series_year:
                                    for r in results:
                                        if str(r.get("year") or "") == series_year:
                                            best = r
                                            break
                                if not best:
                                    best = results[0]

                            if best:
                                matched_title = best.get("title", series_raw)
                                app.logger.info(f"[auto-import] Matched '{series_raw}' → '{matched_title}'")
                                best["qualityProfileId"] = quality_id
                                best["rootFolderPath"]   = root_path
                                best["monitored"]        = True
                                best["monitorNewItems"]  = "all"
                                best["seasonFolder"]     = True
                                best["addOptions"]       = {"searchForMissingEpisodes": False,
                                                             "monitor": "future"}
                                resp = _req_mod.post(f"{base_url}/api/v3/series",
                                                     headers=headers, json=best, timeout=10)
                                if resp.status_code in (200, 201):
                                    series_id    = resp.json().get("id")
                                    series_title = resp.json().get("title") or matched_title
                                    app.logger.info(f"[auto-import] Added series to {inst['name']}: {matched_title}")
                                elif resp.status_code == 400 and "already" in resp.text.lower():
                                    # Race — already exists, find it
                                    for s in existing_series:
                                        if _norm_title(s.get("title") or "") == _norm_title(matched_title):
                                            series_id    = s.get("id")
                                            series_title = s.get("title")
                                            break

                        # Create fake file(s) and trigger Sonarr rescan.
                        # For season packs: create one file per episode so Sonarr
                        # can import each episode individually.
                        t_cat = inst.get("category") or "sonarr"
                        _transfer_manager._set(hash_, state="cached", category=t_cat, imported=0)
                        try:
                            real_files = _transfer_manager.get_files(hash_) or []
                        except Exception:
                            real_files = []

                        # ── Classify the grab ────────────────────────────────
                        # single episode   → SxxEyy present
                        # multi-season pack → "S01-S05" / "Season 1-10"
                        # single-season    → "S07" / "Season 7" (no E, no range)
                        # complete series  → "Complete[ Series]" or a series with
                        #                     no season/episode marker at all
                        ep_match    = re.search(r'S(\d{1,2})E(\d{1,3})', name, re.IGNORECASE)
                        range_match = (re.search(r'S(\d{1,2})\s*[-–]\s*S?(\d{1,2})\b', name, re.IGNORECASE)
                                       or re.search(r'\bSeasons?\s*(\d{1,2})\s*[-–]\s*(\d{1,2})\b', name, re.IGNORECASE))
                        season_match = (re.search(r'S(\d{1,2})\b(?!E)', name, re.IGNORECASE)
                                        or re.search(r'\bSeason\s*(\d{1,2})\b', name, re.IGNORECASE))
                        complete_match = re.search(r'\b(complete|full)\b', name, re.IGNORECASE)
                        is_single_ep   = bool(ep_match)

                        # Decide which seasons the pack should populate.
                        # target_seasons = None means "every season the series has".
                        target_seasons = None
                        if range_match:
                            a, b = int(range_match.group(1)), int(range_match.group(2))
                            target_seasons = set(range(min(a, b), max(a, b) + 1))
                        elif season_match and not complete_match:
                            target_seasons = {int(season_match.group(1))}
                        # else (complete / no marker) → leave None = all seasons

                        if series_id and not is_single_ep:
                            # Fetch the FULL episode list for the series in one call,
                            # then keep only the seasons this pack covers. One call
                            # handles single-season, multi-season and complete-series
                            # packs uniformly.
                            try:
                                eps_resp = _req_mod.get(f"{base_url}/api/v3/episode",
                                                         headers=headers,
                                                         params={"seriesId": series_id},
                                                         timeout=20)
                                all_eps = eps_resp.json() if eps_resp.ok and isinstance(eps_resp.json(), list) else []
                            except Exception:
                                all_eps = []

                            from datetime import datetime as _dt, timezone as _tz
                            def _has_aired(ep):
                                d = ep.get("airDateUtc")
                                if not d:
                                    return True  # no date → don't exclude
                                try:
                                    return _dt.fromisoformat(d.replace("Z", "+00:00")) <= _dt.now(_tz.utc)
                                except Exception:
                                    return True

                            from qbt_mock import _detect_resolution as _det_res
                            res_tag = _det_res(name)
                            # Stub filenames must parse back to the right series, so
                            # use Sonarr's canonical title (e.g. "Andor") rather than
                            # the regex-scraped release name (which can retain junk
                            # like "Seasons 1 and 2"). Fall back to a cleaned
                            # series_raw only if Sonarr gave us no title.
                            if series_title:
                                title_for_files = series_title.strip()
                            else:
                                title_for_files = (series_raw or "").strip()
                                # extra cleanup for worded multi-season the main
                                # regex misses: "Seasons 1 and 2", "Seasons 1 & 2",
                                # "Seasons 1 to 2", "Seasons 1-2"
                                title_for_files = re.sub(
                                    r'\bSeasons?\s+\d+\s*(?:and|&|to|[-–])\s*\d+\b.*',
                                    '', title_for_files, flags=re.IGNORECASE)
                                title_for_files = re.sub(
                                    r'\bSeasons?\s+\d+\b.*', '', title_for_files, flags=re.IGNORECASE)
                            # collapse any internal double-spaces and strip illegal chars
                            title_for_files = re.sub(r'\s{2,}', ' ', title_for_files).strip(' -–')
                            title_for_files = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', title_for_files) or "Unknown"
                            # Top-level download folder (Sonarr sees this as the
                            # torrent root). Episodes are written FLAT into this
                            # folder — Sonarr matches each one by the SxxEyy token
                            # in the filename, not by a Season subfolder. We reuse
                            # _make_fake_file (the same hardened helper the single-
                            # episode path uses) so folder creation, permissions,
                            # mtime and the companion NFO are all handled the same
                            # proven way, instead of re-implementing it inline.
                            folder_name = _safe_name(name)

                            stub_count = 0
                            seasons_hit = set()
                            for ep in all_eps:
                                s_num  = ep.get("seasonNumber")
                                ep_num = ep.get("episodeNumber")
                                if not ep_num or s_num is None:
                                    continue
                                if s_num == 0:
                                    continue  # skip specials unless explicitly requested
                                if target_seasons is not None and s_num not in target_seasons:
                                    continue
                                if not _has_aired(ep):
                                    continue  # don't stub future/unaired episodes
                                ep_filename = (f"{title_for_files}.S{s_num:02d}E{ep_num:02d}"
                                               f".WEBRip-{res_tag}.mkv")
                                try:
                                    _make_fake_file(t_cat, folder_name, ep_filename, real_files)
                                    stub_count += 1
                                    seasons_hit.add(s_num)
                                except Exception as _e:
                                    app.logger.warning(f"[auto-import] stub write failed {ep_filename}: {_e}")

                            if not stub_count:
                                # Episode list unavailable — fall back to one stub so
                                # Sonarr at least sees the grab. Use the first target
                                # season if known, else season 1.
                                fb_season = (min(target_seasons) if target_seasons else 1)
                                ep_filename = f"{title_for_files}.S{fb_season:02d}.WEBRip-{res_tag}.mkv"
                                try:
                                    _make_fake_file(t_cat, folder_name, ep_filename, real_files)
                                    stub_count = 1
                                except Exception as _e:
                                    app.logger.warning(f"[auto-import] season stub write failed: {_e}")

                            app.logger.info(
                                f"[auto-import] Created {stub_count} episode stub(s) "
                                f"across season(s) {sorted(seasons_hit) or 'n/a'} in {folder_name}"
                            )
                            _queue_plex_exact_scan("series", folder_name, name=name, category=t_cat)
                        else:
                            # Single episode or no series_id — create one fake file
                            fake_fn = _pick_fake_filename(name, real_files)
                            folder_name = _safe_name(name)
                            _make_fake_file(t_cat, folder_name, fake_fn, real_files)
                            _queue_plex_exact_scan("series", folder_name, name=name, category=t_cat)

                        if series_id:
                            try:
                                _req_mod.post(f"{base_url}/api/v3/command",
                                              headers=headers,
                                              json={"name": "RescanSeries", "seriesId": series_id},
                                              timeout=10)
                                app.logger.info(f"[auto-import] RescanSeries triggered for seriesId={series_id}")
                            except Exception as e:
                                app.logger.warning(f"[auto-import] RescanSeries failed: {e}")

                    else:
                        # Radarr — extract clean movie title + year
                        def _extract_movie_title_year(raw):
                            """Return (clean_title, year_str|None) from a release name."""
                            n = (raw or "").replace(".", " ").replace("_", " ")
                            # Find year (4-digit 19xx/20xx) — not at position 0
                            m_yr = _re.search(r"(?<!\d)(19|20)(\d{2})(?!\d)", n)
                            if m_yr:
                                yr = m_yr.group(0)
                                title = n[:m_yr.start()].strip(" -–")
                            else:
                                yr = None
                                # Strip quality/codec tags from end instead
                                title = _re.sub(
                                    r"\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|bluray|blu-ray|"
                                    r"web-?dl|webrip|hdtv|x264|x265|hevc|avc|remux|proper|repack"
                                    r"|10bit|extended|theatrical|directors\.cut|unrated)\b.*",
                                    "", n, flags=_re.IGNORECASE
                                ).strip(" -–")
                            # Collapse multiple spaces
                            title = _re.sub(r"\s+", " ", title).strip()
                            return title, yr

                        clean, movie_year = _extract_movie_title_year(name)

                        def _norm_title(s):
                            return _re.sub(r"[^a-z0-9]", "", (s or "").lower())

                        # Check if already in Radarr
                        existing_movies = _req_mod.get(f"{base_url}/api/v3/movie",
                                                        headers=headers, timeout=10).json()
                        existing_movies = existing_movies if isinstance(existing_movies, list) else []

                        movie_id = None
                        norm_clean = _norm_title(clean)
                        # Match by normalised title (and optionally year)
                        for m in existing_movies:
                            m_norm = _norm_title(m.get("title") or "")
                            yr_match = (not movie_year or str(m.get("year") or "") == movie_year)
                            if m_norm == norm_clean and yr_match:
                                movie_id = m.get("id")
                                break
                        if not movie_id:
                            # Looser match without year constraint
                            for m in existing_movies:
                                if _norm_title(m.get("title") or "") == norm_clean:
                                    movie_id = m.get("id")
                                    break

                        if not movie_id:
                            # Not in Radarr yet — search TMDB via Radarr
                            search_term = f"{clean} {movie_year}" if movie_year else clean
                            search = _req_mod.get(f"{base_url}/api/v3/movie/lookup",
                                                   headers=headers,
                                                   params={"term": search_term}, timeout=10)
                            results = search.json() if search.ok and isinstance(search.json(), list) else []
                            # Pick best result: prefer title+year exact match, then title match
                            best = None
                            for r in results:
                                if (_norm_title(r.get("title") or "") == norm_clean and
                                        (not movie_year or str(r.get("year") or "") == movie_year)):
                                    best = r
                                    break
                            if not best:
                                for r in results:
                                    if _norm_title(r.get("title") or "") == norm_clean:
                                        best = r
                                        break
                            if not best and results:
                                best = results[0]

                            if best:
                                matched_title = best.get("title", clean)
                                app.logger.info(f"[auto-import] Movie match '{clean}' → '{matched_title}'")
                                best["qualityProfileId"] = quality_id
                                best["rootFolderPath"]   = root_path
                                best["monitored"]        = False  # file provided — no need to search
                                best["addOptions"]       = {"searchForMovie": False}
                                resp = _req_mod.post(f"{base_url}/api/v3/movie",
                                                     headers=headers, json=best, timeout=10)
                                if resp.status_code in (200, 201):
                                    movie_id = resp.json().get("id")
                                    app.logger.info(f"[auto-import] Added movie to {inst['name']}: {matched_title}")
                                elif resp.status_code == 400 and "already" in resp.text.lower():
                                    for m in existing_movies:
                                        if _norm_title(m.get("title") or "") == _norm_title(matched_title):
                                            movie_id = m.get("id")
                                            break

                        # Create fake file and trigger rescan
                        t_cat = inst.get("category") or "radarr"
                        _transfer_manager._set(hash_, state="cached", category=t_cat, imported=0)
                        try:
                            real_files = _transfer_manager.get_files(hash_) or []
                        except Exception:
                            real_files = []
                        fake_fn = _pick_fake_filename(name, real_files)
                        folder_name = _safe_name(name)
                        _make_fake_file(t_cat, folder_name, fake_fn, real_files)
                        _queue_plex_exact_scan("movie", folder_name, name=name, category=t_cat)
                        if movie_id:
                            try:
                                _req_mod.post(f"{base_url}/api/v3/command",
                                              headers=headers,
                                              json={"name": "RescanMovie", "movieId": movie_id},
                                              timeout=10)
                            except Exception:
                                pass

                except Exception as e:
                    app.logger.warning(f"[auto-import] Error for {inst.get('name')}: {e}")

        except Exception as e:
            app.logger.warning(f"[auto-import] Outer error: {e}")

    _import_pool.submit(_auto_import_to_arr, hash_, name)

    # ── Direct Plex scan for web UI adds (no arr instances) ───────────────────
    # _auto_import_to_arr calls _queue_plex_exact_scan internally when arr
    # instances are configured. When there are no arr instances (pure web UI
    # add), we queue the scan here directly so the stub still appears in Plex.
    # If arr IS configured, notify_ready is idempotent — a duplicate debounced
    # scan just resets the timer, no harm done.
    try:
        instances = _get_sync_config().get("instances", [])
        if not instances:
            kind = t.get("kind") or ("series" if any(
                k in (name or "").lower() for k in (" s0", ".s0", " s1", ".s1", "season")
            ) else "movie")
            folder_name = _safe_name(name)
            from transfer_manager import _plex
            from fuse_mount import _category_subdir
            subdir = _category_subdir(name, "", kind=kind)
            _plex.notify_ready(subdir, folder_name)
            app.logger.info(f"[plex-add] direct scan queued subdir={subdir} folder={folder_name} (no arr instances)")
    except Exception as e:
        app.logger.warning(f"[plex-add] direct scan failed: {e}")

    return jsonify({
        "name":  t.get("name", name) if t else name,
        "hash":  hash_,
        "state": t.get("state") if t else "queued",
    })

# Web UI — direct links for play/download
@app.route("/api/links", methods=["POST"])
def get_links():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_pm_api_key()
    hash_   = data.get("hash", "").strip().lower()
    name    = data.get("name", "").strip()

    if not api_key or not hash_:
        return jsonify({"error": "api_key and hash required"}), 400

    magnet = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
    try:
        from transfer_manager import _pm_api_acquire
        _pm_api_acquire()
        r = requests.post(
            PM_DIRECTDL,
            headers={**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"src": magnet}),
            timeout=30,
        )
        r.raise_for_status()
        data_r = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    if data_r.get("status") != "success":
        return jsonify({"error": data_r.get("message", "Could not generate links")}), 400

    content = data_r.get("content", [])
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}

    links = []
    for item in content:
        path = item.get("path", "")
        file_name = path.split("/")[-1] if "/" in path else path
        ext = os.path.splitext(file_name)[1].lower()
        cdn_url = item.get("link", "")
        token = _make_stream_token(hash_, file_name) if cdn_url else ""
        links.append({
            "name":       file_name or path,
            "path":       path,
            "link":       cdn_url,
            "size":       int(float(item.get("size", 0) or 0)),
            "is_video":   ext in video_exts,
            "stream_url": f"/api/stream/{token}?h={hash_}&f={urllib.parse.quote(file_name)}" if token else "",
        })

    if not links:
        return jsonify({"error": "No files found for this magnet"}), 404

    return jsonify({"links": links})

# Streaming proxy — resolves a fresh CDN URL on every request via the
# directdl cache, so links never go stale no matter how long VLC has been open.
@app.route("/api/stream/<token>")
def stream_proxy(token):
    # Token encodes hash and filename as query params, verified by HMAC
    hash_     = request.args.get("h", "").strip().lower()
    filename  = request.args.get("f", "").strip()

    if not hash_ or not filename:
        return jsonify({"error": "Missing parameters"}), 400

    if not _verify_stream_token(token, hash_, filename):
        return jsonify({"error": "Invalid stream token"}), 403

    def _resolve_cdn():
        files = _get_directdl(hash_, filename)
        for f in files:
            if f.get("name") == filename or f.get("path", "").endswith(filename):
                return f.get("link")
        return None

    cdn_url = _resolve_cdn()
    if not cdn_url:
        return jsonify({"error": "File not found"}), 404

    headers = {}
    if "Range" in request.headers:
        headers["Range"] = request.headers["Range"]

    try:
        upstream = requests.get(cdn_url, headers=headers, stream=True, timeout=30)
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    # CDN URL expired — invalidate cache and retry once with fresh URL
    if upstream.status_code in (403, 410):
        with _directdl_lock:
            _directdl_cache.pop(hash_, None)
        cdn_url = _resolve_cdn()
        if not cdn_url:
            return jsonify({"error": "Could not refresh CDN link"}), 502
        try:
            upstream = requests.get(cdn_url, headers=headers, stream=True, timeout=30)
        except requests.RequestException as e:
            return jsonify({"error": str(e)}), 502

    ext = os.path.splitext(filename)[1].lower()
    mime_map = {
        ".mp4": "video/mp4", ".mkv": "video/x-matroska",
        ".avi": "video/x-msvideo", ".mov": "video/quicktime",
        ".m4v": "video/mp4", ".ts": "video/mp2t",
        ".webm": "video/webm", ".wmv": "video/x-ms-wmv",
    }
    content_type = upstream.headers.get("Content-Type") or mime_map.get(ext, "application/octet-stream")

    resp_headers = {
        "Content-Type":  content_type,
        "Accept-Ranges": upstream.headers.get("Accept-Ranges", "bytes"),
    }
    if "Content-Length" in upstream.headers:
        resp_headers["Content-Length"] = upstream.headers["Content-Length"]
    if "Content-Range" in upstream.headers:
        resp_headers["Content-Range"] = upstream.headers["Content-Range"]

    def generate():
        for chunk in upstream.iter_content(chunk_size=1024 * 256):
            yield chunk

    return Response(generate(), status=upstream.status_code, headers=resp_headers)

# List streamable transfers — used by the Library tab
@app.route("/api/transfers")
def list_transfers():
    transfers = _transfer_manager.all_transfers()
    return jsonify({"transfers": [
        {"hash": t["hash"], "name": t["name"] or t["hash"],
         "state": t["state"], "kind": t.get("kind") or "",
         "category": t.get("category") or ""}
        for t in transfers
    ]})

# ── Classification overrides ──────────────────────────────────────────────────
# Stored in config as {"classification_overrides": {"<name_key>": {...}, ...}}
# _overrides_cache is the live in-memory copy — no disk read needed at call time.

_overrides_cache: dict | None = None   # None = not yet loaded

def _get_overrides() -> dict:
    global _overrides_cache
    if _overrides_cache is not None:
        return _overrides_cache
    _overrides_cache = _load_config().get("classification_overrides", {})
    _push_overrides_to_fuse(_overrides_cache)
    return _overrides_cache

def _push_overrides_to_fuse(ov: dict):
    """Push overrides into fuse_mount module so FUSE threads never import app."""
    try:
        import fuse_mount as _fm
        _fm._overrides = ov
    except Exception:
        pass

_RE_NONALNUM = re.compile(r'[^a-z0-9]')

def _override_key(name: str) -> str:
    """Normalised key: lowercase alphanumeric only."""
    return _RE_NONALNUM.sub('', (name or '').lower())

@app.route("/api/overrides", methods=["GET"])
def overrides_get():
    return jsonify(_get_overrides())

@app.route("/api/overrides", methods=["POST"])
def overrides_set():
    global _overrides_cache
    data = request.get_json(force=True) or {}
    name  = (data.get("name") or "").strip()
    kind  = data.get("kind", "")   # "movie" | "series" | "" (clear)
    if not name:
        return jsonify({"error": "name required"}), 400
    key = _override_key(name)
    cfg = _load_config()
    ov  = cfg.setdefault("classification_overrides", {})
    if kind in ("movie", "series"):
        ov[key] = {"kind": kind, "label": name}
    else:
        ov.pop(key, None)
    _overrides_cache = ov   # update in-memory cache immediately
    _push_overrides_to_fuse(ov)
    _save_config(cfg)

    # Invalidate the FUSE name map so the item moves folders immediately
    try:
        import fuse_mount as fm
        if fm._pfs is not None:
            fm._pfs._invalidate_name_map()
    except Exception:
        pass

    return jsonify({"ok": True, "key": key, "kind": kind})

# Remove a transfer
@app.route("/api/remove", methods=["POST"])
def remove_transfer():
    data  = request.json or {}
    hash_ = data.get("hash", "").strip().lower()
    if not hash_:
        return jsonify({"error": "hash required"}), 400
    _transfer_manager.delete(hash_)
    return jsonify({"ok": True})

# ── Backup / Restore ──────────────────────────────────────────────────────────

@app.route("/api/transfers/setkind", methods=["POST"])
def transfers_setkind():
    """Persist a manual kind override directly on the transfer record.
    This ensures backup/restore can replay the correct classification
    even without the classification_overrides config block."""
    data  = request.json or {}
    hash_ = (data.get("hash") or "").strip().lower()
    kind  = (data.get("kind") or "").strip().lower()
    if not hash_ or kind not in ("movie", "series"):
        return jsonify({"error": "hash and kind (movie|series) required"}), 400
    _transfer_manager._set(hash_, kind=kind)
    return jsonify({"ok": True, "hash": hash_, "kind": kind})


@app.route("/api/backup", methods=["GET"])
def backup_transfers():
    """Export a self-contained backup: all cached transfers PLUS the full
    config (including the active Premiumize API key) so a restore brings back
    both the library and the credentials. Old list-only backups still restore."""
    transfers = _transfer_manager.all_transfers()
    overrides = _get_overrides()   # name_key → {kind, ...}

    def _override_key(name):
        return re.sub(r"[^a-z0-9]", "", (name or "").lower())

    cached = []
    for t in transfers:
        if t.get("state") not in ("cached", "complete"):
            continue
        name = t.get("name") or t["hash"]
        # Resolve the effective kind: stored on transfer > override by name
        effective_kind = t.get("kind") or None
        if not effective_kind:
            ov = overrides.get(_override_key(name))
            if ov:
                effective_kind = ov.get("kind")
        entry = {
            "hash":     t["hash"],
            "name":     name,
            "category": t.get("category") or "",
            "added_at": t.get("added_at") or 0,
        }
        if effective_kind:
            entry["kind"] = effective_kind   # carry classification into backup
        cached.append(entry)
    # Include the config so the PM API key (and other settings) survive a
    # restore. get_pm_api_key() covers the env-var case where the key isn't in
    # config.json yet.
    cfg = dict(_load_config())
    active_key = get_pm_api_key()
    if active_key and not cfg.get("pm_api_key"):
        cfg["pm_api_key"] = active_key
    payload = {"version": 2, "config": cfg, "transfers": cached}
    ts = int(time.time())
    resp = Response(
        json.dumps(payload, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="premiumize-backup-{ts}.json"'},
    )
    return resp

@app.route("/api/restore", methods=["POST"])
def restore_transfers():
    global _config_cache, _overrides_cache
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    try:
        data = json.load(request.files["file"])
    except Exception as e:
        return jsonify({"error": f"Invalid JSON: {e}"}), 400

    # Accept the v2 wrapped format {"version":2,"config":{...},"transfers":[...]}
    # as well as the legacy bare list. If the backup carries a config, merge it
    # back in first — this is how the PM API key and other settings are
    # restored (uploaded values win, existing keys not in the backup are kept).
    if isinstance(data, dict):
        restored_cfg = data.get("config")
        if isinstance(restored_cfg, dict) and restored_cfg:
            merged = {**_load_config(), **restored_cfg}
            _save_config(merged)
            _config_cache    = merged
            _overrides_cache = merged.get("classification_overrides", {})
            try:
                _push_overrides_to_fuse(_overrides_cache)
                _apply_fuse_settings(_get_fuse_settings())
            except Exception:
                pass
            app.logger.info("[restore] config restored from backup (incl. PM API key if present)")
        data = data.get("transfers", [])

    if not isinstance(data, list):
        return jsonify({"error": "Expected a JSON array or a backup object"}), 400

    def generate():
        imported = 0
        skipped  = 0
        errors   = 0
        total    = len(data)

        # Pre-validate all hashes and names first
        items = []
        for item in data:
            hash_ = (item.get("hash") or "").strip().lower()
            if not hash_ or not re.fullmatch(r'[0-9a-f]{40}', hash_):
                continue
            name = (item.get("name") or item.get("filename") or hash_).strip()
            if "." in os.path.basename(name):
                base = os.path.splitext(name)[0]
                if base:
                    name = base
            items.append({
                "hash":     hash_,
                "name":     name,
                "category": item.get("category", "").strip(),
                "added_at": float(item.get("added_at") or time.time()),
            })

        errors = len(data) - len(items)  # invalid hash entries

        # Batch cache-check all hashes against Premiumize (100 per call)
        cached_set = set()
        batch_size = 100
        yield json.dumps({"type": "progress", "current": 0, "total": total,
                          "status": "checking", "name": "Checking Premiumize cache…"}) + "\n"
        for b in range(0, len(items), batch_size):
            batch = items[b:b + batch_size]
            try:
                result = _transfer_manager._cache_fn([{"info_hash": x["hash"]} for x in batch])
                for hash_, is_cached in result.items():
                    if is_cached:
                        cached_set.add(hash_)
            except Exception as e:
                app.logger.warning(f"Cache check batch error: {e}")
            time.sleep(0.2)  # small pause between batch API calls

        for i, item in enumerate(items):
            hash_    = item["hash"]
            name     = item["name"]
            category = item["category"]
            added_at = item["added_at"]

            try:
                existing = _transfer_manager.get_transfer(hash_)
                if existing:
                    if existing.get("name") in (None, "", hash_) and name != hash_:
                        _transfer_manager._set(hash_, name=name)
                    skipped += 1
                    yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                      "status": "skipped", "name": name}) + "\n"
                    continue

                if hash_ not in cached_set:
                    skipped += 1
                    yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                      "status": "skipped", "name": f"{name} (not on Premiumize)"}) + "\n"
                    continue

                kind = item.get("kind", "").strip().lower() or None
                _transfer_manager._set(hash_, name=name, state="cached",
                                       category=category, added_at=added_at,
                                       **({"kind": kind} if kind else {}))
                # Replay the classification override so the library tab
                # shows the item in the correct Movies/Series folder
                if kind in ("movie", "series"):
                    global _overrides_cache
                    ov_key = re.sub(r"[^a-z0-9]", "", name.lower())
                    cfg_now = _load_config()
                    ov_map  = cfg_now.setdefault("classification_overrides", {})
                    if ov_key not in ov_map:   # don't overwrite a newer manual override
                        ov_map[ov_key] = {"kind": kind}
                        _save_config(cfg_now)
                        _overrides_cache = ov_map
                        try:
                            _push_overrides_to_fuse(_overrides_cache)
                        except Exception:
                            pass
                imported += 1
                yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                  "status": "imported", "name": name}) + "\n"
                time.sleep(0.05)

            except Exception as e:
                errors += 1
                yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                  "status": "error", "name": name}) + "\n"
                app.logger.warning(f"Restore error: {e}")

        app.logger.info(f"Restore: {imported} imported, {skipped} skipped, {errors} errors")
        yield json.dumps({"type": "done", "imported": imported,
                          "skipped": skipped, "errors": errors, "total": total}) + "\n"

    return Response(generate(), mimetype="application/x-ndjson",
                    headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"})



# ── Config backup / restore ───────────────────────────────────────────────────

@app.route("/api/config/export", methods=["GET"])
def config_export():
    """Download the full config.json as a file.
    Includes the active PM API key even if it came from an env var,
    so the backup is self-contained and can be restored without env vars.
    """
    cfg = _load_config()
    # Always include the active PM API key so the backup is complete.
    # If it came from an env var it won't be in config.json — add it explicitly.
    active_key = get_pm_api_key()
    if active_key and not cfg.get("pm_api_key"):
        cfg = dict(cfg)           # don't mutate the cache
        cfg["pm_api_key"] = active_key
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
    return Response(
        json.dumps(cfg, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="premiumize-config-{ts}.json"'},
    )

@app.route("/api/config/import", methods=["POST"])
def config_import():
    """Restore config.json from an uploaded file. Merges into current config."""
    global _config_cache, _overrides_cache
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    try:
        uploaded = json.load(request.files["file"])
    except Exception as e:
        return jsonify({"error": f"Invalid JSON: {e}"}), 400
    if not isinstance(uploaded, dict):
        return jsonify({"error": "Expected a JSON object"}), 400

    mode = request.args.get("mode", "merge")  # "merge" or "replace"
    if mode == "replace":
        new_cfg = uploaded
    else:
        # Merge: uploaded keys win, existing keys not in upload are kept
        new_cfg = {**_load_config(), **uploaded}

    _save_config(new_cfg)
    # Invalidate caches so new values take effect immediately
    _config_cache    = new_cfg
    _overrides_cache = new_cfg.get("classification_overrides", {})
    _push_overrides_to_fuse(_overrides_cache)

    # Re-apply FUSE settings if they changed
    try:
        import fuse_mount as fm
        _apply_fuse_settings(_get_fuse_settings())
        if fm._pfs is not None:
            fm._pfs._invalidate_name_map()
    except Exception:
        pass

    return jsonify({"ok": True, "mode": mode, "keys": list(new_cfg.keys())})


# Transfer status polling
@app.route("/api/transfer/status", methods=["POST"])
def transfer_status():
    data        = request.json or {}
    api_key     = data.get("api_key", "").strip() or get_pm_api_key()
    transfer_id = data.get("transfer_id", "").strip()

    if not api_key or not transfer_id:
        return jsonify({"error": "api_key and transfer_id required"}), 400

    try:
        r = requests.get(PM_TRANSFER_LIST, headers=pm_headers(api_key), timeout=15)
        r.raise_for_status()
        data_r = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    if data_r.get("status") != "success":
        return jsonify({"error": data_r.get("message", "Failed to get transfer list")}), 400

    for t in data_r.get("transfers", []):
        if str(t.get("id")) == str(transfer_id):
            return jsonify({
                "status":   t.get("status"),
                "progress": t.get("progress", 0),
                "message":  t.get("message", ""),
                "file_id":  t.get("file_id"),
            })

    return jsonify({"error": "Transfer not found"}), 404

# Frontend config — tells the UI what's already set server-side
@app.route("/api/config")
def get_config():
    return jsonify({
        "has_pm_key":       bool(get_pm_api_key()),
        "has_prowlarr_env": bool(PROWLARR_URL or PROWLARR_KEY),
    })

@app.route("/api/config/pm_key", methods=["POST"])
def save_pm_key():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip()
    if not api_key:
        return jsonify({"error": "api_key required"}), 400
    # Verify it works before saving
    try:
        r = requests.get(PM_ACCOUNT, headers=pm_headers(api_key), timeout=10)
        r.raise_for_status()
        d = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502
    if d.get("status") != "success":
        return jsonify({"error": d.get("message", "Authentication failed")}), 401
    save_pm_api_key(api_key)
    # Flush the directdl cache so FUSE re-fetches with the new key
    with _directdl_lock:
        _directdl_cache.clear()
    app.logger.info("PM API key saved and directdl cache flushed")
    return jsonify({"ok": True})

# Account info
@app.route("/api/account", methods=["POST"])
def account():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_pm_api_key()
    if not api_key:
        return jsonify({"error": "API key required"}), 400
    try:
        r = requests.get(PM_ACCOUNT, headers=pm_headers(api_key), timeout=10)
        r.raise_for_status()
        d = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502
    if d.get("status") != "success":
        return jsonify({"error": d.get("message", "Authentication failed")}), 401
    premium_until = d.get("premium_until")
    is_premium = bool(premium_until and premium_until > datetime.now(timezone.utc).timestamp())
    return jsonify({
        "customer_id":   d.get("customer_id"),
        "is_premium":    is_premium,
        "premium_until": premium_until,
        "limit_used":    d.get("limit_used", 0),
    })

# ── Prowlarr config endpoints ─────────────────────────────────────────────────

@app.route("/api/torznab/cached-only", methods=["GET"])
def get_torznab_cached_only():
    return jsonify({"cached_only": _load_config().get("torznab_cached_only", False)})

@app.route("/api/torznab/cached-only", methods=["POST"])
def set_torznab_cached_only():
    data = request.json or {}
    val  = bool(data.get("cached_only", True))
    cfg  = _load_config()
    cfg["torznab_cached_only"] = val
    _save_config(cfg)
    return jsonify({"ok": True, "cached_only": val})

@app.route("/api/prowlarr/config", methods=["GET"])
def prowlarr_config_get():
    cfg = get_prowlarr_config()
    return jsonify({
        "url":        cfg.get("url", ""),
        "api_key":    cfg.get("api_key", ""),
        "configured": bool(cfg.get("url") and cfg.get("api_key")),
        "from_env":   cfg.get("from_env", False),
    })

@app.route("/api/prowlarr/config", methods=["POST"])
def prowlarr_config_save():
    data    = request.json or {}
    url     = data.get("url", "").strip()
    api_key = data.get("api_key", "").strip()

    if not url or not api_key:
        return jsonify({"error": "url and api_key required"}), 400

    # Test the connection
    try:
        r = requests.get(
            f"{url.rstrip('/')}/api/v1/indexer",
            headers={"X-Api-Key": api_key},
            timeout=10,
        )
        r.raise_for_status()
        indexers = r.json()
    except requests.RequestException as e:
        return jsonify({"error": f"Could not connect to Prowlarr: {e}"}), 400

    save_prowlarr_config(url, api_key)

    torrent_indexers = [i for i in indexers if i.get("protocol") == "torrent"]
    return jsonify({
        "ok": True,
        "indexer_count": len(torrent_indexers),
        "indexers": [{"id": i["id"], "name": i["name"]} for i in torrent_indexers],
    })

@app.route("/api/prowlarr/config", methods=["DELETE"])
def prowlarr_config_delete():
    cfg = _load_config()
    cfg.pop("prowlarr", None)
    _save_config(cfg)
    return jsonify({"ok": True})

# ── Mount Configuration endpoints ────────────────────────────────────────────

def _parse_size(val: str, default: int) -> int:
    """Parse human size string like '8MB', '500MB', '30GB', '1TB' to bytes."""
    if not val:
        return default
    val = val.strip().upper().replace(' ', '')
    units = {'B': 1, 'KB': 1024, 'MB': 1024**2, 'GB': 1024**3, 'TB': 1024**4}
    for suffix, mult in sorted(units.items(), key=lambda x: -len(x[0])):
        if val.endswith(suffix):
            try:
                return int(float(val[:-len(suffix)]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

def _parse_duration(val: str, default: int) -> int:
    """Parse duration string like '24h', '20m', '10s', '1d' to seconds."""
    if not val:
        return default
    val = val.strip().lower()
    units = {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
    for suffix, mult in units.items():
        if val.endswith(suffix):
            try:
                return int(float(val[:-1]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

def _fmt_size(b: int) -> str:
    for unit in ['TB', 'GB', 'MB', 'KB']:
        div = {'TB': 1024**4, 'GB': 1024**3, 'MB': 1024**2, 'KB': 1024}[unit]
        if b >= div:
            return f"{b/div:.1f} {unit}"
    return f"{b} B"

def _disk_used_bytes(path: str) -> int:
    """Return total bytes used by all files under path."""
    total = 0
    try:
        for dirpath, _, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(dirpath, f))
                except OSError:
                    pass
    except OSError:
        pass
    return total

def _enforce_disk_cache(cache_dir: str, max_bytes: int):
    """Delete oldest cache blocks until total disk usage is under max_bytes."""
    if not cache_dir or max_bytes <= 0:
        return
    # Collect all .bin files with their mtime
    files = []
    try:
        for dirpath, _, filenames in os.walk(cache_dir):
            for f in filenames:
                if f.endswith('.bin'):
                    p = os.path.join(dirpath, f)
                    try:
                        files.append((os.path.getmtime(p), os.path.getsize(p), p))
                    except OSError:
                        pass
    except OSError:
        return
    files.sort()  # oldest first
    total = sum(s for _, s, _ in files)
    for mtime, size, path in files:
        if total <= max_bytes:
            break
        try:
            os.remove(path)
            total -= size
        except OSError:
            pass

def _expire_disk_cache(cache_dir: str, max_age_seconds: int):
    """Remove cache blocks older than max_age_seconds."""
    if not cache_dir or max_age_seconds <= 0:
        return
    cutoff = time.time() - max_age_seconds
    try:
        for dirpath, _, filenames in os.walk(cache_dir):
            for f in filenames:
                if f.endswith('.bin'):
                    p = os.path.join(dirpath, f)
                    try:
                        if os.path.getmtime(p) < cutoff:
                            os.remove(p)
                    except OSError:
                        pass
    except OSError:
        pass

def _get_fuse_settings() -> dict:
    saved = _load_config().get("fuse", {})
    return {
        "cache_dir":       saved.get("cache_dir",       os.environ.get("FUSE_CACHE_DIR", "/docker/premiumize-web/cache")),
        "disk_cache_size": saved.get("disk_cache_size", "30GB"),
        "buffer_memory":   saved.get("buffer_memory",   "512MB"),
        "cache_expiry":    saved.get("cache_expiry",    "24h"),
        "cache_cleanup":   saved.get("cache_cleanup",   "20m"),
        "chunk_size":      saved.get("chunk_size",      "8MB"),
        "read_ahead":      saved.get("read_ahead",      "500MB"),
        "daemon_timeout":  saved.get("daemon_timeout",  "10s"),
        "uid":             saved.get("uid",             None),
        "gid":             saved.get("gid",             None),
        "umask":           saved.get("umask",           "022"),
        "prefetch":        saved.get("prefetch",        True),
        "video_only":      saved.get("video_only",      True),
        "enable_4k_folders": saved.get("enable_4k_folders", False),
    }

def _save_fuse_settings(settings: dict):
    cfg = _load_config()
    cfg["fuse"] = settings
    _save_config(cfg)

def _apply_fuse_settings(s: dict):
    """Apply settings live to the running fuse_mount module."""
    import fuse_mount as fm
    chunk_bytes  = _parse_size(s.get("chunk_size",    "8MB"),   8 * 1024 * 1024)
    buffer_bytes = _parse_size(s.get("buffer_memory", "512MB"), 512 * 1024 * 1024)
    cache_dir    = s.get("cache_dir", "") or ""

    # Number of in-memory blocks = buffer / chunk
    cache_blocks = max(4, buffer_bytes // chunk_bytes) if chunk_bytes else 16

    fm.BLOCK_SIZE        = chunk_bytes
    fm._RA_MB            = chunk_bytes // (1024 * 1024)
    fm._CACHE_N          = cache_blocks
    fm._PREFETCH_ENABLED = bool(s.get("prefetch", True))
    fm._CACHE_DIR        = cache_dir
    fm._VIDEO_ONLY       = bool(s.get("video_only", True))
    fm._4K_FOLDERS_ENABLED = bool(s.get("enable_4k_folders", False))
    # Invalidate the name map immediately so the new folder structure
    # takes effect on the next FUSE readdir without waiting for TTL expiry
    try:
        from fuse_mount import _pfs
        if _pfs is not None:
            _pfs._invalidate_name_map()
    except Exception:
        pass
    fm._READ_AHEAD_BYTES = _parse_size(s.get("read_ahead", "500MB"), 500 * 1024 * 1024)
    fm._block_cache      = fm._BlockCache(cache_blocks, cache_dir)

    # UID/GID/umask — apply to os module so getattr returns correct values
    uid = s.get("uid")
    gid = s.get("gid")
    if uid is not None:
        try:
            os.setuid(int(uid))
        except (PermissionError, AttributeError):
            pass
    if gid is not None:
        try:
            os.setgid(int(gid))
        except (PermissionError, AttributeError):
            pass
    umask = s.get("umask", "022")
    try:
        os.umask(int(umask, 8))
    except (ValueError, TypeError):
        pass

# Background cache cleanup thread
_cleanup_stop  = threading.Event()
_cleanup_thread = None

def _start_cache_cleanup():
    global _cleanup_thread
    if _cleanup_thread and _cleanup_thread.is_alive():
        _cleanup_stop.set()
        _cleanup_thread.join(timeout=2)
    _cleanup_stop.clear()

    def _loop():
        while not _cleanup_stop.wait(timeout=1):
            s          = _get_fuse_settings()
            interval   = _parse_duration(s.get("cache_cleanup", "20m"), 1200)
            cache_dir  = s.get("cache_dir", "")
            max_bytes  = _parse_size(s.get("disk_cache_size", "30GB"), 30 * 1024**3)
            max_age    = _parse_duration(s.get("cache_expiry", "24h"), 86400)
            _cleanup_stop.wait(timeout=interval)
            if _cleanup_stop.is_set():
                break
            if cache_dir:
                _expire_disk_cache(cache_dir, max_age)
                _enforce_disk_cache(cache_dir, max_bytes)

    _cleanup_thread = threading.Thread(target=_loop, daemon=True)
    _cleanup_thread.start()

_start_cache_cleanup()

@app.route("/api/fuse/settings", methods=["GET"])
def fuse_settings_get():
    import fuse_mount as fm
    s = _get_fuse_settings()
    cache_dir   = s.get("cache_dir", "")
    disk_used   = _disk_used_bytes(cache_dir) if cache_dir else 0
    buffer_bytes = _parse_size(s.get("buffer_memory", "512MB"), 512 * 1024 * 1024)
    return jsonify({
        **s,
        "live_chunk_size":   _fmt_size(fm.BLOCK_SIZE),
        "live_buffer_mb":    fm.BLOCK_SIZE * fm._CACHE_N // (1024 * 1024),
        "live_disk_used":    _fmt_size(disk_used),
        "live_prefetch":     fm._PREFETCH_ENABLED,
        "cached_blocks":     fm._block_cache.size,
    })

@app.route("/api/fuse/4k-enabled", methods=["GET"])
def fuse_4k_enabled():
    """Lightweight endpoint — just returns whether 4K folders are enabled."""
    return jsonify({"enabled": bool(_get_fuse_settings().get("enable_4k_folders", False))})

@app.route("/api/fuse/settings", methods=["POST"])
def fuse_settings_save():
    data = request.json or {}
    s = {
        "cache_dir":       data.get("cache_dir",       "").strip(),
        "disk_cache_size": data.get("disk_cache_size", "30GB").strip(),
        "buffer_memory":   data.get("buffer_memory",   "512MB").strip(),
        "cache_expiry":    data.get("cache_expiry",    "24h").strip(),
        "cache_cleanup":   data.get("cache_cleanup",   "20m").strip(),
        "chunk_size":      data.get("chunk_size",      "8MB").strip(),
        "read_ahead":      data.get("read_ahead",      "500MB").strip(),
        "daemon_timeout":  data.get("daemon_timeout",  "10s").strip(),
        "uid":             data.get("uid"),
        "gid":             data.get("gid"),
        "umask":           data.get("umask",           "022").strip(),
        "prefetch":        bool(data.get("prefetch",        True)),
        "video_only":      bool(data.get("video_only",      True)),
        "enable_4k_folders": bool(data.get("enable_4k_folders", False)),
    }
    _save_fuse_settings(s)
    _apply_fuse_settings(s)
    _start_cache_cleanup()  # restart with new interval
    app.logger.info(f"Mount config updated: chunk={s['chunk_size']} buffer={s['buffer_memory']} "
                    f"disk={s['disk_cache_size']} expiry={s['cache_expiry']}")
    return jsonify({"ok": True})

@app.route("/api/fuse/cache/clear", methods=["POST"])
def fuse_cache_clear():
    import fuse_mount as fm
    import shutil
    fm._block_cache = fm._BlockCache(fm._CACHE_N, fm._CACHE_DIR)
    cache_dir = fm._CACHE_DIR
    if cache_dir and os.path.isdir(cache_dir):
        try:
            shutil.rmtree(cache_dir)
            os.makedirs(cache_dir, exist_ok=True)
        except OSError as e:
            return jsonify({"error": str(e)}), 500
    return jsonify({"ok": True, "message": "Cache cleared"})

# ── Plex settings ──────────────────────────────────────────────────────────────

@app.route("/api/plex/config", methods=["GET"])
def plex_config_get():
    cfg = _load_config().get("plex", {})
    return jsonify({
        "url":                  cfg.get("url", ""),
        "token":                cfg.get("token", ""),
        "movies_section":       cfg.get("movies_section", "1"),
        "tv_section":           cfg.get("tv_section", "2"),
        "debounce_seconds":     cfg.get("debounce_seconds", 30),
        "mount_path":           cfg.get("mount_path", os.environ.get("PLEX_MOUNT_PATH") or MOUNTPOINT),
        "movie_root":           cfg.get("movie_root", ((cfg.get("mount_path") or os.environ.get("PLEX_MOUNT_PATH") or MOUNTPOINT).rstrip("/") + "/movies")),
        "tv_root":              cfg.get("tv_root", ((cfg.get("mount_path") or os.environ.get("PLEX_MOUNT_PATH") or MOUNTPOINT).rstrip("/") + "/series")),
        "scan_exact_item":      cfg.get("scan_exact_item", True),
        "poll_seconds":         cfg.get("poll_seconds", 10),
        "auto_scan_enabled":    cfg.get("auto_scan_enabled", True),
        "partial_scan":         cfg.get("partial_scan", cfg.get("partial_scan_enabled", True)),
        "fallback_full_scan":   cfg.get("fallback_full_scan", False),
        "scan_on_unlock":       cfg.get("scan_on_unlock", False),
        "partial_scan_enabled": cfg.get("partial_scan_enabled", False),
        "partial_scan_time":    cfg.get("partial_scan_time", "03:00"),
        "scan_interval_minutes": cfg.get("scan_interval_minutes", 60),
    })

@app.route("/api/plex/config", methods=["POST"])
def plex_config_save():
    data = request.get_json(force=True) or {}
    cfg  = _load_config()
    partial_time = (data.get("partial_scan_time") or "03:00").strip()
    # Validate HH:MM format
    import re as _re_plex
    if not _re_plex.match(r"^\d{1,2}:\d{2}$", partial_time):
        partial_time = "03:00"
    cfg["plex"] = {
        "url":                  (data.get("url") or "").strip().rstrip("/"),
        "token":                (data.get("token") or "").strip(),
        "movies_section":       str(data.get("movies_section") or "1").strip(),
        "tv_section":           str(data.get("tv_section") or "2").strip(),
        "debounce_seconds":     max(5, int(data.get("debounce_seconds") or 30)),
        "mount_path":           (data.get("mount_path") or os.environ.get("PLEX_MOUNT_PATH") or MOUNTPOINT).strip().rstrip("/"),
        "movie_root":           (data.get("movie_root") or ((data.get("mount_path") or os.environ.get("PLEX_MOUNT_PATH") or MOUNTPOINT).strip().rstrip("/") + "/movies")).strip().rstrip("/"),
        "tv_root":              (data.get("tv_root") or ((data.get("mount_path") or os.environ.get("PLEX_MOUNT_PATH") or MOUNTPOINT).strip().rstrip("/") + "/series")).strip().rstrip("/"),
        "scan_exact_item":      bool(data.get("scan_exact_item", True)),
        "poll_seconds":         max(5, int(data.get("poll_seconds") or 10)),
        "auto_scan_enabled":    bool(data.get("auto_scan_enabled", True)),
        "partial_scan":         bool(data.get("partial_scan", True)),
        "fallback_full_scan":   bool(data.get("fallback_full_scan", False)),
        "scan_on_unlock":       bool(data.get("scan_on_unlock", False)),
        "partial_scan_enabled": bool(data.get("partial_scan_enabled", False)),
        "partial_scan_time":    partial_time,
        "scan_interval_minutes": max(0, int(data.get("scan_interval_minutes") or 60)),
    }
    _save_config(cfg)
    _restart_plex_partial_scan_timer()
    # Reschedule the periodic missing-scan with the new interval
    try:
        from transfer_manager import _plex
        _plex._schedule_interval_scan()
    except Exception:
        pass
    return jsonify({"ok": True})

@app.route("/api/plex/test", methods=["POST"])
def plex_test():
    """Test Plex connectivity and return available library sections."""
    data  = request.get_json(force=True) or {}
    url   = (data.get("url") or "").strip().rstrip("/")
    token = (data.get("token") or "").strip()
    if not url or not token:
        return jsonify({"error": "url and token required"}), 400
    try:
        r = requests.get(
            f"{url}/library/sections",
            headers={"X-Plex-Token": token, "Accept": "application/json"},
            timeout=8,
        )
        if r.status_code == 401:
            return jsonify({"error": "Invalid token"}), 401
        r.raise_for_status()
        sections = []
        data_r = r.json()
        for s in data_r.get("MediaContainer", {}).get("Directory", []):
            sections.append({
                "key":   s.get("key"),
                "title": s.get("title"),
                "type":  s.get("type"),
            })
        return jsonify({"ok": True, "sections": sections})
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502


# ── Plex targeted scans (manual only) ─────────────────────────────────────────
# Automatic Plex new-item watcher/path-scanning was removed. Premiumize Web now
# keeps FUSE files as stubs and unlocks the exact file on Tautulli playback, so
# deployment does not start background Plex scan threads.

@app.route("/api/plex/scan", methods=["POST"])
def plex_scan():
    """Trigger an immediate Plex library scan."""
    data    = request.get_json(force=True) or {}
    section = data.get("section", "")   # optional specific section
    cfg     = _load_config().get("plex", {})
    url     = (os.environ.get("PLEX_URL") or cfg.get("url") or "").rstrip("/")
    token   = os.environ.get("PLEX_TOKEN") or cfg.get("token") or ""
    if not url or not token:
        return jsonify({"error": "Plex not configured"}), 400
    sections = [section] if section else [
        cfg.get("movies_section", "1"),
        cfg.get("tv_section", "2"),
    ]
    triggered = []
    errors    = []
    for sec in sections:
        if not sec:
            continue
        try:
            r = requests.get(
                f"{url}/library/sections/{sec}/refresh?X-Plex-Token={token}",
                timeout=8,
            )
            if r.status_code in (200, 204):
                triggered.append(sec)
            else:
                errors.append(f"section {sec}: HTTP {r.status_code}")
        except requests.RequestException as e:
            errors.append(f"section {sec}: {e}")
    return jsonify({"ok": not errors, "triggered": triggered, "errors": errors})


@app.route("/api/plex/partial-scan", methods=["POST"])
def plex_partial_scan():
    """Trigger a Plex partial scan — scans only recently added folders.
    Plex's /library/sections/<id>/refresh?X-Plex-Token=...
    with no extra params already does an incremental/partial scan by default
    (only new/changed files). A full scan requires forceMetadataRefresh=1.
    So this is identical to the regular scan but clearly labelled."""
    cfg     = _load_config().get("plex", {})
    url     = (os.environ.get("PLEX_URL") or cfg.get("url") or "").rstrip("/")
    token   = os.environ.get("PLEX_TOKEN") or cfg.get("token") or ""
    if not url or not token:
        return jsonify({"error": "Plex not configured"}), 400
    sections  = [cfg.get("movies_section", "1"), cfg.get("tv_section", "2")]
    triggered = []
    errors    = []
    for sec in sections:
        if not sec:
            continue
        try:
            r = requests.get(
                f"{url}/library/sections/{sec}/refresh?X-Plex-Token={token}",
                timeout=8,
            )
            if r.status_code in (200, 204):
                triggered.append(sec)
            else:
                errors.append(f"section {sec}: HTTP {r.status_code}")
        except requests.RequestException as e:
            errors.append(f"section {sec}: {e}")
    app.logger.info(f"[plex partial scan] triggered={triggered} errors={errors}")
    return jsonify({"ok": not errors, "triggered": triggered, "errors": errors})


@app.route("/api/plex/unlock-scanned", methods=["POST"])
def plex_unlock_scanned():
    """Unlock any FUSE files that Plex has already scanned and imported."""
    try:
        from transfer_manager import _plex
        result = _plex.unlock_scanned_by_plex()
        return jsonify({"ok": True, **result})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/api/plex/scan-missing", methods=["POST"])
def plex_scan_missing():
    """Compare FUSE mount against Plex library and scan anything not yet imported."""
    try:
        from transfer_manager import _plex
        result = _plex.scan_missing_from_plex()
        return jsonify({"ok": True, **result})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/api/plex/unlock-all", methods=["POST"])
def plex_unlock_all():
    """Unlock all cached transfers immediately — every file serves real CDN bytes."""
    try:
        with _transfer_manager._lock:
            db = _transfer_manager._db()
            db.execute("UPDATE files SET cdn_unlocked=1 WHERE cdn_unlocked=0")
            db.execute("UPDATE transfers SET cdn_unlocked=1 WHERE state IN ('cached','complete')")
            db.commit()
        n = _transfer_manager._db().execute(
            "SELECT COUNT(*) FROM transfers WHERE cdn_unlocked=1"
        ).fetchone()[0]
        # Invalidate all FUSE stat caches so real sizes are served immediately
        try:
            import fuse_mount as _fm
            if _fm._pfs is not None:
                _fm._pfs._stat_invalidate_all()
        except Exception:
            pass
        app.logger.warning(f"[unlock-all] {n} transfer(s) unlocked")
        # Refresh Plex metadata only for stub-duration items (11 min)
        refresh_result = {}
        try:
            from transfer_manager import _plex
            refresh_result = _plex.refresh_plex_metadata_all()
        except Exception as e:
            app.logger.warning(f"[unlock-all] metadata refresh failed: {e}")
        refreshed = refresh_result.get("refreshed", 0)
        skipped   = refresh_result.get("skipped", 0)
        return jsonify({"ok": True, "unlocked": n,
                        "message": f"{n} transfer(s) unlocked — refreshing {refreshed} stub-duration items in Plex ({skipped} already correct)"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


# ── Scheduled partial scan timer ───────────────────────────────────────────────

_plex_scan_thread: threading.Thread | None = None
_plex_scan_stop   = threading.Event()

def _run_plex_partial_scan():
    """Do the actual Plex partial scan from the background thread."""
    try:
        cfg   = _load_config().get("plex", {})
        url   = (os.environ.get("PLEX_URL") or cfg.get("url") or "").rstrip("/")
        token = os.environ.get("PLEX_TOKEN") or cfg.get("token") or ""
        if not url or not token:
            app.logger.warning("[plex scheduled scan] Plex not configured, skipping")
            return
        sections = [cfg.get("movies_section", "1"), cfg.get("tv_section", "2")]
        for sec in sections:
            if not sec:
                continue
            try:
                r = requests.get(
                    f"{url}/library/sections/{sec}/refresh?X-Plex-Token={token}",
                    timeout=8,
                )
                app.logger.info(f"[plex scheduled scan] section {sec}: HTTP {r.status_code}")
            except Exception as e:
                app.logger.warning(f"[plex scheduled scan] section {sec}: {e}")
    except Exception as e:
        app.logger.warning(f"[plex scheduled scan] error: {e}")

def _restart_plex_partial_scan_timer():
    """Start or restart the daily partial scan scheduler."""
    global _plex_scan_thread, _plex_scan_stop
    _plex_scan_stop.set()
    if _plex_scan_thread and _plex_scan_thread.is_alive():
        _plex_scan_thread.join(timeout=2)
    _plex_scan_stop.clear()

    cfg     = _load_config().get("plex", {})
    enabled = cfg.get("partial_scan_enabled", False)
    if not enabled:
        return

    scan_time = cfg.get("partial_scan_time", "03:00")
    try:
        hour, minute = [int(x) for x in scan_time.split(":")]
    except Exception:
        hour, minute = 3, 0

    def _loop():
        import datetime as _dt
        app.logger.info(f"[plex scheduled scan] scheduler started — daily at {hour:02d}:{minute:02d}")
        while not _plex_scan_stop.is_set():
            now      = _dt.datetime.now()
            target   = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if target <= now:
                target += _dt.timedelta(days=1)
            wait_secs = (target - now).total_seconds()
            app.logger.info(f"[plex scheduled scan] next scan in {int(wait_secs)}s at {target.strftime('%H:%M')}")
            # Sleep in small chunks so we can be cancelled cleanly
            if _plex_scan_stop.wait(timeout=wait_secs):
                break   # stop requested
            app.logger.info("[plex scheduled scan] running scheduled partial scan")
            _run_plex_partial_scan()

    _plex_scan_thread = threading.Thread(target=_loop, daemon=True, name="plex-scan-scheduler")
    _plex_scan_thread.start()

# Start the scheduler on app boot if it's already configured
_restart_plex_partial_scan_timer()


@app.route("/api/tmdb/config", methods=["GET"])
def get_tmdb_config():
    cfg = _load_config()
    return jsonify({"has_key": bool(cfg.get("tmdb_api_key", "").strip())})


@app.route("/api/tmdb/config", methods=["POST"])
def save_tmdb_config():
    data    = request.get_json(force=True) or {}
    api_key = data.get("api_key", "").strip()
    if not api_key:
        # Allow clearing the key
        cfg = _load_config()
        cfg["tmdb_api_key"] = ""
        _save_config(cfg)
        return jsonify({"ok": True, "cleared": True})
    # Verify the key works — supports both the v3 API key and the v4 read token
    import tmdb as _tmdb
    ok, msg = _tmdb.validate_key(api_key)
    if not ok:
        code = 401 if "401" in msg or "Invalid" in msg else 502
        return jsonify({"error": msg}), code
    cfg = _load_config()
    cfg["tmdb_api_key"] = api_key
    _save_config(cfg)
    # Clear the TMDB in-memory cache so new key takes effect immediately
    try:
        import tmdb as _tmdb
        with _tmdb._cache_lock:
            _tmdb._cache.clear()
    except Exception:
        pass
    app.logger.info("TMDB API key saved")
    return jsonify({"ok": True})


@app.route("/api/tmdb/test", methods=["POST"])
def test_tmdb():
    """Quick lookup test — search for a known movie and return the result."""
    try:
        import tmdb as _tmdb
        meta = _tmdb.lookup("The Dark Knight", 2008, "movie")
        if meta:
            return jsonify({"ok": True, "title": meta.get("title"), "tmdbid": meta.get("tmdbid")})
        return jsonify({"ok": False, "error": "No result — check your API key"}), 400
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/fuse/prewarm", methods=["POST"])
def fuse_prewarm():
    """Pre-warm the FUSE directdl file cache for all streamable transfers."""
    try:
        import fuse_mount as fm
        if fm._pfs is None:
            return jsonify({"error": "FUSE not mounted"}), 503
        hashes = _transfer_manager.streamable_hashes()
        if not hashes:
            return jsonify({"ok": True, "warmed": 0, "message": "No transfers to warm"})
        now    = __import__("time").time()
        cold   = [h for h in hashes if h not in fm._pfs._file_cache
                  or now >= fm._pfs._file_cache[h][1]]
        fm._pfs._prewarm_parallel(cold, block=False)
        return jsonify({
            "ok":      True,
            "total":   len(hashes),
            "warmed":  len(cold),
            "already_warm": len(hashes) - len(cold),
        })
    except Exception as e:
        app.logger.warning(f"[prewarm] {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/transfers/classify", methods=["POST"])
def classify_transfers():
    """Backfill kind='movie'|'series' for all transfers that don't have it yet.
    Uses actual file paths from directdl — the ground truth source."""
    from name_match import classify_from_files
    import fuse_mount as fm

    hashes    = _transfer_manager.streamable_hashes()
    updated   = 0
    skipped   = 0
    no_files  = 0

    for h in hashes:
        t = _transfer_manager.get_transfer(h)
        if not t:
            continue
        if t.get("kind") in ("movie", "series"):
            skipped += 1
            continue
        # Try from FUSE file cache first (fast, no network)
        files = None
        if fm._pfs is not None:
            cached = fm._pfs._file_cache.get(h)
            if cached:
                files, _ = cached
        # Fall back to fetching from Premiumize
        if not files:
            try:
                files = _transfer_manager.get_files(h) or []
            except Exception:
                files = []
        if not files:
            no_files += 1
            continue
        kind = classify_from_files(files)
        if kind:
            _transfer_manager._set(h, kind=kind)
            updated += 1

    # Invalidate FUSE name map so reclassified items move to correct folder
    try:
        if fm._pfs is not None:
            fm._pfs._invalidate_name_map()
    except Exception:
        pass

    return jsonify({
        "ok":       True,
        "updated":  updated,
        "skipped":  skipped,
        "no_files": no_files,
        "total":    len(hashes),
    })

# ── File DB migration ─────────────────────────────────────────────────────────
# Populates the persistent files table for all existing transfers that don't
# have DB entries yet. Run once after upgrading — streams progress via SSE so
# large libraries don't time out. Throttled to avoid hammering Premiumize.

@app.route("/api/transfers/migrate-files", methods=["POST"])
def migrate_files():
    """SSE stream — populate the files DB table for all transfers missing entries.
    Each hash that already has DB entries is skipped (idempotent).
    Calls directdl only for hashes with no stored files — so re-running is safe.
    """
    data          = request.get_json(force=True) or {}
    delay_ms      = max(0, int(data.get("delay_ms", 500)))  # ms between calls
    force_refresh = bool(data.get("force", False))          # re-fetch even if stored

    def generate():
        hashes = _transfer_manager.streamable_hashes()
        total  = len(hashes)
        done   = 0
        skipped = 0
        errors  = 0

        yield f"data: {json.dumps({'type':'start','total':total})}\n\n"

        for h in hashes:
            t = _transfer_manager.get_transfer(h)
            if not t:
                continue

            # Check if already in DB
            if not force_refresh:
                existing = _transfer_manager._db_get_files(h)
                if existing:
                    skipped += 1
                    done += 1
                    if done % 50 == 0:
                        yield f"data: {json.dumps({'type':'progress','done':done,'total':total,'skipped':skipped,'errors':errors})}\n\n"
                    continue

            # Fetch from Premiumize and store
            try:
                files = _transfer_manager.get_files(h, force=force_refresh)
                if files:
                    done += 1
                    yield f"data: {json.dumps({'type':'progress','done':done,'total':total,'skipped':skipped,'errors':errors,'name':(t.get('name') or h)[:50]})}\n\n"
                else:
                    errors += 1
                    done += 1
            except Exception as e:
                errors += 1
                done += 1
                app.logger.warning(f"[migrate-files] {h[:8]}: {e}")

            if delay_ms:
                time.sleep(delay_ms / 1000)

        yield f"data: {json.dumps({'type':'done','total':total,'done':done,'skipped':skipped,'errors':errors})}\n\n"

    from flask import stream_with_context
    return app.response_class(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"}
    )

@app.route("/api/prowlarr/indexers", methods=["GET"])
def prowlarr_indexers():
    cfg = get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"):
        return jsonify({"error": "Prowlarr not configured"}), 400
    try:
        r = requests.get(
            f"{cfg['url']}/api/v1/indexer",
            headers={"X-Api-Key": cfg["api_key"]},
            timeout=10,
        )
        r.raise_for_status()
        indexers = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    torrent_indexers = [i for i in indexers if i.get("protocol") == "torrent"]
    return jsonify({
        "indexers": [{"id": i["id"], "name": i["name"], "enabled": i.get("enableAutomaticSearch", True)} for i in torrent_indexers]
    })

MOUNTPOINT = os.environ.get("FUSE_MOUNTPOINT", "/docker/premiumize-web/mnt")

# ── directdl helpers ──────────────────────────────────────────────────────────

def _directdl_for_manager_raw(hash_: str, name: str) -> list:
    """Raw directdl call — always hits Premiumize API. Use _get_directdl instead."""
    api_key = get_pm_api_key()
    if not api_key:
        return []
    magnet     = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}
    try:
        r = requests.post(
            PM_DIRECTDL,
            headers={**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"src": magnet}),
            timeout=30,
        )
        r.raise_for_status()
        data_r = r.json()
    except Exception:
        return []
    if data_r.get("status") != "success":
        return []
    files = []
    for item in data_r.get("content", []):
        path      = item.get("path", "")
        file_name = path.split("/")[-1] if "/" in path else path
        ext       = os.path.splitext(file_name)[1].lower()
        cdn_url   = item.get("link", "")
        token     = _make_stream_token(hash_, file_name) if cdn_url else ""
        files.append({
            "name":       file_name or path,
            "path":       path,
            "link":       cdn_url,
            "size":       int(float(item.get("size", 0) or 0)),
            "is_video":   ext in video_exts,
            "stream_url": f"/api/stream/{token}?h={hash_}&f={urllib.parse.quote(file_name)}" if token else "",
        })
    return files

def _directdl_for_manager(hash_: str, name: str, force: bool = False) -> list:
    """Cached wrapper — used by transfer manager and FUSE mount."""
    return _get_directdl(hash_, name, force=force)

# ── transfer manager ──────────────────────────────────────────────────────────

from transfer_manager import TransferManager

_transfer_manager = TransferManager(
    pm_api_key_fn  = lambda: get_pm_api_key(),
    directdl_fn    = _directdl_for_manager,
    cache_check_fn = lambda torrents: check_cache_pm(get_pm_api_key(), torrents),
)


# ── qBittorrent mock blueprint ────────────────────────────────────────────────

import qbt_mock
qbt_mock.init(_transfer_manager)
qbt_mock.MOUNTPOINT = MOUNTPOINT
app.register_blueprint(qbt_mock.qbt)

# ── FUSE mount ────────────────────────────────────────────────────────────────

import signal
import subprocess
import atexit

_UMOUNT_TIMEOUT  = 10   # max seconds for any umount/fusermount call
_PROBE_TIMEOUT   = 5    # max seconds to decide a live mount is wedged
_WATCHDOG_PERIOD = 15   # seconds between health probes


def _run(cmd, timeout=_UMOUNT_TIMEOUT):
    """subprocess.run that never hangs and never raises. Returns the
    CompletedProcess, or None if it timed out / couldn't run."""
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        print(f"[FUSE] cmd {cmd!r} did not complete: {e}", flush=True)
        return None


def _is_mounted() -> bool:
    """True if MOUNTPOINT is in the mount table. Reads /proc — never stats the
    filesystem, so it cannot hang on a dead FUSE daemon."""
    r = _run(["mountpoint", "-q", MOUNTPOINT], timeout=3)
    return bool(r is not None and r.returncode == 0)


def _mount_is_healthy() -> bool:
    """True if the mountpoint answers a stat within the probe window.
    A crashed FUSE daemon makes the kernel return ENOTCONN ('Transport endpoint
    is not connected'), so stat fails fast; a wedged daemon makes stat block, so
    we cap it with a timeout and treat a timeout as unhealthy. Run as a
    subprocess so a blocking syscall can't wedge the caller's thread."""
    r = _run(["stat", "-c", "%i", MOUNTPOINT], timeout=_PROBE_TIMEOUT)
    return bool(r is not None and r.returncode == 0)


def _unmount_fuse():
    """Unmount cleanly — fusermount first, then lazy umount. Both time-bounded."""
    _run(["fusermount", "-uz", MOUNTPOINT])
    _run(["umount", "-l", MOUNTPOINT])
    app.logger.info(f"FUSE unmounted {MOUNTPOINT}")


def _clear_stale_mount():
    """Tear down any stale/broken FUSE mount left from a previous run or crash.
    Every step is time-bounded so this can never hang on a dead mount (the old
    version ran a bare `ls`, which blocks forever on a stale endpoint)."""
    for attempt in range(15):
        mounted = _is_mounted()
        healthy = _mount_is_healthy()
        if not mounted and healthy:
            return  # plain directory, nothing mounted → clean
        print(f"[FUSE] clearing stale mount (attempt {attempt + 1})...", flush=True)
        _run(["fusermount", "-uz", MOUNTPOINT])
        _run(["umount", "-l", MOUNTPOINT])
        time.sleep(0.3)
    print("[FUSE] WARNING: could not fully clear stale mount", flush=True)


_fuse_shutdown    = threading.Event()
_watchdog_started = False


def _fuse_watchdog():
    """Periodically probe the live mount. If it has gone stale or wedged while
    the foreground mount() is still blocked, force an unmount — that makes
    mount() return, and the _start_fuse loop remounts. This is what recovers a
    broken mount without a full app restart."""
    while not _fuse_shutdown.is_set():
        _fuse_shutdown.wait(timeout=_WATCHDOG_PERIOD)
        if _fuse_shutdown.is_set():
            break
        try:
            if not _is_mounted():
                continue  # between remounts — the mount loop will handle it
            if not _mount_is_healthy():
                print("[FUSE] watchdog: mount unhealthy — forcing unmount to trigger remount", flush=True)
                _run(["fusermount", "-uz", MOUNTPOINT])
                _run(["umount", "-l", MOUNTPOINT])
        except Exception as e:
            print(f"[FUSE] watchdog error (ignored): {e}", flush=True)
    print("[FUSE] watchdog exited", flush=True)


def _start_fuse():
    import traceback
    import signal as _signal
    try:
        from fuse_mount import mount, FUSE_AVAILABLE
    except Exception as e:
        print(f"[FUSE] import failed: {e}", flush=True)
        traceback.print_exc()
        return

    if not FUSE_AVAILABLE:
        print("[FUSE] fusepy not installed — disabled", flush=True)
        return

    # Block signals in this thread — Flask's main thread handles them.
    try:
        _signal.pthread_sigmask(_signal.SIG_BLOCK,
                                {_signal.SIGTERM, _signal.SIGINT, _signal.SIGHUP})
    except (AttributeError, OSError):
        pass

    # Start the health watchdog once.
    global _watchdog_started
    if not _watchdog_started:
        _watchdog_started = True
        threading.Thread(target=_fuse_watchdog, name="fuse-watchdog", daemon=True).start()

    consecutive_failures = 0
    while not _fuse_shutdown.is_set():
        _clear_stale_mount()
        print(f"[FUSE] mounting at {MOUNTPOINT}", flush=True)
        try:
            mount(MOUNTPOINT, _transfer_manager, foreground=True)
            if _fuse_shutdown.is_set():
                print("[FUSE] mount exited — shutdown requested, not remounting", flush=True)
                break
            print("[FUSE] mount exited — remounting in 2s...", flush=True)
            consecutive_failures = 0
        except Exception as e:
            consecutive_failures += 1
            print(f"[FUSE] mount failed ({consecutive_failures}): {e}", flush=True)
            traceback.print_exc()

        wait = min(2 * consecutive_failures, 30)
        _fuse_shutdown.wait(timeout=max(wait, 2))

    print("[FUSE] thread exited", flush=True)


_shutting_down = threading.Event()


def _shutdown(signum=None, frame=None):
    """Graceful shutdown: stop the watchdog + remount loop, unmount FUSE, and
    stop the web server. Idempotent — safe if called more than once."""
    if _shutting_down.is_set():
        return
    _shutting_down.set()
    print("[shutdown] signal received — unmounting FUSE gracefully", flush=True)
    _fuse_shutdown.set()
    _run(["fusermount", "-uz", MOUNTPOINT])
    time.sleep(0.5)
    _run(["umount", "-l", MOUNTPOINT])
    print("[shutdown] FUSE unmounted", flush=True)
    # Stop the Werkzeug server without blocking the signal handler.
    srv = globals().get("_srv")
    if srv is not None:
        try:
            threading.Thread(target=srv.shutdown, daemon=True).start()
        except Exception:
            pass
    raise SystemExit(0)


def _atexit_unmount():
    """Fallback: unmount on normal interpreter exit (unhandled exception, etc.)
    that didn't go through the signal handler. Can't help on SIGKILL/hard crash
    — the startup _clear_stale_mount + watchdog recover that case on next run."""
    if _shutting_down.is_set():
        return
    _fuse_shutdown.set()
    _unmount_fuse()


# Register signal handlers so FUSE is unmounted on SIGTERM (docker stop) and SIGINT
signal.signal(signal.SIGTERM, _shutdown)
signal.signal(signal.SIGINT, _shutdown)
atexit.register(_atexit_unmount)

# ── Sync API ──────────────────────────────────────────────────────────────────

def _get_sync_config() -> dict:
    cfg = _load_config().get("sync", {})
    return {"instances": cfg.get("instances", [])}

@app.route("/api/sync/config", methods=["GET"])
def sync_config_get():
    return jsonify(_get_sync_config())

@app.route("/api/sync/config", methods=["POST"])
def sync_config_save():
    data = request.get_json(force=True) or {}
    cfg  = _load_config()
    instances = data.get("instances", [])
    # Sanitise
    for inst in instances:
        inst["url"] = (inst.get("url") or "").rstrip("/")
    cfg["sync"] = {"instances": instances}
    _save_config(cfg)
    return jsonify({"ok": True})

@app.route("/api/downloads/clear", methods=["POST"])
def downloads_clear():
    """Delete all subfolders under DOWNLOADS_ROOT (fake import files)."""
    import shutil
    from qbt_mock import DOWNLOADS_ROOT
    removed = 0
    errors  = []
    try:
        if not os.path.isdir(DOWNLOADS_ROOT):
            return jsonify({"ok": True, "removed": 0, "message": "Downloads folder does not exist."})
        for cat_dir in os.scandir(DOWNLOADS_ROOT):
            if not cat_dir.is_dir():
                continue
            for entry in os.scandir(cat_dir.path):
                if entry.is_dir():
                    try:
                        shutil.rmtree(entry.path)
                        removed += 1
                    except Exception as e:
                        errors.append(str(e))
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500
    return jsonify({"ok": True, "removed": removed,
                    "message": f"Removed {removed} folder(s)." + (f" {len(errors)} error(s)." if errors else "")})

@app.route("/api/downloads/clear-config", methods=["GET"])
def downloads_clear_config_get():
    cfg = _load_config().get("downloads_clear", {})
    return jsonify({"interval_hours": cfg.get("interval_hours", 0)})

@app.route("/api/downloads/clear-config", methods=["POST"])
def downloads_clear_config_save():
    data = request.get_json(force=True) or {}
    hours = int(data.get("interval_hours", 0))
    cfg = _load_config()
    cfg["downloads_clear"] = {"interval_hours": max(0, hours)}
    _save_config(cfg)
    _restart_downloads_clear_timer()
    return jsonify({"ok": True, "interval_hours": max(0, hours)})

# ── Downloads auto-clear timer ─────────────────────────────────────────────────

_downloads_clear_stop  = threading.Event()
_downloads_clear_thread = None

def _do_clear_downloads():
    """Actually delete all stub folders — same logic as the API endpoint."""
    import shutil
    from qbt_mock import DOWNLOADS_ROOT
    removed = 0
    try:
        if os.path.isdir(DOWNLOADS_ROOT):
            for cat_dir in os.scandir(DOWNLOADS_ROOT):
                if not cat_dir.is_dir():
                    continue
                for entry in os.scandir(cat_dir.path):
                    if entry.is_dir():
                        try:
                            shutil.rmtree(entry.path)
                            removed += 1
                        except Exception:
                            pass
    except Exception:
        pass
    app.logger.info(f"[downloads-clear-timer] Auto-cleared {removed} folder(s)")
    return removed

def _restart_downloads_clear_timer():
    global _downloads_clear_thread
    _downloads_clear_stop.set()
    if _downloads_clear_thread and _downloads_clear_thread.is_alive():
        _downloads_clear_thread.join(timeout=2)
    _downloads_clear_stop.clear()

    hours = _load_config().get("downloads_clear", {}).get("interval_hours", 0)
    if not hours or hours <= 0:
        return  # disabled

    def _loop():
        while not _downloads_clear_stop.wait(timeout=hours * 3600):
            _do_clear_downloads()

    _downloads_clear_thread = threading.Thread(target=_loop, daemon=True)
    _downloads_clear_thread.start()
    app.logger.info(f"[downloads-clear-timer] Started — interval: {hours}h")

# Start the timer on app load
_restart_downloads_clear_timer()

# ── Auto-backup timer ──────────────────────────────────────────────────────────

BACKUP_DIR = os.path.join(os.path.dirname(CONFIG_PATH), "backups")

@app.route("/api/backup-config", methods=["GET"])
def backup_config_get():
    cfg = _load_config().get("auto_backup", {})
    return jsonify({
        "interval_days": cfg.get("interval_days", 0),
        "keep_count":    cfg.get("keep_count", 5),
        "last_backup":   cfg.get("last_backup", None),
    })

@app.route("/api/backup-config", methods=["POST"])
def backup_config_save():
    data = request.get_json(force=True) or {}
    days  = max(0, int(data.get("interval_days", 0)))
    keep  = max(1, int(data.get("keep_count", 5)))
    cfg   = _load_config()
    cfg.setdefault("auto_backup", {}).update({"interval_days": days, "keep_count": keep})
    _save_config(cfg)
    _restart_backup_timer()
    return jsonify({"ok": True, "interval_days": days, "keep_count": keep})

@app.route("/api/backup-config/run", methods=["POST"])
def backup_config_run():
    """Trigger an immediate backup."""
    path = _do_auto_backup()
    return jsonify({"ok": bool(path), "path": path or ""})

_backup_stop   = threading.Event()
_backup_thread = None

def _do_auto_backup() -> str | None:
    """Write a dated backup JSON to BACKUP_DIR. Returns the file path."""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        transfers = _transfer_manager.all_transfers()
        cached = [
            {
                "hash":     t["hash"],
                "name":     t.get("name") or t["hash"],
                "category": t.get("category") or "",
                "added_at": t.get("added_at") or 0,
            }
            for t in transfers
            if t.get("state") in ("cached", "complete")
        ]
        ts   = datetime.now().strftime("%Y-%m-%d_%H-%M")
        path = os.path.join(BACKUP_DIR, f"premiumize-backup-{ts}.json")
        with open(path, "w") as f:
            json.dump(cached, f, indent=2)

        # Also save a config snapshot alongside the transfer backup
        cfg_snapshot = dict(_load_config())
        active_key = get_pm_api_key()
        if active_key and not cfg_snapshot.get("pm_api_key"):
            cfg_snapshot["pm_api_key"] = active_key
        cfg_path = os.path.join(BACKUP_DIR, f"premiumize-config-{ts}.json")
        with open(cfg_path, "w") as f:
            json.dump(cfg_snapshot, f, indent=2)

        # Keep only the configured number of most recent backups (default 5)
        keep = _load_config().get("auto_backup", {}).get("keep_count", 5)
        for prefix in ("premiumize-backup-", "premiumize-config-"):
            all_backups = sorted(
                [os.path.join(BACKUP_DIR, fn) for fn in os.listdir(BACKUP_DIR)
                 if fn.startswith(prefix) and fn.endswith(".json")]
            )
            for old in all_backups[:-keep]:
                try:
                    os.remove(old)
                    app.logger.info(f"[auto-backup] Deleted old backup: {os.path.basename(old)}")
                except OSError:
                    pass

        # Record last backup time in config
        cfg = _load_config()
        cfg.setdefault("auto_backup", {})["last_backup"] = ts
        _save_config(cfg)

        app.logger.info(f"[auto-backup] Saved {len(cached)} transfers + config → {BACKUP_DIR}")
        return path
    except Exception as e:
        app.logger.warning(f"[auto-backup] Failed: {e}")
        return None

def _restart_backup_timer():
    global _backup_thread
    _backup_stop.set()
    if _backup_thread and _backup_thread.is_alive():
        _backup_thread.join(timeout=2)
    _backup_stop.clear()

    days = _load_config().get("auto_backup", {}).get("interval_days", 0)
    if not days or days <= 0:
        return

    def _loop():
        while not _backup_stop.wait(timeout=days * 86400):
            _do_auto_backup()

    _backup_thread = threading.Thread(target=_loop, daemon=True)
    _backup_thread.start()
    app.logger.info(f"[auto-backup] Started — interval: {days}d")

_restart_backup_timer()

@app.route("/api/sync/run", methods=["POST"])
def sync_run():
    """
    SSE stream — Full or Partial sync between FUSE mount and Radarr/Sonarr.

    New design: write fake files DIRECTLY into the Arr root folder (the
    configured movie/TV library path), then trigger a folder rescan.
    No TMDB/TVDB lookups.  No qBittorrent mock round-trip.

    Full sync
    ─────────
    1. Scan FUSE mount for the selected folder (movies / series / etc.)
    2. Wipe every .mkv stub we previously wrote into the Arr root folder
    3. Set ALL existing Arr items to monitored=True
    4. For each FUSE item:
       a. Build folder name  →  <root>/<Title> (Year)/
       b. Write fake .mkv stub directly into that folder
       c. Trigger RescanMovie / RefreshSeries + RescanSeries
    5. Report counts

    Partial sync
    ────────────
    1. Scan FUSE mount
    2. For each FUSE item:
       a. Check whether our stub already exists in the Arr root folder
       b. If missing → write stub + trigger rescan
       c. If present → skip
    """
    import re as _re, os as _os, shutil as _shutil
    from fuse_mount import build_name_map
    from qbt_mock  import _pick_fake_filename, _safe_name, _detect_resolution, DOWNLOADS_ROOT
    import requests as _req

    data     = request.get_json(force=True) or {}
    folder   = data.get("folder",   "movies")   # movies | series | movies4k | series4k
    arr      = data.get("arr",      "radarr")   # radarr | sonarr
    mode     = data.get("mode",     "partial")  # full | partial
    base_url = data.get("arr_url",  "").rstrip("/")
    api_key  = data.get("arr_key",  "")
    arr_name = data.get("arr_name", arr.title())
    arr_root = data.get("arr_root", "").strip().rstrip("/")  # user-configured root override

    def _headers():
        return {"X-Api-Key": api_key, "Content-Type": "application/json"}

    def sse(log=None, pct=None, status=None, done=False, error=False):
        obj = {}
        if log    is not None: obj["log"]    = log
        if pct    is not None: obj["pct"]    = pct
        if status is not None: obj["status"] = status
        if done:
            obj["done"]  = True
            obj["error"] = error
        return f"data: {json.dumps(obj)}\n\n"

    # ── stub helpers ──────────────────────────────────────────────────────────

    def _ensure_dir(path: str):
        """Create path and chmod every newly created directory 777 so
        Sonarr/Radarr (running as a different uid) can read, write, and
        delete inside it.  makedirs alone only sets the umask-filtered
        permissions on each dir, which is typically root:root 755."""
        to_chmod = []
        check = path
        while not _os.path.exists(check):
            to_chmod.append(check)
            parent = _os.path.dirname(check)
            if parent == check:
                break
            check = parent
        _os.makedirs(path, exist_ok=True)
        for d in to_chmod:
            try:
                _os.chmod(d, 0o777)
            except OSError:
                pass
        # Always ensure the leaf is 777 even if it pre-existed
        try:
            _os.chmod(path, 0o777)
        except OSError:
            pass

    def _write_stub(dest_folder: str, filename: str, real_files: list) -> str:
        """Write a fake MKV stub directly into dest_folder/filename.
        When video_only is OFF, also writes a .nfo alongside. When ON, the
        stub is written video-only with no .nfo — which also keeps the sync
        fast, since the .nfo path does live TMDB lookups that can stall a bulk
        sync item-by-item."""
        try:
            import fuse_mount as _fm
            _nfo_on = not getattr(_fm, "_VIDEO_ONLY", False)
        except Exception:
            _nfo_on = True
        _ensure_dir(dest_folder)
        fpath = _os.path.join(dest_folder, filename)
        if _os.path.exists(fpath):
            _os.utime(fpath, None)
            if _nfo_on:
                from qbt_mock import write_nfo as _write_nfo
                _write_nfo(fpath)
            return fpath
        # Write video stub
        res      = _detect_resolution(filename)
        stub_src = _os.path.join(_os.path.dirname(__file__), "stubs", f"{res}.mkv")
        if not _os.path.exists(stub_src):
            stub_src = _os.path.join(_os.path.dirname(__file__), "stubs", "1080p.mkv")
        if _os.path.exists(stub_src):
            _shutil.copy2(stub_src, fpath)
        else:
            open(fpath, "wb").close()
        try:
            _os.chmod(fpath, 0o666)
        except OSError:
            pass
        if _nfo_on:
            from qbt_mock import write_nfo as _write_nfo
            _write_nfo(fpath)
        return fpath

    def _strip_site_prefix(n: str) -> str:
        """Remove torrent site watermark prefixes from a name.
        e.g. 'www UIndex org - Abbott Elementary' → 'Abbott Elementary'
             '[www.UIndex.org] Abbott Elementary' → 'Abbott Elementary'
             'www.Torrenting.com - Show.Name' → 'Show.Name'
        """
        # Leading bracket groups: [TAG], [www.site.com], [ACESSE HD-ELITE ME]
        n = _re.sub(r'^\[[^\]]{1,80}\]\s*', '', n)
        # www.Domain.tld -  (dots between words)
        n = _re.sub(r'^www\.[A-Za-z0-9-]+\.[A-Za-z]{2,6}\s*[-–]\s*', '', n, flags=_re.IGNORECASE)
        # www Domain tld -  (spaces between words — "www UIndex org - Title")
        n = _re.sub(r'^www\s+[A-Za-z0-9-]+\s+[A-Za-z]{2,6}\s*[-–]\s*', '', n, flags=_re.IGNORECASE)
        # www Something -  (two-word www prefix with no TLD)
        n = _re.sub(r'^www\s+\S+\s*[-–]\s*', '', n, flags=_re.IGNORECASE)
        # SiteName.tld -  e.g. "Torrenting.com - "
        n = _re.sub(r'^[A-Za-z0-9-]+\.(com|org|net|me|to|cc|tv|io|xyz|site|online)\s*[-–]\s*', '', n, flags=_re.IGNORECASE)
        # Repeat in case of stacked brackets
        n = _re.sub(r'^\[[^\]]{1,80}\]\s*', '', n)
        return n.strip()

    def _arr_folder_name(transfer_name: str, arr_type: str) -> str:
        """Build the Arr-style folder name from the transfer name.
        Strips site prefixes, season descriptors, quality tags, year-ranges,
        and subtitle separators so the result matches the Sonarr/Radarr library title.
        """
        # 1. Dots/underscores → spaces so all patterns work uniformly
        n = transfer_name.replace(".", " ").replace("_", " ")

        # 2. Strip site watermark prefixes
        n = _strip_site_prefix(n)

        # 3. Strip trailing unclosed parens/brackets left by truncated names
        #    e.g. "American Dad! Seasons 1 to 18 ("  →  "American Dad! Seasons 1 to 18"
        n = _re.sub(r"\s*[\(\[]\s*$", "", n)

        # 4. Sonarr: strip season/episode descriptors
        if arr_type == "sonarr":
            # Written-out: "Seasons 1 to 18", "Seasons 1 and 2", "Season One"
            n = _re.sub(
                r"\bSeasons?\s+(?:\d[\d\s+\-–toand]*\d|\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b.*",
                "", n, flags=_re.IGNORECASE
            )
            # Dutch: "Seizoen 1+2+3"
            n = _re.sub(r"\bSeizoen\s+[\d+\-–]+.*", "", n, flags=_re.IGNORECASE)
            # S01-S10 ranges
            n = _re.sub(r"\bS\d{1,2}\s*[-–]\s*S?\d{1,2}\b.*", "", n, flags=_re.IGNORECASE)
            # S01E01 or bare S01
            n = _re.sub(r"\bS\d{1,2}(?:E\d{1,3}(?:[-–]E?\d{1,3})?)?\b.*", "", n, flags=_re.IGNORECASE)
            # lowercase "seasons 01-06"
            n = _re.sub(r"\bseasons?\s+\d+.*", "", n, flags=_re.IGNORECASE)
            # "Complete Series/Collection", "Full Series"
            n = _re.sub(r"\bComplete\s+(?:Series|Collection|Season)\b.*", "", n, flags=_re.IGNORECASE)
            n = _re.sub(r"\bFull\s+Series\b.*", "", n, flags=_re.IGNORECASE)
            # "- 1998 - Full Series-207 Episodes" style mid-title year+dash
            n = _re.sub(r"\s*[-–]\s*(19|20)\d{2}\s*[-–].*", "", n)

        # 5. Strip year-range suffixes: "(1999-2015)", "(2018-2022)", "2017-2020"
        n = _re.sub(r"\s*\(\d{4}[-–]\d{4}\)\s*$", "", n).strip()
        n = _re.sub(r"\s*\d{4}[-–]\d{4}\s*$", "", n).strip()

        # 6. Strip trailing lone year in parens: "(2018)"
        #    _norm_variants handles matching with/without year, so strip here for clean labels
        n = _re.sub(r"\s*\(\d{4}\)\s*$", "", n).strip()

        # 7. Strip quality/codec tags
        n = _re.sub(
            r"\b(2160p?|1080p?|720p?|480p?|576p?|4k|uhd|hdr|bluray|blu-ray|web-?dl|"
            r"webrip|hdtv|x264|x265|hevc|remux|proper|repack|10bit|avc|dts|"
            r"dd5|aac|ac3|atmos|truehd|h\.?26[45]|hevc|complete|nordic|multi|amzn)\b.*",
            "", n, flags=_re.IGNORECASE
        ).strip(" -–")

        # 8. Spaced dash = subtitle separator → collapse to space
        #    "Daredevil - Born Again" → "Daredevil Born Again"
        #    Preserves hyphenated words: "Brooklyn Nine-Nine", "X-Men"
        n = _re.sub(r"\s+[-–]\s+", " ", n)

        # 9. Final punctuation cleanup
        n = _re.sub(r"\s*[-–:,]\s*$", "", n).strip()
        return _re.sub(r"\s+", " ", n).strip()

    def _norm(s: str) -> str:
        return _re.sub(r"[^a-z0-9]", "", (s or "").lower())

    def _norm_variants(label: str) -> list:
        """Return all normalised lookup variants of a cleaned label to try
        against lib_by_norm.  Covers year suffixes, qualifier parens,
        year-ranges, multiple stacked parens, and unicode normalisation."""
        seen = set()
        result = []
        def _add(s):
            v = _norm(s)
            if v and v not in seen:
                seen.add(v)
                result.append(v)

        _add(label)
        # Bare trailing year: "Show 2021" / "Show (2021)"
        no_year = _re.sub(r"\s*\(?(19|20)\d{2}\)?\s*$", "", label).strip()
        _add(no_year)
        # Qualifier parens: "Euphoria (US)" / "Show (US) (2019)"
        no_parens = _re.sub(r"\s*\([^)]{1,30}\)\s*$", "", label).strip()
        _add(no_parens)
        # Both: strip all trailing paren groups
        no_all = _re.sub(r"(?:\s*\([^)]{1,30}\)){1,3}\s*$", "", label).strip()
        _add(no_all)
        # Year-range: "Dark 2017-2020"
        no_range = _re.sub(r"\s*\(?\d{4}[-–]\d{4}\)?\s*$", "", label).strip()
        _add(no_range)
        # Unicode-normalised: "Shōgun" → "Shogun"
        try:
            import unicodedata as _ud
            ascii_label = _ud.normalize("NFKD", label).encode("ascii", "ignore").decode()
            _add(ascii_label)
            _add(_re.sub(r"\s*\(?(19|20)\d{2}\)?\s*$", "", ascii_label).strip())
        except Exception:
            pass
        return result

    def _wipe_stubs(root: str):
        """Delete all stub .mkv files (< 10 MB) and their companion .nfo files."""
        removed = 0
        if not _os.path.isdir(root):
            return 0
        for dirpath, dirnames, filenames in _os.walk(root):
            for fn in filenames:
                fpath = _os.path.join(dirpath, fn)
                ext   = fn.lower().rsplit('.', 1)[-1] if '.' in fn else ''
                try:
                    if ext == 'mkv' and _os.path.getsize(fpath) < 10 * 1024 * 1024:
                        _os.remove(fpath)
                        removed += 1
                        # Remove companion NFO
                        nfo = _os.path.splitext(fpath)[0] + ".nfo"
                        if _os.path.exists(nfo):
                            _os.remove(nfo)
                        # Remove parent folder if now empty
                        parent = _os.path.dirname(fpath)
                        if parent != root and not _os.listdir(parent):
                            _shutil.rmtree(parent, ignore_errors=True)
                    elif ext == 'nfo':
                        # Orphaned NFO (stub already removed) — clean it up
                        mkv = _os.path.splitext(fpath)[0] + ".mkv"
                        if not _os.path.exists(mkv):
                            _os.remove(fpath)
                except OSError:
                    pass
        return removed

    def generate():
        if not base_url or not api_key:
            yield sse(log="❌ Missing URL or API key.", done=True, error=True)
            return

        # ── Step 1: connect + get root folder ─────────────────────────────────
        yield sse(log=f"Connecting to {arr_name} at {base_url}…", pct=2, status="Connecting…")
        try:
            ping = _req.get(f"{base_url}/api/v3/system/status", headers=_headers(), timeout=8)
            if ping.status_code not in (200, 201):
                yield sse(log=f"❌ {arr_name} returned HTTP {ping.status_code}.", done=True, error=True)
                return
            yield sse(log=f"Connected to {arr_name} v{ping.json().get('version','?')}", pct=5)
        except Exception as e:
            yield sse(log=f"❌ Cannot reach {arr_name}: {e}", done=True, error=True)
            return

        try:
            rf = _req.get(f"{base_url}/api/v3/rootFolder", headers=_headers(), timeout=8).json()
            auto_root = rf[0]["path"].rstrip("/") if rf else "/movies"
        except Exception as e:
            yield sse(log=f"⚠ Could not get root folder: {e} — using /movies")
            auto_root = "/movies"

        if arr_root:
            root_path = arr_root
            yield sse(log=f"Root folder: {root_path} (configured)", pct=8)
        else:
            root_path = auto_root
            yield sse(log=f"Root folder: {root_path} (auto-detected)", pct=8)

        # ── Step 2: scan FUSE mount ────────────────────────────────────────────
        yield sse(log=f"Scanning FUSE /{folder}…", pct=10, status="Scanning…")
        name_map   = build_name_map(_transfer_manager)
        fuse_items = {}   # folder_name → transfer dict
        for key, hash_ in name_map.items():
            parts = key.split("/", 1)
            if parts[0] != folder or len(parts) < 2:
                continue
            t = _transfer_manager.get_transfer(hash_)
            if t:
                fuse_items[parts[1]] = t

        if not fuse_items:
            available = list({k.split("/")[0] for k in name_map.keys()})
            yield sse(log=f"⚠ No items in /{folder}. Available: {available or ['(empty)']}", done=True)
            return
        yield sse(log=f"Found {len(fuse_items)} items in /{folder}", pct=14)

        # ── Step 3 (full only): wipe existing stubs + set library monitored ────
        if mode == "full":
            yield sse(log="Full sync: wiping existing stubs…", pct=16, status="Wiping stubs…")

            if arr == "sonarr":
                # For Sonarr we must wipe stubs from every series folder the Arr
                # library knows about — not just root_path — because each series
                # lives in its own path (e.g. /plex/shows/The Bear/) and stubs
                # are nested in Season XX subfolders inside those.
                # We fetch the series list here (before the main library index
                # build) so we can wipe immediately.
                _wipe_total = 0
                _wipe_total += _wipe_stubs(root_path)   # catch any orphan folders
                try:
                    _series_list = _req.get(
                        f"{base_url}/api/v3/series", headers=_headers(), timeout=30
                    ).json()
                    _series_paths = [
                        s.get("path", "").rstrip("/")
                        for s in (_series_list if isinstance(_series_list, list) else [])
                        if s.get("path")
                    ]
                    for _sp in _series_paths:
                        if _os.path.isdir(_sp):
                            _wipe_total += _wipe_stubs(_sp)
                    yield sse(log=f"  Removed {_wipe_total} stub file(s) across {len(_series_paths)} series folder(s)")
                except Exception as _we:
                    yield sse(log=f"  ⚠ Could not fetch series list for wipe: {_we} — wiped {_wipe_total} from root only")
            else:
                # Radarr: each movie lives directly under root_path
                removed = _wipe_stubs(root_path)
                yield sse(log=f"  Removed {removed} stub file(s) from {root_path}")

            # Set all existing Arr items to monitored=True
            yield sse(log="Setting existing library items to monitored…", pct=20)
            endpoint = "movie" if arr == "radarr" else "series"
            try:
                existing = _req.get(f"{base_url}/api/v3/{endpoint}",
                                    headers=_headers(), timeout=15).json()
                bulk_monitored = 0
                for item in existing:
                    if not item.get("monitored"):
                        item["monitored"] = True
                        try:
                            _req.put(f"{base_url}/api/v3/{endpoint}/{item['id']}",
                                     headers=_headers(), json=item, timeout=8)
                            bulk_monitored += 1
                        except Exception:
                            pass
                if bulk_monitored:
                    yield sse(log=f"  Set {bulk_monitored} item(s) to monitored")
            except Exception as e:
                yield sse(log=f"⚠ Could not update library: {e}")

        # ── Step 4: write stubs + trigger rescans ──────────────────────────────
        yield sse(log=f"Processing {len(fuse_items)} items…", pct=24, status="Writing stubs…")
        added = imported = skipped = errors = 0
        total = len(fuse_items)

        # Fetch the Arr library ONCE and index it by normalized title. The
        # per-item rescan lookup is then a dict hit instead of a full /series
        # (or /movie) fetch per item — that per-item fetch is what made a large
        # sync crawl and hammer the Arr until it refused connections.
        _endpoint   = "series" if arr == "sonarr" else "movie"
        lib_by_norm = {}   # norm_key → arr_id  (many keys per id)
        lib_path    = {}   # arr_id   → existing folder path on disk
        lib_seasons = {}   # (arr_id, season_num) → list of existing Season XX folder paths

        def _folder_norm_variants(folder_basename: str) -> list:
            """All normalised variants of a disk folder name for index building.
            Handles: 'Yellowstone (2018)' 'Yellowstone 2018' 'Euphoria (US)' etc."""
            variants = set()
            n = folder_basename
            variants.add(_norm(n))
            # Strip trailing year in parens: "Show (2018)"
            v = _re.sub(r"\s*\(\d{4}\)\s*$", "", n).strip()
            variants.add(_norm(v))
            # Strip trailing bare year: "Show 2018"
            v2 = _re.sub(r"\s*(19|20)\d{2}\s*$", "", n).strip()
            variants.add(_norm(v2))
            # Strip qualifier in parens: "Euphoria (US)"
            v3 = _re.sub(r"\s*\([^)]{1,30}\)\s*$", "", n).strip()
            variants.add(_norm(v3))
            # Strip year-range: "Dark (2017-2020)"
            v4 = _re.sub(r"\s*\(\d{4}[-–]\d{4}\)\s*$", "", n).strip()
            variants.add(_norm(v4))
            # Strip multiple trailing parens: "Euphoria (US) (2019)"
            v5 = _re.sub(r"(?:\s*\([^)]{1,30}\)){1,3}\s*$", "", n).strip()
            variants.add(_norm(v5))
            return [v for v in variants if v]

        try:
            _lib = _req.get(f"{base_url}/api/v3/{_endpoint}", headers=_headers(), timeout=30).json()
            for _it in (_lib if isinstance(_lib, list) else []):
                _id   = _it.get("id")
                _path = (_it.get("path") or "").rstrip("/")
                if _id is None:
                    continue
                if _path:
                    lib_path[_id] = _path
                    # Index existing Season XX subfolders
                    if arr == "sonarr" and _os.path.isdir(_path):
                        for _sd in _os.scandir(_path):
                            if _sd.is_dir() and _re.match(r"Season\s+\d+", _sd.name, _re.IGNORECASE):
                                _sn = int(_re.search(r"\d+", _sd.name).group())
                                lib_seasons.setdefault((_id, _sn), []).append(_sd.path)
                    # Index from the actual folder basename on disk — this catches
                    # cases where the Arr title differs from the folder name
                    # (e.g. title="Yellowstone", folder="Yellowstone (2018)")
                    _folder_base = _path.split("/")[-1] if "/" in _path else _path
                    for _fv in _folder_norm_variants(_folder_base):
                        lib_by_norm.setdefault(_fv, _id)  # don't override API-title keys

                # Index from Sonarr/Radarr API title fields (these take priority)
                for _key in (_it.get("title"), _it.get("cleanTitle"), _it.get("sortTitle")):
                    if _key:
                        lib_by_norm[_norm(_key)] = _id   # overrides folder-derived keys

            yield sse(log=f"Indexed {len(set(lib_by_norm.values()))} existing {_endpoint} from {arr_name} ({len(lib_by_norm)} lookup keys)")
        except Exception as e:
            yield sse(log=f"⚠ Could not fetch {arr_name} library: {e} — rescans may be skipped")

        rescanned = set()   # ids already sent a rescan — avoids duplicate commands

        _HASH_RE = _re.compile(r'^[0-9a-f]{32,64}$', _re.IGNORECASE)

        def _needs_resolution(raw: str) -> bool:
            """True if raw is a bare hash or a site-prefix-only name with no
            usable show title — both cases are resolved from file paths."""
            s = raw.strip()
            if _HASH_RE.match(s):
                return True
            # Check if stripping the site prefix leaves nothing
            n = s.replace(".", " ").replace("_", " ")
            stripped = _strip_site_prefix(n)
            if not stripped or len(stripped) < 2:
                return True
            # Still starts with www after stripping (e.g. "www Torrenting")
            if _re.match(r'^www\s+', stripped, _re.IGNORECASE):
                return True
            return False

        def _resolve_name_from_files(t_hash: str, t_name: str) -> str | None:
            """Extract the real torrent name from the top-level path component
            of the directdl file list.  Returns None if nothing useful found."""
            try:
                files = _transfer_manager.get_files(t_hash) or []
                if not files:
                    return None
                tops = [f.get("path", "").split("/")[0]
                        for f in files if f.get("path")]
                # Discard entries that are themselves hashes or empty
                tops = [t for t in tops if t and not _HASH_RE.match(t)]
                if not tops:
                    return None
                from collections import Counter as _Ctr
                resolved = _Ctr(tops).most_common(1)[0][0]
                # Single-file torrent: strip video extension
                if "." in resolved:
                    base, ext = _os.path.splitext(resolved)
                    if ext.lower() in (".mkv", ".mp4", ".avi", ".ts", ".m4v", ".wmv"):
                        resolved = base
                return resolved or None
            except Exception:
                return None

        for i, (item_name, transfer) in enumerate(fuse_items.items()):
            pct    = 24 + int(72 * (i + 1) / max(total, 1))
            t_name = transfer.get("name") or item_name
            t_hash = transfer.get("hash", "")

            # ── Resolve unreadable names from Premiumize file paths ────────
            # Covers two cases:
            #   1. Bare hash  — name was never set (e.g. added via magnet with no dn=)
            #   2. Site-prefix-only — name IS the watermark folder with no show title
            #      (e.g. "www Torrenting", "www UIndex org")
            # In both cases the real torrent name is the top-level folder in the
            # directdl content[].path response.
            if _needs_resolution(t_name):
                resolved = _resolve_name_from_files(t_hash, t_name)
                if resolved and resolved != t_name:
                    yield sse(log=f"  ℹ {t_name[:40]} → resolved: {resolved[:60]}")
                    t_name = resolved
                    _transfer_manager._set(t_hash, name=resolved)
                else:
                    # Still nothing — skip rather than creating a junk folder
                    yield sse(log=f"  ⚠ Skipping — cannot resolve title: {t_name[:60]}")
                    skipped += 1
                    continue

            # Heartbeat BEFORE the work: keeps the SSE connection warm and makes
            # the in-flight item visible, so a stall points at a specific title
            # instead of freezing with no output.
            yield sse(status=f"[{i+1}/{total}] {t_name[:48]}", pct=pct)

            try:
                # Build Arr folder name and filename
                folder_label = _arr_folder_name(t_name, arr)

                # Safety net: if folder_label is still empty after all cleaning, skip
                if not folder_label or len(folder_label) < 2:
                    yield sse(log=f"  ⚠ Skipping — no usable title: {t_name[:60]}")
                    skipped += 1
                    continue

                # Prefer the real on-disk path that Sonarr/Radarr already knows about.
                # This ensures stubs land in the existing library folder (which may
                # have a different casing or year suffix than our generated name).
                # Fall back to root_path/<folder_label> if the series/movie is not
                # yet in the Arr library — in that case we create the folder fresh.
                # Try normalised variants (exact, year-stripped, paren-stripped)
                # so "Invincible 2021" matches Sonarr's "Invincible" etc.
                _arr_id = next(
                    (lib_by_norm[v] for v in _norm_variants(folder_label) if v in lib_by_norm),
                    None
                )
                if _arr_id and lib_path.get(_arr_id):
                    dest_dir = lib_path[_arr_id]
                else:
                    dest_dir = _os.path.join(root_path, folder_label)

                # Get real files for filename selection
                try:
                    real_files = _transfer_manager.get_files(t_hash) or []
                except Exception:
                    real_files = []

                if arr == "sonarr":
                    series_id = _arr_id or next(
                        (lib_by_norm[v] for v in _norm_variants(folder_label) if v in lib_by_norm),
                        None
                    )
                    res_tag = _detect_resolution(t_name)

                    # ── Resolve series path — always from Sonarr ──────────────
                    # Priority:
                    #   1. Series already in Sonarr → use its path from lib_path
                    #   2. Series not in Sonarr → add it via /api/v3/series/lookup
                    #      + POST, then use the path Sonarr assigns
                    #   3. Add fails → create root_path/folder_label ourselves

                    if series_id and lib_path.get(series_id):
                        # Known series — use Sonarr's authoritative path
                        series_root = lib_path[series_id]
                    else:
                        # Not in Sonarr yet — look it up by title and add it
                        series_root = None
                        try:
                            lookup = _req.get(
                                f"{base_url}/api/v3/series/lookup",
                                headers=_headers(),
                                params={"term": folder_label},
                                timeout=10,
                            ).json()
                            match = lookup[0] if isinstance(lookup, list) and lookup else None
                            if match:
                                # Fetch quality profile + root folder defaults
                                qp = _req.get(f"{base_url}/api/v3/qualityProfile",
                                              headers=_headers(), timeout=8).json()
                                qp_id = qp[0]["id"] if isinstance(qp, list) and qp else 1
                                rf = _req.get(f"{base_url}/api/v3/rootFolder",
                                              headers=_headers(), timeout=8).json()
                                rf_path = rf[0]["path"].rstrip("/") if isinstance(rf, list) and rf else root_path

                                # Build the series folder path Sonarr would use
                                title_slug = _re.sub(r'[<>:"/\\|?*]', '', match.get("title", folder_label))
                                proposed_path = _os.path.join(rf_path, title_slug)

                                add_payload = {
                                    **match,
                                    "monitored":        True,
                                    "qualityProfileId": qp_id,
                                    "rootFolderPath":   rf_path,
                                    "path":             proposed_path,
                                    "addOptions":       {"searchForMissingEpisodes": False,
                                                         "monitor": "all"},
                                }
                                add_resp = _req.post(
                                    f"{base_url}/api/v3/series",
                                    headers=_headers(),
                                    json=add_payload,
                                    timeout=15,
                                )
                                if add_resp.ok:
                                    added_series = add_resp.json()
                                    series_id    = added_series.get("id")
                                    series_root  = (added_series.get("path") or proposed_path).rstrip("/")
                                    # Update local indexes so Season dirs and rescans work
                                    if series_id:
                                        lib_path[series_id] = series_root
                                        for _key in (added_series.get("title"),
                                                     added_series.get("cleanTitle")):
                                            if _key:
                                                lib_by_norm[_norm(_key)] = series_id
                                    yield sse(log=f"  ➕ Added to Sonarr: {folder_label} → {series_root}")
                                else:
                                    yield sse(log=f"  ⚠ Could not add {folder_label} to Sonarr ({add_resp.status_code}) — using fallback path")
                        except Exception as _add_err:
                            yield sse(log=f"  ⚠ Sonarr lookup/add failed for {folder_label}: {_add_err}")

                        if not series_root:
                            # Fallback: create the folder ourselves under root_path
                            series_root = _os.path.join(root_path, folder_label)

                    # Ensure series_root exists with full rw permissions so
                    # Sonarr (potentially a different uid) can read/delete stubs
                    _ensure_dir(series_root)

                    # ── helpers (use series_root, not dest_dir) ───────────────
                    def _season_dir_for(sid, snum):
                        """Return the Season XX dir inside series_root.
                        Uses existing on-disk dir if Sonarr already created it
                        (matching any 'Season N' / 'Season 01' naming), otherwise
                        creates 'Season 01' style next to any existing seasons."""
                        # Check on-disk first (may already exist from a previous sync
                        # or Sonarr's own folder creation)
                        if sid:
                            existing = lib_seasons.get((sid, snum), [])
                            if existing:
                                return existing[0]
                        # Scan series_root for any Season folder with this number
                        if _os.path.isdir(series_root):
                            for _sd in _os.scandir(series_root):
                                if _sd.is_dir():
                                    _m = _re.match(r'Season\s*(\d+)$', _sd.name, _re.IGNORECASE)
                                    if _m and int(_m.group(1)) == snum:
                                        return _sd.path
                        return _os.path.join(series_root, f"Season {snum:02d}")

                    def _write_season(sid, snum):
                        """Write one stub per episode for season snum.
                        Returns number of stubs written."""
                        sdir  = _season_dir_for(sid, snum)
                        count = 0
                        if sid:
                            try:
                                eps = _req.get(f"{base_url}/api/v3/episode",
                                               headers=_headers(),
                                               params={"seriesId": sid,
                                                       "seasonNumber": snum},
                                               timeout=10).json()
                                for ep in (eps if isinstance(eps, list) else []):
                                    ep_num = ep.get("episodeNumber")
                                    if not ep_num:
                                        continue
                                    ep_fn = (f"{folder_label} S{snum:02d}E{ep_num:02d}"
                                             f".WEBRip-{res_tag}.mkv")
                                    _write_stub(sdir, ep_fn, real_files)
                                    count += 1
                            except Exception:
                                pass
                        if not count:
                            ep_fn = f"{folder_label} S{snum:02d}.WEBRip-{res_tag}.mkv"
                            _write_stub(sdir, ep_fn, real_files)
                            count = 1
                        return count

                    def _rescan(sid):
                        if sid and sid not in rescanned:
                            rescanned.add(sid)
                            try:
                                _req.post(f"{base_url}/api/v3/command",
                                          headers=_headers(),
                                          json={"name": "RescanSeries", "seriesId": sid},
                                          timeout=8)
                            except Exception:
                                pass

                    # ── detect what we have ───────────────────────────────────
                    ep_match = _re.search(r'S(\d{1,2})E(\d{1,3})', t_name, _re.IGNORECASE)

                    _season_nums = set()
                    for _m in _re.finditer(r'S(\d{1,2})\s*[-–]\s*S?(\d{1,2})', t_name, _re.IGNORECASE):
                        for _s in range(int(_m.group(1)), int(_m.group(2)) + 1):
                            _season_nums.add(_s)
                    for _m in _re.finditer(r'Season\s*(\d+)\s*[-–]\s*(\d+)', t_name, _re.IGNORECASE):
                        for _s in range(int(_m.group(1)), int(_m.group(2)) + 1):
                            _season_nums.add(_s)
                    for _m in _re.finditer(r'Season\s*(\d+)\b', t_name, _re.IGNORECASE):
                        if not _re.search(r'Season\s*' + _m.group(1) + r'\s*[-–]', t_name, _re.IGNORECASE):
                            _season_nums.add(int(_m.group(1)))
                    if not ep_match:
                        for _m in _re.finditer(r'\bS(\d{1,2})\b(?!\s*[-–])(?!E)', t_name, _re.IGNORECASE):
                            _season_nums.add(int(_m.group(1)))

                    is_pack = bool(_season_nums and not ep_match)

                    if is_pack:
                        stub_count = 0
                        for _snum in sorted(_season_nums):
                            stub_count += _write_season(series_id, _snum)
                        _rescan(series_id)
                        season_label = (f"S{min(_season_nums):02d}"
                                        if len(_season_nums) == 1
                                        else f"S{min(_season_nums):02d}-S{max(_season_nums):02d}")
                        yield sse(log=f"  ✓ {folder_label} {season_label} — {stub_count} stubs → {series_root}", pct=pct)
                        imported += stub_count

                    elif ep_match:
                        sn      = int(ep_match.group(1))
                        ep_dir  = _season_dir_for(series_id, sn)
                        fake_fn = _pick_fake_filename(t_name, real_files)
                        stub_path = _os.path.join(ep_dir, fake_fn)
                        if mode == "partial" and _os.path.exists(stub_path):
                            skipped += 1
                            continue
                        _write_stub(ep_dir, fake_fn, real_files)
                        _rescan(series_id)
                        imported += 1
                        yield sse(log=f"  ✓ {folder_label} S{sn:02d}E{ep_match.group(2)} → {ep_dir}", pct=pct)

                    else:
                        # No season marker — get all seasons from Sonarr
                        stub_count = 0
                        if series_id:
                            try:
                                all_seasons = _req.get(f"{base_url}/api/v3/season",
                                                       headers=_headers(),
                                                       params={"seriesId": series_id},
                                                       timeout=10).json()
                                all_snums = sorted(set(
                                    s.get("seasonNumber") for s in (all_seasons if isinstance(all_seasons, list) else [])
                                    if s.get("seasonNumber") is not None and s.get("seasonNumber") > 0
                                ))
                            except Exception:
                                all_snums = []
                            if all_snums:
                                for _snum in all_snums:
                                    stub_count += _write_season(series_id, _snum)
                                _rescan(series_id)
                                yield sse(log=f"  ✓ {folder_label} (complete) — {stub_count} stubs across {len(all_snums)} season(s) → {series_root}", pct=pct)
                                imported += stub_count
                            else:
                                fake_fn = _pick_fake_filename(t_name, real_files)
                                stub_path = _os.path.join(series_root, fake_fn)
                                if mode == "partial" and _os.path.exists(stub_path):
                                    skipped += 1
                                else:
                                    _write_stub(series_root, fake_fn, real_files)
                                    _rescan(series_id)
                                    imported += 1
                                    yield sse(log=f"  ✓ {folder_label} (no season data) → {series_root}", pct=pct)
                        else:
                            fake_fn = _pick_fake_filename(t_name, real_files)
                            _write_stub(series_root, fake_fn, real_files)
                            imported += 1
                            yield sse(log=f"  ✓ {folder_label} (not in Sonarr) → {series_root}", pct=pct)

                else:
                    # Radarr — single movie stub
                    fake_fn   = _pick_fake_filename(t_name, real_files)
                    stub_path = _os.path.join(dest_dir, fake_fn)

                    if mode == "partial" and _os.path.exists(stub_path):
                        skipped += 1
                        continue

                    # Ensure dest_dir and all parents are rw for Radarr
                    _ensure_dir(dest_dir)
                    _write_stub(dest_dir, fake_fn, real_files)

                    # Trigger RescanMovie (once per movie) via the index
                    mid = next(
                        (lib_by_norm[v] for v in _norm_variants(folder_label) if v in lib_by_norm),
                        None
                    )
                    if mid and mid not in rescanned:
                        rescanned.add(mid)
                        try:
                            _req.post(f"{base_url}/api/v3/command",
                                      headers=_headers(),
                                      json={"name": "RescanMovie", "movieId": mid},
                                      timeout=8)
                        except Exception:
                            pass

                    imported += 1
                    yield sse(log=f"  ✓ {folder_label}", pct=pct)

            except Exception as e:
                yield sse(log=f"  ❌ {item_name[:60]}: {e}")
                errors += 1

        yield sse(
            log=f"\n✅ Sync complete. Written: {imported}  Skipped: {skipped}  Errors: {errors}",
            pct=100, status="Done", done=True
        )

    from flask import stream_with_context
    return app.response_class(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"}
    )




if os.environ.get("ENABLE_FUSE", "true").lower() == "true":
    # Apply any saved mount config before starting FUSE
    _apply_fuse_settings(_get_fuse_settings())
    t = threading.Thread(target=_start_fuse, daemon=False)
    t.start()



@app.route("/api/fuse/stubs/reset", methods=["POST"])
def fuse_stubs_reset():
    with _transfer_manager._lock:
        db = _transfer_manager._db()
        db.execute("UPDATE files SET cdn_unlocked=0")
        db.execute("UPDATE transfers SET cdn_unlocked=0")
        db.execute("DELETE FROM meta WHERE key='import_done'")
        db.commit()
    try:
        import transfer_manager as _tm
        _tm._unlocked_hashes.clear()
        _tm._unlocked_all = False
    except Exception:
        pass
    try:
        import fuse_mount as _fm
        if getattr(_fm, "_pfs", None) is not None:
            _fm._pfs._stat_invalidate_all()
    except Exception:
        pass
    _pw_log("[playback-unlock] reset all files back to stub mode")
    return jsonify({"ok": True})





if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))

    # Raise the process fd limit so select() doesn't hit its 1024-fd ceiling.
    import resource
    try:
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = min(hard, 65536)
        if soft < target:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
            app.logger.info(f"Raised RLIMIT_NOFILE {soft} → {target}")
    except Exception as e:
        app.logger.warning(f"Could not raise fd limit: {e}")

    # Werkzeug server with a hard cap on concurrent request threads.
    from werkzeug.serving import make_server as _make_server
    max_threads = int(os.environ.get("SERVER_THREADS", "16"))
    _thread_sem = threading.Semaphore(max_threads)

    _srv = _make_server("0.0.0.0", port, app, threaded=True)
    _orig_process_request = _srv.process_request

    def _capped_process_request(request, client_address):
        if _thread_sem.acquire(blocking=False):
            def _run():
                try:
                    _srv.finish_request(request, client_address)
                except Exception:
                    _srv.handle_error(request, client_address)
                finally:
                    _srv.shutdown_request(request)
                    _thread_sem.release()
            t = threading.Thread(target=_run, daemon=True)
            t.start()
        else:
            # All slots busy — serve synchronously rather than drop the request
            try:
                _srv.finish_request(request, client_address)
            except Exception:
                _srv.handle_error(request, client_address)
            finally:
                _srv.shutdown_request(request)

    _srv.process_request = _capped_process_request
    app.logger.info(f"Starting server on :{port} (max {max_threads} threads)")
    _srv.serve_forever()

import os
import re
import json
import secrets
import threading
import time
import urllib.parse
import requests
from collections import defaultdict
from datetime import datetime, timezone
from xml.sax.saxutils import escape as xml_escape
from flask import Flask, request, jsonify, render_template, Response

app = Flask(__name__)

# ── stream token cache ────────────────────────────────────────────────────────
# Tokens map to (hash, filename) — NOT a CDN URL.
# The proxy resolves a fresh CDN URL on every request via the directdl cache,
# so links never go stale regardless of how long VLC has been open.

import hmac

# Secret key for signing tokens — generated once per process lifetime.
# Tokens are deterministic per (hash, filename) so they survive restarts as long
# as the same secret is used. We store it in config so it persists across restarts.
def _get_token_secret() -> str:
    cfg = _load_config()
    if "token_secret" not in cfg:
        cfg["token_secret"] = secrets.token_hex(32)
        _save_config(cfg)
    return cfg["token_secret"]

_TOKEN_SECRET: str = ""

def _make_stream_token(hash_: str, filename: str) -> str:
    """Generate a deterministic token for (hash, filename) — survives restarts."""
    global _TOKEN_SECRET
    if not _TOKEN_SECRET:
        _TOKEN_SECRET = _get_token_secret()
    payload = f"{hash_}:{filename}"
    return hmac.new(_TOKEN_SECRET.encode(), payload.encode(), "sha256").hexdigest()

def _verify_stream_token(token: str, hash_: str, filename: str) -> bool:
    expected = _make_stream_token(hash_, filename)
    return hmac.compare_digest(token, expected)

# ── directdl cache ────────────────────────────────────────────────────────────
# Shared cache so the stream proxy doesn't call directdl on every chunk read.
# TTL matches the FUSE layer (30 min). Automatically refreshed on expiry.

_DIRECTDL_TTL    = 21600  # 6 hours — Premiumize CDN URLs are valid well beyond 30 min
_DIRECTDL_MARGIN = 300   # refresh in the background once within 5 min of expiry
_directdl_cache: dict = {}  # hash → (files: list, expires_at: float)
_directdl_lock  = threading.Lock()
_directdl_refreshing: set = set()  # hashes with an in-flight background refresh


def _spawn_directdl_refresh(hash_: str, name: str) -> None:
    """Re-mint CDN links in the background so an active stream never blocks."""
    with _directdl_lock:
        if hash_ in _directdl_refreshing:
            return
        _directdl_refreshing.add(hash_)

    def _do():
        try:
            files = _directdl_for_manager_raw(hash_, name)
            if files:
                with _directdl_lock:
                    _directdl_cache[hash_] = (files, time.time() + _DIRECTDL_TTL)
        except Exception:
            app.logger.warning(f"[directdl {hash_[:8]}] background refresh failed")
        finally:
            with _directdl_lock:
                _directdl_refreshing.discard(hash_)

    threading.Thread(target=_do, daemon=True).start()


def _get_directdl(hash_: str, name: str, force: bool = False) -> list:
    """
    Return directdl file list, refreshing from Premiumize as needed.

    - force=True bypasses the cache and overwrites it with a fresh result —
      used when a CDN URL has been observed to expire (403/410).
    - Otherwise this is stale-while-revalidate: a fresh entry is returned
      directly; an entry inside the refresh margin is returned immediately while
      a background thread re-mints the links, so reads never wait on the network.
    """
    now = time.time()
    if not force:
        with _directdl_lock:
            cached = _directdl_cache.get(hash_)
        if cached:
            files, expires_at = cached
            if now < expires_at - _DIRECTDL_MARGIN:
                return files                      # comfortably fresh
            if now < expires_at:
                _spawn_directdl_refresh(hash_, name)  # refresh ahead of expiry
                return files                      # current link is still valid
            # hard-expired → fall through to a synchronous fetch
    # Cache miss, expired, or forced — fetch fresh
    files = _directdl_for_manager_raw(hash_, name)
    if files:
        with _directdl_lock:
            _directdl_cache[hash_] = (files, now + _DIRECTDL_TTL)
    return files

# ── persistent config ─────────────────────────────────────────────────────────

CONFIG_PATH = os.environ.get("CONFIG_PATH", "/app/config.json")
_config_lock = threading.Lock()

def _load_config() -> dict:
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except Exception:
        return {}

def _save_config(cfg: dict):
    os.makedirs(os.path.dirname(CONFIG_PATH) or ".", exist_ok=True)
    with _config_lock:
        with open(CONFIG_PATH, "w") as f:
            json.dump(cfg, f, indent=2)

def get_prowlarr_config() -> dict:
    saved = _load_config().get("prowlarr", {})
    # Env vars take precedence if set, otherwise fall back to saved config
    return {
        "url":     PROWLARR_URL or saved.get("url", ""),
        "api_key": PROWLARR_KEY or saved.get("api_key", ""),
        "from_env": bool(PROWLARR_URL or PROWLARR_KEY),
    }

def save_prowlarr_config(url: str, api_key: str):
    url = url.strip().rstrip("/")
    if url and not url.startswith(("http://", "https://")):
        url = "http://" + url
    cfg = _load_config()
    cfg["prowlarr"] = {"url": url, "api_key": api_key}
    _save_config(cfg)

# ── static config ─────────────────────────────────────────────────────────────

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

PM_BASE          = "https://www.premiumize.me/api"
PM_CACHE         = f"{PM_BASE}/cache/check"
PM_DIRECTDL      = f"{PM_BASE}/transfer/directdl"
PM_TRANSFER      = f"{PM_BASE}/transfer/create"
PM_TRANSFER_LIST = f"{PM_BASE}/transfer/list"
PM_ACCOUNT       = f"{PM_BASE}/account/info"

PM_API_KEY_ENV = os.environ.get("PREMIUMIZE_API_KEY", "")
TORZNAB_APIKEY = os.environ.get("TORZNAB_APIKEY", "changeme")
PROWLARR_URL   = os.environ.get("PROWLARR_URL", "")
PROWLARR_KEY   = os.environ.get("PROWLARR_API_KEY", "")

def get_pm_api_key() -> str:
    """Return PM API key — env var takes precedence, then saved config."""
    if PM_API_KEY_ENV:
        return PM_API_KEY_ENV
    return _load_config().get("pm_api_key", "")

def save_pm_api_key(key: str):
    cfg = _load_config()
    cfg["pm_api_key"] = key
    _save_config(cfg)

# Module-level alias kept for backwards compat with code that reads PM_API_KEY directly.
# Use get_pm_api_key() wherever the key is needed so it picks up saved values.
PM_API_KEY = property(get_pm_api_key) if False else get_pm_api_key()

# Torznab rate limit: requests per window
TORZNAB_RATE_LIMIT  = int(os.environ.get("TORZNAB_RATE_LIMIT", "60"))   # max requests
TORZNAB_RATE_WINDOW = int(os.environ.get("TORZNAB_RATE_WINDOW", "60"))  # per N seconds

# ── torznab rate limiter (sliding window per IP) ──────────────────────────────

_rate_lock = threading.Lock()
_rate_data: dict[str, list] = defaultdict(list)  # ip -> [timestamps]

def _check_rate_limit(ip: str) -> tuple[bool, int, int, int]:
    """Returns (allowed, limit, remaining, reset_ts)"""
    now = time.time()
    window_start = now - TORZNAB_RATE_WINDOW
    with _rate_lock:
        hits = [t for t in _rate_data[ip] if t > window_start]
        remaining = max(0, TORZNAB_RATE_LIMIT - len(hits))
        reset_ts = int(now + TORZNAB_RATE_WINDOW)
        if remaining == 0:
            return False, TORZNAB_RATE_LIMIT, 0, reset_ts
        hits.append(now)
        _rate_data[ip] = hits
        return True, TORZNAB_RATE_LIMIT, remaining - 1, reset_ts

def _rate_headers(limit: int, remaining: int, reset_ts: int) -> dict:
    return {
        "X-RateLimit-Limit":     str(limit),
        "X-RateLimit-Remaining": str(remaining),
        "X-RateLimit-Reset":     str(reset_ts),
    }

# ── category maps ─────────────────────────────────────────────────────────────

def tpb_to_newznab(tpb_cat, name=""):
    name_up = name.upper()
    if re.search(r'S\d{2}E\d{2}|SEASON\s+\d+|\bS\d{2}\b', name_up):
        return 5000
    try:
        c = int(tpb_cat)
    except Exception:
        return 8000
    if 200 <= c < 300: return 2000
    if 500 <= c < 600: return 5000
    if 300 <= c < 400: return 3000
    return 8000

# ── helpers ───────────────────────────────────────────────────────────────────

QUALITY_PATTERNS = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE
)

def fmt_size(b):
    try: return int(b)
    except Exception: return 0

def fmt_size_str(b):
    try: b = int(b)
    except Exception: return "?"
    if b > 1_000_000_000: return f"{b/1_000_000_000:.2f} GB"
    if b > 1_000_000:     return f"{b/1_000_000:.0f} MB"
    if b > 1_000:         return f"{b/1_000:.0f} KB"
    return f"{b} B"

def _sanitize(query):
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()

def parse_query(raw):
    quality = QUALITY_PATTERNS.findall(raw)
    search_raw = QUALITY_PATTERNS.sub('', raw).strip()
    season, episode = None, None
    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        search_raw = re.sub(r'\bseason\s+\d+\b', f'S{season:02d}', search_raw, flags=re.IGNORECASE)
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return ' '.join(search_raw.split()).strip(), season, episode, quality

def strip_season(query):
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', '', query, flags=re.IGNORECASE)
    return ' '.join(t.split())

def filter_by_season(torrents, season, episode):
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        if episode is not None and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out

def filter_by_quality(torrents, quality):
    if not quality:
        return torrents
    out = []
    for t in torrents:
        name_up = t.get("name", "").upper()
        for q in quality:
            if q.upper().rstrip('P') in name_up:
                out.append(t)
                break
    return out if out else torrents

# ── TPB fetch ─────────────────────────────────────────────────────────────────

def _fetch_tpb(query, limit=40):
    queries = [query]
    sanitized = _sanitize(query)
    if sanitized.lower() != query.lower():
        queries.append(sanitized)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = requests.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict)
                    and x.get("info_hash")
                    and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
                ]
                if valid:
                    return valid[:limit]
            except Exception:
                continue
    return []

# ── Prowlarr fetch ────────────────────────────────────────────────────────────

def _fetch_prowlarr(query: str, season=None, episode=None, limit=40) -> list:
    """Search Prowlarr and return normalised torrent dicts."""
    cfg = get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"):
        return []

    base = cfg["url"]
    key  = cfg["api_key"]

    # Build query string. Strip any season/episode token the caller may already
    # have baked into `query` before re-adding the canonical one, so we never
    # emit a doubled term like "Spongebob S15 S15".
    q = query
    if season is not None:
        q_base = strip_season(query)
        q = f"{q_base} S{season:02d}" if q_base else f"S{season:02d}"
        if episode is not None:
            q += f"E{episode:02d}"
        q = " ".join(q.split())

    params = {
        "query":      q,
        "indexerIds": -2,     # all torrent indexers
        "categories": [2000, 5000, 8000],
        "type":       "search",
        "limit":      limit,
    }

    try:
        r = requests.get(
            f"{base}/api/v1/search",
            headers={"X-Api-Key": key},
            params=params,
            timeout=20,
        )
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        app.logger.warning(f"Prowlarr search failed: {e}")
        return []

    def _extract_hash(item: dict) -> str:
        """Return a 40-char hex info_hash from the result, trying multiple fields."""
        # 1. Direct infoHash field (ideal case)
        h = (item.get("infoHash") or "").lower().strip()
        if re.fullmatch(r'[0-9a-fA-F]{40}', h):
            return h

        # 2. Scan all URL-like fields for a hash in any position:
        #    - magnet: btih:<hash>
        #    - https://site.com/<HASH>/title  (e.g. TorrentDownload guid)
        #    - base32 btih variant
        for field in ("magnetUrl", "downloadUrl", "guid"):
            val = item.get(field) or ""
            # btih: prefix (magnets)
            m = re.search(r'btih:([0-9a-fA-F]{40})', val, re.IGNORECASE)
            if m:
                return m.group(1).lower()
            # bare 40-char hex segment anywhere in the URL path/query
            m = re.search(r'(?<![0-9a-fA-F])([0-9a-fA-F]{40})(?![0-9a-fA-F])', val)
            if m:
                return m.group(1).lower()
            # base32 btih (32 uppercase chars)
            m32 = re.search(r'btih:([A-Z2-7]{32})', val, re.IGNORECASE)
            if m32:
                try:
                    import base64
                    raw = base64.b32decode(m32.group(1).upper())
                    candidate = raw.hex()
                    if re.fullmatch(r'[0-9a-f]{40}', candidate):
                        return candidate
                except Exception:
                    pass

        return ""

    def _prowlarr_category(item: dict) -> int:
        """
        Map a Prowlarr result to a top-level newznab category (2000/5000/8000).

        Prowlarr often returns subcategory IDs like 5030, 5040, 2040, etc.
        The category filter uses integer division (cat // 1000) to match, but
        the raw sub-ID must still be a recognised newznab ID range.
        We also fall back to name-based detection when the categories list is
        missing or contains an unrecognised ID (e.g. 0 from showRSS).
        """
        cats = item.get("categories") or []
        name = item.get("title", "")

        for c in cats:
            cid = c.get("id", 0) if isinstance(c, dict) else int(c or 0)
            if 2000 <= cid < 3000:
                return cid   # Movies (sub or parent — filter uses // 1000)
            if 5000 <= cid < 6000:
                return cid   # TV
            if 8000 <= cid < 9000:
                return cid   # Other

        # No usable newznab ID — infer from title
        if re.search(r'\bS\d{1,2}(?:E\d{1,2})?\b|\bSeason\s*\d+\b|\b\d{1,2}x\d{2}\b', name, re.IGNORECASE):
            return 5000
        return 8000

    results = []
    skipped = 0
    for item in data:
        info_hash = _extract_hash(item)
        if not info_hash:
            skipped += 1
            continue
        # Extract tracker list from the original magnet guid if present,
        # so downstream clients with DHT disabled can still use the magnet.
        trackers = []
        guid_val = item.get("guid") or ""
        if "btih:" in guid_val.lower():
            trackers = re.findall(r'[&?]tr=([^&]+)', guid_val)
        # Also check magnetUrl
        mag_val = item.get("magnetUrl") or ""
        if "btih:" in mag_val.lower() and not trackers:
            trackers = re.findall(r'[&?]tr=([^&]+)', mag_val)

        results.append({
            "info_hash": info_hash,
            "name":      item.get("title", "Unknown"),
            "size":      item.get("size", 0),
            "seeders":   item.get("seeders", 0) or 0,
            "leechers":  item.get("leechers", 0) or 0,
            "category":  _prowlarr_category(item),
            "indexer":   item.get("indexer", ""),
            "trackers":  trackers,
        })

    if skipped:
        app.logger.debug(f"Prowlarr: skipped {skipped} results with no extractable hash")

    return results

# ── Premiumize helpers ────────────────────────────────────────────────────────

def _make_magnet(torrent):
    h    = torrent["info_hash"].lower()
    name = urllib.parse.quote(torrent.get("name", ""), safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={name}"

def pm_headers(api_key):
    return {"Authorization": f"Bearer {api_key}"}

def check_cache_pm(api_key, torrents):
    if not torrents:
        return {}
    hashes = [t["info_hash"].lower() for t in torrents]
    headers = {**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"}
    try:
        r = requests.post(
            PM_CACHE,
            headers=headers,
            data=urllib.parse.urlencode([("items[]", h) for h in hashes]),
            timeout=15,
        )
        r.raise_for_status()
        data = r.json()
    except Exception:
        return {}
    if data.get("status") != "success":
        return {}
    responses = data.get("response", [])
    return {h: bool(responses[i]) if i < len(responses) else False
            for i, h in enumerate(hashes)}

# ── unified search ────────────────────────────────────────────────────────────

def do_search(query, season=None, episode=None, quality=None, limit=40, pm_key=None):
    # Try Prowlarr first, fall back to TPB
    prowlarr_cfg = get_prowlarr_config()
    if prowlarr_cfg.get("url") and prowlarr_cfg.get("api_key"):
        torrents = _fetch_prowlarr(query, season, episode, limit)
        source = "prowlarr"
    else:
        torrents = []
        source = "tpb"

    if not torrents:
        torrents = _fetch_tpb(query, limit)
        source = "tpb"
        if not torrents and season is not None:
            fallback = strip_season(query)
            if fallback and fallback.lower() != query.lower():
                torrents = _fetch_tpb(fallback, limit * 2)

    if not torrents:
        return []

    if source == "tpb":
        torrents = filter_by_season(torrents, season, episode)
        if not torrents and season is not None:
            torrents = _fetch_tpb(query, limit)
        if quality:
            torrents = filter_by_quality(torrents, quality)

    ready_map = check_cache_pm(pm_key, torrents) if pm_key else {}

    results = []
    seen = set()
    for t in torrents:
        h = t["info_hash"].lower()
        if h in seen:
            continue
        seen.add(h)
        cat = t.get("category", 8000)
        # Normalise TPB category numbers to newznab IDs
        if isinstance(cat, int) and cat < 1000:
            cat = tpb_to_newznab(cat, t.get("name", ""))
        results.append({
            "hash":     h,
            "name":     t.get("name", "Unknown"),
            "size":     fmt_size(t.get("size", 0)),
            "size_str": fmt_size_str(t.get("size", 0)),
            "seeders":  int(t.get("seeders", 0) or 0),
            "leechers": int(t.get("leechers", 0) or 0),
            "category": cat,
            "cached":   ready_map.get(h, False),
            "indexer":  t.get("indexer", "TPB"),
            "trackers": t.get("trackers", []),
        })

    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results

# ── Torznab XML ───────────────────────────────────────────────────────────────

def torznab_caps():
    return '''<?xml version="1.0" encoding="UTF-8"?>
<caps>
  <server title="Premiumize Indexer" />
  <limits default="40" max="100"/>
  <searching>
    <search available="yes" supportedParams="q"/>
    <tv-search available="yes" supportedParams="q,season,ep"/>
    <movie-search available="yes" supportedParams="q"/>
  </searching>
  <categories>
    <category id="2000" name="Movies">
      <subcat id="2010" name="Movies/Foreign"/>
      <subcat id="2020" name="Movies/Other"/>
      <subcat id="2030" name="Movies/SD"/>
      <subcat id="2040" name="Movies/HD"/>
      <subcat id="2045" name="Movies/UHD"/>
      <subcat id="2050" name="Movies/BluRay"/>
      <subcat id="2060" name="Movies/3D"/>
      <subcat id="2070" name="Movies/DVD"/>
      <subcat id="2080" name="Movies/WEB-DL"/>
    </category>
    <category id="5000" name="TV">
      <subcat id="5040" name="TV/HD"/>
      <subcat id="5045" name="TV/UHD"/>
      <subcat id="5030" name="TV/SD"/>
      <subcat id="5010" name="TV/WEB-DL"/>
    </category>
    <category id="8000" name="Other"/>
  </categories>
</caps>'''

# Well-known public trackers appended to every magnet as a fallback so
# clients with DHT disabled can still connect. Indexer-supplied trackers
# (from the Prowlarr result) are prepended and take precedence.
_FALLBACK_TRACKERS = [
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.tracker.cl:1337/announce",
    "udp://tracker.openbittorrent.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce",
    "udp://explodie.org:6969/announce",
]

def torznab_results(results, query=""):
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items = []
    for r in results:
        # Build magnet with trackers so clients with DHT disabled can use it
        trackers = r.get("trackers") or []
        all_trackers = list(dict.fromkeys(trackers + _FALLBACK_TRACKERS))  # dedup, indexer first
        tr_params = "".join(f"&tr={urllib.parse.quote(t, safe='')}" for t in all_trackers)
        magnet = f"magnet:?xt=urn:btih:{r['hash']}&dn={urllib.parse.quote(r['name'], safe='')}{tr_params}"
        cached_attr = '<torznab:attr name="cached" value="1"/>' if r.get("cached") else ''
        items.append(f"""    <item>
      <title>{xml_escape(r['name'])}</title>
      <guid>{xml_escape(magnet)}</guid>
      <link>{xml_escape(magnet)}</link>
      <pubDate>{now}</pubDate>
      <size>{r['size']}</size>
      <enclosure url="{xml_escape(magnet)}" length="{r['size']}" type="application/x-bittorrent"/>
      <torznab:attr name="magneturl" value="{xml_escape(magnet)}"/>
      <torznab:attr name="infohash" value="{r['hash']}"/>
      <torznab:attr name="seeders" value="{r['seeders']}"/>
      <torznab:attr name="leechers" value="{r['leechers']}"/>
      <torznab:attr name="size" value="{r['size']}"/>
      <torznab:attr name="category" value="{r['category']}"/>
      {cached_attr}
    </item>""")
    items_xml = "\n".join(items)
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <channel>
    <title>Premiumize Indexer</title>
    <description>TPB/Prowlarr via Premiumize cache check</description>
    <link>http://localhost</link>
    <language>en-US</language>
    <pubDate>{now}</pubDate>
    <response xmlns="urn:newznab:api" offset="0" total="{len(results)}"/>
{items_xml}
  </channel>
</rss>'''

def xml_error(code, description, extra_headers=None):
    r = Response(
        f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="{code}" description="{xml_escape(description)}"/>''',
        mimetype="application/xml", status=400
    )
    if extra_headers:
        for k, v in extra_headers.items():
            r.headers[k] = v
    return r

# ── routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

# Torznab — with rate limiting
@app.route("/torznab")
@app.route("/torznab/api")
def torznab():
    t = request.args.get("t", "").lower()

    # Caps is always public — Prowlarr probes it without a key
    if t == "caps":
        return Response(torznab_caps(), mimetype="application/xml")

    # API key check for all other requests
    apikey = request.args.get("apikey", "") or request.headers.get("X-Api-Key", "")
    if TORZNAB_APIKEY and apikey != TORZNAB_APIKEY:
        return xml_error(100, "Invalid API key")

    # Rate limit by IP
    ip = request.headers.get("X-Forwarded-For", request.remote_addr).split(",")[0].strip()
    allowed, limit, remaining, reset_ts = _check_rate_limit(ip)
    rh = _rate_headers(limit, remaining, reset_ts)

    if not allowed:
        retry_after = reset_ts - int(time.time())
        r = Response(
            f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="429" description="Rate limit exceeded. Retry after {retry_after}s"/>''',
            mimetype="application/xml", status=429,
            headers={**rh, "Retry-After": str(retry_after)},
        )
        return r

    if t in ("search", "tvsearch", "movie"):
        q      = request.args.get("q", "").strip()
        season = request.args.get("season", "").strip()
        ep     = request.args.get("ep", "").strip()
        cat    = request.args.get("cat", "").strip()

        app.logger.info(f"Torznab {t}: q={q!r} season={season!r} ep={ep!r} cat={cat!r}")

        # Parse season/ep from the explicit Torznab params (sent by Sonarr/Radarr).
        # Do NOT bake them into the query string — _fetch_prowlarr rebuilds the
        # query itself, and parse_query below also extracts them from q.
        # Baking them in first caused doubled tokens like "SpongeBob S15 S15".
        parsed_s, parsed_ep = None, None
        if season:
            try:
                parsed_s = int(season)
                if ep:
                    parsed_ep = int(ep)
            except ValueError:
                pass
        query = q  # raw title only; season/ep passed as separate numeric params

        # Empty query — return cached library items for the requested category.
        # This satisfies Radarr/Sonarr connection tests and browse calls.
        # Falls back to TPB if the library is empty so the connection test passes.
        if not query:
            all_transfers = _transfer_manager.all_transfers()
            streamable    = [t for t in all_transfers if t["state"] in ("cached", "complete")]
            fb_results    = []
            for t in streamable:
                h    = t["hash"]
                name = t.get("name") or h
                is_series = bool(re.search(
                    r'\bS\d{1,2}(?:E\d{1,2})?\b|\bSeason\s*\d+\b|\b\d{1,2}x\d{2}\b',
                    name, re.IGNORECASE))
                item_cat = 5000 if is_series else 2000
                fb_results.append({
                    "hash":     h,
                    "name":     name,
                    "size":     0,
                    "size_str": "",
                    "seeders":  1,
                    "leechers": 0,
                    "category": item_cat,
                    "cached":   True,
                    "indexer":  "premiumize",
                    "trackers": [],  # fallback trackers added by torznab_results
                })

            # Filter by requested category
            if cat and cat != "0":
                requested = [int(c) for c in cat.split(",") if c.strip().isdigit() and c.strip() != "0"]
                if requested:
                    filtered = [r for r in fb_results if any(
                        r["category"] == rc or r["category"] // 1000 == rc // 1000
                        for rc in requested
                    )]
                    if filtered:
                        fb_results = filtered

            # Fall back to TPB if library is empty or category filter left nothing
            if not fb_results:
                raw = _fetch_tpb("1080p", 20)
                for ti in raw:
                    h       = ti["info_hash"].lower()
                    ti_cat  = tpb_to_newznab(ti.get("category", 0), ti.get("name", ""))
                    fb_results.append({
                        "hash":     h,
                        "name":     ti.get("name", "Unknown"),
                        "size":     fmt_size(ti.get("size", 0)),
                        "size_str": fmt_size_str(ti.get("size", 0)),
                        "seeders":  int(ti.get("seeders", 0) or 0),
                        "leechers": int(ti.get("leechers", 0) or 0),
                        "category": ti_cat,
                        "cached":   False,
                        "indexer":  "TPB",
                    })

            resp = Response(torznab_results(fb_results, ""), mimetype="application/xml")
            for k, v in rh.items():
                resp.headers[k] = v
            return resp

        parsed_q, ps, pe, quality = parse_query(query)
        parsed_s = parsed_s or ps
        parsed_ep = parsed_ep or pe

        results = do_search(parsed_q, parsed_s, parsed_ep, quality, limit=40, pm_key=get_pm_api_key())

        # Filter to cached-only if explicitly enabled in config (default: off)
        # When enabled AND there are cached results, restrict to cached only.
        # We intentionally do NOT fall back silently — if cached_only is on and
        # nothing is cached, return everything so Prowlarr doesn't think the
        # indexer is broken. The UI toggle should be used deliberately.
        if _load_config().get("torznab_cached_only", False):
            cached = [r for r in results if r.get("cached")]
            if cached:
                results = cached
            else:
                app.logger.debug("torznab_cached_only enabled but no cached results — returning all")

        if cat and cat != "0":
            requested = [int(c) for c in cat.split(",") if c.strip().isdigit() and c.strip() != "0"]
            if requested:
                filtered = [r for r in results if any(
                    r["category"] == rc or r["category"] // 1000 == rc // 1000
                    for rc in requested
                )]
                if filtered:
                    results = filtered

        resp = Response(torznab_results(results, q), mimetype="application/xml")
        for k, v in rh.items():
            resp.headers[k] = v
        return resp

    app.logger.warning(f"Unknown torznab function: {t!r}")
    return xml_error(202, f"Unknown function: {t}", rh)

# Web UI — search
@app.route("/api/search", methods=["POST"])
def search():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_pm_api_key()
    query   = data.get("query", "").strip()

    if not api_key:
        return jsonify({"error": "API key required"}), 400
    if not query:
        return jsonify({"error": "Query required"}), 400

    parsed_q, season, episode, quality = parse_query(query)
    results = do_search(parsed_q, season, episode, quality, limit=40, pm_key=api_key)

    return jsonify({
        "results": [{**r, "size": r["size_str"]} for r in results],
        "total":   len(results),
        "source":  "prowlarr" if get_prowlarr_config().get("url") else "tpb",
    })

# Web UI — add to transfer manager (cached → FUSE instantly, uncached → download then FUSE)
@app.route("/api/add", methods=["POST"])
def add():
    data      = request.json or {}
    hash_     = data.get("hash", "").strip().lower()
    name      = data.get("name", "").strip()
    is_cached = data.get("cached", None)  # passed from frontend search results

    if not hash_:
        return jsonify({"error": "hash required"}), 400

    # If frontend already knows it's cached, write the state directly so it
    # appears in the FUSE mount immediately without an extra round-trip to the
    # Premiumize cache-check API.
    # FIX: always persist the real human-readable name so the FUSE directory
    # gets a proper title instead of the raw hash. Also use _set only for the
    # state transition so we don't race with the poller on existing entries.
    if is_cached is True:
        existing = _transfer_manager.get_transfer(hash_)
        if not existing:
            _transfer_manager._set(hash_, name=name or hash_, state="cached",
                                   added_at=time.time())
        else:
            # Always update name if we now have a better one
            updates = {}
            if name and existing.get("name") in (None, "", existing["hash"]):
                updates["name"] = name
            if existing["state"] not in ("cached", "complete"):
                updates["state"] = "cached"
            if updates:
                _transfer_manager._set(hash_, **updates)
        t = _transfer_manager.get_transfer(hash_)
    else:
        t = _transfer_manager.add(hash_, name)

    return jsonify({
        "name":  t.get("name", name) if t else name,
        "hash":  hash_,
        "state": t.get("state") if t else "queued",
    })

# Web UI — direct links for play/download
@app.route("/api/links", methods=["POST"])
def get_links():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_pm_api_key()
    hash_   = data.get("hash", "").strip().lower()
    name    = data.get("name", "").strip()

    if not api_key or not hash_:
        return jsonify({"error": "api_key and hash required"}), 400

    magnet = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
    try:
        r = requests.post(
            PM_DIRECTDL,
            headers={**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"src": magnet}),
            timeout=30,
        )
        r.raise_for_status()
        data_r = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    if data_r.get("status") != "success":
        return jsonify({"error": data_r.get("message", "Could not generate links")}), 400

    content = data_r.get("content", [])
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}

    links = []
    for item in content:
        path = item.get("path", "")
        file_name = path.split("/")[-1] if "/" in path else path
        ext = os.path.splitext(file_name)[1].lower()
        cdn_url = item.get("link", "")
        token = _make_stream_token(hash_, file_name) if cdn_url else ""
        links.append({
            "name":       file_name or path,
            "path":       path,
            "link":       cdn_url,
            "size":       int(float(item.get("size", 0) or 0)),
            "is_video":   ext in video_exts,
            "stream_url": f"/api/stream/{token}?h={hash_}&f={urllib.parse.quote(file_name)}" if token else "",
        })

    if not links:
        return jsonify({"error": "No files found for this magnet"}), 404

    return jsonify({"links": links})

# Streaming proxy — resolves a fresh CDN URL on every request via the
# directdl cache, so links never go stale no matter how long VLC has been open.
@app.route("/api/stream/<token>")
def stream_proxy(token):
    # Token encodes hash and filename as query params, verified by HMAC
    hash_     = request.args.get("h", "").strip().lower()
    filename  = request.args.get("f", "").strip()

    if not hash_ or not filename:
        return jsonify({"error": "Missing parameters"}), 400

    if not _verify_stream_token(token, hash_, filename):
        return jsonify({"error": "Invalid stream token"}), 403

    def _resolve_cdn():
        files = _get_directdl(hash_, filename)
        for f in files:
            if f.get("name") == filename or f.get("path", "").endswith(filename):
                return f.get("link")
        return None

    cdn_url = _resolve_cdn()
    if not cdn_url:
        return jsonify({"error": "File not found"}), 404

    headers = {}
    if "Range" in request.headers:
        headers["Range"] = request.headers["Range"]

    try:
        upstream = requests.get(cdn_url, headers=headers, stream=True, timeout=30)
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    # CDN URL expired — invalidate cache and retry once with fresh URL
    if upstream.status_code in (403, 410):
        with _directdl_lock:
            _directdl_cache.pop(hash_, None)
        cdn_url = _resolve_cdn()
        if not cdn_url:
            return jsonify({"error": "Could not refresh CDN link"}), 502
        try:
            upstream = requests.get(cdn_url, headers=headers, stream=True, timeout=30)
        except requests.RequestException as e:
            return jsonify({"error": str(e)}), 502

    ext = os.path.splitext(filename)[1].lower()
    mime_map = {
        ".mp4": "video/mp4", ".mkv": "video/x-matroska",
        ".avi": "video/x-msvideo", ".mov": "video/quicktime",
        ".m4v": "video/mp4", ".ts": "video/mp2t",
        ".webm": "video/webm", ".wmv": "video/x-ms-wmv",
    }
    content_type = upstream.headers.get("Content-Type") or mime_map.get(ext, "application/octet-stream")

    resp_headers = {
        "Content-Type":  content_type,
        "Accept-Ranges": upstream.headers.get("Accept-Ranges", "bytes"),
    }
    if "Content-Length" in upstream.headers:
        resp_headers["Content-Length"] = upstream.headers["Content-Length"]
    if "Content-Range" in upstream.headers:
        resp_headers["Content-Range"] = upstream.headers["Content-Range"]

    def generate():
        for chunk in upstream.iter_content(chunk_size=1024 * 256):
            yield chunk

    return Response(generate(), status=upstream.status_code, headers=resp_headers)

# List streamable transfers — used by the Library tab
@app.route("/api/transfers")
def list_transfers():
    transfers = _transfer_manager.all_transfers()
    return jsonify({"transfers": [
        {"hash": t["hash"], "name": t["name"] or t["hash"], "state": t["state"]}
        for t in transfers
    ]})

# Remove a transfer
@app.route("/api/remove", methods=["POST"])
def remove_transfer():
    data  = request.json or {}
    hash_ = data.get("hash", "").strip().lower()
    if not hash_:
        return jsonify({"error": "hash required"}), 400
    _transfer_manager.delete(hash_)
    return jsonify({"ok": True})

# ── Backup / Restore ──────────────────────────────────────────────────────────

@app.route("/api/backup", methods=["GET"])
def backup_transfers():
    """Export all cached transfers as a JSON file download."""
    transfers = _transfer_manager.all_transfers()
    cached = [
        {
            "hash":     t["hash"],
            "name":     t.get("name") or t["hash"],
            "category": t.get("category") or "",
            "added_at": t.get("added_at") or 0,
        }
        for t in transfers
        if t.get("state") in ("cached", "complete")
    ]
    ts = int(time.time())
    resp = Response(
        json.dumps(cached, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="premiumize-backup-{ts}.json"'},
    )
    return resp

@app.route("/api/restore", methods=["POST"])
def restore_transfers():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    try:
        data = json.load(request.files["file"])
    except Exception as e:
        return jsonify({"error": f"Invalid JSON: {e}"}), 400

    if not isinstance(data, list):
        return jsonify({"error": "Expected a JSON array"}), 400

    def generate():
        imported = 0
        skipped  = 0
        errors   = 0
        total    = len(data)

        # Pre-validate all hashes and names first
        items = []
        for item in data:
            hash_ = (item.get("hash") or "").strip().lower()
            if not hash_ or not re.fullmatch(r'[0-9a-f]{40}', hash_):
                continue
            name = (item.get("name") or item.get("filename") or hash_).strip()
            if "." in os.path.basename(name):
                base = os.path.splitext(name)[0]
                if base:
                    name = base
            items.append({
                "hash":     hash_,
                "name":     name,
                "category": item.get("category", "").strip(),
                "added_at": float(item.get("added_at") or time.time()),
            })

        errors = len(data) - len(items)  # invalid hash entries

        # Batch cache-check all hashes against Premiumize (100 per call)
        cached_set = set()
        batch_size = 100
        yield json.dumps({"type": "progress", "current": 0, "total": total,
                          "status": "checking", "name": "Checking Premiumize cache…"}) + "\n"
        for b in range(0, len(items), batch_size):
            batch = items[b:b + batch_size]
            try:
                result = _transfer_manager._cache_fn([{"info_hash": x["hash"]} for x in batch])
                for hash_, is_cached in result.items():
                    if is_cached:
                        cached_set.add(hash_)
            except Exception as e:
                app.logger.warning(f"Cache check batch error: {e}")
            time.sleep(0.2)  # small pause between batch API calls

        for i, item in enumerate(items):
            hash_    = item["hash"]
            name     = item["name"]
            category = item["category"]
            added_at = item["added_at"]

            try:
                existing = _transfer_manager.get_transfer(hash_)
                if existing:
                    if existing.get("name") in (None, "", hash_) and name != hash_:
                        _transfer_manager._set(hash_, name=name)
                    skipped += 1
                    yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                      "status": "skipped", "name": name}) + "\n"
                    continue

                if hash_ not in cached_set:
                    skipped += 1
                    yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                      "status": "skipped", "name": f"{name} (not on Premiumize)"}) + "\n"
                    continue

                _transfer_manager._set(hash_, name=name, state="cached",
                                       category=category, added_at=added_at)
                imported += 1
                yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                  "status": "imported", "name": name}) + "\n"
                time.sleep(0.05)

            except Exception as e:
                errors += 1
                yield json.dumps({"type": "progress", "current": i+1, "total": total,
                                  "status": "error", "name": name}) + "\n"
                app.logger.warning(f"Restore error: {e}")

        app.logger.info(f"Restore: {imported} imported, {skipped} skipped, {errors} errors")
        yield json.dumps({"type": "done", "imported": imported,
                          "skipped": skipped, "errors": errors, "total": total}) + "\n"

    return Response(generate(), mimetype="application/x-ndjson",
                    headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"})



# Transfer status polling
@app.route("/api/transfer/status", methods=["POST"])
def transfer_status():
    data        = request.json or {}
    api_key     = data.get("api_key", "").strip() or get_pm_api_key()
    transfer_id = data.get("transfer_id", "").strip()

    if not api_key or not transfer_id:
        return jsonify({"error": "api_key and transfer_id required"}), 400

    try:
        r = requests.get(PM_TRANSFER_LIST, headers=pm_headers(api_key), timeout=15)
        r.raise_for_status()
        data_r = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    if data_r.get("status") != "success":
        return jsonify({"error": data_r.get("message", "Failed to get transfer list")}), 400

    for t in data_r.get("transfers", []):
        if str(t.get("id")) == str(transfer_id):
            return jsonify({
                "status":   t.get("status"),
                "progress": t.get("progress", 0),
                "message":  t.get("message", ""),
                "file_id":  t.get("file_id"),
            })

    return jsonify({"error": "Transfer not found"}), 404

# Frontend config — tells the UI what's already set server-side
@app.route("/api/config")
def get_config():
    return jsonify({
        "has_pm_key":       bool(get_pm_api_key()),
        "has_prowlarr_env": bool(PROWLARR_URL or PROWLARR_KEY),
    })

@app.route("/api/config/pm_key", methods=["POST"])
def save_pm_key():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip()
    if not api_key:
        return jsonify({"error": "api_key required"}), 400
    # Verify it works before saving
    try:
        r = requests.get(PM_ACCOUNT, headers=pm_headers(api_key), timeout=10)
        r.raise_for_status()
        d = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502
    if d.get("status") != "success":
        return jsonify({"error": d.get("message", "Authentication failed")}), 401
    save_pm_api_key(api_key)
    # Flush the directdl cache so FUSE re-fetches with the new key
    with _directdl_lock:
        _directdl_cache.clear()
    app.logger.info("PM API key saved and directdl cache flushed")
    return jsonify({"ok": True})

# Account info
@app.route("/api/account", methods=["POST"])
def account():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_pm_api_key()
    if not api_key:
        return jsonify({"error": "API key required"}), 400
    try:
        r = requests.get(PM_ACCOUNT, headers=pm_headers(api_key), timeout=10)
        r.raise_for_status()
        d = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502
    if d.get("status") != "success":
        return jsonify({"error": d.get("message", "Authentication failed")}), 401
    premium_until = d.get("premium_until")
    is_premium = bool(premium_until and premium_until > datetime.now(timezone.utc).timestamp())
    return jsonify({
        "customer_id":   d.get("customer_id"),
        "is_premium":    is_premium,
        "premium_until": premium_until,
        "limit_used":    d.get("limit_used", 0),
    })

# ── Prowlarr config endpoints ─────────────────────────────────────────────────

@app.route("/api/torznab/cached-only", methods=["GET"])
def get_torznab_cached_only():
    return jsonify({"cached_only": _load_config().get("torznab_cached_only", False)})

@app.route("/api/torznab/cached-only", methods=["POST"])
def set_torznab_cached_only():
    data = request.json or {}
    val  = bool(data.get("cached_only", True))
    cfg  = _load_config()
    cfg["torznab_cached_only"] = val
    _save_config(cfg)
    return jsonify({"ok": True, "cached_only": val})

@app.route("/api/prowlarr/config", methods=["GET"])
def prowlarr_config_get():
    cfg = get_prowlarr_config()
    return jsonify({
        "url":        cfg.get("url", ""),
        "api_key":    cfg.get("api_key", ""),
        "configured": bool(cfg.get("url") and cfg.get("api_key")),
        "from_env":   cfg.get("from_env", False),
    })

@app.route("/api/prowlarr/config", methods=["POST"])
def prowlarr_config_save():
    data    = request.json or {}
    url     = data.get("url", "").strip()
    api_key = data.get("api_key", "").strip()

    if not url or not api_key:
        return jsonify({"error": "url and api_key required"}), 400

    # Test the connection
    try:
        r = requests.get(
            f"{url.rstrip('/')}/api/v1/indexer",
            headers={"X-Api-Key": api_key},
            timeout=10,
        )
        r.raise_for_status()
        indexers = r.json()
    except requests.RequestException as e:
        return jsonify({"error": f"Could not connect to Prowlarr: {e}"}), 400

    save_prowlarr_config(url, api_key)

    torrent_indexers = [i for i in indexers if i.get("protocol") == "torrent"]
    return jsonify({
        "ok": True,
        "indexer_count": len(torrent_indexers),
        "indexers": [{"id": i["id"], "name": i["name"]} for i in torrent_indexers],
    })

@app.route("/api/prowlarr/config", methods=["DELETE"])
def prowlarr_config_delete():
    cfg = _load_config()
    cfg.pop("prowlarr", None)
    _save_config(cfg)
    return jsonify({"ok": True})

# ── Mount Configuration endpoints ────────────────────────────────────────────

def _parse_size(val: str, default: int) -> int:
    """Parse human size string like '8MB', '500MB', '30GB', '1TB' to bytes."""
    if not val:
        return default
    val = val.strip().upper().replace(' ', '')
    units = {'B': 1, 'KB': 1024, 'MB': 1024**2, 'GB': 1024**3, 'TB': 1024**4}
    for suffix, mult in sorted(units.items(), key=lambda x: -len(x[0])):
        if val.endswith(suffix):
            try:
                return int(float(val[:-len(suffix)]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

def _parse_duration(val: str, default: int) -> int:
    """Parse duration string like '24h', '20m', '10s', '1d' to seconds."""
    if not val:
        return default
    val = val.strip().lower()
    units = {'d': 86400, 'h': 3600, 'm': 60, 's': 1}
    for suffix, mult in units.items():
        if val.endswith(suffix):
            try:
                return int(float(val[:-1]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

def _fmt_size(b: int) -> str:
    for unit in ['TB', 'GB', 'MB', 'KB']:
        div = {'TB': 1024**4, 'GB': 1024**3, 'MB': 1024**2, 'KB': 1024}[unit]
        if b >= div:
            return f"{b/div:.1f} {unit}"
    return f"{b} B"

def _disk_used_bytes(path: str) -> int:
    """Return total bytes used by all files under path."""
    total = 0
    try:
        for dirpath, _, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(dirpath, f))
                except OSError:
                    pass
    except OSError:
        pass
    return total

def _enforce_disk_cache(cache_dir: str, max_bytes: int):
    """Delete oldest cache blocks until total disk usage is under max_bytes."""
    if not cache_dir or max_bytes <= 0:
        return
    # Collect all .bin files with their mtime
    files = []
    try:
        for dirpath, _, filenames in os.walk(cache_dir):
            for f in filenames:
                if f.endswith('.bin'):
                    p = os.path.join(dirpath, f)
                    try:
                        files.append((os.path.getmtime(p), os.path.getsize(p), p))
                    except OSError:
                        pass
    except OSError:
        return
    files.sort()  # oldest first
    total = sum(s for _, s, _ in files)
    for mtime, size, path in files:
        if total <= max_bytes:
            break
        try:
            os.remove(path)
            total -= size
        except OSError:
            pass

def _expire_disk_cache(cache_dir: str, max_age_seconds: int):
    """Remove cache blocks older than max_age_seconds."""
    if not cache_dir or max_age_seconds <= 0:
        return
    cutoff = time.time() - max_age_seconds
    try:
        for dirpath, _, filenames in os.walk(cache_dir):
            for f in filenames:
                if f.endswith('.bin'):
                    p = os.path.join(dirpath, f)
                    try:
                        if os.path.getmtime(p) < cutoff:
                            os.remove(p)
                    except OSError:
                        pass
    except OSError:
        pass

def _get_fuse_settings() -> dict:
    saved = _load_config().get("fuse", {})
    return {
        "cache_dir":       saved.get("cache_dir",       os.environ.get("FUSE_CACHE_DIR", "/docker/premiumize-web/cache")),
        "disk_cache_size": saved.get("disk_cache_size", "30GB"),
        "buffer_memory":   saved.get("buffer_memory",   "512MB"),
        "cache_expiry":    saved.get("cache_expiry",    "24h"),
        "cache_cleanup":   saved.get("cache_cleanup",   "20m"),
        "chunk_size":      saved.get("chunk_size",      "8MB"),
        "read_ahead":      saved.get("read_ahead",      "500MB"),
        "daemon_timeout":  saved.get("daemon_timeout",  "10s"),
        "uid":             saved.get("uid",             None),
        "gid":             saved.get("gid",             None),
        "umask":           saved.get("umask",           "022"),
        "prefetch":        saved.get("prefetch",        True),
        "video_only":      saved.get("video_only",      True),
        "enable_4k_folders": saved.get("enable_4k_folders", False),
    }

def _save_fuse_settings(settings: dict):
    cfg = _load_config()
    cfg["fuse"] = settings
    _save_config(cfg)

def _apply_fuse_settings(s: dict):
    """Apply settings live to the running fuse_mount module."""
    import fuse_mount as fm
    chunk_bytes  = _parse_size(s.get("chunk_size",    "8MB"),   8 * 1024 * 1024)
    buffer_bytes = _parse_size(s.get("buffer_memory", "512MB"), 512 * 1024 * 1024)
    cache_dir    = s.get("cache_dir", "") or ""

    # Number of in-memory blocks = buffer / chunk
    cache_blocks = max(4, buffer_bytes // chunk_bytes) if chunk_bytes else 16

    fm.BLOCK_SIZE        = chunk_bytes
    fm._RA_MB            = chunk_bytes // (1024 * 1024)
    fm._CACHE_N          = cache_blocks
    fm._PREFETCH_ENABLED = bool(s.get("prefetch", True))
    fm._CACHE_DIR        = cache_dir
    fm._VIDEO_ONLY       = bool(s.get("video_only", True))
    fm._4K_FOLDERS_ENABLED = bool(s.get("enable_4k_folders", False))
    # Invalidate the name map immediately so the new folder structure
    # takes effect on the next FUSE readdir without waiting for TTL expiry
    try:
        from fuse_mount import _pfs
        if _pfs is not None:
            _pfs._invalidate_name_map()
    except Exception:
        pass
    fm._READ_AHEAD_BYTES = _parse_size(s.get("read_ahead", "500MB"), 500 * 1024 * 1024)
    fm._block_cache      = fm._BlockCache(cache_blocks, cache_dir)

    # UID/GID/umask — apply to os module so getattr returns correct values
    uid = s.get("uid")
    gid = s.get("gid")
    if uid is not None:
        try:
            os.setuid(int(uid))
        except (PermissionError, AttributeError):
            pass
    if gid is not None:
        try:
            os.setgid(int(gid))
        except (PermissionError, AttributeError):
            pass
    umask = s.get("umask", "022")
    try:
        os.umask(int(umask, 8))
    except (ValueError, TypeError):
        pass

# Background cache cleanup thread
_cleanup_stop  = threading.Event()
_cleanup_thread = None

def _start_cache_cleanup():
    global _cleanup_thread
    if _cleanup_thread and _cleanup_thread.is_alive():
        _cleanup_stop.set()
        _cleanup_thread.join(timeout=2)
    _cleanup_stop.clear()

    def _loop():
        while not _cleanup_stop.wait(timeout=1):
            s          = _get_fuse_settings()
            interval   = _parse_duration(s.get("cache_cleanup", "20m"), 1200)
            cache_dir  = s.get("cache_dir", "")
            max_bytes  = _parse_size(s.get("disk_cache_size", "30GB"), 30 * 1024**3)
            max_age    = _parse_duration(s.get("cache_expiry", "24h"), 86400)
            _cleanup_stop.wait(timeout=interval)
            if _cleanup_stop.is_set():
                break
            if cache_dir:
                _expire_disk_cache(cache_dir, max_age)
                _enforce_disk_cache(cache_dir, max_bytes)

    _cleanup_thread = threading.Thread(target=_loop, daemon=True)
    _cleanup_thread.start()

_start_cache_cleanup()

@app.route("/api/fuse/settings", methods=["GET"])
def fuse_settings_get():
    import fuse_mount as fm
    s = _get_fuse_settings()
    cache_dir   = s.get("cache_dir", "")
    disk_used   = _disk_used_bytes(cache_dir) if cache_dir else 0
    buffer_bytes = _parse_size(s.get("buffer_memory", "512MB"), 512 * 1024 * 1024)
    return jsonify({
        **s,
        "live_chunk_size":  _fmt_size(fm.BLOCK_SIZE),
        "live_buffer_mb":   fm.BLOCK_SIZE * fm._CACHE_N // (1024 * 1024),
        "live_disk_used":   _fmt_size(disk_used),
        "live_prefetch":    fm._PREFETCH_ENABLED,
        "cached_blocks":    fm._block_cache.size,
    })

@app.route("/api/fuse/settings", methods=["POST"])
def fuse_settings_save():
    data = request.json or {}
    s = {
        "cache_dir":       data.get("cache_dir",       "").strip(),
        "disk_cache_size": data.get("disk_cache_size", "30GB").strip(),
        "buffer_memory":   data.get("buffer_memory",   "512MB").strip(),
        "cache_expiry":    data.get("cache_expiry",    "24h").strip(),
        "cache_cleanup":   data.get("cache_cleanup",   "20m").strip(),
        "chunk_size":      data.get("chunk_size",      "8MB").strip(),
        "read_ahead":      data.get("read_ahead",      "500MB").strip(),
        "daemon_timeout":  data.get("daemon_timeout",  "10s").strip(),
        "uid":             data.get("uid"),
        "gid":             data.get("gid"),
        "umask":           data.get("umask",           "022").strip(),
        "prefetch":        bool(data.get("prefetch",        True)),
        "video_only":      bool(data.get("video_only",      True)),
        "enable_4k_folders": bool(data.get("enable_4k_folders", False)),
    }
    _save_fuse_settings(s)
    _apply_fuse_settings(s)
    _start_cache_cleanup()  # restart with new interval
    app.logger.info(f"Mount config updated: chunk={s['chunk_size']} buffer={s['buffer_memory']} "
                    f"disk={s['disk_cache_size']} expiry={s['cache_expiry']}")
    return jsonify({"ok": True})

@app.route("/api/fuse/cache/clear", methods=["POST"])
def fuse_cache_clear():
    import fuse_mount as fm
    import shutil
    fm._block_cache = fm._BlockCache(fm._CACHE_N, fm._CACHE_DIR)
    cache_dir = fm._CACHE_DIR
    if cache_dir and os.path.isdir(cache_dir):
        try:
            shutil.rmtree(cache_dir)
            os.makedirs(cache_dir, exist_ok=True)
        except OSError as e:
            return jsonify({"error": str(e)}), 500
    return jsonify({"ok": True, "message": "Cache cleared"})

@app.route("/api/prowlarr/indexers", methods=["GET"])
def prowlarr_indexers():
    cfg = get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"):
        return jsonify({"error": "Prowlarr not configured"}), 400
    try:
        r = requests.get(
            f"{cfg['url']}/api/v1/indexer",
            headers={"X-Api-Key": cfg["api_key"]},
            timeout=10,
        )
        r.raise_for_status()
        indexers = r.json()
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    torrent_indexers = [i for i in indexers if i.get("protocol") == "torrent"]
    return jsonify({
        "indexers": [{"id": i["id"], "name": i["name"], "enabled": i.get("enableAutomaticSearch", True)} for i in torrent_indexers]
    })

MOUNTPOINT = os.environ.get("FUSE_MOUNTPOINT", "/docker/premiumize-web/mnt")

# ── directdl helpers ──────────────────────────────────────────────────────────

def _directdl_for_manager_raw(hash_: str, name: str) -> list:
    """Raw directdl call — always hits Premiumize API. Use _get_directdl instead."""
    api_key = get_pm_api_key()
    if not api_key:
        return []
    magnet     = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}
    try:
        r = requests.post(
            PM_DIRECTDL,
            headers={**pm_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"src": magnet}),
            timeout=30,
        )
        r.raise_for_status()
        data_r = r.json()
    except Exception:
        return []
    if data_r.get("status") != "success":
        return []
    files = []
    for item in data_r.get("content", []):
        path      = item.get("path", "")
        file_name = path.split("/")[-1] if "/" in path else path
        ext       = os.path.splitext(file_name)[1].lower()
        cdn_url   = item.get("link", "")
        token     = _make_stream_token(hash_, file_name) if cdn_url else ""
        files.append({
            "name":       file_name or path,
            "path":       path,
            "link":       cdn_url,
            "size":       int(float(item.get("size", 0) or 0)),
            "is_video":   ext in video_exts,
            "stream_url": f"/api/stream/{token}?h={hash_}&f={urllib.parse.quote(file_name)}" if token else "",
        })
    return files

def _directdl_for_manager(hash_: str, name: str, force: bool = False) -> list:
    """Cached wrapper — used by transfer manager and FUSE mount."""
    return _get_directdl(hash_, name, force=force)

# ── transfer manager ──────────────────────────────────────────────────────────

from transfer_manager import TransferManager, SymlinkManager

_transfer_manager = TransferManager(
    pm_api_key_fn  = lambda: get_pm_api_key(),
    directdl_fn    = _directdl_for_manager,
    cache_check_fn = lambda torrents: check_cache_pm(get_pm_api_key(), torrents),
)

# ── Symlink manager ───────────────────────────────────────────────────────────

_symlink_manager = SymlinkManager(_transfer_manager)

# Run a reconciliation sync on startup in a background thread so we do not
# block the Flask startup while the FUSE mount is still initialising.
def _sync_symlinks_delayed(delay: int = 15):
    """Wait for FUSE to be ready then sync symlinks."""
    import threading, time
    def _do():
        time.sleep(delay)
        try:
            _symlink_manager.sync(_transfer_manager)
        except Exception as e:
            app.logger.warning(f"Startup symlink sync failed: {e}")
    threading.Thread(target=_do, daemon=True).start()

_sync_symlinks_delayed()

# ── qBittorrent mock blueprint ────────────────────────────────────────────────

import qbt_mock
qbt_mock.init(_transfer_manager)
qbt_mock.MOUNTPOINT = MOUNTPOINT
app.register_blueprint(qbt_mock.qbt)

# ── FUSE mount ────────────────────────────────────────────────────────────────

import signal
import subprocess

def _unmount_fuse():
    """Unmount cleanly — try fusermount first, fall back to lazy umount."""
    try:
        subprocess.run(["fusermount", "-uz", MOUNTPOINT], check=False, capture_output=True)
    except FileNotFoundError:
        pass
    subprocess.run(["umount", "-l", MOUNTPOINT], check=False, capture_output=True)
    app.logger.info(f"FUSE unmounted {MOUNTPOINT}")


def _clear_stale_mount():
    """
    Tear down any stale/broken FUSE mount left over from a previous run.
    Handles both the normal 'mountpoint exists' case and the broken
    'Transport endpoint is not connected' case.
    """
    for attempt in range(15):
        # Check if still mounted
        r = subprocess.run(["mountpoint", "-q", MOUNTPOINT], capture_output=True)
        if r.returncode != 0:
            # Double-check for broken transport endpoint
            ls = subprocess.run(["ls", MOUNTPOINT], capture_output=True, text=True)
            if "Transport endpoint" not in (ls.stderr or ""):
                return  # clean
        print(f"[FUSE] clearing stale mount (attempt {attempt + 1})...", flush=True)
        subprocess.run(["fusermount", "-uz", MOUNTPOINT], capture_output=True)
        subprocess.run(["umount", "-l",   MOUNTPOINT], capture_output=True)
        time.sleep(0.3)
    print("[FUSE] WARNING: could not fully clear stale mount", flush=True)


_fuse_shutdown = threading.Event()

def _start_fuse():
    import traceback
    import signal as _signal
    try:
        from fuse_mount import mount, FUSE_AVAILABLE
    except Exception as e:
        print(f"[FUSE] import failed: {e}", flush=True)
        traceback.print_exc()
        return

    if not FUSE_AVAILABLE:
        print("[FUSE] fusepy not installed — disabled", flush=True)
        return

    # Block signals in this thread — Flask's main thread handles them.
    try:
        _signal.pthread_sigmask(_signal.SIG_BLOCK,
                                {_signal.SIGTERM, _signal.SIGINT, _signal.SIGHUP})
    except (AttributeError, OSError):
        pass

    consecutive_failures = 0
    while not _fuse_shutdown.is_set():
        _clear_stale_mount()
        print(f"[FUSE] mounting at {MOUNTPOINT}", flush=True)
        try:
            mount(MOUNTPOINT, _transfer_manager, foreground=True)
            if _fuse_shutdown.is_set():
                print("[FUSE] mount exited — shutdown requested, not remounting", flush=True)
                break
            print("[FUSE] mount exited — remounting in 2s...", flush=True)
            consecutive_failures = 0
        except Exception as e:
            consecutive_failures += 1
            print(f"[FUSE] mount failed ({consecutive_failures}): {e}", flush=True)
            traceback.print_exc()

        wait = min(2 * consecutive_failures, 30)
        _fuse_shutdown.wait(timeout=max(wait, 2))

    print("[FUSE] thread exited", flush=True)


def _shutdown(signum, frame):
    print("[shutdown] signal received — unmounting FUSE gracefully", flush=True)
    _fuse_shutdown.set()
    # Give fusermount a chance to exit cleanly first
    subprocess.run(["fusermount", "-uz", MOUNTPOINT], capture_output=True)
    time.sleep(0.5)
    # Force if still mounted
    subprocess.run(["umount", "-l", MOUNTPOINT], capture_output=True)
    print("[shutdown] FUSE unmounted", flush=True)
    raise SystemExit(0)

# Register signal handlers so FUSE is unmounted on SIGTERM (docker stop) and SIGINT
signal.signal(signal.SIGTERM, _shutdown)
signal.signal(signal.SIGINT, _shutdown)

# ── Sync API ──────────────────────────────────────────────────────────────────

def _get_sync_config() -> dict:
    cfg = _load_config().get("sync", {})
    return {"instances": cfg.get("instances", [])}

@app.route("/api/sync/config", methods=["GET"])
def sync_config_get():
    return jsonify(_get_sync_config())

@app.route("/api/sync/config", methods=["POST"])
def sync_config_save():
    data = request.get_json(force=True) or {}
    cfg  = _load_config()
    instances = data.get("instances", [])
    # Sanitise
    for inst in instances:
        inst["url"] = (inst.get("url") or "").rstrip("/")
    cfg["sync"] = {"instances": instances}
    _save_config(cfg)
    return jsonify({"ok": True})

@app.route("/api/sync/run", methods=["POST"])
def sync_run():
    """
    SSE stream that performs a full or partial sync between the FUSE mount
    and a Radarr or Sonarr instance.

    Full sync:
      1. Get all items from the FUSE folder
      2. Clear the Arr library (delete all movies/series)
      3. For each FUSE item: create a fake file and add to Arr via API

    Partial sync:
      1. Get all items from the FUSE folder
      2. Get existing Arr library
      3. For items in FUSE but not in Arr: create fake file and add
    """
    import requests as _req
    from fuse_mount import build_name_map, _category_subdir
    from qbt_mock import _make_fake_file, _pick_fake_filename, _safe_name, _dl_dir, DOWNLOADS_ROOT as _DL_ROOT

    data   = request.get_json(force=True) or {}
    folder = data.get("folder", "movies")          # movies | movies4k | series | tv4k
    arr    = data.get("arr", "radarr")             # radarr | sonarr
    mode   = data.get("mode", "partial")           # full | partial

    # Accept url/key directly from the request (multi-instance support)
    base_url = data.get("arr_url", "").rstrip("/")
    api_key  = data.get("arr_key", "")
    arr_name = data.get("arr_name", arr.title())

    def _headers():
        return {"X-Api-Key": api_key, "Content-Type": "application/json"}

    def sse(log=None, pct=None, status=None, done=False, error=False):
        obj = {}
        if log    is not None: obj["log"]    = log
        if pct    is not None: obj["pct"]    = pct
        if status is not None: obj["status"] = status
        if done:
            obj["done"]  = True
            obj["error"] = error
        return f"data: {json.dumps(obj)}\n\n"

    def generate():
        import math, shutil

        if not base_url or not api_key:
            yield sse(log="❌ Missing URL or API key — configure connection settings first.", done=True, error=True)
            return

        # ── Step 1: scan FUSE folder ──────────────────────────────────────────
        yield sse(log=f"Scanning FUSE mount: /{folder}", pct=2, status="Scanning FUSE…")
        name_map = build_name_map(_transfer_manager)
        fuse_items = {}   # folder_name → transfer dict
        for key, hash_ in name_map.items():
            parts = key.split("/", 1)
            if parts[0] != folder or len(parts) < 2:
                continue
            t = _transfer_manager.get_transfer(hash_)
            if t:
                fuse_items[parts[1]] = t

        if not fuse_items:
            yield sse(log=f"No items found in /{folder}. Nothing to sync.", done=True)
            return

        yield sse(log=f"Found {len(fuse_items)} items in /{folder}", pct=5)

        # ── Step 2: connect to Arr ────────────────────────────────────────────
        yield sse(log=f"Connecting to {arr.title()} at {base_url}…", status="Connecting…")
        try:
            ping = _req.get(f"{base_url}/api/v3/system/status", headers=_headers(), timeout=8)
            if ping.status_code not in (200, 201):
                yield sse(log=f"❌ {arr.title()} returned HTTP {ping.status_code}. Check URL and API key.", done=True, error=True)
                return
            arr_version = ping.json().get("version", "?")
            yield sse(log=f"Connected to {arr.title()} v{arr_version}", pct=8)
        except Exception as e:
            yield sse(log=f"❌ Cannot reach {arr.title()}: {e}", done=True, error=True)
            return

        # ── Step 3: get root folder ───────────────────────────────────────────
        try:
            rf = _req.get(f"{base_url}/api/v3/rootFolder", headers=_headers(), timeout=8)
            root_folders = rf.json()
            root_path = root_folders[0]["path"].rstrip("/") if root_folders else "/movies"
            yield sse(log=f"Root folder: {root_path}")
        except Exception as e:
            yield sse(log=f"⚠ Could not get root folder: {e} — using /movies")
            root_path = "/movies"

        # ── Step 4: get quality profile ───────────────────────────────────────
        try:
            qp = _req.get(f"{base_url}/api/v3/qualityProfile", headers=_headers(), timeout=8)
            profiles = qp.json()
            quality_id = profiles[0]["id"] if profiles else 1
            yield sse(log=f"Quality profile: {profiles[0]['name'] if profiles else 'default'}")
        except Exception as e:
            yield sse(log=f"⚠ Could not get quality profiles: {e}")
            quality_id = 1

        # ── Step 5: full sync — clear library ────────────────────────────────
        existing_titles = set()
        if mode == "full":
            yield sse(log="Full sync: clearing existing library…", pct=10, status="Clearing library…")
            try:
                endpoint = "movie" if arr == "radarr" else "series"
                existing = _req.get(f"{base_url}/api/v3/{endpoint}", headers=_headers(), timeout=15).json()
                total_del = len(existing)
                for i, item in enumerate(existing):
                    try:
                        _req.delete(
                            f"{base_url}/api/v3/{endpoint}/{item['id']}",
                            headers=_headers(),
                            params={"deleteFiles": "false", "addImportExclusion": "false"},
                            timeout=10
                        )
                    except Exception:
                        pass
                    pct = 10 + int(20 * (i + 1) / max(total_del, 1))
                    if i % 10 == 0:
                        yield sse(log=f"  Deleted {i+1}/{total_del}…", pct=pct)
                yield sse(log=f"Cleared {total_del} items from {arr.title()} library.", pct=30)
            except Exception as e:
                yield sse(log=f"⚠ Error clearing library: {e}")
        else:
            # Partial: get existing titles to skip
            yield sse(log="Partial sync: fetching existing library…", pct=10, status="Checking library…")
            try:
                endpoint = "movie" if arr == "radarr" else "series"
                existing = _req.get(f"{base_url}/api/v3/{endpoint}", headers=_headers(), timeout=15).json()
                existing_titles = {
                    (item.get("title") or item.get("sortTitle") or "").lower()
                    for item in existing
                }
                yield sse(log=f"Found {len(existing_titles)} existing items in {arr.title()}.", pct=30)
            except Exception as e:
                yield sse(log=f"⚠ Error fetching library: {e}")

        # ── Step 6: add items ─────────────────────────────────────────────────
        yield sse(log=f"Adding {len(fuse_items)} items…", pct=32, status="Adding items…")
        added, skipped, errors = 0, 0, 0
        total = len(fuse_items)

        for i, (item_name, transfer) in enumerate(fuse_items.items()):
            pct = 32 + int(60 * (i + 1) / max(total, 1))
            t_name = transfer.get("name") or item_name
            t_cat  = transfer.get("category") or ""

            # Partial sync: skip if already in Arr
            if mode == "partial" and item_name.lower() in existing_titles:
                skipped += 1
                continue

            # Create fake file so Arr can import it
            try:
                files = _transfer_manager.get_files(transfer["hash"]) or []
            except Exception:
                files = []
            fake_fn = _pick_fake_filename(t_name, files)
            fake_category = t_cat or ("radarr" if arr == "radarr" else "tv-sonarr")
            try:
                fake_path = _make_fake_file(fake_category, _safe_name(t_name), fake_fn, files)
            except Exception as e:
                yield sse(log=f"  ⚠ Could not create fake file for {item_name}: {e}")
                errors += 1
                continue

            # Add to Arr via API — search for it by title
            # We use the title from the folder name (cleaned up)
            import re as _re
            clean_title = _re.sub(
                r'\b(19|20)\d{2}\b.*', '', item_name
            ).replace('.', ' ').strip()

            try:
                if arr == "radarr":
                    # Search Radarr for the movie
                    search = _req.get(
                        f"{base_url}/api/v3/movie/lookup",
                        headers=_headers(),
                        params={"term": clean_title},
                        timeout=10
                    )
                    results = search.json()
                    if not results:
                        yield sse(log=f"  ⚠ Not found in TMDB: {clean_title}")
                        errors += 1
                        continue
                    movie = results[0]
                    movie["qualityProfileId"] = quality_id
                    movie["rootFolderPath"]   = root_path
                    movie["monitored"]        = True
                    movie["addOptions"]       = {"searchForMovie": False}
                    resp = _req.post(f"{base_url}/api/v3/movie", headers=_headers(), json=movie, timeout=10)
                    if resp.status_code in (200, 201):
                        added += 1
                        yield sse(log=f"  ✓ {clean_title}", pct=pct)
                    elif resp.status_code == 400 and "already" in resp.text.lower():
                        skipped += 1
                    else:
                        yield sse(log=f"  ⚠ {clean_title}: HTTP {resp.status_code}")
                        errors += 1
                else:
                    # Sonarr lookup
                    search = _req.get(
                        f"{base_url}/api/v3/series/lookup",
                        headers=_headers(),
                        params={"term": clean_title},
                        timeout=10
                    )
                    results = search.json()
                    if not results:
                        yield sse(log=f"  ⚠ Not found in TVDB: {clean_title}")
                        errors += 1
                        continue
                    series = results[0]
                    series["qualityProfileId"]  = quality_id
                    series["rootFolderPath"]    = root_path
                    series["monitored"]         = True
                    series["seasonFolder"]      = True
                    series["addOptions"]        = {"searchForMissingEpisodes": False, "monitor": "all"}
                    resp = _req.post(f"{base_url}/api/v3/series", headers=_headers(), json=series, timeout=10)
                    if resp.status_code in (200, 201):
                        added += 1
                        yield sse(log=f"  ✓ {clean_title}", pct=pct)
                    elif resp.status_code == 400 and "already" in resp.text.lower():
                        skipped += 1
                    else:
                        yield sse(log=f"  ⚠ {clean_title}: HTTP {resp.status_code}")
                        errors += 1
            except Exception as e:
                yield sse(log=f"  ❌ {clean_title}: {e}")
                errors += 1

        # ── Step 7: trigger Arr rescan ────────────────────────────────────────
        yield sse(log="Triggering library rescan…", pct=95, status="Rescanning…")
        try:
            cmd = "RescanMovie" if arr == "radarr" else "RescanSeries"
            _req.post(f"{base_url}/api/v3/command", headers=_headers(),
                      json={"name": cmd}, timeout=10)
        except Exception:
            pass

        yield sse(
            log=f"\n✅ Sync complete. Added: {added}  Skipped: {skipped}  Errors: {errors}",
            pct=100, status="Done", done=True
        )

    from flask import stream_with_context
    return app.response_class(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"}
    )


if os.environ.get("ENABLE_FUSE", "true").lower() == "true":
    # Apply any saved mount config before starting FUSE
    _apply_fuse_settings(_get_fuse_settings())
    t = threading.Thread(target=_start_fuse, daemon=False)
    t.start()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)

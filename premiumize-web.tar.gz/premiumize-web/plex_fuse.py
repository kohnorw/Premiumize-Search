"""
Plex-specific FUSE mount for Premiumize.

Mounts at /docker/premiumize-web/plex — point Plex at this, NOT the main mount.

Two modes, toggled by a single global flag (_cdn_unlocked):

  _cdn_unlocked = False  → serve stub MKV bytes (initial Plex scan/import)
  _cdn_unlocked = True   → serve real CDN bytes (after "Import Complete" clicked)

Flow:
  1. Container starts → _cdn_unlocked = False
  2. Plex scans, reads stub bytes, imports items to its library
  3. User clicks "Import Complete" in Settings → unlock() is called
  4. _cdn_unlocked = True, stat cache cleared
  5. All subsequent reads serve real CDN bytes — playback works

Configure Plex container:
    volumes:
      - /docker/premiumize-web/plex:/docker/premiumize-web/plex:rshared
"""

import errno
import logging
import os
import re
import stat
import threading
import time
from collections import OrderedDict

import requests

log = logging.getLogger(__name__)

# ── Global unlock flag ────────────────────────────────────────────────────────
# False = serve stubs, True = serve CDN bytes.
# Set once by unlock() when the user clicks "Import Complete".
_cdn_unlocked = False
_unlock_lock  = threading.Lock()

def unlock():
    """Switch from stub mode to CDN mode. Called by the Import Complete button."""
    global _cdn_unlocked
    with _unlock_lock:
        _cdn_unlocked = True
    # Clear stat cache so FUSE picks up the new mode immediately
    if _pfs is not None:
        _pfs._stat_invalidate_all()
    log.info("[plex_fuse] CDN unlocked — serving real bytes")

def is_unlocked() -> bool:
    return _cdn_unlocked

# ── Tuning ────────────────────────────────────────────────────────────────────

_BLOCK_MB  = int(os.environ.get("PLEX_FUSE_BLOCK_MB", "8"))
_CACHE_N   = int(os.environ.get("PLEX_FUSE_CACHE_N",  "32"))
BLOCK_SIZE = _BLOCK_MB * 1024 * 1024

READ_TIMEOUT      = int(os.environ.get("PLEX_FUSE_READ_TIMEOUT", "30"))
READ_MAX_ATTEMPTS = 4
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 4.0

KERNEL_ATTR_TIMEOUT  = 300.0
KERNEL_ENTRY_TIMEOUT = 300.0
NAME_MAP_TTL         = 60

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — Plex FUSE mount unavailable")

# ── Stub bytes (cached per resolution tier) ───────────────────────────────────

_stub_cache: dict[str, bytes] = {}
_stub_lock  = threading.Lock()

def _get_stub(filename: str) -> bytes:
    try:
        from qbt_mock import _detect_resolution, _stub_bytes_for
    except ImportError:
        return b""
    tier = _detect_resolution(filename)
    with _stub_lock:
        if tier in _stub_cache:
            return _stub_cache[tier]
    data = _stub_bytes_for(filename)
    with _stub_lock:
        _stub_cache[tier] = data
    return data

# ── Block cache (CDN playback reads) ──────────────────────────────────────────

class _BlockCache:
    def __init__(self, max_blocks: int):
        self._max   = max_blocks
        self._lock  = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def invalidate(self, cdn_url: str):
        with self._lock:
            for k in [k for k in self._store if k[0] == cdn_url]:
                del self._store[k]

_block_cache = _BlockCache(_CACHE_N)

# ── Helpers ───────────────────────────────────────────────────────────────────

def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"

VIDEO_EXTENSIONS = {
    ".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
    ".wmv", ".flv", ".webm", ".m2ts", ".mpg", ".mpeg",
}

def _is_video(filename: str) -> bool:
    return os.path.splitext(filename)[1].lower() in VIDEO_EXTENSIONS

# Running instance — set by mount()
_pfs = None

# ── Filesystem ────────────────────────────────────────────────────────────────

class PlexFS(Operations):
    def __init__(self, transfer_manager):
        self._tm   = transfer_manager
        self._now  = time.time()
        self._lock = threading.Lock()

        # name map cache
        self._name_map:         dict  = {}
        self._name_map_expires: float = 0.0
        self._name_map_lock           = threading.Lock()

        # stat cache: path → (stat_dict, expires_at)
        self._stat_cache: dict = {}
        self._stat_lock        = threading.Lock()

        # file handle counter
        self._fh_counter: int = 0
        self._fh_lock = threading.Lock()

        # CDN fetch dedup
        self._fetching:  set = set()
        self._fetch_lock = threading.Lock()

    # ── name map ──────────────────────────────────────────────────────────────

    def _get_name_map(self) -> dict:
        now = time.time()
        with self._name_map_lock:
            if now < self._name_map_expires:
                return self._name_map
        nm = self._build_name_map()
        with self._name_map_lock:
            self._name_map         = nm
            self._name_map_expires = now + NAME_MAP_TTL
        return nm

    def _build_name_map(self) -> dict:
        from fuse_mount import _category_subdir
        result = {}
        try:
            hashes = self._tm.streamable_hashes()
        except Exception:
            return result
        for h in hashes:
            try:
                t = self._tm.get_transfer(h)
                if not t:
                    continue
                base   = _safe_name(t.get("name") or h)
                subdir = _category_subdir(
                    t.get("name") or "", t.get("category", ""), kind=t.get("kind", "")
                )
                key = f"{subdir}/{base}"
                if key in result:
                    key = f"{subdir}/{base}_{h[:8]}"
                result[key] = h
            except Exception:
                continue
        return result

    def _invalidate_name_map(self):
        with self._name_map_lock:
            self._name_map_expires = 0.0

    # ── stat cache ────────────────────────────────────────────────────────────

    def _stat_get(self, path):
        now = time.time()
        with self._stat_lock:
            e = self._stat_cache.get(path)
            if e and now < e[1]:
                return e[0]
        return None

    def _stat_put(self, path, st, ttl=300):
        with self._stat_lock:
            self._stat_cache[path] = (st, time.time() + ttl)

    def _stat_invalidate_all(self):
        with self._stat_lock:
            self._stat_cache.clear()

    # ── file list ─────────────────────────────────────────────────────────────

    def _get_files(self, hash_: str) -> list:
        rows = self._tm._db_get_files(hash_)
        if rows:
            for r in rows:
                r["hash"] = hash_
            return self._tm._db_files_to_list(rows)
        # DB miss — call directdl once and persist
        files = self._tm.get_files(hash_)
        return files if files else []

    def _find_file(self, hash_: str, filename: str):
        for f in self._get_files(hash_):
            name = f.get("name", "")
            base = os.path.basename(f.get("path", "") or name)
            if name == filename or base == filename:
                return f
        return None

    # ── path parsing ──────────────────────────────────────────────────────────

    def _parse_path(self, path):
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None, None, None, None

        from fuse_mount import _4K_FOLDERS_ENABLED
        valid_subdirs = {"movies", "series"}
        if _4K_FOLDERS_ENABLED:
            valid_subdirs |= {"movies4k", "series4k"}

        if parts[0] in valid_subdirs:
            subdir   = parts[0]
            dirname  = parts[1] if len(parts) > 1 else None
            filename = "/".join(parts[2:]) if len(parts) > 2 else None
        else:
            subdir   = None
            dirname  = parts[0]
            filename = "/".join(parts[1:]) if len(parts) > 1 else None

        if dirname is None:
            return subdir, None, None, None

        key   = f"{subdir}/{dirname}" if subdir else dirname
        hash_ = self._get_name_map().get(key)
        return subdir, dirname, filename, hash_

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        cached = self._stat_get(path)
        if cached:
            return cached

        base = {
            "st_uid":   os.getuid(),
            "st_gid":   os.getgid(),
            "st_atime": self._now,
            "st_mtime": self._now,
            "st_ctime": self._now,
            "st_nlink": 2,
        }

        if path == "/":
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st)
            return st

        from fuse_mount import _4K_FOLDERS_ENABLED
        valid = {"/movies", "/series"}
        if _4K_FOLDERS_ENABLED:
            valid |= {"/movies4k", "/series4k"}
        if path in valid:
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st)
            return st

        subdir, dirname, filename, hash_ = self._parse_path(path)

        if filename is None:
            if hash_ is not None:
                st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
                self._stat_put(path, st)
                return st
            raise FuseOSError(errno.ENOENT)

        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        file_size = int(f.get("size", 0) or 0)
        if file_size == 0:
            raise FuseOSError(errno.ENOENT)

        # Always report the real CDN file size so Plex records the correct
        # size at import time. When we switch from stub→CDN nothing changes
        # in stat() so Plex never notices the switch.
        # Cache briefly after unlock so CDN URL refreshes are picked up.
        ttl = 60 if _cdn_unlocked else 300
        st = {
            **base,
            "st_mode":  stat.S_IFREG | 0o444,
            "st_nlink": 1,
            "st_size":  file_size,
        }
        self._stat_put(path, st, ttl)
        return st

    def readdir(self, path, fh):
        entries = [".", ".."]

        if path == "/":
            from fuse_mount import _4K_FOLDERS_ENABLED
            entries += ["movies", "series"]
            if _4K_FOLDERS_ENABLED:
                entries += ["movies4k", "series4k"]
            return entries

        from fuse_mount import _4K_FOLDERS_ENABLED
        valid = ["/movies", "/series"]
        if _4K_FOLDERS_ENABLED:
            valid += ["/movies4k", "/series4k"]
        if path in valid:
            subdir = path.lstrip("/")
            nm     = self._get_name_map()
            entries += [k[len(subdir)+1:] for k in nm if k.startswith(subdir + "/")]
            return entries

        subdir, dirname, _, hash_ = self._parse_path(path)
        if hash_:
            for f in self._get_files(hash_):
                name = f.get("name", "")
                size = int(f.get("size", 0) or 0)
                if name and _is_video(name) and size > 0:
                    entries.append(name)
        return entries

    def open(self, path, flags):
        subdir, dirname, filename, hash_ = self._parse_path(path)
        if not filename or hash_ is None:
            raise FuseOSError(errno.ENOENT)
        f = self._find_file(hash_, filename)
        if not f or int(f.get("size", 0) or 0) == 0:
            raise FuseOSError(errno.ENOENT)
        with self._fh_lock:
            self._fh_counter += 1
            fh = self._fh_counter
        return fh

    def release(self, path, fh):
        return 0

    def read(self, path, size, offset, fh):
        try:
            return self._read_safe(path, size, offset, fh)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"PlexFS read({path}): {e}", exc_info=True)
            raise FuseOSError(errno.EIO)

    def _read_safe(self, path, size, offset, fh):
        subdir, dirname, filename, hash_ = self._parse_path(path)
        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        # ── Stub mode (before Import Complete) ────────────────────────────────
        # Serve stub bytes so Plex can scan and import without hitting the CDN.
        # The stub is a real MKV with correct headers (resolution/codec/duration).
        # We advertise the real CDN file size in getattr() so Plex records the
        # correct size — reads beyond the stub's physical length return zeros.
        if not _cdn_unlocked:
            stub = _get_stub(filename)
            if stub:
                stub_len = len(stub)
                if offset >= stub_len:
                    return b"\x00" * size
                available = stub[offset:offset + size]
                shortfall = size - len(available)
                if shortfall > 0:
                    available = available + b"\x00" * shortfall
                return available

        # ── CDN mode (after Import Complete) ─────────────────────────────────
        cdn_url   = f.get("link", "")
        file_size = int(f.get("size", 0) or 0)

        if not cdn_url:
            new_url = self._tm.refresh_cdn_url(hash_, filename)
            if not new_url:
                raise FuseOSError(errno.EIO)
            cdn_url = new_url

        block_idx = offset // BLOCK_SIZE
        key       = (cdn_url, block_idx)
        data      = _block_cache.get(key)

        if data is None:
            data = self._fetch_block(cdn_url, block_idx, file_size)
            if data is None:
                log.info(f"[plex_fuse] CDN expired for {filename}, refreshing")
                new_url = self._tm.refresh_cdn_url(hash_, filename)
                if new_url:
                    _block_cache.invalidate(cdn_url)
                    cdn_url = new_url
                    data    = self._fetch_block(cdn_url, block_idx, file_size)
            if data is None:
                log.warning(f"[plex_fuse] block fetch failed: {path} block {block_idx}")
                raise FuseOSError(errno.EIO)

        self._prefetch(cdn_url, block_idx + 1, file_size)

        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        chunk        = data[slice_offset:slice_offset + size]

        if len(chunk) < size and (block_idx + 1) * BLOCK_SIZE < file_size:
            next_data = _block_cache.get((cdn_url, block_idx + 1))
            if next_data is None:
                next_data = self._fetch_block(cdn_url, block_idx + 1, file_size)
            if next_data:
                chunk = chunk + next_data[:size - len(chunk)]
        return chunk

    def _fetch_block(self, cdn_url: str, block_idx: int, file_size: int) -> bytes | None:
        start   = block_idx * BLOCK_SIZE
        end     = min(start + BLOCK_SIZE - 1, file_size - 1) if file_size else start + BLOCK_SIZE - 1
        headers = {"Range": f"bytes={start}-{end}"}
        for attempt in range(READ_MAX_ATTEMPTS):
            try:
                r = requests.get(cdn_url, headers=headers, timeout=READ_TIMEOUT, stream=True)
                if r.status_code in (200, 206):
                    data = r.content
                    _block_cache.put((cdn_url, block_idx), data)
                    return data
                if r.status_code in (403, 410):
                    return None
                time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))
            except requests.RequestException:
                time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))
        return None

    def _prefetch(self, cdn_url: str, block_idx: int, file_size: int):
        if block_idx * BLOCK_SIZE >= file_size:
            return
        key = (cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with self._fetch_lock:
            if key in self._fetching:
                return
            self._fetching.add(key)
        def _do():
            try:
                self._fetch_block(cdn_url, block_idx, file_size)
            finally:
                with self._fetch_lock:
                    self._fetching.discard(key)
        threading.Thread(target=_do, daemon=True).start()

    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


def mount(mountpoint: str, transfer_manager, foreground: bool = True):
    if not FUSE_AVAILABLE:
        log.error("fusepy not installed — Plex FUSE mount unavailable")
        return
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"[plex_fuse] Mounting at {mountpoint} "
             f"(block={_BLOCK_MB}MB, cache={_CACHE_N} blocks)")
    global _pfs
    _pfs = PlexFS(transfer_manager)
    try:
        FUSE(
            _pfs,
            mountpoint,
            nothreads=False,
            foreground=foreground,
            allow_other=True,
            nonempty=True,
            ro=True,
            attr_timeout=KERNEL_ATTR_TIMEOUT,
            entry_timeout=KERNEL_ENTRY_TIMEOUT,
            negative_timeout=10.0,
        )
    except Exception as e:
        log.error(f"[plex_fuse] mount exited: {e}", exc_info=True)
        raise
    log.info("[plex_fuse] mount exited cleanly")

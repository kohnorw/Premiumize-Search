"""
Plex-specific FUSE mount for Premiumize.

Mounts at /docker/premiumize-web/plex — point Plex at this, NOT the main mount.

Per-file state (stored in SQLite files.plex_ready):
  plex_ready = 0  → serve stub MKV bytes (Plex is still scanning/importing)
  plex_ready = 1  → serve real CDN bytes (Tautulli confirmed Plex imported it)

Flow:
  1. New file added → plex_ready=0 → Plex scans, reads stub, gets metadata (zero CDN)
  2. Plex finishes import → Tautulli fires POST /api/tautulli/imported
  3. App marks plex_ready=1 for that transfer
  4. Next open() of the file → CDN bytes served → real playback works

Configure Plex container:
    volumes:
      - /docker/premiumize-web/plex:/docker/premiumize-web/plex:rshared
"""

import errno
import logging
import os
import re
import stat
import threading
import time
from collections import OrderedDict

import requests

log = logging.getLogger(__name__)

# ── Tuning ────────────────────────────────────────────────────────────────────

_BLOCK_MB  = int(os.environ.get("PLEX_FUSE_BLOCK_MB",  "8"))
_CACHE_N   = int(os.environ.get("PLEX_FUSE_CACHE_N",   "32"))
BLOCK_SIZE = _BLOCK_MB * 1024 * 1024

READ_TIMEOUT      = int(os.environ.get("PLEX_FUSE_READ_TIMEOUT", "30"))
READ_MAX_ATTEMPTS = 4
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 4.0

KERNEL_ATTR_TIMEOUT  = 300.0
KERNEL_ENTRY_TIMEOUT = 300.0
NAME_MAP_TTL         = 60

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — Plex FUSE mount unavailable")

# ── Stub bytes (cached per resolution tier) ───────────────────────────────────

_stub_cache: dict[str, bytes] = {}
_stub_lock  = threading.Lock()

def _get_stub(filename: str) -> bytes:
    try:
        from qbt_mock import _detect_resolution, _stub_bytes_for
    except ImportError:
        return b""
    tier = _detect_resolution(filename)
    with _stub_lock:
        if tier in _stub_cache:
            return _stub_cache[tier]
    data = _stub_bytes_for(filename)
    with _stub_lock:
        _stub_cache[tier] = data
    return data

# ── Block cache (CDN playback reads) ─────────────────────────────────────────

class _BlockCache:
    def __init__(self, max_blocks: int):
        self._max   = max_blocks
        self._lock  = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        return None

    def put(self, key, data: bytes):
        with self._lock:
            self._store[key] = data
            self._store.move_to_end(key)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def invalidate(self, cdn_url: str):
        with self._lock:
            for k in [k for k in self._store if k[0] == cdn_url]:
                del self._store[k]

_block_cache = _BlockCache(_CACHE_N)

# ── Helpers ───────────────────────────────────────────────────────────────────

def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"

VIDEO_EXTENSIONS = {
    ".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
    ".wmv", ".flv", ".webm", ".m2ts", ".mpg", ".mpeg",
}

def _is_video(filename: str) -> bool:
    return os.path.splitext(filename)[1].lower() in VIDEO_EXTENSIONS

# Running instance — set by mount(), used for cache invalidation
_pfs = None

# ── Filesystem ────────────────────────────────────────────────────────────────

class PlexFS(Operations):
    def __init__(self, transfer_manager):
        self._tm   = transfer_manager
        self._now  = time.time()
        self._lock = threading.Lock()

        # name map cache
        self._name_map:         dict  = {}
        self._name_map_expires: float = 0.0
        self._name_map_lock           = threading.Lock()

        # stat cache: path → (stat_dict, expires_at)
        self._stat_cache: dict = {}
        self._stat_lock        = threading.Lock()

        # file handle counter
        self._fh_counter: int = 0
        self._fh_lock = threading.Lock()

        # CDN fetch dedup
        self._fetching:  set = set()
        self._fetch_lock = threading.Lock()

    # ── name map ──────────────────────────────────────────────────────────────

    def _get_name_map(self) -> dict:
        now = time.time()
        with self._name_map_lock:
            if now < self._name_map_expires:
                return self._name_map
        nm = self._build_name_map()
        with self._name_map_lock:
            self._name_map         = nm
            self._name_map_expires = now + NAME_MAP_TTL
        return nm

    def _build_name_map(self) -> dict:
        from fuse_mount import _category_subdir
        result = {}
        try:
            hashes = self._tm.streamable_hashes()
        except Exception:
            return result
        for h in hashes:
            try:
                t = self._tm.get_transfer(h)
                if not t:
                    continue
                base   = _safe_name(t.get("name") or h)
                subdir = _category_subdir(
                    t.get("name") or "", t.get("category", ""), kind=t.get("kind", "")
                )
                key = f"{subdir}/{base}"
                if key in result:
                    key = f"{subdir}/{base}_{h[:8]}"
                result[key] = h
            except Exception:
                continue
        return result

    def _invalidate_name_map(self):
        with self._name_map_lock:
            self._name_map_expires = 0.0

    # ── stat cache ────────────────────────────────────────────────────────────

    def _stat_get(self, path):
        now = time.time()
        with self._stat_lock:
            e = self._stat_cache.get(path)
            if e and now < e[1]:
                return e[0]
        return None

    def _stat_put(self, path, st, ttl=300):
        with self._stat_lock:
            self._stat_cache[path] = (st, time.time() + ttl)

    def _stat_invalidate_all(self):
        with self._stat_lock:
            self._stat_cache.clear()

    # ── file list ─────────────────────────────────────────────────────────────

    def _get_files(self, hash_: str) -> list:
        rows = self._tm._db_get_files(hash_)
        if not rows:
            return []
        for r in rows:
            r["hash"] = hash_
        return self._tm._db_files_to_list(rows)

    def _find_file(self, hash_: str, filename: str):
        for f in self._get_files(hash_):
            name = f.get("name", "")
            base = os.path.basename(f.get("path", "") or name)
            if name == filename or base == filename:
                return f
        return None

    # ── path parsing ──────────────────────────────────────────────────────────

    def _parse_path(self, path):
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None, None, None, None

        from fuse_mount import _4K_FOLDERS_ENABLED
        valid_subdirs = {"movies", "series"}
        if _4K_FOLDERS_ENABLED:
            valid_subdirs |= {"movies4k", "series4k"}

        if parts[0] in valid_subdirs:
            subdir   = parts[0]
            dirname  = parts[1] if len(parts) > 1 else None
            filename = "/".join(parts[2:]) if len(parts) > 2 else None
        else:
            subdir   = None
            dirname  = parts[0]
            filename = "/".join(parts[1:]) if len(parts) > 1 else None

        if dirname is None:
            return subdir, None, None, None

        key   = f"{subdir}/{dirname}" if subdir else dirname
        hash_ = self._get_name_map().get(key)
        return subdir, dirname, filename, hash_

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        cached = self._stat_get(path)
        if cached:
            return cached

        base = {
            "st_uid":   os.getuid(),
            "st_gid":   os.getgid(),
            "st_atime": self._now,
            "st_mtime": self._now,
            "st_ctime": self._now,
            "st_nlink": 2,
        }

        if path == "/":
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st)
            return st

        from fuse_mount import _4K_FOLDERS_ENABLED
        valid = {"/movies", "/series"}
        if _4K_FOLDERS_ENABLED:
            valid |= {"/movies4k", "/series4k"}
        if path in valid:
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st)
            return st

        subdir, dirname, filename, hash_ = self._parse_path(path)

        if filename is None:
            if hash_ is not None:
                st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
                self._stat_put(path, st)
                return st
            raise FuseOSError(errno.ENOENT)

        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        file_size = int(f.get("size", 0) or 0)
        if file_size == 0:
            raise FuseOSError(errno.ENOENT)

        # Report stub size while not yet plex_ready, real size after
        ready = self._tm.is_plex_ready(hash_, filename)
        if ready:
            reported_size = file_size
            # Don't cache ready files long — CDN URLs change
            ttl = 60
        else:
            stub = _get_stub(filename)
            reported_size = len(stub) if stub else file_size
            ttl = 300

        st = {
            **base,
            "st_mode":  stat.S_IFREG | 0o444,
            "st_nlink": 1,
            "st_size":  reported_size,
        }
        self._stat_put(path, st, ttl)
        return st

    def readdir(self, path, fh):
        entries = [".", ".."]

        if path == "/":
            from fuse_mount import _4K_FOLDERS_ENABLED
            entries += ["movies", "series"]
            if _4K_FOLDERS_ENABLED:
                entries += ["movies4k", "series4k"]
            return entries

        from fuse_mount import _4K_FOLDERS_ENABLED
        valid = ["/movies", "/series"]
        if _4K_FOLDERS_ENABLED:
            valid += ["/movies4k", "/series4k"]
        if path in valid:
            subdir = path.lstrip("/")
            nm     = self._get_name_map()
            entries += [k[len(subdir)+1:] for k in nm if k.startswith(subdir + "/")]
            return entries

        subdir, dirname, _, hash_ = self._parse_path(path)
        if hash_:
            for f in self._get_files(hash_):
                name = f.get("name", "")
                size = int(f.get("size", 0) or 0)
                if name and _is_video(name) and size > 0:
                    entries.append(name)
        return entries

    def open(self, path, flags):
        subdir, dirname, filename, hash_ = self._parse_path(path)
        if not filename or hash_ is None:
            raise FuseOSError(errno.ENOENT)
        f = self._find_file(hash_, filename)
        if not f or int(f.get("size", 0) or 0) == 0:
            raise FuseOSError(errno.ENOENT)
        with self._fh_lock:
            self._fh_counter += 1
            fh = self._fh_counter
        return fh

    def release(self, path, fh):
        return 0

    def read(self, path, size, offset, fh):
        try:
            return self._read_safe(path, size, offset, fh)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"PlexFS read({path}): {e}", exc_info=True)
            raise FuseOSError(errno.EIO)

    def _read_safe(self, path, size, offset, fh):
        subdir, dirname, filename, hash_ = self._parse_path(path)
        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        # ── Per-file state check ──────────────────────────────────────────────
        # plex_ready=0: Plex is still scanning/importing → serve stub bytes
        #               Zero CDN hits, zero Fair Use points
        # plex_ready=1: Tautulli confirmed Plex imported it → serve real CDN bytes
        if not self._tm.is_plex_ready(hash_, filename):
            stub = _get_stub(filename)
            if stub:
                chunk = stub[offset:offset + size]
                if len(chunk) < size:
                    chunk = chunk + b"\x00" * (size - len(chunk))
                return chunk
            # No stub available — fall through to CDN (shouldn't happen)

        # ── Real CDN bytes ────────────────────────────────────────────────────
        cdn_url   = f.get("link", "")
        file_size = int(f.get("size", 0) or 0)

        if not cdn_url:
            new_url = self._tm.refresh_cdn_url(hash_, filename)
            if not new_url:
                raise FuseOSError(errno.EIO)
            cdn_url = new_url

        block_idx = offset // BLOCK_SIZE
        key       = (cdn_url, block_idx)
        data      = _block_cache.get(key)

        if data is None:
            data = self._fetch_block(cdn_url, block_idx, file_size)
            if data is None:
                log.info(f"[plex_fuse] CDN expired for {filename}, refreshing")
                new_url = self._tm.refresh_cdn_url(hash_, filename)
                if new_url:
                    _block_cache.invalidate(cdn_url)
                    cdn_url = new_url
                    data    = self._fetch_block(cdn_url, block_idx, file_size)
            if data is None:
                log.warning(f"[plex_fuse] block fetch failed: {path} block {block_idx}")
                raise FuseOSError(errno.EIO)

        self._prefetch(cdn_url, block_idx + 1, file_size)

        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        chunk        = data[slice_offset:slice_offset + size]

        if len(chunk) < size and (block_idx + 1) * BLOCK_SIZE < file_size:
            next_data = _block_cache.get((cdn_url, block_idx + 1))
            if next_data is None:
                next_data = self._fetch_block(cdn_url, block_idx + 1, file_size)
            if next_data:
                chunk = chunk + next_data[:size - len(chunk)]
        return chunk

    def _fetch_block(self, cdn_url: str, block_idx: int, file_size: int) -> bytes | None:
        start   = block_idx * BLOCK_SIZE
        end     = min(start + BLOCK_SIZE - 1, file_size - 1) if file_size else start + BLOCK_SIZE - 1
        headers = {"Range": f"bytes={start}-{end}"}
        for attempt in range(READ_MAX_ATTEMPTS):
            try:
                r = requests.get(cdn_url, headers=headers, timeout=READ_TIMEOUT, stream=True)
                if r.status_code in (200, 206):
                    data = r.content
                    _block_cache.put((cdn_url, block_idx), data)
                    return data
                if r.status_code in (403, 410):
                    return None
                time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))
            except requests.RequestException:
                time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))
        return None

    def _prefetch(self, cdn_url: str, block_idx: int, file_size: int):
        if block_idx * BLOCK_SIZE >= file_size:
            return
        key = (cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with self._fetch_lock:
            if key in self._fetching:
                return
            self._fetching.add(key)
        def _do():
            try:
                self._fetch_block(cdn_url, block_idx, file_size)
            finally:
                with self._fetch_lock:
                    self._fetching.discard(key)
        threading.Thread(target=_do, daemon=True).start()

    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


def mount(mountpoint: str, transfer_manager, foreground: bool = True):
    if not FUSE_AVAILABLE:
        log.error("fusepy not installed — Plex FUSE mount unavailable")
        return
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"[plex_fuse] Mounting at {mountpoint} "
             f"(block={_BLOCK_MB}MB, cache={_CACHE_N} blocks)")
    global _pfs
    _pfs = PlexFS(transfer_manager)
    try:
        FUSE(
            _pfs,
            mountpoint,
            nothreads=False,
            foreground=foreground,
            allow_other=True,
            nonempty=True,
            ro=True,
            attr_timeout=KERNEL_ATTR_TIMEOUT,
            entry_timeout=KERNEL_ENTRY_TIMEOUT,
            negative_timeout=10.0,
        )
    except Exception as e:
        log.error(f"[plex_fuse] mount exited: {e}", exc_info=True)
        raise
    log.info("[plex_fuse] mount exited cleanly")

"""
Transfer manager — tracks torrent state using SQLite.

States:
  queued      → just received, not yet checked
  cached      → Premiumize has it cached, ready to stream
  downloading → not cached, transfer created on Premiumize, polling
  complete    → transfer finished, ready to stream
  error       → something went wrong

File lists and CDN URLs are stored persistently in the `files` table.
directdl is called once per hash when content is first added, then never
again unless a CDN URL actually expires (403/410) during playback.
This eliminates recurring Fair Use point drain from periodic directdl
refreshes on large libraries.
"""

import logging
import sys
import os
import sqlite3
import threading
import time
import urllib.parse

import requests


# ── Plex library scan (debounced) ─────────────────────────────────────────────
# Waits PLEX_SCAN_DEBOUNCE seconds after the last ready-state transition before
# triggering a scan. A bulk import of 50 files fires exactly one scan, not 50.

class _PlexScanner:
    """Debounced Plex partial-library scanner."""

    def __init__(self):
        self._lock        = threading.Lock()
        self._timer: threading.Timer | None = None
        self._pending: set = set()   # set of (subdir, rel_path|None)
        self._loc_cache: dict = {}   # cached Plex section→Location paths
        self._log = logging.getLogger(__name__ + ".plex")
        # Start the periodic scan/unlock background thread
        self._interval_stop = threading.Event()
        self._interval_wake  = threading.Event()
        t = threading.Thread(target=self._interval_loop, daemon=True)
        t.start()

    def _scan_interval_minutes(self) -> int:
        """Return the configured periodic scan interval in minutes. 0 = disabled."""
        try:
            import sys as _sys
            _app_mod = _sys.modules.get("app") or _sys.modules.get("__main__")
            _load_config = getattr(_app_mod, "_load_config", None) if _app_mod else None
            if _load_config:
                return int((_load_config() or {}).get("plex", {}).get("scan_interval_minutes", 60))
        except Exception:
            pass
        return 60

    def _schedule_interval_scan(self):
        """Wake the interval loop immediately so it picks up the new setting."""
        self._interval_wake.set()

    def _interval_loop(self):
        """Background thread: sleep for the configured interval, then scan+unlock.
        Uses an Event so _schedule_interval_scan() can wake it early when
        settings change or a manual trigger is needed."""
        while not self._interval_stop.is_set():
            minutes = self._scan_interval_minutes()
            if minutes <= 0:
                # Disabled — wait 60s then re-check in case setting changes
                self._interval_wake.wait(timeout=60)
                self._interval_wake.clear()
                continue
            # Wait for the interval or until woken early
            self._interval_wake.wait(timeout=minutes * 60)
            self._interval_wake.clear()
            if self._interval_stop.is_set():
                break
            self._run_interval_scan()

    def _run_interval_scan(self):
        """Run the scan+unlock cycle."""
        self._log.warning("[plex-interval] running periodic scan+unlock")
        try:
            unlock_result = self.unlock_scanned_by_plex()
            self._log.warning(f"[plex-interval] unlocked {unlock_result.get('unlocked', 0)} transfer(s)")
            scan_result = self.scan_missing_from_plex()
            movies = len((scan_result.get("scanned") or {}).get("movies") or [])
            series = len((scan_result.get("scanned") or {}).get("series") or [])
            self._log.warning(f"[plex-interval] scanned {movies} movies, {series} series missing from Plex")
        except Exception as e:
            self._log.warning(f"[plex-interval] error: {e}")

    def _config(self):
        """Return Plex scan config.

        Env vars take precedence; falls back to saved config. movie_root/tv_root
        are the exact filesystem roots Plex sees, e.g.
        /docker/premiumize-web/mnt/movies and /docker/premiumize-web/mnt/series.
        """
        # Env vars
        url       = os.environ.get("PLEX_URL",            "").rstrip("/")
        token     = os.environ.get("PLEX_TOKEN",          "")
        movies    = os.environ.get("PLEX_MOVIES_SECTION", "")
        tv        = os.environ.get("PLEX_TV_SECTION",     "")
        movie_root= os.environ.get("PLEX_MOVIE_ROOT",     "").rstrip("/")
        tv_root   = os.environ.get("PLEX_TV_ROOT",        "").rstrip("/")
        debounce  = int(os.environ.get("PLEX_SCAN_DEBOUNCE", "0"))

        # Fall back to saved config for anything not set via env
        try:
            # Use _load_config() so we always get the populated cache, not just
            # the module-level None that exists before the first request.
            import sys as _sys
            _app_mod = _sys.modules.get("app") or _sys.modules.get("__main__")
            _app_load_config = getattr(_app_mod, "_load_config", None) if _app_mod else None
            cfg_data = (_app_load_config() or {}).get("plex", {}) if _app_load_config else {}
            url        = url        or cfg_data.get("url",            "").rstrip("/")
            token      = token      or cfg_data.get("token",          "")
            movies     = movies     or str(cfg_data.get("movies_section", "1"))
            tv         = tv         or str(cfg_data.get("tv_section",     "2"))
            mount_path = (cfg_data.get("mount_path") or os.environ.get("PLEX_MOUNT_PATH") or "/docker/premiumize-web/mnt").rstrip("/")
            movie_root = movie_root or (cfg_data.get("movie_root") or (mount_path + "/movies")).rstrip("/")
            tv_root    = tv_root    or (cfg_data.get("tv_root")    or (mount_path + "/series")).rstrip("/")
            debounce   = debounce or int(cfg_data.get("debounce_seconds", 30))
        except Exception:
            mount_path = os.environ.get("PLEX_MOUNT_PATH", "/docker/premiumize-web/mnt").rstrip("/")
            movie_root = movie_root or (mount_path + "/movies")
            tv_root    = tv_root or (mount_path + "/series")

        debounce = debounce or 30
        movies   = movies   or "1"
        tv       = tv       or "2"
        # 4K roots — default to mount_path/movies4k and mount_path/series4k
        try:
            mount_path_4k = (cfg_data.get("mount_path") or os.environ.get("PLEX_MOUNT_PATH") or "/docker/premiumize-web/mnt").rstrip("/")
            movie4k_root = (cfg_data.get("movie4k_root") or (mount_path_4k + "/movies4k")).rstrip("/")
            tv4k_root    = (cfg_data.get("tv4k_root")    or (mount_path_4k + "/series4k")).rstrip("/")
        except Exception:
            movie4k_root = movie_root.replace("/movies", "/movies4k")
            tv4k_root    = tv_root.replace("/series", "/series4k")
        return (url, token, movies, tv, debounce, movie_root, tv_root, movie4k_root, tv4k_root) if url and token else (None, None, movies, tv, debounce, movie_root, tv_root, movie4k_root, tv4k_root)

    def _cfg_bool(self, key: str, default: bool) -> bool:
        """Read a Plex boolean from env/config without importing app eagerly."""
        env_key = "PLEX_" + key.upper()
        v = os.environ.get(env_key)
        if v is not None:
            return v.strip().lower() not in ("0", "false", "no", "off")
        try:
            import sys as _sys
            _app_mod = _sys.modules.get("app") or _sys.modules.get("__main__")
            _config_cache = getattr(_app_mod, "_config_cache", None) if _app_mod else None
            plex_cfg = (_config_cache or {}).get("plex", {})
            if key in plex_cfg:
                return bool(plex_cfg.get(key))
        except Exception:
            pass
        return default

    def _auto_scan_enabled(self) -> bool:
        """Whether new FUSE items should automatically trigger Plex refreshes."""
        return self._cfg_bool("auto_scan_enabled", True)

    def _partial_enabled(self) -> bool:
        """Whether to use Plex path-scoped scans: /refresh?path=/library/item."""
        return self._cfg_bool("partial_scan", True)

    def _fallback_full_enabled(self) -> bool:
        """Whether a failed path scan may fall back to a full section refresh."""
        return self._cfg_bool("fallback_full_scan", True)

    def _section_locations(self, url: str, token: str, section: str) -> list:
        """Return the filesystem Location path(s) Plex has for a section, as the
        Plex server sees them. Cached for 5 min (locations rarely change)."""
        now = time.time()
        ent = self._loc_cache.get("_all")
        if not ent or now >= ent[1]:
            mapping: dict = {}
            try:
                r = requests.get(
                    f"{url}/library/sections",
                    headers={"X-Plex-Token": token, "Accept": "application/json"},
                    timeout=10,
                )
                if r.status_code == 200:
                    for d in (r.json().get("MediaContainer", {}).get("Directory", []) or []):
                        key   = str(d.get("key"))
                        paths = [l.get("path") for l in (d.get("Location") or []) if l.get("path")]
                        if key:
                            mapping[key] = paths
            except Exception as e:
                self._log.debug(f"Plex section-location lookup failed: {e}")
            ent = (mapping, now + 300)
            self._loc_cache["_all"] = ent
        return ent[0].get(str(section), [])

    @staticmethod
    def _pick_location(locations: list, subdir: str) -> str | None:
        """Choose the section Location that matches this subdir. Handles a single
        location, and split setups where movies/movies4k (or series/series4k)
        are separate Locations of the same section."""
        if not locations:
            return None
        if len(locations) == 1:
            return locations[0]
        # 1. Exact basename match (case-insensitive) — e.g. '.../movies4k'
        for p in locations:
            if os.path.basename(p.rstrip("/")).lower() == subdir:
                return p
        # 2. Score on 4K-ness + media type inferred from the location basename
        want_4k     = subdir.endswith("4k")
        want_series = subdir.startswith("series")

        def score(p: str) -> int:
            b = os.path.basename(p.rstrip("/")).lower()
            is4k     = ("4k" in b) or ("uhd" in b) or ("2160" in b)
            isseries = any(k in b for k in ("tv", "series", "show"))
            ismovie  = ("movie" in b) or ("film" in b)
            s = 0
            if is4k == want_4k:
                s += 2
            if want_series and isseries:
                s += 2
            if (not want_series) and ismovie:
                s += 2
            return s

        return max(locations, key=score)

    def notify_ready(self, subdir: str, rel_path: str | None = None):
        """Schedule a debounced Plex scan for a transfer that became ready.

        rel_path: the item's folder name relative to the section's library root
                  (the safe torrent-folder name). When supplied, Plex is asked to
                  scan ONLY that folder — a path-scoped partial scan — so it walks
                  one directory instead of the whole section. When None, a full
                  section refresh is scheduled (used as a fallback)."""
        if not self._auto_scan_enabled():
            self._log.debug("Plex auto-scan disabled; skipping notify_ready")
            return

        # Resolve debounce only — don't check URL here since _config_cache may
        # not be populated yet on background threads. _fire() resolves the full
        # config when the timer actually fires.
        _, _, _, _, debounce, *_ = self._config()

        with self._lock:
            self._pending.add((subdir, rel_path))
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(debounce, self._fire)
            self._timer.daemon = True
            self._timer.start()
            self._log.warning(f"[plex-add] scan scheduled in {debounce}s queued={self._pending}")

    def _fire(self):
        with self._lock:
            self._pending.clear()
            self._timer = None

        url, token, movies_section, tv_section, _, movie_root, tv_root, movie4k_root, tv4k_root = self._config()
        if not url or not token:
            self._log.warning("[plex-add] _fire: no Plex URL or token configured — scan skipped")
            return
        self._log.warning(f"[plex-add] _fire: scanning missing items url={url}")
        # Compare FUSE against Plex library and scan only what's missing
        result = self.scan_missing_from_plex()
        self._log.warning(f"[plex-add] _fire: done — {result}")
        # Schedule unlock 60s after the scan so Plex has time to import the stub
        t = threading.Timer(60, self._unlock_after_scan)
        t.daemon = True
        t.start()

    def _unlock_after_scan(self):
        """Called 60s after a new-item scan — by then Plex has imported the stub.
        Since files are already unlocked, just fire metadata refresh so Plex
        picks up real duration/codec/size instead of stub values."""
        self._log.warning("[plex-add] refreshing Plex metadata for newly scanned items")
        try:
            result = self.unlock_scanned_by_plex()
            self._log.warning(f"[plex-add] metadata refreshed for {result.get('unlocked', 0)} transfer(s)")
        except Exception as e:
            self._log.warning(f"[plex-add] post-scan metadata refresh failed: {e}")

    def get_missing_from_plex(self) -> dict:
        """Compare FUSE name map against Plex library and return folders not yet in Plex.

        Returns {"movies": [...folder_names...], "series": [...folder_names...]}
        """
        url, token, movies_section, tv_section, _, movie_root, tv_root, movie4k_root, tv4k_root = self._config()
        if not url or not token:
            return {"error": "Plex not configured", "movies": [], "series": []}

        def plex_folder_names(section: str, root: str) -> set:
            """Get the set of folder basenames currently in a Plex section."""
            names = set()
            try:
                r = requests.get(
                    f"{url}/library/sections/{section}/all",
                    headers={"X-Plex-Token": token, "Accept": "application/json"},
                    params={"type": "1" if root.endswith("movies") or "movie" in root else "4"},
                    timeout=15,
                )
                if r.status_code != 200:
                    self._log.warning(f"[plex-missing] sections/{section}/all HTTP {r.status_code}")
                    return names
                for item in (r.json().get("MediaContainer", {}).get("Metadata") or []):
                    for media in (item.get("Media") or []):
                        for part in (media.get("Part") or []):
                            fp = part.get("file") or ""
                            if fp:
                                # Get the folder name (parent of the file)
                                names.add(os.path.basename(os.path.dirname(fp)))
            except Exception as e:
                self._log.warning(f"[plex-missing] section {section} query failed: {e}")
            return names

        # Get what Plex already has
        plex_movies = plex_folder_names(movies_section, movie_root)
        plex_series = plex_folder_names(tv_section, tv_root)
        self._log.warning(f"[plex-missing] Plex has {len(plex_movies)} movie folders, {len(plex_series)} series folders")

        # Get what FUSE has
        try:
            import fuse_mount as _fm
            nm = _fm.build_name_map(self)  # {subdir/folder: hash}
        except Exception as e:
            return {"error": f"FUSE name map failed: {e}", "movies": [], "series": []}

        missing_movies   = []
        missing_movies4k = []
        missing_series   = []
        missing_series4k = []
        for key in nm:
            parts = key.split("/", 1)
            if len(parts) != 2:
                continue
            subdir, folder = parts
            if subdir == "movies":
                if folder not in plex_movies:
                    missing_movies.append(folder)
            elif subdir == "movies4k":
                if folder not in plex_movies:
                    missing_movies4k.append(folder)
            elif subdir == "series":
                if folder not in plex_series:
                    missing_series.append(folder)
            elif subdir == "series4k":
                if folder not in plex_series:
                    missing_series4k.append(folder)

        self._log.warning(f"[plex-missing] missing from Plex: {len(missing_movies)} movies, {len(missing_movies4k)} movies4k, {len(missing_series)} series, {len(missing_series4k)} series4k")
        return {"movies": missing_movies, "movies4k": missing_movies4k, "series": missing_series, "series4k": missing_series4k}

    def refresh_plex_metadata_all(self) -> dict:
        """Refresh Plex metadata only for items that still show stub duration (≤660s / 11min).
        This avoids unnecessary CDN bandwidth for items Plex already has correct metadata for."""
        url, token, movies_section, tv_section, _, movie_root, tv_root, movie4k_root, tv4k_root = self._config()
        if not url or not token:
            return {"error": "Plex not configured", "refreshed": 0}

        STUB_DURATION_MS = 660 * 1000  # 11 minutes in milliseconds (Plex stores ms)

        refreshed = 0
        skipped = 0
        for section in [movies_section, tv_section]:
            if not section:
                continue
            try:
                r = requests.get(
                    f"{url}/library/sections/{section}/all",
                    headers={"X-Plex-Token": token, "Accept": "application/json"},
                    timeout=15,
                )
                if r.status_code != 200:
                    continue
                for item in (r.json().get("MediaContainer", {}).get("Metadata") or []):
                    rk = item.get("ratingKey") or ""
                    if not rk:
                        continue
                    duration = int(item.get("duration") or 0)
                    # Only refresh items at or under stub duration (11 min = 660s)
                    if duration > STUB_DURATION_MS:
                        skipped += 1
                        continue
                    try:
                        requests.put(
                            f"{url}/library/metadata/{rk}/refresh",
                            headers={"X-Plex-Token": token},
                            params={"force": 1},
                            timeout=8,
                        )
                        refreshed += 1
                        self._log.debug(f"[plex-refresh] refreshed rk={rk} duration={duration}ms")
                    except Exception:
                        pass
            except Exception as e:
                self._log.warning(f"[plex-refresh-all] section {section} failed: {e}")

        self._log.warning(f"[plex-refresh-all] refreshed {refreshed} stub-duration items, skipped {skipped} already correct")
        return {"refreshed": refreshed, "skipped": skipped}

    def unlock_scanned_by_plex(self) -> dict:
        """Unlock any files in FUSE that Plex has already scanned and imported.

        Compares Plex library folder names against the FUSE name map. Any folder
        that exists in both is already imported — unlock it so playback goes
        straight to CDN. Also triggers a metadata refresh on newly-unlocked items
        so Plex picks up the real duration and file size instead of stub values.
        """
        url, token, movies_section, tv_section, _, movie_root, tv_root, movie4k_root, tv4k_root = self._config()
        if not url or not token:
            return {"error": "Plex not configured", "unlocked": 0}

        def plex_folder_map(section: str, root: str) -> dict:
            """Return {folder_name: ratingKey} for all items in this section."""
            result = {}
            try:
                r = requests.get(
                    f"{url}/library/sections/{section}/all",
                    headers={"X-Plex-Token": token, "Accept": "application/json"},
                    params={"type": "1" if "movie" in root else "4"},
                    timeout=15,
                )
                if r.status_code == 200:
                    for item in (r.json().get("MediaContainer", {}).get("Metadata") or []):
                        rk = item.get("ratingKey") or ""
                        for media in (item.get("Media") or []):
                            for part in (media.get("Part") or []):
                                fp = part.get("file") or ""
                                if fp and rk:
                                    folder = os.path.basename(os.path.dirname(fp))
                                    result[folder] = rk
            except Exception as e:
                self._log.warning(f"[plex-unlock] section {section} query failed: {e}")
            return result

        def plex_refresh_metadata(rating_key: str):
            """Tell Plex to re-analyse this item and pick up real duration/size/codec.
            Uses force=1 so Plex re-reads the file even if it thinks it has metadata."""
            try:
                requests.put(
                    f"{url}/library/metadata/{rating_key}/refresh",
                    headers={"X-Plex-Token": token},
                    params={"force": 1, "refreshLocalMediaAgent": 1},
                    timeout=8,
                )
            except Exception as e:
                self._log.debug(f"[plex-unlock] metadata refresh failed rk={rating_key}: {e}")

        plex_movies = plex_folder_map(movies_section, movie_root)
        plex_series = plex_folder_map(tv_section, tv_root)
        self._log.warning(f"[plex-unlock] Plex movies folders: {list(plex_movies.keys())[:5]}")
        self._log.warning(f"[plex-unlock] Plex series folders: {list(plex_series.keys())[:5]}")

        try:
            import fuse_mount as _fm
            nm = _fm.build_name_map(self)
        except Exception as e:
            return {"error": f"FUSE name map failed: {e}", "unlocked": 0}

        self._log.warning(f"[plex-unlock] FUSE folders sample: {list(nm.keys())[:5]}")
        unlocked = 0
        for key, hash_ in nm.items():
            parts = key.split("/", 1)
            if len(parts) != 2:
                continue
            subdir, folder = parts
            rating_key = None
            if subdir in ("movies", "movies4k"):
                rating_key = plex_movies.get(folder)
            elif subdir in ("series", "series4k"):
                rating_key = plex_series.get(folder)
            if not rating_key:
                continue
            # Already fully unlocked — just refresh metadata in case it's stale
            if self.is_cdn_unlocked(hash_):
                continue
            # Unlock all files in this transfer
            ok = self.unlock_file_cdn(hash_, mark_played=False)
            if ok:
                unlocked += 1
                self._log.warning(f"[plex-unlock] unlocked {folder} (rk={rating_key} hash={hash_[:8]})")
                # Invalidate FUSE stat cache so real size is served immediately
                try:
                    import fuse_mount as _fmx
                    if _fmx._pfs is not None:
                        _fmx._pfs._stat_invalidate(key)
                except Exception:
                    pass
                # Trigger Plex metadata refresh so it picks up real duration/size
                # now that the file is unlocked and getattr reports real size.
                plex_refresh_metadata(rating_key)

        self._log.warning(f"[plex-unlock] unlocked {unlocked} transfer(s) already in Plex")
        return {"unlocked": unlocked}

    def scan_missing_from_plex(self) -> dict:
        """Scan only items in FUSE that are not yet in the Plex library."""
        missing = self.get_missing_from_plex()
        if "error" in missing:
            return missing

        url, token, movies_section, tv_section, _, movie_root, tv_root, movie4k_root, tv4k_root = self._config()
        scanned = {"movies": [], "series": []}

        for folder in missing.get("movies", []):
            target = movie_root.rstrip("/") + "/" + folder
            self._do_refresh(url, token, movies_section, "movies", target)
            scanned["movies"].append(folder)

        for folder in missing.get("movies4k", []):
            target = movie4k_root.rstrip("/") + "/" + folder
            self._do_refresh(url, token, movies_section, "movies4k", target)
            scanned["movies"].append(folder)

        for folder in missing.get("series", []):
            target = tv_root.rstrip("/") + "/" + folder
            self._do_refresh(url, token, tv_section, "series", target)
            scanned["series"].append(folder)

        for folder in missing.get("series4k", []):
            target = tv4k_root.rstrip("/") + "/" + folder
            self._do_refresh(url, token, tv_section, "series4k", target)
            scanned["series"].append(folder)

        return {"scanned": scanned, "missing": missing}

    def _do_refresh(self, url, token, section, subdir, target_path):
        """Fire a single refresh. If a path-scoped scan is rejected, fall back to
        a full section refresh so the item still appears."""
        if target_path:
            q = urllib.parse.urlencode({"path": target_path, "X-Plex-Token": token,
                                        "includeExternalMedia": "0"})
            label = f"path '{target_path}' (section {section})"
        else:
            q = urllib.parse.urlencode({"X-Plex-Token": token,
                                        "includeExternalMedia": "0"})
            label = f"section {section} ({subdir})"
        scan_url = f"{url}/library/sections/{section}/refresh?{q}"
        try:
            r = requests.get(scan_url, timeout=10)
            if r.status_code in (200, 204):
                self._log.warning(f"[plex-add] Plex scan triggered: {label}")
            elif target_path:
                if self._fallback_full_enabled():
                    self._log.warning(
                        f"Plex path scan HTTP {r.status_code} for {label} — "
                        "falling back to full section refresh"
                    )
                    self._do_refresh(url, token, section, subdir, None)
                else:
                    self._log.warning(
                        f"Plex path scan HTTP {r.status_code} for {label}; "
                        "full-section fallback disabled"
                    )
            else:
                self._log.warning(f"Plex scan HTTP {r.status_code} for {label}")
        except requests.RequestException as e:
            self._log.warning(f"Plex scan failed for {label}: {e}")
            if target_path and self._fallback_full_enabled():
                self._do_refresh(url, token, section, subdir, None)


_plex = _PlexScanner()

log = logging.getLogger(__name__)

def _tm_log(msg: str) -> None:
    try:
        log.warning(msg)
    except Exception:
        pass


def _fuse_location(hash_: str, name: str, category: str = "", kind: str = ""):
    """Return (subdir, folder_name) for a transfer as it appears in the FUSE
    mount, e.g. ('movies', 'The.Batman.2022').

    Uses the live FUSE name map when available so the authoritative subdir and
    any dedup suffix (…_<hash8>) are honoured — that folder is exactly what Plex
    sees, so a path-scoped scan lands on the right directory. Falls back to
    computing it directly when the map isn't ready yet.
    """
    try:
        import fuse_mount as _fm
        if _fm._pfs is not None:
            nm = _fm._pfs._get_name_map()
            for key, h in nm.items():
                if h == hash_ and "/" in key:
                    sd, folder = key.split("/", 1)
                    return sd, folder
    except Exception:
        pass
    try:
        from fuse_mount import _category_subdir, _safe_name
        sd = _category_subdir(name or "", category or "", kind=kind or "")
        return sd, _safe_name(name or hash_)
    except Exception:
        return _category_subdir_fallback(name, category, kind), (name or hash_)


def _category_subdir_fallback(name, category, kind):
    return "series" if (kind == "series") else "movies"

# In-memory set of hashes that have been CDN-unlocked.
# In-memory set of unlocked hashes for fast FUSE read-path checks
# immediately without waiting for SQLite WAL visibility across connections.
_unlocked_hashes: set = set()

DB_PATH       = os.environ.get("DB_PATH", "/config/transfers.db")
# ── Stream token (moved here from app.py to avoid circular import) ────────────
import hmac as _hmac, secrets as _secrets

_TOKEN_SECRET: str = ""

def _get_token_secret() -> str:
    global _TOKEN_SECRET
    if _TOKEN_SECRET:
        return _TOKEN_SECRET
    try:
        import sys as _sys
        _app_mod = _sys.modules.get("app") or _sys.modules.get("__main__")
        _load_config = getattr(_app_mod, "_load_config", None) if _app_mod else None
        _save_config = getattr(_app_mod, "_save_config", None) if _app_mod else None
        if not _load_config:
            return _secrets.token_hex(32)
        cfg = _load_config()
        if "token_secret" not in cfg:
            cfg["token_secret"] = _secrets.token_hex(32)
            _save_config(cfg)
        _TOKEN_SECRET = cfg["token_secret"]
    except Exception:
        # Fallback: generate a process-lifetime secret if app isn't available
        _TOKEN_SECRET = _secrets.token_hex(32)
    return _TOKEN_SECRET

def _make_stream_token(hash_: str, filename: str) -> str:
    secret = _get_token_secret()
    payload = f"{hash_}:{filename}"
    return _hmac.new(secret.encode(), payload.encode(), "sha256").hexdigest()


POLL_INTERVAL = 10  # seconds between polling downloading transfers

class RateLimitError(Exception):
    def __init__(self, retry_after: int = 60):
        self.retry_after = retry_after
        super().__init__(f"Rate limited, retry after {retry_after}s")


# ── Global Premiumize API rate limiter ────────────────────────────────────────
# Hard cap: no more than PM_API_MAX_RPS calls per second to Premiumize API,
# regardless of how many threads are running. Prevents any future circular
# import or thread explosion from hammering the API.
PM_API_MAX_RPS  = int(os.environ.get("PM_API_MAX_RPS", "2"))   # calls/second
_pm_api_lock    = threading.Lock()
_pm_api_tokens  = PM_API_MAX_RPS
_pm_api_last_ts = time.time()

def _pm_api_acquire():
    """Token-bucket rate limiter. Block until a call slot is available."""
    global _pm_api_tokens, _pm_api_last_ts
    while True:
        with _pm_api_lock:
            now = time.time()
            elapsed = now - _pm_api_last_ts
            _pm_api_tokens = min(PM_API_MAX_RPS, _pm_api_tokens + elapsed * PM_API_MAX_RPS)
            _pm_api_last_ts = now
            if _pm_api_tokens >= 1:
                _pm_api_tokens -= 1
                return
        time.sleep(0.1)

# ── CDN unlock cool-down ──────────────────────────────────────────────────────
# After the one-time "Import Complete" latch is set, every NEW library file



class TransferManager:
    def __init__(self, pm_api_key_fn, directdl_fn, cache_check_fn):
        self._key_fn      = pm_api_key_fn
        self._directdl_fn = directdl_fn
        self._cache_fn    = cache_check_fn
        self._lock        = threading.Lock()
        self._local       = threading.local()  # per-thread connections
        self._init_db()
        self._start_poller()

    # ── DB ────────────────────────────────────────────────────────────────────

    def _make_conn(self):
        os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
        conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
        conn.row_factory = sqlite3.Row
        # WAL mode allows concurrent reads while a write is in progress
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-8000")  # 8 MB page cache
        return conn

    def _db(self):
        """Return a per-thread connection, creating one if needed.
        Each thread (FUSE read threads, poller, Flask workers) gets its own
        SQLite connection so concurrent reads never collide.  WAL mode means
        readers never block writers and vice-versa.
        """
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = self._make_conn()
            self._local.conn = conn
        else:
            try:
                conn.execute("SELECT 1")
            except Exception:
                conn = self._make_conn()
                self._local.conn = conn
        return conn

    def _init_db(self):
        with self._lock:
            self._db().execute("""
                CREATE TABLE IF NOT EXISTS transfers (
                    hash            TEXT PRIMARY KEY,
                    name            TEXT,
                    state           TEXT DEFAULT 'queued',
                    pm_transfer_id  TEXT,
                    error           TEXT,
                    added_at        REAL,
                    updated_at      REAL,
                    category        TEXT DEFAULT ''
                )
            """)
            # Migrate existing DBs — add any missing columns
            cols = {row[1] for row in self._db().execute("PRAGMA table_info(transfers)")}
            if "category" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN category TEXT DEFAULT ''")
            if "size" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN size INTEGER DEFAULT 0")
            if "imported" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN imported INTEGER DEFAULT 0")
            if "kind" not in cols:
                # 'movie' | 'series' | '' (unknown — classified from file paths on first directdl)
                self._db().execute("ALTER TABLE transfers ADD COLUMN kind TEXT DEFAULT ''")
            if "cdn_unlocked" not in cols:
                # 0 = serve stub bytes, 1 = serve real CDN bytes
                # Set to 1 per-transfer by "Import Complete" so new transfers
                # added afterwards still get stubs for their initial Plex scan.
                self._db().execute("ALTER TABLE transfers ADD COLUMN cdn_unlocked INTEGER DEFAULT 0")
            if "streamable_at" not in cols:
                # Epoch seconds of when this transfer first became streamable
                # (cached/complete). Anchors the per-file CDN cool-down window.
                self._db().execute("ALTER TABLE transfers ADD COLUMN streamable_at REAL")
                # Backfill existing streamable rows with a past timestamp so the
                # new cool-down gating treats them as already elapsed and never
                # traps previously-visible content as a stub after upgrade.
                self._db().execute(
                    "UPDATE transfers SET streamable_at = COALESCE(added_at, updated_at) "
                    "WHERE state IN ('cached','complete') AND streamable_at IS NULL"
                )

            # Index on state for fast streamable_hashes + poll queries
            self._db().execute(
                "CREATE INDEX IF NOT EXISTS idx_transfers_state ON transfers(state)"
            )

            # ── Persistent file list table ────────────────────────────────────
            # Stores directdl results permanently so we never call directdl
            # again just to serve Plex scans or FUSE readdir/getattr calls.
            # CDN URLs are stored and only refreshed when they actually expire
            # (403/410) during a real playback read.
            self._db().execute("""
                CREATE TABLE IF NOT EXISTS files (
                    hash        TEXT NOT NULL,
                    name        TEXT NOT NULL,
                    path        TEXT DEFAULT '',
                    size        INTEGER DEFAULT 0,
                    cdn_url     TEXT DEFAULT '',
                    cdn_expires REAL DEFAULT 0,
                    PRIMARY KEY (hash, name)
                )
            """)
            self._db().execute(
                "CREATE INDEX IF NOT EXISTS idx_files_hash ON files(hash)"
            )
            file_cols = {row[1] for row in self._db().execute("PRAGMA table_info(files)")}
            if "cdn_unlocked" not in file_cols:
                # Per-file playback unlock. This lets a season-pack torrent keep
                # every other episode as a stub while only the file being played
                # flips to real CDN bytes.
                self._db().execute("ALTER TABLE files ADD COLUMN cdn_unlocked INTEGER DEFAULT 0")
            if "cdn_played" not in file_cols:
                # Once played, this file is never re-locked by the stub TTL sweeper.
                self._db().execute("ALTER TABLE files ADD COLUMN cdn_played INTEGER DEFAULT 0")

            # ── Persistent key/value meta table ───────────────────────────────
            self._db().execute("""
                CREATE TABLE IF NOT EXISTS meta (
                    key   TEXT PRIMARY KEY,
                    value TEXT
                )
            """)
            self._db().commit()
            # Restore unlocked hashes from DB on startup
            global _unlocked_hashes
            rows = self._db().execute(
                "SELECT hash FROM transfers WHERE cdn_unlocked=1"
            ).fetchall()
            _unlocked_hashes = {r[0] for r in rows}
            if _unlocked_hashes:
                log.debug(f"Restored {len(_unlocked_hashes)} CDN-unlocked transfer(s) from DB")

    def _get(self, hash_: str):
        row = self._db().execute(
            "SELECT * FROM transfers WHERE hash=?", (hash_,)
        ).fetchone()
        return dict(row) if row else None

    def _set(self, hash_: str, **kwargs):
        kwargs["updated_at"] = time.time()
        with self._lock:
            existing = self._get(hash_)
            # Stamp the cool-down anchor the first time a transfer becomes
            # streamable, so its per-file CDN cool-down window starts now.
            if kwargs.get("state") in ("cached", "complete") and not (
                existing and existing.get("streamable_at")
            ):
                kwargs.setdefault("streamable_at", time.time())
            if existing:
                sets = ", ".join(f"{k}=?" for k in kwargs)
                vals = list(kwargs.values()) + [hash_]
                self._db().execute(f"UPDATE transfers SET {sets} WHERE hash=?", vals)
            else:
                kwargs.setdefault("added_at", time.time())
                kwargs["hash"] = hash_
                cols = ", ".join(kwargs.keys())
                plac = ", ".join("?" for _ in kwargs)
                self._db().execute(
                    f"INSERT INTO transfers ({cols}) VALUES ({plac})",
                    list(kwargs.values())
                )
            self._db().commit()

    def _set_many(self, rows: list[dict]):
        """Bulk upsert — used by restore to avoid per-row lock overhead."""
        with self._lock:
            now = time.time()
            for kwargs in rows:
                kwargs.setdefault("added_at", now)
                kwargs["updated_at"] = now
                kwargs.setdefault("state", "cached")
                if kwargs.get("state") in ("cached", "complete"):
                    kwargs.setdefault("streamable_at", now)
                cols = ", ".join(kwargs.keys())
                plac = ", ".join("?" for _ in kwargs)
                upd  = ", ".join(f"{k}=excluded.{k}" for k in kwargs if k != "hash")
                self._db().execute(
                    f"INSERT INTO transfers ({cols}) VALUES ({plac}) "
                    f"ON CONFLICT(hash) DO UPDATE SET {upd}",
                    list(kwargs.values())
                )
            self._db().commit()

    # ── File list DB helpers ──────────────────────────────────────────────────

    def _db_get_files(self, hash_: str) -> list:
        """Return stored file list for hash from DB. Empty list if none stored."""
        rows = self._db().execute(
            "SELECT name, path, size, cdn_url, cdn_expires, cdn_unlocked FROM files WHERE hash=?",
            (hash_,)
        ).fetchall()
        return [dict(r) for r in rows]

    def _db_store_files(self, hash_: str, files: list):
        """Persist a directdl file list to the DB. Overwrites existing entries.

        Preserve per-file cdn_unlocked and cdn_played flags across CDN URL
        refreshes, otherwise a played file could fall back to stub mode after
        a directdl refresh.
        """
        now = time.time()
        with self._lock:
            old_rows = self._db().execute(
                "SELECT name, path, cdn_unlocked, cdn_played FROM files WHERE hash=?", (hash_,)
            ).fetchall()
            unlocked_by_name = {}
            played_by_name   = {}
            for r in old_rows:
                keys = []
                if r["name"]:
                    keys.append(r["name"])
                if r["path"]:
                    keys.append(r["path"])
                    keys.append(os.path.basename(r["path"]))
                if int(r["cdn_unlocked"] or 0):
                    for k in keys:
                        unlocked_by_name[k] = 1
                try:
                    played_val = int(r["cdn_played"] or 0)
                except (IndexError, KeyError):
                    played_val = 0
                if played_val:
                    for k in keys:
                        played_by_name[k] = 1
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            for f in files:
                name = f.get("name", "") or ""
                path = f.get("path", "") or ""
                bname = os.path.basename(path)
                unlocked = 1 if (unlocked_by_name.get(name) or unlocked_by_name.get(path) or unlocked_by_name.get(bname)) else 0
                played   = 1 if (played_by_name.get(name)   or played_by_name.get(path)   or played_by_name.get(bname))   else 0
                self._db().execute(
                    "INSERT OR REPLACE INTO files (hash, name, path, size, cdn_url, cdn_expires, cdn_unlocked, cdn_played) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        hash_,
                        name,
                        path,
                        int(f.get("size", 0) or 0),
                        f.get("link", ""),
                        now + 172800,  # CDN URLs valid ~48h
                        unlocked,
                        played,
                    )
                )
            self._db().commit()
        log.debug(f"[{hash_[:8]}] stored {len(files)} file(s) to DB")

    def _db_update_cdn_url(self, hash_: str, name: str, cdn_url: str):
        """Update a single file's CDN URL after a forced refresh."""
        with self._lock:
            self._db().execute(
                "UPDATE files SET cdn_url=?, cdn_expires=? WHERE hash=? AND name=?",
                (cdn_url, time.time() + 172800, hash_, name)
            )
            self._db().commit()

    def _db_files_to_list(self, rows: list) -> list:
        """Convert DB file rows to the standard file-list dict format."""
        try:
            pass
        except Exception:
            pass
        import urllib.parse as _up
        video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
                      ".wmv", ".flv", ".webm"}
        result = []
        for r in rows:
            name = r.get("name") or ""
            cdn  = r.get("cdn_url") or ""
            if not name:
                continue  # skip corrupt DB rows with NULL name
            ext  = os.path.splitext(name)[1].lower()
            token = ""
            if cdn and _make_stream_token:
                try:
                    token = _make_stream_token(r.get("hash", ""), name)
                except Exception:
                    pass
            result.append({
                "name":       name,
                "path":       r.get("path", ""),
                "link":       cdn,
                "size":       int(r.get("size", 0) or 0),
                "is_video":   ext in video_exts,
                "cdn_expires": r.get("cdn_expires", 0),
                "stream_url": (
                    f"/api/stream/{token}?h={r.get('hash','')}&f={_up.quote(name)}"
                    if token else ""
                ),
            })
        return result

    # ── Public API ────────────────────────────────────────────────────────────

    def add(self, hash_: str, name: str):
        hash_ = hash_.lower()
        existing = self._get(hash_)
        if existing and existing["state"] in ("cached", "downloading", "complete"):
            if existing.get("name") == hash_ and name and name != hash_:
                self._set(hash_, name=name)
            return self._get(hash_)
        self._set(hash_, name=name, state="queued")
        # Use the app-level pool if available, else fall back to a plain thread
        try:
            import sys as _sys
            _app_mod = _sys.modules.get("app") or _sys.modules.get("__main__")
            _import_pool = getattr(_app_mod, "_import_pool", None) if _app_mod else None
            if _import_pool:
                _import_pool.submit(self._process, hash_)
            else:
                raise ImportError("_import_pool not available")
        except Exception:
            threading.Thread(target=self._process, args=(hash_,), daemon=True).start()
        return self._get(hash_)

    def delete(self, hash_: str):
        # Remove symlinks before deleting from DB so we still have name/files
        with self._lock:
            self._db().execute("DELETE FROM transfers WHERE hash=?", (hash_,))
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            self._db().commit()

    def get_transfer(self, hash_: str):
        return self._get(hash_)

    def all_transfers(self):
        rows = self._db().execute("SELECT * FROM transfers").fetchall()
        return [dict(r) for r in rows]

    def streamable_hashes(self):
        rows = self._db().execute(
            "SELECT hash FROM transfers WHERE state IN ('cached','complete')"
        ).fetchall()
        return [r["hash"] for r in rows]

    def get_files(self, hash_: str, force: bool = False) -> list:
        """Return file list for hash.

        Serves from the persistent DB unless:
        - force=True (caller has detected a CDN expiry and needs a refresh)
        - DB has no entries for this hash yet (first-time fetch)

        When a fresh directdl call is made the result is written to the DB
        so subsequent calls are free forever.
        """
        t = self._get(hash_)
        if not t or t["state"] not in ("cached", "complete"):
            return []

        if not force:
            db_rows = self._db_get_files(hash_)
            if db_rows:
                # Attach hash to each row so _db_files_to_list can build tokens
                for r in db_rows:
                    r["hash"] = hash_
                result = self._db_files_to_list(db_rows)
                if result:
                    return result

        # DB miss or forced refresh — call directdl once and persist
        api_key = self._key_fn()
        if not api_key:
            log.error(
                f"[{hash_[:8]}] get_files: PREMIUMIZE_API_KEY is not set — "
                "FUSE directory will appear empty until the key is configured"
            )
            return []
        name = t.get("name") or hash_
        files = self._directdl_fn(hash_, name, force=force)
        if files:
            self._db_store_files(hash_, files)
        return files

    def refresh_cdn_url(self, hash_: str, filename: str) -> str | None:
        """Force-refresh the CDN URL for a single file after a 403/410.
        Updates the DB and returns the new URL, or None on failure.
        This is the ONLY path that should trigger a new directdl call
        after initial import — and only when a real playback read fails.
        """
        t = self._get(hash_)
        if not t:
            return None
        name = t.get("name") or hash_
        log.info(f"[{hash_[:8]}] CDN URL expired for {filename} — refreshing")
        files = self._directdl_fn(hash_, name, force=True)
        if not files:
            return None
        self._db_store_files(hash_, files)
        for f in files:
            if f.get("name") == filename or f.get("path", "").endswith(filename):
                return f.get("link")
        return None

    def is_cdn_unlocked(self, hash_: str) -> bool:
        """Return True if this transfer should serve real CDN bytes instead of
        stub bytes.

        A transfer is unlocked only once it has been explicitly promoted —
        either by the one-time "Import Complete" latch (which unlocks everything
        cached at that moment) or by the cool-down sweeper, which flips a newly
        added file to real bytes after it has been played.
        stub until played. Until then it stays a stub, so add-time
        scans cost no Premiumize bandwidth.

        Checks the in-memory set first so FUSE threads see a promotion
        immediately, without any SQLite cross-thread visibility delay.
        """
        global _unlocked_hashes
        if hash_ in _unlocked_hashes:
            return True
        # Fall back to DB (e.g. after a restart, before the set is repopulated)
        try:
            row = self._db().execute(
                "SELECT cdn_unlocked FROM transfers WHERE hash=?", (hash_,)
            ).fetchone()
            result = bool(row and row[0])
            if result:
                _unlocked_hashes.add(hash_)  # cache it in memory
            return result
        except Exception as e:
            log.debug(f"is_cdn_unlocked error for {hash_[:8]}: {e}")
            return False

    def is_file_cdn_unlocked(self, hash_: str, filename: str | None = None) -> bool:
        """Return true when this exact file should serve real CDN bytes.

        Per-file unlock wins first. Transfer-level unlock remains as a backwards
        compatible fallback for old imports / Import Complete.
        """
        if not filename:
            return self.is_cdn_unlocked(hash_)
        base = os.path.basename(filename or "")
        try:
            row = self._db().execute(
                """
                SELECT cdn_unlocked, cdn_played
                FROM files
                WHERE hash=? AND (name=? OR path=? OR path LIKE ?)
                LIMIT 1
                """,
                (hash_, base, filename, "%/" + base),
            ).fetchone()
            if row and int(row[0] or 0):
                return True
        except Exception as e:
            log.debug(f"is_file_cdn_unlocked error for {hash_[:8]}/{base}: {e}")
        return self.is_cdn_unlocked(hash_)

    def is_file_played(self, hash_: str, filename: str) -> bool:
        """Return True if this file has ever been played (cdn_played=1).
        Played files are never re-locked by the stub TTL sweeper."""
        base = os.path.basename(filename or "")
        try:
            row = self._db().execute(
                "SELECT cdn_played FROM files WHERE hash=? AND (name=? OR path=? OR path LIKE ?) LIMIT 1",
                (hash_, base, filename, "%/" + base),
            ).fetchone()
            return bool(row and int(row[0] or 0))
        except Exception as e:
            log.debug(f"is_file_played error for {hash_[:8]}/{base}: {e}")
        return False

    def unlock_file_cdn(self, hash_: str, filename: str | None = None,
                         mark_played: bool = False) -> bool:
        """Unlock one file inside a transfer for CDN streaming.

        mark_played=True: also sets cdn_played=1, which permanently exempts this
        file from the stub TTL sweeper. Pass this flag when the unlock is
        triggered by actual playback (Plex webhook), not just a pre-unlock.
        If filename is omitted, unlocks the whole transfer.
        """
        global _unlocked_hashes
        hash_ = (hash_ or "").lower().strip()
        if not hash_:
            return False
        base = os.path.basename(filename or "") if filename else ""
        with self._lock:
            if base:
                played_sql = ", cdn_played=1" if mark_played else ""
                cur = self._db().execute(
                    f"UPDATE files SET cdn_unlocked=1{played_sql} "
                    "WHERE hash=? AND (name=? OR path=? OR path LIKE ?)",
                    (hash_, base, filename, "%/" + base),
                )
                changed = cur.rowcount or 0
                self._db().commit()
                if changed:
                    return True
                return False
            played_sql = ", cdn_played=1" if mark_played else ""
            self._db().execute(
                f"UPDATE transfers SET cdn_unlocked=1 WHERE hash=?", (hash_,)
            )
            if mark_played:
                self._db().execute(
                    "UPDATE files SET cdn_played=1 WHERE hash=?", (hash_,)
                )
            self._db().commit()
            _unlocked_hashes.add(hash_)
            return True

    def find_hash_by_filename(self, filename: str) -> str | None:
        """Look up a transfer hash by a video filename — used by Tautulli webhook
        to match a Plex-reported filename back to a Premiumize hash."""
        # Exact match first
        row = self._db().execute(
            "SELECT hash FROM files WHERE name=? LIMIT 1", (filename,)
        ).fetchone()
        if row:
            return row[0]
        # Fuzzy: strip extension and compare normalised names
        import re as _re
        stem = _re.sub(r'\.[^.]+$', '', filename).lower()
        stem_norm = _re.sub(r'[^a-z0-9]', '', stem)
        rows = self._db().execute("SELECT hash, name FROM files").fetchall()
        for r in rows:
            n = _re.sub(r'\.[^.]+$', '', r[1]).lower()  # r[1] is name
            if _re.sub(r'[^a-z0-9]', '', n) == stem_norm:
                return r[0]  # return hash
        return None


    # ── Processing ────────────────────────────────────────────────────────────

    def _process(self, hash_: str):
        t = self._get(hash_)
        if not t:
            return
        if t["state"] in ("cached", "complete", "downloading"):
            return
        try:
            cached_map = self._cache_fn([{"info_hash": hash_}])
            is_cached  = cached_map.get(hash_, False)
            if is_cached:
                log.info(f"[{hash_[:8]}] Cached — ready to stream")
                self._set(hash_, state="cached")
                t2 = self._get(hash_)
                # Create fake import file and pre-warm FUSE cache immediately
                try:
                    import qbt_mock as _qbt
                    from name_match import classify, classify_from_files
                    _name     = t2.get("name") or hash_
                    _category = t2.get("category") or ""
                    _files    = self.get_files(hash_) or []

                    # Classify from file paths (ground truth) and persist to DB
                    _kind = classify_from_files(_files)
                    if _kind and not t2.get("kind"):
                        self._set(hash_, kind=_kind)
                    else:
                        _kind = t2.get("kind") or _kind or classify(_name, _files)

                    # Pre-warm FUSE file cache so readdir is instant
                    if _files:
                        try:
                            import fuse_mount as _fm
                            import time as _time
                            if _fm._pfs is not None:
                                with _fm._pfs._lock:
                                    _fm._pfs._file_cache[hash_] = (_files, _time.time() + _fm.DIRECTDL_TTL)
                                _fm._pfs._invalidate_name_map()
                        except Exception:
                            pass

                    _fn = _qbt._pick_fake_filename(_name, _files)
                    _qbt._make_fake_file(_category, _qbt._safe_name(_name), _fn, _files)
                except Exception as _e:
                    log.debug(f"Fake file / classify failed: {_e}")
                    _kind = "movie"

                # Notify Plex using the authoritative kind — scan just this
                # item's folder so Plex doesn't walk the whole section.
                t2 = self._get(hash_)
                subdir, folder = _fuse_location(
                    hash_, t2.get("name", ""), t2.get("category", ""), t2.get("kind", "")
                )
                _plex.notify_ready(subdir, folder)
                # Unlock immediately so the file is playable as soon as it
                # appears in Plex. The stub is served during the scan window
                # (zero CDN), then the metadata refresh after unlock fetches
                # one small header block to update duration/size in Plex.
                self.unlock_file_cdn(hash_, mark_played=False)
                log.info(f"[{hash_[:8]}] Unlocked immediately on arrival — ready to play")
            else:
                log.info(f"[{hash_[:8]}] Not cached — creating Premiumize transfer")
                pm_id = self._create_transfer(hash_, t.get("name") or hash_)
                if not pm_id:
                    self._set(hash_, state="error", error="Failed to create transfer")
                    return
                self._set(hash_, state="downloading", pm_transfer_id=pm_id)
        except Exception as e:
            log.exception(f"[{hash_[:8]}] Processing error")
            self._set(hash_, state="error", error=str(e))

    def _create_transfer(self, hash_: str, name: str):
        api_key = self._key_fn()
        if not api_key:
            return None
        magnet = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
        try:
            _pm_api_acquire()
            r = requests.post(
                "https://www.premiumize.me/api/transfer/create",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data=urllib.parse.urlencode({"src": magnet}),
                timeout=20,
            )
            r.raise_for_status()
            data = r.json()
            if data.get("status") == "success":
                return data.get("id")
        except Exception as e:
            log.warning(f"create_transfer error: {e}")
        return None

    # ── Background poller ─────────────────────────────────────────────────────

    def _start_poller(self):
        _POLLER_STARTED = getattr(TransferManager, "_poller_started", False)
        if _POLLER_STARTED:
            log.warning("Poll loop already started — skipping duplicate _start_poller call")
            return
        TransferManager._poller_started = True
        threading.Thread(target=self._poll_loop, daemon=True, name="pm-poller").start()
        # Refresh expired CDN URLs for unlocked files in the background at startup
        threading.Thread(target=self._cdn_refresh_loop, daemon=True, name="pm-cdn-refresh").start()

    def _cdn_refresh_loop(self):
        """Runs _refresh_expired_cdn_urls on startup then every 12 hours."""
        import time as _time
        self._refresh_expired_cdn_urls()
        while True:
            _time.sleep(12 * 3600)  # 12 hours
            self._refresh_expired_cdn_urls()

    def _refresh_expired_cdn_urls(self):
        """On startup, refresh CDN URLs for unlocked files that are expired or
        expiring within 24 hours.

        CDN URLs are valid for ~48h. We refresh anything with less than 24h
        remaining so users never hit a 403 mid-session. Only unlocked files
        are checked — locked stubs don't need valid CDN URLs.

        Rate-limited via _pm_api_acquire() to avoid hammering the Premiumize API.
        """
        import time as _time
        _time.sleep(10)  # Wait for app and FUSE to finish initialising
        now = _time.time()
        soon = now + 86400  # 24 hours from now

        try:
            # Get one row per transfer (not per file) to avoid refreshing same
            # transfer multiple times when it has many files
            rows = self._db().execute(
                """SELECT DISTINCT t.hash, t.name
                   FROM transfers t
                   JOIN files f ON f.hash = t.hash
                   WHERE f.cdn_unlocked = 1
                   AND (f.cdn_expires < ? OR f.cdn_expires = 0)
                   AND t.state IN ('cached', 'complete')
                   ORDER BY f.cdn_expires ASC""",
                (soon,)
            ).fetchall()
        except Exception as e:
            log.warning(f"[cdn-refresh] startup query failed: {e}")
            return

        if not rows:
            log.info("[cdn-refresh] all CDN URLs are fresh — nothing to refresh")
            return

        expired  = sum(1 for r in rows if self._db().execute(
            "SELECT COUNT(*) FROM files WHERE hash=? AND cdn_expires < ? AND cdn_expires > 0",
            (r["hash"], now)).fetchone()[0] > 0)
        expiring = len(rows) - expired
        log.warning(f"[cdn-refresh] startup: {expired} expired, {expiring} expiring within 24h — refreshing {len(rows)} transfers")

        refreshed = 0
        failed = 0
        for row in rows:
            try:
                _pm_api_acquire()
                name = row["name"] or row["hash"]
                files = self._directdl_fn(row["hash"], name, force=True)
                if files:
                    self._db_store_files(row["hash"], files)
                    refreshed += 1
                else:
                    failed += 1
            except Exception as e:
                log.debug(f"[cdn-refresh] failed for {row['hash'][:8]}: {e}")
                failed += 1

        log.warning(f"[cdn-refresh] done — refreshed {refreshed}, failed {failed}")

    def _poll_loop(self):
        # File lock ensures only one poll loop runs across all processes/restarts
        import fcntl
        try:
            _lf = open("/tmp/pm_poller.lock", "w")
            fcntl.flock(_lf, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            log.warning("Poll loop already running in another process — this instance will not poll")
            return

        backoff = 0  # seconds to wait after a 429
        while True:
            if backoff > 0:
                time.sleep(backoff)
                backoff = 0
            try:
                self._poll_all()
            except RateLimitError as e:
                backoff = min(e.retry_after, 300)
                log.warning(f"poll_all rate-limited — backing off {backoff}s")
            except Exception:
                log.exception("Poller error")
            time.sleep(POLL_INTERVAL)

    def _poll_all(self):
        rows = self._db().execute(
            "SELECT hash, name, pm_transfer_id FROM transfers WHERE state='downloading'"
        ).fetchall()
        if not rows:
            return

        api_key = self._key_fn()
        if not api_key:
            return

        try:
            _pm_api_acquire()
            r = requests.get(
                "https://www.premiumize.me/api/transfer/list",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=15,
            )
            if r.status_code == 429:
                retry_after = int(r.headers.get("Retry-After", 60))
                raise RateLimitError(retry_after)
            r.raise_for_status()
            data = r.json()
        except RateLimitError:
            raise
        except Exception as e:
            log.warning(f"poll_all error: {e}")
            return

        pm_map = {str(t["id"]): t for t in data.get("transfers", [])}

        for row in rows:
            hash_  = row["hash"]
            pm_id  = row["pm_transfer_id"]
            t      = pm_map.get(str(pm_id))
            if not t:
                continue
            status = t.get("status", "")
            if status in ("finished", "seeding"):
                log.info(f"[{hash_[:8]}] Transfer complete — ready to stream")
                self._set(hash_, state="complete")
                t2 = self._get(hash_)
                try:
                    import qbt_mock as _qbt
                    from name_match import classify_from_files
                    _name     = t2.get("name") or hash_
                    _category = t2.get("category") or ""
                    _files    = self.get_files(hash_) or []
                    # Classify from file paths and persist to DB
                    _kind = classify_from_files(_files)
                    if _kind and not t2.get("kind"):
                        self._set(hash_, kind=_kind)
                    _fn = _qbt._pick_fake_filename(_name, _files)
                    _qbt._make_fake_file(_category, _qbt._safe_name(_name), _fn, _files)
                except Exception as _e:
                    log.debug(f"Fake file creation skipped: {_e}")
                t2 = self._get(hash_)
                subdir, folder = _fuse_location(
                    hash_, t2.get("name", ""), t2.get("category", ""), t2.get("kind", "")
                )
                _plex.notify_ready(subdir, folder)
                # Unlock immediately so playback works as soon as Plex imports
                self.unlock_file_cdn(hash_, mark_played=False)
                log.info(f"[{hash_[:8]}] Unlocked immediately on download complete")
            elif status == "error":
                self._set(hash_, state="error", error=t.get("message", "unknown"))



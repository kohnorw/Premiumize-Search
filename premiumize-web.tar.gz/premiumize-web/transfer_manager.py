"""
Transfer manager — tracks torrent state using SQLite.

States:
  queued      → just received, not yet checked
  cached      → Premiumize has it cached, ready to stream
  downloading → not cached, transfer created on Premiumize, polling
  complete    → transfer finished, ready to stream
  error       → something went wrong

CDN URLs are intentionally NOT stored — they expire after a few hours.
Instead we store only hash + name and call directdl fresh each time.
The FUSE layer caches directdl responses in memory with a TTL.
"""

import logging
import os
import sqlite3
import threading
import time
import urllib.parse

import requests


# ── Plex library scan (debounced) ─────────────────────────────────────────────
# Waits PLEX_SCAN_DEBOUNCE seconds after the last ready-state transition before
# triggering a scan. A bulk import of 50 files fires exactly one scan, not 50.

class _PlexScanner:
    """Debounced Plex partial-library scanner."""

    DEBOUNCE = int(os.environ.get("PLEX_SCAN_DEBOUNCE", "30"))  # seconds

    def __init__(self):
        self._lock        = threading.Lock()
        self._timer: threading.Timer | None = None
        self._pending_dirs: set = set()
        self._log = logging.getLogger(__name__ + ".plex")

    def _config(self):
        """Return (url, token) from env, or (None, None) if not configured."""
        url   = os.environ.get("PLEX_URL", "").rstrip("/")
        token = os.environ.get("PLEX_TOKEN", "")
        return (url, token) if url and token else (None, None)

    def notify_ready(self, subdir: str):
        """
        Call when a transfer becomes cached/complete.
        subdir is "movies" or "series" — the FUSE subdirectory that changed.
        """
        url, token = self._config()
        if not url:
            return  # Plex not configured — silent no-op

        with self._lock:
            self._pending_dirs.add(subdir)
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(self.DEBOUNCE, self._fire)
            self._timer.daemon = True
            self._timer.start()
            self._log.debug(
                f"Plex scan scheduled in {self.DEBOUNCE}s "                f"(queued dirs: {self._pending_dirs})"
            )

    def _fire(self):
        with self._lock:
            dirs = set(self._pending_dirs)
            self._pending_dirs.clear()
            self._timer = None

        url, token = self._config()
        if not url or not token:
            return

        # Map FUSE subdirs to Plex section keys
        subdir_map = {
            "movies": os.environ.get("PLEX_MOVIES_SECTION", "1"),
            "series": os.environ.get("PLEX_TV_SECTION",     "2"),
        }

        for subdir in dirs:
            section = subdir_map.get(subdir)
            if not section:
                continue
            scan_url = (
                f"{url}/library/sections/{section}/refresh"
                f"?X-Plex-Token={token}"
            )
            try:
                r = requests.get(scan_url, timeout=10)
                if r.status_code in (200, 204):
                    self._log.info(
                        f"Plex scan triggered for section {section} ({subdir})"
                    )
                else:
                    self._log.warning(
                        f"Plex scan returned HTTP {r.status_code} "                        f"for section {section}"
                    )
            except requests.RequestException as e:
                self._log.warning(f"Plex scan request failed: {e}")


_plex = _PlexScanner()

log = logging.getLogger(__name__)

DB_PATH       = os.environ.get("DB_PATH", "/config/transfers.db")
POLL_INTERVAL = 10  # seconds between polling downloading transfers


class TransferManager:
    def __init__(self, pm_api_key_fn, directdl_fn, cache_check_fn):
        self._key_fn      = pm_api_key_fn
        self._directdl_fn = directdl_fn
        self._cache_fn    = cache_check_fn
        self._lock        = threading.Lock()
        self._conn        = self._make_conn()
        self._init_db()
        self._start_poller()

    # ── DB ────────────────────────────────────────────────────────────────────

    def _make_conn(self):
        os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
        conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
        conn.row_factory = sqlite3.Row
        # WAL mode allows concurrent reads while a write is in progress
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-8000")  # 8 MB page cache
        return conn

    def _db(self):
        """Return the shared connection, reconnecting if needed."""
        try:
            self._conn.execute("SELECT 1")
        except Exception:
            self._conn = self._make_conn()
        return self._conn

    def _init_db(self):
        with self._lock:
            self._db().execute("""
                CREATE TABLE IF NOT EXISTS transfers (
                    hash            TEXT PRIMARY KEY,
                    name            TEXT,
                    state           TEXT DEFAULT 'queued',
                    pm_transfer_id  TEXT,
                    error           TEXT,
                    added_at        REAL,
                    updated_at      REAL,
                    category        TEXT DEFAULT ''
                )
            """)
            # Migrate existing DBs that predate the category column
            cols = {row[1] for row in self._db().execute("PRAGMA table_info(transfers)")}
            if "category" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN category TEXT DEFAULT ''")
            self._db().commit()

    def _get(self, hash_: str):
        row = self._db().execute(
            "SELECT * FROM transfers WHERE hash=?", (hash_,)
        ).fetchone()
        return dict(row) if row else None

    def _set(self, hash_: str, **kwargs):
        kwargs["updated_at"] = time.time()
        with self._lock:
            existing = self._get(hash_)
            if existing:
                sets = ", ".join(f"{k}=?" for k in kwargs)
                vals = list(kwargs.values()) + [hash_]
                self._db().execute(f"UPDATE transfers SET {sets} WHERE hash=?", vals)
            else:
                kwargs.setdefault("added_at", time.time())
                kwargs["hash"] = hash_
                cols = ", ".join(kwargs.keys())
                plac = ", ".join("?" for _ in kwargs)
                self._db().execute(
                    f"INSERT INTO transfers ({cols}) VALUES ({plac})",
                    list(kwargs.values())
                )
            self._db().commit()

    def _set_many(self, rows: list[dict]):
        """Bulk upsert — used by restore to avoid per-row lock overhead."""
        with self._lock:
            now = time.time()
            for kwargs in rows:
                kwargs.setdefault("added_at", now)
                kwargs["updated_at"] = now
                kwargs.setdefault("state", "cached")
                cols = ", ".join(kwargs.keys())
                plac = ", ".join("?" for _ in kwargs)
                upd  = ", ".join(f"{k}=excluded.{k}" for k in kwargs if k != "hash")
                self._db().execute(
                    f"INSERT INTO transfers ({cols}) VALUES ({plac}) "
                    f"ON CONFLICT(hash) DO UPDATE SET {upd}",
                    list(kwargs.values())
                )
            self._db().commit()

    # ── Public API ────────────────────────────────────────────────────────────

    def add(self, hash_: str, name: str):
        hash_ = hash_.lower()
        existing = self._get(hash_)
        if existing and existing["state"] in ("cached", "downloading", "complete"):
            if existing.get("name") == hash_ and name and name != hash_:
                self._set(hash_, name=name)
            return self._get(hash_)
        self._set(hash_, name=name, state="queued")
        threading.Thread(target=self._process, args=(hash_,), daemon=True).start()
        return self._get(hash_)

    def delete(self, hash_: str):
        # Remove symlinks before deleting from DB so we still have name/files
        try:
            SymlinkManager(self).remove(hash_)
        except Exception as _e:
            log.debug(f"Symlink removal skipped: {_e}")
        with self._lock:
            self._db().execute("DELETE FROM transfers WHERE hash=?", (hash_,))
            self._db().commit()

    def get_transfer(self, hash_: str):
        return self._get(hash_)

    def all_transfers(self):
        rows = self._db().execute("SELECT * FROM transfers").fetchall()
        return [dict(r) for r in rows]

    def streamable_hashes(self):
        rows = self._db().execute(
            "SELECT hash FROM transfers WHERE state IN ('cached','complete')"
        ).fetchall()
        return [r["hash"] for r in rows]

    def get_files(self, hash_: str, force: bool = False) -> list:
        t = self._get(hash_)
        if not t or t["state"] not in ("cached", "complete"):
            return []
        api_key = self._key_fn()
        if not api_key:
            log.error(
                f"[{hash_[:8]}] get_files: PREMIUMIZE_API_KEY is not set — "
                "FUSE directory will appear empty until the key is configured"
            )
            return []
        name = t.get("name") or hash_
        return self._directdl_fn(hash_, name, force=force)

    # ── Processing ────────────────────────────────────────────────────────────

    def _process(self, hash_: str):
        t = self._get(hash_)
        if not t:
            return
        if t["state"] in ("cached", "complete", "downloading"):
            return
        try:
            cached_map = self._cache_fn([{"info_hash": hash_}])
            is_cached  = cached_map.get(hash_, False)
            if is_cached:
                log.info(f"[{hash_[:8]}] Cached — ready to stream")
                self._set(hash_, state="cached")
                t2 = self._get(hash_)
                from fuse_mount import _category_subdir
                subdir = _category_subdir(t2.get("name", ""), t2.get("category", ""))
                _plex.notify_ready(subdir)
                try:
                    SymlinkManager(self).add(hash_)
                except Exception as _e:
                    log.debug(f"Symlink creation skipped: {_e}")
                # Create fake import file immediately so Radarr/Sonarr find it
                # on their next poll without waiting for a /torrents/info call
                try:
                    import qbt_mock as _qbt
                    _name   = t2.get("name") or hash_
                    _files  = self.get_files(hash_) or []
                    _fn     = _qbt._pick_fake_filename(_name, _files)
                    _qbt._make_fake_file(subdir, _qbt._safe_name(_name), _fn, _files)
                except Exception as _e:
                    log.debug(f"Fake file creation skipped: {_e}")
            else:
                log.info(f"[{hash_[:8]}] Not cached — creating Premiumize transfer")
                pm_id = self._create_transfer(hash_, t.get("name") or hash_)
                if not pm_id:
                    self._set(hash_, state="error", error="Failed to create transfer")
                    return
                self._set(hash_, state="downloading", pm_transfer_id=pm_id)
        except Exception as e:
            log.exception(f"[{hash_[:8]}] Processing error")
            self._set(hash_, state="error", error=str(e))

    def _create_transfer(self, hash_: str, name: str):
        api_key = self._key_fn()
        if not api_key:
            return None
        magnet = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
        try:
            r = requests.post(
                "https://www.premiumize.me/api/transfer/create",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data=urllib.parse.urlencode({"src": magnet}),
                timeout=20,
            )
            r.raise_for_status()
            data = r.json()
            if data.get("status") == "success":
                return data.get("id")
        except Exception as e:
            log.warning(f"create_transfer error: {e}")
        return None

    # ── Background poller ─────────────────────────────────────────────────────

    def _start_poller(self):
        threading.Thread(target=self._poll_loop, daemon=True).start()

    def _poll_loop(self):
        while True:
            try:
                self._poll_all()
            except Exception:
                log.exception("Poller error")
            time.sleep(POLL_INTERVAL)

    def _poll_all(self):
        rows = self._db().execute(
            "SELECT hash, name, pm_transfer_id FROM transfers WHERE state='downloading'"
        ).fetchall()
        if not rows:
            return

        api_key = self._key_fn()
        if not api_key:
            return

        try:
            r = requests.get(
                "https://www.premiumize.me/api/transfer/list",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=15,
            )
            r.raise_for_status()
            data = r.json()
        except Exception as e:
            log.warning(f"poll_all error: {e}")
            return

        pm_map = {str(t["id"]): t for t in data.get("transfers", [])}

        for row in rows:
            hash_  = row["hash"]
            pm_id  = row["pm_transfer_id"]
            t      = pm_map.get(str(pm_id))
            if not t:
                continue
            status = t.get("status", "")
            if status in ("finished", "seeding"):
                log.info(f"[{hash_[:8]}] Transfer complete — ready to stream")
                self._set(hash_, state="complete")
                t2 = self._get(hash_)
                from fuse_mount import _category_subdir
                subdir = _category_subdir(t2.get("name", ""), t2.get("category", ""))
                _plex.notify_ready(subdir)
                try:
                    SymlinkManager(self).add(hash_)
                except Exception as _e:
                    log.debug(f"Symlink creation skipped: {_e}")
                # Create fake import file immediately
                try:
                    import qbt_mock as _qbt
                    _name   = t2.get("name") or hash_
                    _files  = self.get_files(hash_) or []
                    _fn     = _qbt._pick_fake_filename(_name, _files)
                    _qbt._make_fake_file(subdir, _qbt._safe_name(_name), _fn, _files)
                except Exception as _e:
                    log.debug(f"Fake file creation skipped: {_e}")
            elif status == "error":
                self._set(hash_, state="error", error=t.get("message", "unknown"))


# ── Symlink manager ───────────────────────────────────────────────────────────

class SymlinkManager:
    """
    Creates per-file symlinks in SYMLINK_ROOT so Radarr/Sonarr can import and
    delete cleanly without needing access to the FUSE mount.

    Layout (one symlink per video file, not per folder):
      /docker/premiumize-web/downloads/
        movies/
          The.Dark.Knight.2008.2160p.mkv  →  /mnt/movies/The.Dark.Knight.../The.Dark.Knight.2008.2160p.mkv
        series/
          Breaking.Bad.S01E01.mkv         →  /mnt/series/Breaking.Bad.S01/Breaking.Bad.S01E01.mkv

    Using file-level symlinks (not folder symlinks) means:
    - Radarr/Sonarr see individual importable files
    - Deleting after import just unlinks the symlink — nothing touches the FUSE mount
    - No risk of Radarr trying to rm -rf a folder symlink and failing
    """

    SYMLINK_ROOT = os.environ.get("SYMLINK_ROOT",   "/docker/premiumize-web/downloads")
    FUSE_ROOT    = os.environ.get("FUSE_MOUNTPOINT", "/docker/premiumize-web/mnt")

    # Video extensions we expose as symlinks
    VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
                  ".wmv", ".flv", ".webm", ".m2ts", ".mpg", ".mpeg"}

    def __init__(self, transfer_manager):
        self._tm      = transfer_manager
        self._log     = logging.getLogger(__name__ + ".symlinks")
        self._lock    = threading.Lock()
        self._enabled = os.environ.get("ENABLE_SYMLINKS", "true").lower() != "false"
        if self._enabled:
            os.makedirs(os.path.join(self.SYMLINK_ROOT, "movies"), exist_ok=True)
            os.makedirs(os.path.join(self.SYMLINK_ROOT, "series"), exist_ok=True)
            self._log.info(f"Symlink manager ready at {self.SYMLINK_ROOT}")

    def _is_video(self, filename: str) -> bool:
        _, ext = os.path.splitext(filename)
        return ext.lower() in self.VIDEO_EXTS

    def _safe_filename(self, name: str) -> str:
        """Sanitise a filename for use on the host filesystem."""
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)
        return name.strip(". ")[:200] or "unknown"

    # ── per-transfer helpers ──────────────────────────────────────────────────

    def _link_dir(self, subdir: str) -> str:
        return os.path.join(self.SYMLINK_ROOT, subdir)

    def _fuse_dir(self, subdir: str, folder_name: str) -> str:
        return os.path.join(self.FUSE_ROOT, subdir, folder_name)

    def _get_fuse_files(self, hash_: str) -> list[tuple[str, str, str]]:
        """
        Return list of (subdir, fuse_folder_name, filename) for all video
        files in this transfer. Returns empty if files aren't available yet.
        """
        from fuse_mount import _safe_name, _category_subdir
        t = self._tm.get_transfer(hash_)
        if not t:
            return []
        folder_name = _safe_name(t.get("name") or hash_)
        subdir      = _category_subdir(t.get("name") or "", t.get("category", ""))
        try:
            files = self._tm.get_files(hash_) or []
        except Exception:
            return []
        result = []
        for f in files:
            raw      = f.get("name") or f.get("path") or ""
            filename = os.path.basename(raw)
            if filename and self._is_video(filename):
                result.append((subdir, folder_name, filename))
        return result

    # ── public API ────────────────────────────────────────────────────────────

    def add(self, hash_: str):
        """
        Create per-file symlinks for a newly ready transfer.
        Falls back gracefully if the FUSE directdl call isn't ready yet —
        sync() will catch it on the next startup.
        """
        if not self._enabled:
            return
        entries = self._get_fuse_files(hash_)
        if not entries:
            # Files not available from directdl yet — sync() will handle it
            self._log.debug(f"[{hash_[:8]}] No files yet for symlink creation, sync() will retry")
            return
        with self._lock:
            for subdir, folder_name, filename in entries:
                safe_fn = self._safe_filename(filename)
                link    = os.path.join(self._link_dir(subdir), safe_fn)
                target  = os.path.join(self._fuse_dir(subdir, folder_name), filename)
                if os.path.islink(link):
                    continue
                try:
                    os.symlink(target, link)
                    self._log.info(f"Symlink created: {link} → {target}")
                except OSError as e:
                    self._log.warning(f"Could not create symlink {link}: {e}")

    def remove(self, hash_: str):
        """Remove all symlinks for a transfer being deleted."""
        if not self._enabled:
            return
        from fuse_mount import _safe_name, _category_subdir
        t = self._tm.get_transfer(hash_)
        if not t:
            return
        folder_name = _safe_name(t.get("name") or hash_)
        subdir      = _category_subdir(t.get("name") or "", t.get("category", ""))

        # Try to remove via file list first (most accurate)
        try:
            files = self._tm.get_files(hash_) or []
        except Exception:
            files = []

        with self._lock:
            if files:
                for f in files:
                    raw      = f.get("name") or f.get("path") or ""
                    filename = os.path.basename(raw)
                    if not filename:
                        continue
                    safe_fn = self._safe_filename(filename)
                    link    = os.path.join(self._link_dir(subdir), safe_fn)
                    if os.path.islink(link):
                        try:
                            os.unlink(link)
                            self._log.info(f"Symlink removed: {link}")
                        except OSError as e:
                            self._log.warning(f"Could not remove symlink {link}: {e}")
            else:
                # Fall back: scan the downloads dir for any symlink whose target
                # contains this transfer's FUSE folder name
                fuse_folder = self._fuse_dir(subdir, folder_name)
                folder      = self._link_dir(subdir)
                if os.path.isdir(folder):
                    for entry in os.scandir(folder):
                        if entry.is_symlink():
                            target = os.readlink(entry.path)
                            if target.startswith(fuse_folder):
                                try:
                                    os.unlink(entry.path)
                                    self._log.info(f"Symlink removed (fallback): {entry.path}")
                                except OSError as e:
                                    self._log.warning(f"Could not remove {entry.path}: {e}")

    def sync(self, transfer_manager=None):
        """
        Reconcile symlinks on startup.
        - Creates missing symlinks for all ready transfers
        - Removes stale symlinks whose FUSE target no longer exists in the DB
        """
        if not self._enabled:
            return
        tm = transfer_manager or self._tm
        from fuse_mount import _safe_name, _category_subdir

        # Build expected set: link_path → fuse_target
        expected: dict[str, str] = {}
        for h in tm.streamable_hashes():
            t = tm.get_transfer(h)
            if not t:
                continue
            folder_name = _safe_name(t.get("name") or h)
            subdir      = _category_subdir(t.get("name") or "", t.get("category", ""))
            try:
                files = tm.get_files(h) or []
            except Exception:
                files = []
            for f in files:
                raw      = f.get("name") or f.get("path") or ""
                filename = os.path.basename(raw)
                if filename and self._is_video(filename):
                    safe_fn  = self._safe_filename(filename)
                    link     = os.path.join(self._link_dir(subdir), safe_fn)
                    target   = os.path.join(self._fuse_dir(subdir, folder_name), filename)
                    expected[link] = target

        with self._lock:
            # Create missing
            for link, target in expected.items():
                if not os.path.islink(link):
                    try:
                        os.symlink(target, link)
                        self._log.info(f"Sync: created {link}")
                    except OSError as e:
                        self._log.debug(f"Sync: could not create {link}: {e}")

            # Remove stale
            for subdir in ("movies", "series"):
                folder = self._link_dir(subdir)
                if not os.path.isdir(folder):
                    continue
                for entry in os.scandir(folder):
                    if entry.is_symlink() and entry.path not in expected:
                        try:
                            os.unlink(entry.path)
                            self._log.info(f"Sync: removed stale {entry.path}")
                        except OSError as e:
                            self._log.debug(f"Sync: could not remove {entry.path}: {e}")

        self._log.info("Symlink sync complete")
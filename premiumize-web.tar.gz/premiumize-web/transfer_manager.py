"""
Transfer manager — tracks torrent state using SQLite.

States:
  queued      → just received, not yet checked
  cached      → Premiumize has it cached, ready to stream
  downloading → not cached, transfer created on Premiumize, polling
  complete    → transfer finished, ready to stream
  error       → something went wrong

CDN URLs are intentionally NOT stored — they expire after a few hours.
Instead we store only hash + name and call directdl fresh each time.
The FUSE layer caches directdl responses in memory with a TTL.
"""

import json
import logging
import os
import sqlite3
import threading
import time
import urllib.parse

import requests

log = logging.getLogger(__name__)

DB_PATH       = os.environ.get("DB_PATH", "/config/transfers.db")
POLL_INTERVAL = 10  # seconds between polling downloading transfers


class TransferManager:
    def __init__(self, pm_api_key_fn, directdl_fn, cache_check_fn):
        """
        pm_api_key_fn  : callable → str
        directdl_fn    : callable(hash, name) → list[dict]  — called fresh each time
        cache_check_fn : callable(list[dict]) → dict{hash: bool}
        """
        self._key_fn      = pm_api_key_fn
        self._directdl_fn = directdl_fn
        self._cache_fn    = cache_check_fn
        self._init_db()
        self._start_poller()

    # ── DB ────────────────────────────────────────────────────────────────────

    def _conn(self):
        os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
        conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._conn() as c:
            c.execute("""
                CREATE TABLE IF NOT EXISTS transfers (
                    hash            TEXT PRIMARY KEY,
                    name            TEXT,
                    state           TEXT DEFAULT 'queued',
                    pm_transfer_id  TEXT,
                    error           TEXT,
                    added_at        REAL,
                    updated_at      REAL,
                    category        TEXT DEFAULT ''
                )
            """)
            # Migrate existing DBs that predate the category column
            cols = {row[1] for row in c.execute("PRAGMA table_info(transfers)")}
            if "category" not in cols:
                c.execute("ALTER TABLE transfers ADD COLUMN category TEXT DEFAULT ''")

    def _get(self, hash_: str):
        with self._conn() as c:
            row = c.execute(
                "SELECT * FROM transfers WHERE hash=?", (hash_,)
            ).fetchone()
            return dict(row) if row else None

    def _set(self, hash_: str, **kwargs):
        kwargs["updated_at"] = time.time()
        existing = self._get(hash_)
        if existing:
            sets = ", ".join(f"{k}=?" for k in kwargs)
            vals = list(kwargs.values()) + [hash_]
            with self._conn() as c:
                c.execute(f"UPDATE transfers SET {sets} WHERE hash=?", vals)
        else:
            kwargs.setdefault("added_at", time.time())
            kwargs["hash"] = hash_
            cols = ", ".join(kwargs.keys())
            plac = ", ".join("?" for _ in kwargs)
            with self._conn() as c:
                c.execute(
                    f"INSERT INTO transfers ({cols}) VALUES ({plac})",
                    list(kwargs.values())
                )

    # ── Public API ────────────────────────────────────────────────────────────

    def add(self, hash_: str, name: str):
        hash_ = hash_.lower()
        existing = self._get(hash_)
        if existing and existing["state"] in ("cached", "downloading", "complete"):
            # FIX: update name if it was previously stored as just the hash
            if existing.get("name") == hash_ and name and name != hash_:
                self._set(hash_, name=name)
            return self._get(hash_)
        self._set(hash_, name=name, state="queued")
        threading.Thread(target=self._process, args=(hash_,), daemon=True).start()
        return self._get(hash_)

    def delete(self, hash_: str):
        with self._conn() as c:
            c.execute("DELETE FROM transfers WHERE hash=?", (hash_,))

    def get_transfer(self, hash_: str):
        return self._get(hash_)

    def all_transfers(self):
        with self._conn() as c:
            rows = c.execute("SELECT * FROM transfers").fetchall()
        return [dict(r) for r in rows]

    def streamable_hashes(self):
        """Hashes that are ready to stream (cached or complete)."""
        with self._conn() as c:
            rows = c.execute(
                "SELECT hash FROM transfers WHERE state IN ('cached','complete')"
            ).fetchall()
        return [r["hash"] for r in rows]

    def get_files(self, hash_: str, force: bool = False) -> list:
        """
        Returns current file list for a streamable hash by calling directdl fresh.
        The FUSE layer is responsible for caching this with a TTL.

        force=True propagates down to the directdl cache so an expired CDN URL
        can be refreshed even if a still-valid cache entry would otherwise shadow it.

        FIX: log clearly when PM_API_KEY is missing so the silent empty-mount
        case is immediately obvious in container logs.
        """
        t = self._get(hash_)
        if not t or t["state"] not in ("cached", "complete"):
            return []
        api_key = self._key_fn()
        if not api_key:
            log.error(
                f"[{hash_[:8]}] get_files: PREMIUMIZE_API_KEY is not set — "
                "FUSE directory will appear empty until the key is configured"
            )
            return []
        name = t.get("name") or hash_
        return self._directdl_fn(hash_, name, force=force)

    # ── Processing ────────────────────────────────────────────────────────────

    def _process(self, hash_: str):
        t = self._get(hash_)
        if not t:
            return
        # Skip if already resolved by the caller (e.g. qbt torrents_add did a
        # synchronous cache check and already set state=cached)
        if t["state"] in ("cached", "complete", "downloading"):
            return
        try:
            cached_map = self._cache_fn([{"info_hash": hash_}])
            is_cached  = cached_map.get(hash_, False)

            if is_cached:
                log.info(f"[{hash_[:8]}] Cached — ready to stream")
                self._set(hash_, state="cached")
            else:
                log.info(f"[{hash_[:8]}] Not cached — creating Premiumize transfer")
                pm_id = self._create_transfer(hash_, t.get("name") or hash_)
                if not pm_id:
                    self._set(hash_, state="error", error="Failed to create transfer")
                    return
                self._set(hash_, state="downloading", pm_transfer_id=pm_id)

        except Exception as e:
            log.exception(f"[{hash_[:8]}] Processing error")
            self._set(hash_, state="error", error=str(e))

    def _create_transfer(self, hash_: str, name: str):
        api_key = self._key_fn()
        if not api_key:
            return None
        magnet = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
        try:
            r = requests.post(
                "https://www.premiumize.me/api/transfer/create",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data=urllib.parse.urlencode({"src": magnet}),
                timeout=20,
            )
            r.raise_for_status()
            data = r.json()
            if data.get("status") == "success":
                return data.get("id")
        except Exception as e:
            log.warning(f"create_transfer error: {e}")
        return None

    # ── Background poller ─────────────────────────────────────────────────────

    def _start_poller(self):
        threading.Thread(target=self._poll_loop, daemon=True).start()

    def _poll_loop(self):
        while True:
            try:
                self._poll_all()
            except Exception:
                log.exception("Poller error")
            time.sleep(POLL_INTERVAL)

    def _poll_all(self):
        with self._conn() as c:
            rows = c.execute(
                "SELECT hash, name, pm_transfer_id FROM transfers WHERE state='downloading'"
            ).fetchall()
        if not rows:
            return

        api_key = self._key_fn()
        if not api_key:
            return

        try:
            r = requests.get(
                "https://www.premiumize.me/api/transfer/list",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=15,
            )
            r.raise_for_status()
            data = r.json()
        except Exception as e:
            log.warning(f"poll_all error: {e}")
            return

        pm_map = {str(t["id"]): t for t in data.get("transfers", [])}

        for row in rows:
            hash_  = row["hash"]
            pm_id  = row["pm_transfer_id"]
            t      = pm_map.get(str(pm_id))
            if not t:
                continue

            status = t.get("status", "")
            log.debug(f"[{hash_[:8]}] status={status} progress={t.get('progress', 0):.0%}")

            if status in ("finished", "seeding"):
                log.info(f"[{hash_[:8]}] Transfer complete — ready to stream")
                self._set(hash_, state="complete")
            elif status == "error":
                self._set(hash_, state="error", error=t.get("message", "unknown"))

"""
Transfer manager — tracks torrent state using SQLite.

States:
  queued      → just received, not yet checked
  cached      → Premiumize has it cached, ready to stream
  downloading → not cached, transfer created on Premiumize, polling
  complete    → transfer finished, ready to stream
  error       → something went wrong

File lists and CDN URLs are stored persistently in the `files` table.
directdl is called once per hash when content is first added, then never
again unless a CDN URL actually expires (403/410) during playback.
This eliminates recurring Fair Use point drain from periodic directdl
refreshes on large libraries.
"""

import logging
import sys
import os
import sqlite3
import threading
import time
import urllib.parse

import requests


# ── Plex library scan (debounced) ─────────────────────────────────────────────
# Waits PLEX_SCAN_DEBOUNCE seconds after the last ready-state transition before
# triggering a scan. A bulk import of 50 files fires exactly one scan, not 50.

class _PlexScanner:
    """Debounced Plex partial-library scanner."""

    def __init__(self):
        self._lock        = threading.Lock()
        self._timer: threading.Timer | None = None
        self._pending: set = set()   # set of (subdir, rel_path|None)
        self._loc_cache: dict = {}   # cached Plex section→Location paths
        self._log = logging.getLogger(__name__ + ".plex")

    def _config(self):
        """Return (url, token, movies_section, tv_section, debounce).
        Env vars take precedence; falls back to saved config."""
        # Env vars
        url     = os.environ.get("PLEX_URL",            "").rstrip("/")
        token   = os.environ.get("PLEX_TOKEN",          "")
        movies  = os.environ.get("PLEX_MOVIES_SECTION", "")
        tv      = os.environ.get("PLEX_TV_SECTION",     "")
        debounce = int(os.environ.get("PLEX_SCAN_DEBOUNCE", "0"))

        # Fall back to saved config for anything not set via env
        if not url or not token:
            try:
                # Use the shared config cache — never import app from a non-main thread
                from app import _config_cache
                cfg_data = (_config_cache or {}).get("plex", {})
                url     = url     or cfg_data.get("url",            "").rstrip("/")
                token   = token   or cfg_data.get("token",          "")
                movies  = movies  or str(cfg_data.get("movies_section", "1"))
                tv      = tv      or str(cfg_data.get("tv_section",     "2"))
                debounce = debounce or int(cfg_data.get("debounce_seconds", 30))
            except Exception:
                pass

        debounce = debounce or 30
        movies   = movies   or "1"
        tv       = tv       or "2"
        return (url, token, movies, tv, debounce) if url and token else (None, None, movies, tv, debounce)

    def _cfg_bool(self, key: str, default: bool) -> bool:
        """Read a Plex boolean from env/config without importing app eagerly."""
        env_key = "PLEX_" + key.upper()
        v = os.environ.get(env_key)
        if v is not None:
            return v.strip().lower() not in ("0", "false", "no", "off")
        try:
            from app import _config_cache
            plex_cfg = (_config_cache or {}).get("plex", {})
            if key in plex_cfg:
                return bool(plex_cfg.get(key))
            # Backwards compatibility with older UI names
            if key == "partial_scan" and "partial_scan_enabled" in plex_cfg:
                return bool(plex_cfg.get("partial_scan_enabled"))
        except Exception:
            pass
        return default

    def _auto_scan_enabled(self) -> bool:
        """Whether new FUSE items should automatically trigger Plex refreshes."""
        return self._cfg_bool("auto_scan_enabled", True)

    def _partial_enabled(self) -> bool:
        """Whether to use Plex path-scoped scans: /refresh?path=/library/item."""
        return self._cfg_bool("partial_scan", True)

    def _fallback_full_enabled(self) -> bool:
        """Whether a failed path scan may fall back to a full section refresh."""
        return self._cfg_bool("fallback_full_scan", False)

    def _section_locations(self, url: str, token: str, section: str) -> list:
        """Return the filesystem Location path(s) Plex has for a section, as the
        Plex server sees them. Cached for 5 min (locations rarely change)."""
        now = time.time()
        ent = self._loc_cache.get("_all")
        if not ent or now >= ent[1]:
            mapping: dict = {}
            try:
                r = requests.get(
                    f"{url}/library/sections",
                    headers={"X-Plex-Token": token, "Accept": "application/json"},
                    timeout=10,
                )
                if r.status_code == 200:
                    for d in (r.json().get("MediaContainer", {}).get("Directory", []) or []):
                        key   = str(d.get("key"))
                        paths = [l.get("path") for l in (d.get("Location") or []) if l.get("path")]
                        if key:
                            mapping[key] = paths
            except Exception as e:
                self._log.debug(f"Plex section-location lookup failed: {e}")
            ent = (mapping, now + 300)
            self._loc_cache["_all"] = ent
        return ent[0].get(str(section), [])

    @staticmethod
    def _pick_location(locations: list, subdir: str) -> str | None:
        """Choose the section Location that matches this subdir. Handles a single
        location, and split setups where movies/movies4k (or series/series4k)
        are separate Locations of the same section."""
        if not locations:
            return None
        if len(locations) == 1:
            return locations[0]
        # 1. Exact basename match (case-insensitive) — e.g. '.../movies4k'
        for p in locations:
            if os.path.basename(p.rstrip("/")).lower() == subdir:
                return p
        # 2. Score on 4K-ness + media type inferred from the location basename
        want_4k     = subdir.endswith("4k")
        want_series = subdir.startswith("series")

        def score(p: str) -> int:
            b = os.path.basename(p.rstrip("/")).lower()
            is4k     = ("4k" in b) or ("uhd" in b) or ("2160" in b)
            isseries = any(k in b for k in ("tv", "series", "show"))
            ismovie  = ("movie" in b) or ("film" in b)
            s = 0
            if is4k == want_4k:
                s += 2
            if want_series and isseries:
                s += 2
            if (not want_series) and ismovie:
                s += 2
            return s

        return max(locations, key=score)

    def notify_ready(self, subdir: str, rel_path: str | None = None):
        """Schedule a debounced Plex scan for a transfer that became ready.

        rel_path: the item's folder name relative to the section's library root
                  (the safe torrent-folder name). When supplied, Plex is asked to
                  scan ONLY that folder — a path-scoped partial scan — so it walks
                  one directory instead of the whole section. When None, a full
                  section refresh is scheduled (used as a fallback)."""
        if not self._auto_scan_enabled():
            self._log.debug("Plex auto-scan disabled; skipping notify_ready")
            return
        url, token, _, _, debounce = self._config()
        if not url:
            return  # Plex not configured — silent no-op

        with self._lock:
            self._pending.add((subdir, rel_path))
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(debounce, self._fire)
            self._timer.daemon = True
            self._timer.start()
            self._log.debug(f"Plex scan scheduled in {debounce}s (queued: {self._pending})")

    def _fire(self):
        with self._lock:
            pending = set(self._pending)
            self._pending.clear()
            self._timer = None

        url, token, movies_section, tv_section, _ = self._config()
        if not url or not token:
            return

        subdir_map = {"movies": movies_section, "series": tv_section,
                      "movies4k": movies_section, "series4k": tv_section}
        partial = self._partial_enabled()

        # A queued full-section refresh for a subdir supersedes the path-scoped
        # entries for that same subdir (the full scan already covers them).
        full_subdirs = {sd for (sd, rp) in pending if rp is None}

        for (subdir, rel_path) in pending:
            section = subdir_map.get(subdir)
            if not section:
                continue
            if rel_path is not None and subdir in full_subdirs:
                continue  # covered by the full refresh

            target_path = None
            if partial and rel_path:
                root = self._pick_location(
                    self._section_locations(url, token, section), subdir
                )
                if not root:
                    # Fallback when Plex section locations cannot be fetched.
                    # mount_path is the path Plex sees for the FUSE mount.
                    try:
                        from app import _config_cache
                        pcfg = (_config_cache or {}).get("plex", {})
                        root = (os.environ.get("PLEX_MOUNT_PATH") or pcfg.get("mount_path") or "").rstrip("/")
                    except Exception:
                        root = (os.environ.get("PLEX_MOUNT_PATH") or "").rstrip("/")
                if root:
                    base = os.path.basename(root.rstrip("/")).lower()
                    # If the Plex location is already the media-type folder
                    # (/mnt/series or /mnt/movies), scan root/folder. If the
                    # location is the FUSE mount root (/mnt), scan
                    # root/subdir/folder. This keeps scans path-scoped and avoids
                    # walking the full library.
                    if base in ("movies", "series", "movies4k", "series4k"):
                        target_path = root.rstrip("/") + "/" + rel_path
                    else:
                        target_path = root.rstrip("/") + "/" + subdir + "/" + rel_path
            self._do_refresh(url, token, section, subdir, target_path)

    def _do_refresh(self, url, token, section, subdir, target_path):
        """Fire a single refresh. If a path-scoped scan is rejected, fall back to
        a full section refresh so the item still appears."""
        if target_path:
            q = urllib.parse.urlencode({"path": target_path, "X-Plex-Token": token})
            label = f"path '{target_path}' (section {section})"
        else:
            q = urllib.parse.urlencode({"X-Plex-Token": token})
            label = f"section {section} ({subdir})"
        scan_url = f"{url}/library/sections/{section}/refresh?{q}"
        try:
            r = requests.get(scan_url, timeout=10)
            if r.status_code in (200, 204):
                self._log.warning(f"[plex-add] path refresh triggered: {label}") if target_path else self._log.warning(f"[plex-add] section refresh triggered: {label}")
            elif target_path:
                if self._fallback_full_enabled():
                    self._log.warning(
                        f"Plex path scan HTTP {r.status_code} for {label} — "
                        "falling back to full section refresh"
                    )
                    self._do_refresh(url, token, section, subdir, None)
                else:
                    self._log.warning(
                        f"Plex path scan HTTP {r.status_code} for {label}; "
                        "full-section fallback disabled"
                    )
            else:
                self._log.warning(f"Plex scan HTTP {r.status_code} for {label}")
        except requests.RequestException as e:
            self._log.warning(f"Plex scan failed for {label}: {e}")
            if target_path and self._fallback_full_enabled():
                self._do_refresh(url, token, section, subdir, None)


_plex = _PlexScanner()

log = logging.getLogger(__name__)

def _tm_log(msg: str) -> None:
    try:
        log.warning(msg)
    except Exception:
        pass


def _fuse_location(hash_: str, name: str, category: str = "", kind: str = ""):
    """Return (subdir, folder_name) for a transfer as it appears in the FUSE
    mount, e.g. ('movies', 'The.Batman.2022').

    Uses the live FUSE name map when available so the authoritative subdir and
    any dedup suffix (…_<hash8>) are honoured — that folder is exactly what Plex
    sees, so a path-scoped scan lands on the right directory. Falls back to
    computing it directly when the map isn't ready yet.
    """
    try:
        import fuse_mount as _fm
        if _fm._pfs is not None:
            nm = _fm._pfs._get_name_map()
            for key, h in nm.items():
                if h == hash_ and "/" in key:
                    sd, folder = key.split("/", 1)
                    return sd, folder
    except Exception:
        pass
    try:
        from fuse_mount import _category_subdir, _safe_name
        sd = _category_subdir(name or "", category or "", kind=kind or "")
        return sd, _safe_name(name or hash_)
    except Exception:
        return _category_subdir_fallback(name, category, kind), (name or hash_)


def _category_subdir_fallback(name, category, kind):
    return "series" if (kind == "series") else "movies"

# In-memory set of hashes that have been CDN-unlocked.
# Populated by unlock_all_cdn() so FUSE read threads see the change
# immediately without waiting for SQLite WAL visibility across connections.
_unlocked_hashes: set = set()
_unlocked_all: bool = False  # True after first bulk unlock

DB_PATH       = os.environ.get("DB_PATH", "/config/transfers.db")
POLL_INTERVAL = 10  # seconds between polling downloading transfers

# ── CDN unlock cool-down ──────────────────────────────────────────────────────
# After the one-time "Import Complete" latch is set, every NEW library file
# still serves stub bytes for this many seconds before it auto-unlocks to real
# CDN bytes. The window lets Plex / Sonarr / Radarr run their add-time scan
# (ffprobe, analysis, thumbnailing) against the tiny stub — zero Premiumize
# bandwidth / Fair-Use points — and the file flips to the real stream once the
# window elapses. Set CDN_COOLDOWN_SECONDS=0 to disable the cool-down so new
# files unlock immediately (the legacy behaviour).
CDN_COOLDOWN_SECONDS = int(os.environ.get("CDN_COOLDOWN_SECONDS", "300"))


class TransferManager:
    def __init__(self, pm_api_key_fn, directdl_fn, cache_check_fn):
        self._key_fn      = pm_api_key_fn
        self._directdl_fn = directdl_fn
        self._cache_fn    = cache_check_fn
        self._lock        = threading.Lock()
        self._local       = threading.local()  # per-thread connections
        self._init_db()
        self._start_poller()

    # ── DB ────────────────────────────────────────────────────────────────────

    def _make_conn(self):
        os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
        conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
        conn.row_factory = sqlite3.Row
        # WAL mode allows concurrent reads while a write is in progress
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-8000")  # 8 MB page cache
        return conn

    def _db(self):
        """Return a per-thread connection, creating one if needed.
        Each thread (FUSE read threads, poller, Flask workers) gets its own
        SQLite connection so concurrent reads never collide.  WAL mode means
        readers never block writers and vice-versa.
        """
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = self._make_conn()
            self._local.conn = conn
        else:
            try:
                conn.execute("SELECT 1")
            except Exception:
                conn = self._make_conn()
                self._local.conn = conn
        return conn

    def _init_db(self):
        with self._lock:
            self._db().execute("""
                CREATE TABLE IF NOT EXISTS transfers (
                    hash            TEXT PRIMARY KEY,
                    name            TEXT,
                    state           TEXT DEFAULT 'queued',
                    pm_transfer_id  TEXT,
                    error           TEXT,
                    added_at        REAL,
                    updated_at      REAL,
                    category        TEXT DEFAULT ''
                )
            """)
            # Migrate existing DBs — add any missing columns
            cols = {row[1] for row in self._db().execute("PRAGMA table_info(transfers)")}
            if "category" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN category TEXT DEFAULT ''")
            if "size" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN size INTEGER DEFAULT 0")
            if "imported" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN imported INTEGER DEFAULT 0")
            if "kind" not in cols:
                # 'movie' | 'series' | '' (unknown — classified from file paths on first directdl)
                self._db().execute("ALTER TABLE transfers ADD COLUMN kind TEXT DEFAULT ''")
            if "cdn_unlocked" not in cols:
                # 0 = serve stub bytes, 1 = serve real CDN bytes
                # Set to 1 per-transfer by "Import Complete" so new transfers
                # added afterwards still get stubs for their initial Plex scan.
                self._db().execute("ALTER TABLE transfers ADD COLUMN cdn_unlocked INTEGER DEFAULT 0")
            if "streamable_at" not in cols:
                # Epoch seconds of when this transfer first became streamable
                # (cached/complete). Anchors the per-file CDN cool-down window.
                self._db().execute("ALTER TABLE transfers ADD COLUMN streamable_at REAL")
                # Backfill existing streamable rows with a past timestamp so the
                # new cool-down gating treats them as already elapsed and never
                # traps previously-visible content as a stub after upgrade.
                self._db().execute(
                    "UPDATE transfers SET streamable_at = COALESCE(added_at, updated_at) "
                    "WHERE state IN ('cached','complete') AND streamable_at IS NULL"
                )

            # Index on state for fast streamable_hashes + poll queries
            self._db().execute(
                "CREATE INDEX IF NOT EXISTS idx_transfers_state ON transfers(state)"
            )

            # ── Persistent file list table ────────────────────────────────────
            # Stores directdl results permanently so we never call directdl
            # again just to serve Plex scans or FUSE readdir/getattr calls.
            # CDN URLs are stored and only refreshed when they actually expire
            # (403/410) during a real playback read.
            self._db().execute("""
                CREATE TABLE IF NOT EXISTS files (
                    hash        TEXT NOT NULL,
                    name        TEXT NOT NULL,
                    path        TEXT DEFAULT '',
                    size        INTEGER DEFAULT 0,
                    cdn_url     TEXT DEFAULT '',
                    cdn_expires REAL DEFAULT 0,
                    PRIMARY KEY (hash, name)
                )
            """)
            self._db().execute(
                "CREATE INDEX IF NOT EXISTS idx_files_hash ON files(hash)"
            )
            file_cols = {row[1] for row in self._db().execute("PRAGMA table_info(files)")}
            if "cdn_unlocked" not in file_cols:
                # Per-file playback unlock. This lets a season-pack torrent keep
                # every other episode as a stub while only the file being played
                # flips to real CDN bytes.
                self._db().execute("ALTER TABLE files ADD COLUMN cdn_unlocked INTEGER DEFAULT 0")

            # ── Persistent key/value meta table ───────────────────────────────
            # Holds small global flags. 'import_done' is the one-way latch set
            # by the "Import Complete" button: once set, every transfer (existing
            # AND any added later) serves real CDN bytes — no more stubs.
            self._db().execute("""
                CREATE TABLE IF NOT EXISTS meta (
                    key   TEXT PRIMARY KEY,
                    value TEXT
                )
            """)
            self._db().commit()
            # Restore the unlock state from DB on startup
            global _unlocked_hashes, _unlocked_all
            # Ultimate mode: do not restore the old import-complete latch.
            # Files are stubs for Plex scans and unlock on first real FUSE read.
            if os.environ.get("ULTIMATE_RESET_STUBS_ON_START", "true").lower() != "false":
                self._db().execute("DELETE FROM meta WHERE key='import_done'")
                self._db().execute("UPDATE transfers SET cdn_unlocked=0")
                self._db().execute("UPDATE files SET cdn_unlocked=0")
                self._db().commit()
                _unlocked_all = False
                _unlocked_hashes = set()
                log.warning("[ultimate-mode] startup reset: all files are stubs until first read")
            else:
                row = self._db().execute(
                    "SELECT value FROM meta WHERE key='import_done'"
                ).fetchone()
                _unlocked_all = False
                rows = self._db().execute(
                    "SELECT hash FROM transfers WHERE cdn_unlocked=1"
                ).fetchall()
                _unlocked_hashes = {r[0] for r in rows}
                if _unlocked_hashes:
                    log.debug(f"Restored {len(_unlocked_hashes)} CDN-unlocked transfer(s) from DB")

    def _get(self, hash_: str):
        row = self._db().execute(
            "SELECT * FROM transfers WHERE hash=?", (hash_,)
        ).fetchone()
        return dict(row) if row else None

    def _set(self, hash_: str, **kwargs):
        kwargs["updated_at"] = time.time()
        with self._lock:
            existing = self._get(hash_)
            # Stamp the cool-down anchor the first time a transfer becomes
            # streamable, so its per-file CDN cool-down window starts now.
            if kwargs.get("state") in ("cached", "complete") and not (
                existing and existing.get("streamable_at")
            ):
                kwargs.setdefault("streamable_at", time.time())
            if existing:
                sets = ", ".join(f"{k}=?" for k in kwargs)
                vals = list(kwargs.values()) + [hash_]
                self._db().execute(f"UPDATE transfers SET {sets} WHERE hash=?", vals)
            else:
                kwargs.setdefault("added_at", time.time())
                kwargs["hash"] = hash_
                cols = ", ".join(kwargs.keys())
                plac = ", ".join("?" for _ in kwargs)
                self._db().execute(
                    f"INSERT INTO transfers ({cols}) VALUES ({plac})",
                    list(kwargs.values())
                )
            self._db().commit()

    def _set_many(self, rows: list[dict]):
        """Bulk upsert — used by restore to avoid per-row lock overhead."""
        with self._lock:
            now = time.time()
            for kwargs in rows:
                kwargs.setdefault("added_at", now)
                kwargs["updated_at"] = now
                kwargs.setdefault("state", "cached")
                if kwargs.get("state") in ("cached", "complete"):
                    kwargs.setdefault("streamable_at", now)
                cols = ", ".join(kwargs.keys())
                plac = ", ".join("?" for _ in kwargs)
                upd  = ", ".join(f"{k}=excluded.{k}" for k in kwargs if k != "hash")
                self._db().execute(
                    f"INSERT INTO transfers ({cols}) VALUES ({plac}) "
                    f"ON CONFLICT(hash) DO UPDATE SET {upd}",
                    list(kwargs.values())
                )
            self._db().commit()

    # ── File list DB helpers ──────────────────────────────────────────────────

    def _db_get_files(self, hash_: str) -> list:
        """Return stored file list for hash from DB. Empty list if none stored."""
        rows = self._db().execute(
            "SELECT name, path, size, cdn_url, cdn_expires, cdn_unlocked FROM files WHERE hash=?",
            (hash_,)
        ).fetchall()
        return [dict(r) for r in rows]

    def _db_store_files(self, hash_: str, files: list):
        """Persist a directdl file list to the DB. Overwrites existing entries.

        Preserve per-file cdn_unlocked flags across CDN URL refreshes, otherwise
        a played file could silently fall back to stub mode after directdl refresh.
        """
        now = time.time()
        with self._lock:
            old_rows = self._db().execute(
                "SELECT name, path, cdn_unlocked FROM files WHERE hash=?", (hash_,)
            ).fetchall()
            unlocked_by_name = {}
            for r in old_rows:
                if int(r["cdn_unlocked"] or 0):
                    if r["name"]:
                        unlocked_by_name[r["name"]] = 1
                    if r["path"]:
                        unlocked_by_name[os.path.basename(r["path"])] = 1
                        unlocked_by_name[r["path"]] = 1
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            for f in files:
                name = f.get("name", "") or ""
                path = f.get("path", "") or ""
                unlocked = 1 if (unlocked_by_name.get(name) or unlocked_by_name.get(path) or unlocked_by_name.get(os.path.basename(path))) else 0
                self._db().execute(
                    "INSERT OR REPLACE INTO files (hash, name, path, size, cdn_url, cdn_expires, cdn_unlocked) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        hash_,
                        name,
                        path,
                        int(f.get("size", 0) or 0),
                        f.get("link", ""),
                        now + 172800,  # CDN URLs valid ~48h
                        unlocked,
                    )
                )
            self._db().commit()
        log.debug(f"[{hash_[:8]}] stored {len(files)} file(s) to DB")

    def _db_update_cdn_url(self, hash_: str, name: str, cdn_url: str):
        """Update a single file's CDN URL after a forced refresh."""
        with self._lock:
            self._db().execute(
                "UPDATE files SET cdn_url=?, cdn_expires=? WHERE hash=? AND name=?",
                (cdn_url, time.time() + 172800, hash_, name)
            )
            self._db().commit()

    def _db_files_to_list(self, rows: list) -> list:
        """Convert DB file rows to the standard file-list dict format."""
        try:
            from app import _make_stream_token
        except Exception:
            _make_stream_token = None
        import urllib.parse as _up
        video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
                      ".wmv", ".flv", ".webm"}
        result = []
        for r in rows:
            name = r.get("name") or ""
            cdn  = r.get("cdn_url") or ""
            if not name:
                continue  # skip corrupt DB rows with NULL name
            ext  = os.path.splitext(name)[1].lower()
            token = ""
            if cdn and _make_stream_token:
                try:
                    token = _make_stream_token(r.get("hash", ""), name)
                except Exception:
                    pass
            result.append({
                "name":       name,
                "path":       r.get("path", ""),
                "link":       cdn,
                "size":       int(r.get("size", 0) or 0),
                "is_video":   ext in video_exts,
                "cdn_expires": r.get("cdn_expires", 0),
                "stream_url": (
                    f"/api/stream/{token}?h={r.get('hash','')}&f={_up.quote(name)}"
                    if token else ""
                ),
            })
        return result

    # ── Public API ────────────────────────────────────────────────────────────

    def add(self, hash_: str, name: str):
        hash_ = hash_.lower()
        existing = self._get(hash_)
        if existing and existing["state"] in ("cached", "downloading", "complete"):
            if existing.get("name") == hash_ and name and name != hash_:
                self._set(hash_, name=name)
            return self._get(hash_)
        self._set(hash_, name=name, state="queued")
        # Use the app-level pool if available, else fall back to a plain thread
        try:
            from app import _import_pool
            _import_pool.submit(self._process, hash_)
        except Exception:
            threading.Thread(target=self._process, args=(hash_,), daemon=True).start()
        return self._get(hash_)

    def delete(self, hash_: str):
        # Remove symlinks before deleting from DB so we still have name/files
        with self._lock:
            self._db().execute("DELETE FROM transfers WHERE hash=?", (hash_,))
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            self._db().commit()

    def get_transfer(self, hash_: str):
        return self._get(hash_)

    def all_transfers(self):
        rows = self._db().execute("SELECT * FROM transfers").fetchall()
        return [dict(r) for r in rows]

    def streamable_hashes(self):
        rows = self._db().execute(
            "SELECT hash FROM transfers WHERE state IN ('cached','complete')"
        ).fetchall()
        return [r["hash"] for r in rows]

    def get_files(self, hash_: str, force: bool = False) -> list:
        """Return file list for hash.

        Serves from the persistent DB unless:
        - force=True (caller has detected a CDN expiry and needs a refresh)
        - DB has no entries for this hash yet (first-time fetch)

        When a fresh directdl call is made the result is written to the DB
        so subsequent calls are free forever.
        """
        t = self._get(hash_)
        if not t or t["state"] not in ("cached", "complete"):
            return []

        if not force:
            db_rows = self._db_get_files(hash_)
            if db_rows:
                # Attach hash to each row so _db_files_to_list can build tokens
                for r in db_rows:
                    r["hash"] = hash_
                result = self._db_files_to_list(db_rows)
                if result:
                    return result

        # DB miss or forced refresh — call directdl once and persist
        api_key = self._key_fn()
        if not api_key:
            log.error(
                f"[{hash_[:8]}] get_files: PREMIUMIZE_API_KEY is not set — "
                "FUSE directory will appear empty until the key is configured"
            )
            return []
        name = t.get("name") or hash_
        files = self._directdl_fn(hash_, name, force=force)
        if files:
            self._db_store_files(hash_, files)
        return files

    def refresh_cdn_url(self, hash_: str, filename: str) -> str | None:
        """Force-refresh the CDN URL for a single file after a 403/410.
        Updates the DB and returns the new URL, or None on failure.
        This is the ONLY path that should trigger a new directdl call
        after initial import — and only when a real playback read fails.
        """
        t = self._get(hash_)
        if not t:
            return None
        name = t.get("name") or hash_
        log.info(f"[{hash_[:8]}] CDN URL expired for {filename} — refreshing")
        files = self._directdl_fn(hash_, name, force=True)
        if not files:
            return None
        self._db_store_files(hash_, files)
        for f in files:
            if f.get("name") == filename or f.get("path", "").endswith(filename):
                return f.get("link")
        return None

    def is_cdn_unlocked(self, hash_: str) -> bool:
        """Return True if this transfer should serve real CDN bytes instead of
        stub bytes.

        A transfer is unlocked only once it has been explicitly promoted —
        either by the one-time "Import Complete" latch (which unlocks everything
        cached at that moment) or by the cool-down sweeper, which flips a newly
        added file to real bytes after it has spent CDN_COOLDOWN_SECONDS as a
        stub (see _sweep_cooldowns). Until then it stays a stub, so add-time
        scans cost no Premiumize bandwidth.

        Checks the in-memory set first so FUSE threads see a promotion
        immediately, without any SQLite cross-thread visibility delay.
        """
        global _unlocked_hashes
        if hash_ in _unlocked_hashes:
            return True
        # Fall back to DB (e.g. after a restart, before the set is repopulated)
        try:
            row = self._db().execute(
                "SELECT cdn_unlocked FROM transfers WHERE hash=?", (hash_,)
            ).fetchone()
            result = bool(row and row[0])
            if result:
                _unlocked_hashes.add(hash_)  # cache it in memory
            return result
        except Exception as e:
            log.debug(f"is_cdn_unlocked error for {hash_[:8]}: {e}")
            return False

    def is_file_cdn_unlocked(self, hash_: str, filename: str | None = None) -> bool:
        """Return true when this exact file should serve real CDN bytes.

        Per-file unlock wins first. Transfer-level unlock remains as a backwards
        compatible fallback for old imports / Import Complete.
        """
        if not filename:
            return self.is_cdn_unlocked(hash_)
        base = os.path.basename(filename or "")
        try:
            row = self._db().execute(
                """
                SELECT cdn_unlocked
                FROM files
                WHERE hash=? AND (name=? OR path=? OR path LIKE ?)
                LIMIT 1
                """,
                (hash_, base, filename, "%/" + base),
            ).fetchone()
            if row and int(row[0] or 0):
                return True
        except Exception as e:
            log.debug(f"is_file_cdn_unlocked error for {hash_[:8]}/{base}: {e}")
        return self.is_cdn_unlocked(hash_)

    def unlock_file_cdn(self, hash_: str, filename: str | None = None) -> bool:
        """Unlock one file inside a transfer. If filename is omitted, unlocks the transfer."""
        global _unlocked_hashes
        hash_ = (hash_ or "").lower().strip()
        if not hash_:
            return False
        base = os.path.basename(filename or "") if filename else ""
        with self._lock:
            if base:
                cur = self._db().execute(
                    """
                    UPDATE files
                    SET cdn_unlocked=1
                    WHERE hash=? AND (name=? OR path=? OR path LIKE ?)
                    """,
                    (hash_, base, filename, "%/" + base),
                )
                changed = cur.rowcount or 0
                self._db().commit()
                if changed:
                    return True
                return False
            self._db().execute("UPDATE transfers SET cdn_unlocked=1 WHERE hash=?", (hash_,))
            self._db().commit()
            _unlocked_hashes.add(hash_)
            return True

    def unlock_all_cdn(self) -> int:
        """Legacy compatibility endpoint.

        Ultimate mode keeps every file as a stub until its first FUSE read.
        This avoids Premiumize bandwidth during Plex add-time scans and removes
        the old import-complete/cool-down promotion path. Calling this no longer
        unlocks the library.
        """
        global _unlocked_all, _unlocked_hashes
        with self._lock:
            self._db().execute("DELETE FROM meta WHERE key='import_done'")
            self._db().execute("UPDATE transfers SET cdn_unlocked=0")
            self._db().execute("UPDATE files SET cdn_unlocked=0")
            self._db().commit()
        _unlocked_all = False
        _unlocked_hashes.clear()
        log.warning("[ultimate-mode] import-complete is disabled; all files remain stubs until first read")
        return 0

    def cooldown_status(self) -> dict:
        """Report the cool-down config and how many transfers are currently
        inside their stub cool-down window (for the UI / status endpoint)."""
        cooling = 0
        try:
            if CDN_COOLDOWN_SECONDS > 0 and self.is_import_done():
                cutoff = time.time() - CDN_COOLDOWN_SECONDS
                cooling = self._db().execute(
                    "SELECT COUNT(*) FROM transfers "
                    "WHERE state IN ('cached','complete') AND cdn_unlocked=0 "
                    "AND COALESCE(streamable_at, added_at, 0) > ?",
                    (cutoff,)
                ).fetchone()[0]
        except Exception:
            pass
        return {"cooldown_seconds": CDN_COOLDOWN_SECONDS, "cooling_down": cooling}

    def is_import_done(self) -> bool:
        """True once the one-time 'Import Complete' latch has been set."""
        global _unlocked_all
        if _unlocked_all:
            return True
        try:
            row = self._db().execute(
                "SELECT value FROM meta WHERE key='import_done'"
            ).fetchone()
            if row and row[0] == "1":
                _unlocked_all = True
                return True
        except Exception:
            pass
        return False

    def find_hash_by_filename(self, filename: str) -> str | None:
        """Look up a transfer hash by a video filename — used by Tautulli webhook
        to match a Plex-reported filename back to a Premiumize hash."""
        # Exact match first
        row = self._db().execute(
            "SELECT hash FROM files WHERE name=? LIMIT 1", (filename,)
        ).fetchone()
        if row:
            return row[0]
        # Fuzzy: strip extension and compare normalised names
        import re as _re
        stem = _re.sub(r'\.[^.]+$', '', filename).lower()
        stem_norm = _re.sub(r'[^a-z0-9]', '', stem)
        rows = self._db().execute("SELECT hash, name FROM files").fetchall()
        for r in rows:
            n = _re.sub(r'\.[^.]+$', '', r[1]).lower()  # r[1] is name
            if _re.sub(r'[^a-z0-9]', '', n) == stem_norm:
                return r[0]  # return hash
        return None


    # ── Processing ────────────────────────────────────────────────────────────

    def _process(self, hash_: str):
        t = self._get(hash_)
        if not t:
            return
        if t["state"] in ("cached", "complete", "downloading"):
            return
        try:
            cached_map = self._cache_fn([{"info_hash": hash_}])
            is_cached  = cached_map.get(hash_, False)
            if is_cached:
                log.info(f"[{hash_[:8]}] Cached — ready to stream")
                self._set(hash_, state="cached")
                t2 = self._get(hash_)
                # Create fake import file and pre-warm FUSE cache immediately
                try:
                    import qbt_mock as _qbt
                    from name_match import classify, classify_from_files
                    _name     = t2.get("name") or hash_
                    _category = t2.get("category") or ""
                    _files    = self.get_files(hash_) or []

                    # Classify from file paths (ground truth) and persist to DB
                    _kind = classify_from_files(_files)
                    if _kind and not t2.get("kind"):
                        self._set(hash_, kind=_kind)
                    else:
                        _kind = t2.get("kind") or _kind or classify(_name, _files)

                    # Pre-warm FUSE file cache so readdir is instant
                    if _files:
                        try:
                            import fuse_mount as _fm
                            import time as _time
                            if _fm._pfs is not None:
                                with _fm._pfs._lock:
                                    _fm._pfs._file_cache[hash_] = (_files, _time.time() + _fm.DIRECTDL_TTL)
                                _fm._pfs._invalidate_name_map()
                        except Exception:
                            pass

                    _fn = _qbt._pick_fake_filename(_name, _files)
                    _qbt._make_fake_file(_category, _qbt._safe_name(_name), _fn, _files)
                except Exception as _e:
                    log.debug(f"Fake file / classify failed: {_e}")
                    _kind = "movie"

                # Notify Plex using the authoritative kind — scan just this
                # item's folder so Plex doesn't walk the whole section.
                t2 = self._get(hash_)
                subdir, folder = _fuse_location(
                    hash_, t2.get("name", ""), t2.get("category", ""), t2.get("kind", "")
                )
                _plex.notify_ready(subdir, folder)
            else:
                log.info(f"[{hash_[:8]}] Not cached — creating Premiumize transfer")
                pm_id = self._create_transfer(hash_, t.get("name") or hash_)
                if not pm_id:
                    self._set(hash_, state="error", error="Failed to create transfer")
                    return
                self._set(hash_, state="downloading", pm_transfer_id=pm_id)
        except Exception as e:
            log.exception(f"[{hash_[:8]}] Processing error")
            self._set(hash_, state="error", error=str(e))

    def _create_transfer(self, hash_: str, name: str):
        api_key = self._key_fn()
        if not api_key:
            return None
        magnet = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
        try:
            r = requests.post(
                "https://www.premiumize.me/api/transfer/create",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data=urllib.parse.urlencode({"src": magnet}),
                timeout=20,
            )
            r.raise_for_status()
            data = r.json()
            if data.get("status") == "success":
                return data.get("id")
        except Exception as e:
            log.warning(f"create_transfer error: {e}")
        return None

    # ── Background poller ─────────────────────────────────────────────────────

    def _start_poller(self):
        threading.Thread(target=self._poll_loop, daemon=True).start()

    def _poll_loop(self):
        while True:
            try:
                self._poll_all()
            except Exception:
                log.exception("Poller error")
            try:
                self._sweep_cooldowns()
            except Exception:
                log.exception("Cool-down sweep error")
            time.sleep(POLL_INTERVAL)

    def _poll_all(self):
        rows = self._db().execute(
            "SELECT hash, name, pm_transfer_id FROM transfers WHERE state='downloading'"
        ).fetchall()
        if not rows:
            return

        api_key = self._key_fn()
        if not api_key:
            return

        try:
            r = requests.get(
                "https://www.premiumize.me/api/transfer/list",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=15,
            )
            r.raise_for_status()
            data = r.json()
        except Exception as e:
            log.warning(f"poll_all error: {e}")
            return

        pm_map = {str(t["id"]): t for t in data.get("transfers", [])}

        for row in rows:
            hash_  = row["hash"]
            pm_id  = row["pm_transfer_id"]
            t      = pm_map.get(str(pm_id))
            if not t:
                continue
            status = t.get("status", "")
            if status in ("finished", "seeding"):
                log.info(f"[{hash_[:8]}] Transfer complete — ready to stream")
                self._set(hash_, state="complete")
                t2 = self._get(hash_)
                try:
                    import qbt_mock as _qbt
                    from name_match import classify_from_files
                    _name     = t2.get("name") or hash_
                    _category = t2.get("category") or ""
                    _files    = self.get_files(hash_) or []
                    # Classify from file paths and persist to DB
                    _kind = classify_from_files(_files)
                    if _kind and not t2.get("kind"):
                        self._set(hash_, kind=_kind)
                    _fn = _qbt._pick_fake_filename(_name, _files)
                    _qbt._make_fake_file(_category, _qbt._safe_name(_name), _fn, _files)
                except Exception as _e:
                    log.debug(f"Fake file creation skipped: {_e}")
                t2 = self._get(hash_)
                subdir, folder = _fuse_location(
                    hash_, t2.get("name", ""), t2.get("category", ""), t2.get("kind", "")
                )
                _plex.notify_ready(subdir, folder)
            elif status == "error":
                self._set(hash_, state="error", error=t.get("message", "unknown"))

    # ── CDN cool-down sweeper ─────────────────────────────────────────────────

    def _sweep_cooldowns(self):
        """Promote transfers whose CDN stub cool-down window has elapsed.

        Runs every poll tick, but only once the one-time "Import Complete" latch
        is set — during the initial bulk import everything stays a stub until the
        user clicks the button. After that, each NEW streamable file is held as a
        stub for CDN_COOLDOWN_SECONDS (so Plex / Sonarr / Radarr can scan the
        tiny stub for free) and is then flipped to real CDN bytes here.

        On promotion it: marks cdn_unlocked=1 (persisted + in-memory so FUSE
        threads see it at once), invalidates the FUSE stat cache so the reported
        size flips stub→real, and nudges Plex to re-scan the affected sections so
        it picks up the now-streamable file.
        """
        if not self.is_import_done():
            return  # cool-down only applies after the initial bulk import

        global _unlocked_hashes
        try:
            if CDN_COOLDOWN_SECONDS <= 0:
                # Cool-down disabled — unlock every streamable file immediately
                # (legacy "everything unlocks after import" behaviour).
                rows = self._db().execute(
                    "SELECT hash, name, category, kind FROM transfers "
                    "WHERE state IN ('cached','complete') AND cdn_unlocked=0"
                ).fetchall()
            else:
                cutoff = time.time() - CDN_COOLDOWN_SECONDS
                rows = self._db().execute(
                    "SELECT hash, name, category, kind FROM transfers "
                    "WHERE state IN ('cached','complete') AND cdn_unlocked=0 "
                    "AND COALESCE(streamable_at, added_at, 0) <= ?",
                    (cutoff,)
                ).fetchall()
        except Exception as e:
            log.debug(f"cool-down sweep query failed: {e}")
            return

        if not rows:
            return

        hashes = [r["hash"] for r in rows]
        with self._lock:
            self._db().executemany(
                "UPDATE transfers SET cdn_unlocked=1 WHERE hash=?",
                [(h,) for h in hashes]
            )
            self._db().commit()
        for h in hashes:
            _unlocked_hashes.add(h)
        log.info(f"CDN cool-down elapsed for {len(hashes)} transfer(s) — now serving real CDN bytes")

        # Flip reported sizes stub→real so Plex re-scans against the real file.
        try:
            import fuse_mount as _fm
            if _fm._pfs is not None:
                _fm._pfs._stat_invalidate_all()
        except Exception:
            pass

        # Optional: nudge Plex again after stub→real unlock. Usually keep this
        # disabled for FUSE libraries because the add-time path scan is enough,
        # and re-analysis can cause heavy Plex scanner churn.
        if _plex._cfg_bool("scan_on_unlock", False):
            try:
                for r in rows:
                    subdir, folder = _fuse_location(
                        r["hash"], r["name"] or "", r["category"] or "", r["kind"] or ""
                    )
                    _plex.notify_ready(subdir, folder)
            except Exception as e:
                log.debug(f"cool-down Plex notify failed: {e}")

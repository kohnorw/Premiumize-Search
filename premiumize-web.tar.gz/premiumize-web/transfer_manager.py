"""
Transfer manager — tracks torrent state using SQLite.

States:
  queued      → just received, not yet checked
  cached      → Premiumize has it cached, ready to stream
  downloading → not cached, transfer created on Premiumize, polling
  complete    → transfer finished, ready to stream
  error       → something went wrong

File lists and CDN URLs are stored persistently in the `files` table.
directdl is called once per hash when content is first added, then never
again unless a CDN URL actually expires (403/410) during playback.
This eliminates recurring Fair Use point drain from periodic directdl
refreshes on large libraries.
"""

import logging
import os
import sqlite3
import threading
import time
import urllib.parse

import requests


# ── Plex library scan (debounced) ─────────────────────────────────────────────
# Waits PLEX_SCAN_DEBOUNCE seconds after the last ready-state transition before
# triggering a scan. A bulk import of 50 files fires exactly one scan, not 50.

class _PlexScanner:
    """Debounced Plex partial-library scanner."""

    def __init__(self):
        self._lock        = threading.Lock()
        self._timer: threading.Timer | None = None
        self._pending_dirs: set = set()
        self._log = logging.getLogger(__name__ + ".plex")

    def _config(self):
        """Return (url, token, movies_section, tv_section, debounce).
        Env vars take precedence; falls back to saved config."""
        # Env vars
        url     = os.environ.get("PLEX_URL",            "").rstrip("/")
        token   = os.environ.get("PLEX_TOKEN",          "")
        movies  = os.environ.get("PLEX_MOVIES_SECTION", "")
        tv      = os.environ.get("PLEX_TV_SECTION",     "")
        debounce = int(os.environ.get("PLEX_SCAN_DEBOUNCE", "0"))

        # Fall back to saved config for anything not set via env
        if not url or not token:
            try:
                # Use the shared config cache — never import app from a non-main thread
                from app import _config_cache
                cfg_data = (_config_cache or {}).get("plex", {})
                url     = url     or cfg_data.get("url",            "").rstrip("/")
                token   = token   or cfg_data.get("token",          "")
                movies  = movies  or str(cfg_data.get("movies_section", "1"))
                tv      = tv      or str(cfg_data.get("tv_section",     "2"))
                debounce = debounce or int(cfg_data.get("debounce_seconds", 30))
            except Exception:
                pass

        debounce = debounce or 30
        movies   = movies   or "1"
        tv       = tv       or "2"
        return (url, token, movies, tv, debounce) if url and token else (None, None, movies, tv, debounce)

    def notify_ready(self, subdir: str):
        """Call when a transfer becomes cached/complete."""
        url, token, _, _, debounce = self._config()
        if not url:
            return  # Plex not configured — silent no-op

        with self._lock:
            self._pending_dirs.add(subdir)
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(debounce, self._fire)
            self._timer.daemon = True
            self._timer.start()
            self._log.debug(f"Plex scan scheduled in {debounce}s (queued: {self._pending_dirs})")

    def _fire(self):
        with self._lock:
            dirs = set(self._pending_dirs)
            self._pending_dirs.clear()
            self._timer = None

        url, token, movies_section, tv_section, _ = self._config()
        if not url or not token:
            return

        subdir_map = {"movies": movies_section, "series": tv_section,
                      "movies4k": movies_section, "series4k": tv_section}

        for subdir in dirs:
            section = subdir_map.get(subdir)
            if not section:
                continue
            scan_url = f"{url}/library/sections/{section}/refresh?X-Plex-Token={token}"
            try:
                r = requests.get(scan_url, timeout=10)
                if r.status_code in (200, 204):
                    self._log.info(f"Plex scan triggered: section {section} ({subdir})")
                else:
                    self._log.warning(f"Plex scan HTTP {r.status_code} for section {section}")
            except requests.RequestException as e:
                self._log.warning(f"Plex scan failed: {e}")


_plex = _PlexScanner()

log = logging.getLogger(__name__)

DB_PATH       = os.environ.get("DB_PATH", "/config/transfers.db")
POLL_INTERVAL = 10  # seconds between polling downloading transfers


class TransferManager:
    def __init__(self, pm_api_key_fn, directdl_fn, cache_check_fn):
        self._key_fn      = pm_api_key_fn
        self._directdl_fn = directdl_fn
        self._cache_fn    = cache_check_fn
        self._lock        = threading.Lock()
        self._conn        = self._make_conn()
        self._init_db()
        self._start_poller()

    # ── DB ────────────────────────────────────────────────────────────────────

    def _make_conn(self):
        os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
        conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
        conn.row_factory = sqlite3.Row
        # WAL mode allows concurrent reads while a write is in progress
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-8000")  # 8 MB page cache
        return conn

    def _db(self):
        """Return the shared connection, reconnecting if needed."""
        try:
            self._conn.execute("SELECT 1")
        except Exception:
            self._conn = self._make_conn()
        return self._conn

    def _init_db(self):
        with self._lock:
            self._db().execute("""
                CREATE TABLE IF NOT EXISTS transfers (
                    hash            TEXT PRIMARY KEY,
                    name            TEXT,
                    state           TEXT DEFAULT 'queued',
                    pm_transfer_id  TEXT,
                    error           TEXT,
                    added_at        REAL,
                    updated_at      REAL,
                    category        TEXT DEFAULT ''
                )
            """)
            # Migrate existing DBs — add any missing columns
            cols = {row[1] for row in self._db().execute("PRAGMA table_info(transfers)")}
            if "category" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN category TEXT DEFAULT ''")
            if "size" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN size INTEGER DEFAULT 0")
            if "imported" not in cols:
                self._db().execute("ALTER TABLE transfers ADD COLUMN imported INTEGER DEFAULT 0")
            if "kind" not in cols:
                # 'movie' | 'series' | '' (unknown — classified from file paths on first directdl)
                self._db().execute("ALTER TABLE transfers ADD COLUMN kind TEXT DEFAULT ''")

            # Index on state for fast streamable_hashes + poll queries
            self._db().execute(
                "CREATE INDEX IF NOT EXISTS idx_transfers_state ON transfers(state)"
            )

            # ── Persistent file list table ────────────────────────────────────
            # Stores directdl results permanently so we never call directdl
            # again just to serve Plex scans or FUSE readdir/getattr calls.
            # CDN URLs are stored and only refreshed when they actually expire
            # (403/410) during a real playback read.
            self._db().execute("""
                CREATE TABLE IF NOT EXISTS files (
                    hash        TEXT NOT NULL,
                    name        TEXT NOT NULL,
                    path        TEXT DEFAULT '',
                    size        INTEGER DEFAULT 0,
                    cdn_url     TEXT DEFAULT '',
                    cdn_expires REAL DEFAULT 0,
                    plex_ready  INTEGER DEFAULT 0,
                    PRIMARY KEY (hash, name)
                )
            """)
            self._db().execute(
                "CREATE INDEX IF NOT EXISTS idx_files_hash ON files(hash)"
            )
            # Migrate existing files tables missing plex_ready
            file_cols = {row[1] for row in self._db().execute("PRAGMA table_info(files)")}
            if "plex_ready" not in file_cols:
                self._db().execute("ALTER TABLE files ADD COLUMN plex_ready INTEGER DEFAULT 0")
            self._db().commit()

    def _get(self, hash_: str):
        row = self._db().execute(
            "SELECT * FROM transfers WHERE hash=?", (hash_,)
        ).fetchone()
        return dict(row) if row else None

    def _set(self, hash_: str, **kwargs):
        kwargs["updated_at"] = time.time()
        with self._lock:
            existing = self._get(hash_)
            if existing:
                sets = ", ".join(f"{k}=?" for k in kwargs)
                vals = list(kwargs.values()) + [hash_]
                self._db().execute(f"UPDATE transfers SET {sets} WHERE hash=?", vals)
            else:
                kwargs.setdefault("added_at", time.time())
                kwargs["hash"] = hash_
                cols = ", ".join(kwargs.keys())
                plac = ", ".join("?" for _ in kwargs)
                self._db().execute(
                    f"INSERT INTO transfers ({cols}) VALUES ({plac})",
                    list(kwargs.values())
                )
            self._db().commit()

    def _set_many(self, rows: list[dict]):
        """Bulk upsert — used by restore to avoid per-row lock overhead."""
        with self._lock:
            now = time.time()
            for kwargs in rows:
                kwargs.setdefault("added_at", now)
                kwargs["updated_at"] = now
                kwargs.setdefault("state", "cached")
                cols = ", ".join(kwargs.keys())
                plac = ", ".join("?" for _ in kwargs)
                upd  = ", ".join(f"{k}=excluded.{k}" for k in kwargs if k != "hash")
                self._db().execute(
                    f"INSERT INTO transfers ({cols}) VALUES ({plac}) "
                    f"ON CONFLICT(hash) DO UPDATE SET {upd}",
                    list(kwargs.values())
                )
            self._db().commit()

    # ── File list DB helpers ──────────────────────────────────────────────────

    def _db_get_files(self, hash_: str) -> list:
        """Return stored file list for hash from DB. Empty list if none stored."""
        rows = self._db().execute(
            "SELECT name, path, size, cdn_url, cdn_expires FROM files WHERE hash=?",
            (hash_,)
        ).fetchall()
        return [dict(r) for r in rows]

    def _db_store_files(self, hash_: str, files: list):
        """Persist a directdl file list to the DB. Overwrites existing entries."""
        now = time.time()
        with self._lock:
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            for f in files:
                self._db().execute(
                    "INSERT OR REPLACE INTO files (hash, name, path, size, cdn_url, cdn_expires) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        hash_,
                        f.get("name", ""),
                        f.get("path", ""),
                        int(f.get("size", 0) or 0),
                        f.get("link", ""),
                        now + 172800,  # CDN URLs valid ~48h
                    )
                )
            self._db().commit()
        log.debug(f"[{hash_[:8]}] stored {len(files)} file(s) to DB")

    def _db_update_cdn_url(self, hash_: str, name: str, cdn_url: str):
        """Update a single file's CDN URL after a forced refresh."""
        with self._lock:
            self._db().execute(
                "UPDATE files SET cdn_url=?, cdn_expires=? WHERE hash=? AND name=?",
                (cdn_url, time.time() + 172800, hash_, name)
            )
            self._db().commit()

    def _db_files_to_list(self, rows: list) -> list:
        """Convert DB file rows to the standard file-list dict format."""
        try:
            from app import _make_stream_token
        except Exception:
            _make_stream_token = None
        import urllib.parse as _up
        video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
                      ".wmv", ".flv", ".webm"}
        result = []
        for r in rows:
            name = r.get("name", "")
            cdn  = r.get("cdn_url", "")
            ext  = os.path.splitext(name)[1].lower()
            token = ""
            if cdn and _make_stream_token:
                try:
                    token = _make_stream_token(r.get("hash", ""), name)
                except Exception:
                    pass
            result.append({
                "name":       name,
                "path":       r.get("path", ""),
                "link":       cdn,
                "size":       int(r.get("size", 0) or 0),
                "is_video":   ext in video_exts,
                "cdn_expires": r.get("cdn_expires", 0),
                "stream_url": (
                    f"/api/stream/{token}?h={r.get('hash','')}&f={_up.quote(name)}"
                    if token else ""
                ),
            })
        return result

    # ── Public API ────────────────────────────────────────────────────────────

    def add(self, hash_: str, name: str):
        hash_ = hash_.lower()
        existing = self._get(hash_)
        if existing and existing["state"] in ("cached", "downloading", "complete"):
            if existing.get("name") == hash_ and name and name != hash_:
                self._set(hash_, name=name)
            return self._get(hash_)
        self._set(hash_, name=name, state="queued")
        # Use the app-level pool if available, else fall back to a plain thread
        try:
            from app import _import_pool
            _import_pool.submit(self._process, hash_)
        except Exception:
            threading.Thread(target=self._process, args=(hash_,), daemon=True).start()
        return self._get(hash_)

    def delete(self, hash_: str):
        # Remove symlinks before deleting from DB so we still have name/files
        with self._lock:
            self._db().execute("DELETE FROM transfers WHERE hash=?", (hash_,))
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            self._db().commit()

    def get_transfer(self, hash_: str):
        return self._get(hash_)

    def all_transfers(self):
        rows = self._db().execute("SELECT * FROM transfers").fetchall()
        return [dict(r) for r in rows]

    def streamable_hashes(self):
        rows = self._db().execute(
            "SELECT hash FROM transfers WHERE state IN ('cached','complete')"
        ).fetchall()
        return [r["hash"] for r in rows]

    def get_files(self, hash_: str, force: bool = False) -> list:
        """Return file list for hash.

        Serves from the persistent DB unless:
        - force=True (caller has detected a CDN expiry and needs a refresh)
        - DB has no entries for this hash yet (first-time fetch)

        When a fresh directdl call is made the result is written to the DB
        so subsequent calls are free forever.
        """
        t = self._get(hash_)
        if not t or t["state"] not in ("cached", "complete"):
            return []

        if not force:
            db_rows = self._db_get_files(hash_)
            if db_rows:
                # Attach hash to each row so _db_files_to_list can build tokens
                for r in db_rows:
                    r["hash"] = hash_
                result = self._db_files_to_list(db_rows)
                if result:
                    return result

        # DB miss or forced refresh — call directdl once and persist
        api_key = self._key_fn()
        if not api_key:
            log.error(
                f"[{hash_[:8]}] get_files: PREMIUMIZE_API_KEY is not set — "
                "FUSE directory will appear empty until the key is configured"
            )
            return []
        name = t.get("name") or hash_
        files = self._directdl_fn(hash_, name, force=force)
        if files:
            self._db_store_files(hash_, files)
        return files

    def refresh_cdn_url(self, hash_: str, filename: str) -> str | None:
        """Force-refresh the CDN URL for a single file after a 403/410.
        Updates the DB and returns the new URL, or None on failure.
        This is the ONLY path that should trigger a new directdl call
        after initial import — and only when a real playback read fails.
        """
        t = self._get(hash_)
        if not t:
            return None
        name = t.get("name") or hash_
        log.info(f"[{hash_[:8]}] CDN URL expired for {filename} — refreshing")
        files = self._directdl_fn(hash_, name, force=True)
        if not files:
            return None
        self._db_store_files(hash_, files)
        for f in files:
            if f.get("name") == filename or f.get("path", "").endswith(filename):
                return f.get("link")
        return None

    def is_plex_ready(self, hash_: str, filename: str) -> bool:
        """Return True if Plex has already imported this file (Tautulli confirmed)."""
        row = self._db().execute(
            "SELECT plex_ready FROM files WHERE hash=? AND name=?",
            (hash_, filename)
        ).fetchone()
        return bool(row and row[0])

    def mark_plex_ready(self, hash_: str, filename: str | None = None) -> int:
        """Mark file(s) as ready for CDN playback after Plex has imported them.
        If filename is None, marks all files for this hash as ready.
        Returns number of rows updated.
        """
        with self._lock:
            if filename:
                self._db().execute(
                    "UPDATE files SET plex_ready=1 WHERE hash=? AND name=?",
                    (hash_, filename)
                )
            else:
                self._db().execute(
                    "UPDATE files SET plex_ready=1 WHERE hash=?",
                    (hash_,)
                )
            self._db().commit()
        n = self._db().execute(
            "SELECT COUNT(*) FROM files WHERE hash=? AND plex_ready=1", (hash_,)
        ).fetchone()[0]
        log.info(f"[{hash_[:8]}] marked {n} file(s) as plex_ready")
        return n

    def find_hash_by_filename(self, filename: str) -> str | None:
        """Look up a transfer hash by a video filename — used by Tautulli webhook
        to match a Plex-reported filename back to a Premiumize hash."""
        # Exact match first
        row = self._db().execute(
            "SELECT hash FROM files WHERE name=? LIMIT 1", (filename,)
        ).fetchone()
        if row:
            return row[0]
        # Fuzzy: strip extension and compare normalised names
        import re as _re
        stem = _re.sub(r'\.[^.]+$', '', filename).lower()
        stem_norm = _re.sub(r'[^a-z0-9]', '', stem)
        rows = self._db().execute("SELECT hash, name FROM files").fetchall()
        for r in rows:
            n = _re.sub(r'\.[^.]+$', '', r[1]).lower()  # r[1] is name
            if _re.sub(r'[^a-z0-9]', '', n) == stem_norm:
                return r[0]  # return hash
        return None


    # ── Processing ────────────────────────────────────────────────────────────

    def _process(self, hash_: str):
        t = self._get(hash_)
        if not t:
            return
        if t["state"] in ("cached", "complete", "downloading"):
            return
        try:
            cached_map = self._cache_fn([{"info_hash": hash_}])
            is_cached  = cached_map.get(hash_, False)
            if is_cached:
                log.info(f"[{hash_[:8]}] Cached — ready to stream")
                self._set(hash_, state="cached")
                t2 = self._get(hash_)
                # Create fake import file and pre-warm FUSE cache immediately
                try:
                    import qbt_mock as _qbt
                    from name_match import classify, classify_from_files
                    _name     = t2.get("name") or hash_
                    _category = t2.get("category") or ""
                    _files    = self.get_files(hash_) or []

                    # Classify from file paths (ground truth) and persist to DB
                    _kind = classify_from_files(_files)
                    if _kind and not t2.get("kind"):
                        self._set(hash_, kind=_kind)
                    else:
                        _kind = t2.get("kind") or _kind or classify(_name, _files)

                    # Pre-warm FUSE file cache so readdir is instant
                    if _files:
                        try:
                            import fuse_mount as _fm
                            import time as _time
                            if _fm._pfs is not None:
                                with _fm._pfs._lock:
                                    _fm._pfs._file_cache[hash_] = (_files, _time.time() + _fm.DIRECTDL_TTL)
                                _fm._pfs._invalidate_name_map()
                        except Exception:
                            pass

                    _fn = _qbt._pick_fake_filename(_name, _files)
                    _qbt._make_fake_file(_category, _qbt._safe_name(_name), _fn, _files)
                except Exception as _e:
                    log.debug(f"Fake file / classify failed: {_e}")
                    _kind = "movie"

                # Notify Plex using the authoritative kind
                from fuse_mount import _category_subdir
                t2 = self._get(hash_)
                subdir = _category_subdir(t2.get("name", ""), t2.get("category", ""),
                                          kind=t2.get("kind", ""))
                _plex.notify_ready(subdir)
                try:
                    from app import write_strm_library as _write_strm
                    _write_strm(hash_)
                except Exception as _e:
                    log.debug(f"STRM library write skipped: {_e}")
            else:
                log.info(f"[{hash_[:8]}] Not cached — creating Premiumize transfer")
                pm_id = self._create_transfer(hash_, t.get("name") or hash_)
                if not pm_id:
                    self._set(hash_, state="error", error="Failed to create transfer")
                    return
                self._set(hash_, state="downloading", pm_transfer_id=pm_id)
        except Exception as e:
            log.exception(f"[{hash_[:8]}] Processing error")
            self._set(hash_, state="error", error=str(e))

    def _create_transfer(self, hash_: str, name: str):
        api_key = self._key_fn()
        if not api_key:
            return None
        magnet = f"magnet:?xt=urn:btih:{hash_}&dn={urllib.parse.quote(name, safe='')}"
        try:
            r = requests.post(
                "https://www.premiumize.me/api/transfer/create",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data=urllib.parse.urlencode({"src": magnet}),
                timeout=20,
            )
            r.raise_for_status()
            data = r.json()
            if data.get("status") == "success":
                return data.get("id")
        except Exception as e:
            log.warning(f"create_transfer error: {e}")
        return None

    # ── Background poller ─────────────────────────────────────────────────────

    def _start_poller(self):
        threading.Thread(target=self._poll_loop, daemon=True).start()

    def _poll_loop(self):
        while True:
            try:
                self._poll_all()
            except Exception:
                log.exception("Poller error")
            time.sleep(POLL_INTERVAL)

    def _poll_all(self):
        rows = self._db().execute(
            "SELECT hash, name, pm_transfer_id FROM transfers WHERE state='downloading'"
        ).fetchall()
        if not rows:
            return

        api_key = self._key_fn()
        if not api_key:
            return

        try:
            r = requests.get(
                "https://www.premiumize.me/api/transfer/list",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=15,
            )
            r.raise_for_status()
            data = r.json()
        except Exception as e:
            log.warning(f"poll_all error: {e}")
            return

        pm_map = {str(t["id"]): t for t in data.get("transfers", [])}

        for row in rows:
            hash_  = row["hash"]
            pm_id  = row["pm_transfer_id"]
            t      = pm_map.get(str(pm_id))
            if not t:
                continue
            status = t.get("status", "")
            if status in ("finished", "seeding"):
                log.info(f"[{hash_[:8]}] Transfer complete — ready to stream")
                self._set(hash_, state="complete")
                t2 = self._get(hash_)
                try:
                    import qbt_mock as _qbt
                    from name_match import classify_from_files
                    _name     = t2.get("name") or hash_
                    _category = t2.get("category") or ""
                    _files    = self.get_files(hash_) or []
                    # Classify from file paths and persist to DB
                    _kind = classify_from_files(_files)
                    if _kind and not t2.get("kind"):
                        self._set(hash_, kind=_kind)
                    _fn = _qbt._pick_fake_filename(_name, _files)
                    _qbt._make_fake_file(_category, _qbt._safe_name(_name), _fn, _files)
                except Exception as _e:
                    log.debug(f"Fake file creation skipped: {_e}")
                from fuse_mount import _category_subdir
                t2 = self._get(hash_)
                subdir = _category_subdir(t2.get("name", ""), t2.get("category", ""),
                                          kind=t2.get("kind", ""))
                _plex.notify_ready(subdir)
                try:
                    from app import write_strm_library as _write_strm
                    _write_strm(hash_)
                except Exception as _e:
                    log.debug(f"STRM library write skipped: {_e}")
            elif status == "error":
                self._set(hash_, state="error", error=t.get("message", "unknown"))

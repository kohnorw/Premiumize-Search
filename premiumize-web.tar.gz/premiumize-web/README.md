# premiumize-web

Web UI + qBittorrent mock + FUSE virtual filesystem for Premiumize.me.

## First-time setup

Run once on the host as root before deploying:

```bash
sudo ./setup.sh
```

This creates the shared bind-mount that allows the FUSE filesystem to propagate
from inside the container to the host, and persists it across reboots via `/etc/rc.local`.

## Deploy

```bash
cd /docker/premiumize-web
cp .env.example .env        # add your PREMIUMIZE_API_KEY
docker compose up -d --build
```

## Mount structure

```
/docker/premiumize-web/mnt/
  movies/   ← auto-detected by name (no season code)
  series/   ← auto-detected by S01E01 / Season 1 patterns
  cache/    ← persistent block cache
```

Point Plex at `/docker/premiumize-web/mnt/movies` and `/docker/premiumize-web/mnt/series`.

## Sonarr / Radarr

Add as a qBittorrent download client:

| Setting       | Value                        |
|---------------|------------------------------|
| Host          | `<your-server-ip>`           |
| Port          | `5000`                       |
| URL Base      | `/qbt`                       |
| Category      | `tv-sonarr` / `radarr`       |
| Username/Pass | leave blank                  |

Remote path mapping:
- Radarr: `/docker/premiumize-web/mnt/movies`
- Sonarr: `/docker/premiumize-web/mnt/series`

## Environment variables

| Variable              | Default     | Description                        |
|-----------------------|-------------|------------------------------------|
| `PREMIUMIZE_API_KEY`  | —           | Required                           |
| `TORZNAB_APIKEY`      | `changeme`  | API key for Torznab endpoint       |
| `PROWLARR_URL`        | —           | Optional Prowlarr URL              |
| `PROWLARR_API_KEY`    | —           | Optional Prowlarr API key          |
| `ENABLE_FUSE`         | `true`      | Set to `false` to disable FUSE     |

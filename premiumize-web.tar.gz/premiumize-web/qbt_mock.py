"""
qBittorrent Web API v2 mock.

Implements the endpoints Sonarr and Radarr use:
  GET  /qbt/api/v2/auth/login
  GET  /qbt/api/v2/app/version
  GET  /qbt/api/v2/app/webapiVersion
  GET  /qbt/api/v2/torrents/info
  POST /qbt/api/v2/torrents/add
  POST /qbt/api/v2/torrents/delete
  GET  /qbt/api/v2/torrents/files
  GET  /qbt/api/v2/torrents/properties

qBittorrent state mapping:
  queued      → "checkingResumeData"
  cached      → "checkingResumeData"  (fast path, will flip to complete shortly)
  downloading → "downloading"
  complete    → "uploading"  (seeding = complete in qbt terms)
  error       → "error"
"""

import hashlib
import re
import time
import urllib.parse

from flask import Blueprint, jsonify, request, Response

qbt = Blueprint("qbt", __name__, url_prefix="/qbt/api/v2")

# Injected by app.py on startup
_tm = None

def init(transfer_manager):
    global _tm
    _tm = transfer_manager


# ── State helpers ─────────────────────────────────────────────────────────────

QBT_STATE = {
    "queued":      "checkingResumeData",
    "cached":      "checkingResumeData",
    "downloading": "downloading",
    "complete":    "uploading",
    "error":       "error",
}

MOUNTPOINT = "/docker/premiumize-web/mnt"

def _torrent_to_qbt(t: dict) -> dict:
    hash_  = t["hash"]
    name   = t.get("name") or hash_
    state  = t.get("state", "queued")
    files  = []
    try:
        import json
        files = json.loads(t.get("files") or "[]")
    except Exception:
        pass

    size         = sum(int(f.get("size", 0)) for f in files) if files else 0
    completed    = size if state == "complete" else 0
    progress     = 1.0 if state == "complete" else 0.0
    save_path    = f"{MOUNTPOINT}/{hash_}/"

    return {
        "hash":           hash_,
        "name":           name,
        "state":          QBT_STATE.get(state, "unknown"),
        "size":           size,
        "completed":      completed,
        "progress":       progress,
        "save_path":      save_path,
        "content_path":   save_path,
        "category":       "",
        "tags":           "",
        "added_on":       int(t.get("added_at", time.time())),
        "completion_on":  int(t.get("updated_at", time.time())) if state == "complete" else -1,
        "dl_speed":       0,
        "up_speed":       0,
        "eta":            8640000 if state == "downloading" else 0,
        "num_seeds":      0,
        "num_leechs":     0,
        "ratio":          0.0,
        "tracker":        "",
        "seq_dl":         False,
        "f_l_piece_prio": False,
        "force_start":    False,
        "super_seeding":  False,
        "auto_tmm":       False,
        "availability":   1.0 if state == "complete" else 0.0,
    }


def _extract_hash(src: str) -> str | None:
    """Extract info hash from magnet URI or raw hash string."""
    if src.startswith("magnet:"):
        m = re.search(r'urn:btih:([0-9a-fA-F]{40})', src, re.IGNORECASE)
        if m:
            return m.group(1).lower()
        # base32 btih
        m = re.search(r'urn:btih:([A-Z2-7]{32})', src, re.IGNORECASE)
        if m:
            import base64
            try:
                b = base64.b32decode(m.group(1).upper())
                return b.hex()
            except Exception:
                pass
    if re.fullmatch(r'[0-9a-fA-F]{40}', src):
        return src.lower()
    return None


# ── Routes ────────────────────────────────────────────────────────────────────

@qbt.route("/auth/login", methods=["GET", "POST"])
def login():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/auth/logout", methods=["POST"])
def logout():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/app/version")
def app_version():
    return Response("v4.6.0", mimetype="text/plain")

@qbt.route("/app/webapiVersion")
def webapi_version():
    return Response("2.8.3", mimetype="text/plain")

@qbt.route("/app/preferences")
def preferences():
    return jsonify({
        "save_path":                  MOUNTPOINT,
        "temp_path":                  MOUNTPOINT,
        "temp_path_enabled":          False,
        "autorun_enabled":            False,
        "queueing_enabled":           False,
        "max_active_downloads":       5,
        "max_active_torrents":        5,
        "max_active_uploads":         5,
        "incomplete_files_ext":       False,
        "add_to_top_of_queue":        False,
    })

@qbt.route("/torrents/info")
def torrents_info():
    if _tm is None:
        return jsonify([])
    filter_  = request.args.get("filter", "all")
    hashes   = request.args.get("hashes", "")
    hash_set = set(h.lower() for h in hashes.split("|") if h) if hashes else None

    all_t = _tm.all_transfers()
    result = []
    for t in all_t:
        if hash_set and t["hash"] not in hash_set:
            continue
        result.append(_torrent_to_qbt(t))

    return jsonify(result)

@qbt.route("/torrents/add", methods=["POST"])
def torrents_add():
    if _tm is None:
        return Response("fails", mimetype="text/plain")

    # Accept magnet URLs or torrent files
    magnets = request.form.getlist("urls") or []
    raw     = request.form.get("urls", "")
    if raw and not magnets:
        magnets = [u.strip() for u in raw.splitlines() if u.strip()]

    name     = request.form.get("rename", "") or request.form.get("savepath", "")
    category = request.form.get("category", "")

    added = 0
    for src in magnets:
        hash_ = _extract_hash(src)
        if not hash_:
            continue
        torrent_name = name or hash_
        _tm.add(hash_, torrent_name)
        added += 1

    # Also handle uploaded .torrent files
    for f in request.files.getlist("torrents"):
        data = f.read()
        # Extract hash from torrent using bencode (basic)
        hash_ = _hash_from_torrent(data)
        if hash_:
            _tm.add(hash_, name or f.filename or hash_)
            added += 1

    return Response("Ok." if added else "fails", mimetype="text/plain")

@qbt.route("/torrents/delete", methods=["POST"])
def torrents_delete():
    if _tm is None:
        return Response("Ok.", mimetype="text/plain")
    hashes        = request.form.get("hashes", "")
    delete_files  = request.form.get("deleteFiles", "false").lower() == "true"
    for h in hashes.split("|"):
        h = h.strip().lower()
        if h:
            _tm.delete(h)
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/pause", methods=["POST"])
def torrents_pause():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/resume", methods=["POST"])
def torrents_resume():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/files")
def torrents_files():
    if _tm is None:
        return jsonify([])
    hash_ = request.args.get("hash", "").lower()
    files = _tm.get_files(hash_)
    result = []
    for i, f in enumerate(files):
        result.append({
            "index":        i,
            "name":         f.get("name", ""),
            "size":         int(f.get("size", 0)),
            "progress":     1.0,
            "priority":     1,
            "is_seed":      True,
            "piece_range":  [0, 0],
            "availability": 1.0,
        })
    return jsonify(result)

@qbt.route("/torrents/properties")
def torrents_properties():
    if _tm is None:
        return jsonify({})
    hash_ = request.args.get("hash", "").lower()
    t     = _tm.get_transfer(hash_)
    if not t:
        return jsonify({}), 404
    qbt_t = _torrent_to_qbt(t)
    return jsonify({
        "save_path":         qbt_t["save_path"],
        "creation_date":     int(t.get("added_at", time.time())),
        "piece_size":        262144,
        "comment":           "",
        "total_wasted":      0,
        "total_uploaded":    0,
        "total_downloaded":  qbt_t["completed"],
        "up_limit":          -1,
        "dl_limit":          -1,
        "time_elapsed":      0,
        "seeding_time":      0,
        "nb_connections":    0,
        "share_ratio":       0.0,
        "addition_date":     int(t.get("added_at", time.time())),
        "completion_date":   qbt_t["completion_on"],
        "created_by":        "premiumize-web",
        "dl_speed_avg":      0,
        "up_speed_avg":      0,
        "eta":               qbt_t["eta"],
        "last_seen":         int(time.time()),
        "peers":             0,
        "peers_total":       0,
        "pieces_have":       1,
        "pieces_num":        1,
        "reannounce":        0,
        "seeds":             0,
        "seeds_total":       0,
        "total_size":        qbt_t["size"],
    })

@qbt.route("/torrents/setCategory", methods=["POST"])
def set_category():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/addTags", methods=["POST"])
def add_tags():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/setAutoManagement", methods=["POST"])
def set_auto_mgmt():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/sync/maindata")
def sync_maindata():
    if _tm is None:
        return jsonify({"rid": 0, "full_update": True, "torrents": {}, "categories": {}})
    all_t = _tm.all_transfers()
    torrents = {t["hash"]: _torrent_to_qbt(t) for t in all_t}
    return jsonify({
        "rid":         int(time.time()),
        "full_update": True,
        "torrents":    torrents,
        "categories":  {},
        "tags":        [],
        "trackers":    {},
    })


# ── Torrent hash extraction ───────────────────────────────────────────────────

def _hash_from_torrent(data: bytes) -> str | None:
    """Very basic bencode info-hash extractor."""
    try:
        # Find the info dict
        idx = data.find(b"4:info")
        if idx == -1:
            return None
        info_start = idx + 6
        # Find the end of the info dict (find matching 'e')
        # Simple approach: hash from info_start to end-1
        info_data = data[info_start:-1]
        return hashlib.sha1(info_data).hexdigest()
    except Exception:
        return None

"""
qBittorrent Web API v2 mock.

Implements the endpoints Sonarr and Radarr use:
  GET  /qbt/api/v2/auth/login
  GET  /qbt/api/v2/app/version
  GET  /qbt/api/v2/app/webapiVersion
  GET  /qbt/api/v2/torrents/info
  POST /qbt/api/v2/torrents/add
  POST /qbt/api/v2/torrents/delete
  GET  /qbt/api/v2/torrents/files
  GET  /qbt/api/v2/torrents/properties

qBittorrent state mapping:
  queued      → "checkingResumeData"
  cached      → "uploading"   (already on CDN — treat as complete so Sonarr/Radarr imports)
  downloading → "downloading"
  complete    → "uploading"   (seeding = complete in qbt terms)
  error       → "error"
"""

import hashlib
import os
import re
import time
import urllib.parse

from flask import Blueprint, jsonify, request, Response

qbt = Blueprint("qbt", __name__, url_prefix="/qbt/api/v2")

# Injected by app.py on startup
_tm = None

def init(transfer_manager):
    global _tm
    _tm = transfer_manager


# ── State helpers ─────────────────────────────────────────────────────────────

QBT_STATE = {
    "queued":      "checkingResumeData",
    "cached":      "uploading",    # FIX: was "checkingResumeData" — Sonarr never imports from that state
    "downloading": "downloading",
    "complete":    "uploading",
    "error":       "error",
}

MOUNTPOINT = "/docker/premiumize-web/mnt"

# Matches S01, S01E01, S01E01-E03, Season 1, etc.
_SERIES_RE = re.compile(
    r'\bS\d{1,2}(?:E\d{1,2})?(?:-?E\d{1,2})?\b'   # S01 / S01E02 / S01E02-E04
    r'|\bSeason\s*\d+\b'                             # Season 1
    r'|\b\d{1,2}x\d{2}\b',                          # 1x02 (older naming)
    re.IGNORECASE
)

def _is_series(name: str) -> bool:
    return bool(_SERIES_RE.search(name or ""))

def _category_subdir(name: str, category: str = "") -> str:
    """Return 'series' or 'movies' based on torrent name patterns."""
    if _is_series(name):
        return "series"
    # Fall back to category keyword if name gives no signal
    cat = (category or "").lower()
    if any(k in cat for k in ("sonarr", "tv", "series", "show")):
        return "series"
    return "movies"

# Lazy import so fuse_mount.py doesn't have to be importable at module load
def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"


def _torrent_to_qbt(t: dict) -> dict:
    hash_  = t["hash"]
    name   = t.get("name") or hash_
    state  = t.get("state", "queued")

    # FIX: the transfers table has no "files" column, so the previous
    # json.loads(t.get("files")) always yielded [] and every cached torrent was
    # reported to Sonarr/Radarr as 0 bytes — which made them skip the import and
    # never import the file. For streamable states, pull the real
    # file list from the (cached, 30-min-TTL) directdl call instead.
    files = []
    if state in ("cached", "complete") and _tm is not None:
        try:
            files = _tm.get_files(hash_) or []
        except Exception:
            files = []

    size         = sum(int(f.get("size", 0)) for f in files)
    completed    = size if state in ("complete", "cached") else 0
    progress     = 1.0 if state in ("complete", "cached") else 0.0

    # FIX: use _safe_name so the FUSE directory name is reproduced exactly.
    fuse_dir  = _safe_name(name)
    subdir    = _category_subdir(name, t.get("category", ""))
    save_path    = f"{MOUNTPOINT}/{subdir}"
    content_path = f"{MOUNTPOINT}/{subdir}/{fuse_dir}"

    return {
        "hash":           hash_,
        "name":           name,
        "state":          QBT_STATE.get(state, "unknown"),
        "size":           size,
        "completed":      completed,
        "progress":       progress,
        "save_path":      save_path,
        "content_path":   content_path,
        "category":       t.get("category") or "",
        "tags":           "",
        "added_on":       int(t.get("added_at", time.time())),
        "completion_on":  int(t.get("updated_at", time.time())) if state in ("complete", "cached") else -1,
        "dl_speed":       0,
        "up_speed":       0,
        "eta":            8640000 if state == "downloading" else 0,
        "num_seeds":      0,
        "num_leechs":     0,
        "ratio":          0.0,
        "tracker":        "",
        "seq_dl":         False,
        "f_l_piece_prio": False,
        "force_start":    False,
        "super_seeding":  False,
        "auto_tmm":       False,
        "availability":   1.0 if state in ("complete", "cached") else 0.0,
    }


def _extract_hash(src: str) -> str | None:
    """Extract info hash from magnet URI or raw hash string."""
    if src.startswith("magnet:"):
        m = re.search(r'urn:btih:([0-9a-fA-F]{40})', src, re.IGNORECASE)
        if m:
            return m.group(1).lower()
        # base32 btih
        m = re.search(r'urn:btih:([A-Z2-7]{32})', src, re.IGNORECASE)
        if m:
            import base64
            try:
                b = base64.b32decode(m.group(1).upper())
                return b.hex()
            except Exception:
                pass
    if re.fullmatch(r'[0-9a-fA-F]{40}', src):
        return src.lower()
    return None


def _extract_name(src: str) -> str:
    """Extract torrent name from the dn= parameter of a magnet URI."""
    m = re.search(r'[?&]dn=([^&]+)', src)
    if m:
        return urllib.parse.unquote_plus(m.group(1))
    return ""


# ── Routes ────────────────────────────────────────────────────────────────────

@qbt.route("/auth/login", methods=["GET", "POST"])
def login():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/auth/logout", methods=["POST"])
def logout():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/app/version")
def app_version():
    return Response("v4.6.0", mimetype="text/plain")

@qbt.route("/app/webapiVersion")
def webapi_version():
    return Response("2.8.3", mimetype="text/plain")

@qbt.route("/app/preferences")
def preferences():
    return jsonify({
        "save_path":                  MOUNTPOINT,
        "temp_path":                  MOUNTPOINT,
        "temp_path_enabled":          False,
        "autorun_enabled":            False,
        "queueing_enabled":           False,
        "max_active_downloads":       5,
        "max_active_torrents":        5,
        "max_active_uploads":         5,
        "incomplete_files_ext":       False,
        "add_to_top_of_queue":        False,
    })

@qbt.route("/torrents/info")
def torrents_info():
    if _tm is None:
        return jsonify([])
    filter_   = request.args.get("filter", "all")
    hashes    = request.args.get("hashes", "")
    category  = request.args.get("category", "")
    hash_set  = set(h.lower() for h in hashes.split("|") if h) if hashes else None

    all_t  = _tm.all_transfers()
    result = []
    for t in all_t:
        if hash_set and t["hash"] not in hash_set:
            continue
        if category and t.get("category", "") != category:
            continue
        result.append(_torrent_to_qbt(t))

    return jsonify(result)

@qbt.route("/torrents/add", methods=["POST"])
def torrents_add():
    import logging
    import threading as _threading
    _log = logging.getLogger(__name__)

    if _tm is None:
        return Response("fails", mimetype="text/plain")

    # Accept magnet URLs or torrent files
    magnets = request.form.getlist("urls") or []
    raw     = request.form.get("urls", "")
    if raw and not magnets:
        magnets = [u.strip() for u in raw.splitlines() if u.strip()]

    # Sonarr/Radarr sends the release title in 'rename', fall back to
    # extracting from the magnet dn= or torrent metadata, never use raw hash
    rename   = (request.form.get("rename", "")
                or request.form.get("name", "")).strip()
    category = request.form.get("category", "").strip()

    # Collect all hashes + names from magnets
    torrents = []
    for src in magnets:
        hash_ = _extract_hash(src)
        if not hash_:
            continue
        torrent_name = rename or _extract_name(src) or hash_
        torrents.append((hash_, torrent_name))

    # Also handle uploaded .torrent files
    for f in request.files.getlist("torrents"):
        data  = f.read()
        hash_ = _hash_from_torrent(data)
        if hash_:
            # Extract name from torrent metadata, fall back to filename without .torrent
            meta_name   = _name_from_torrent(data)
            torrent_name = rename or meta_name or os.path.splitext(f.filename)[0] or hash_
            torrents.append((hash_, torrent_name))

    if not torrents:
        return Response("fails", mimetype="text/plain")

    # Check Premiumize cache for all hashes in one API call — cached torrents
    # are set to state="cached" immediately so the very first /torrents/info
    # poll from Sonarr/Radarr already sees them as complete (state="uploading").
    # Uncached torrents fall through to background _process() which creates a
    # Premiumize transfer and polls until done.
    cache_input = [{"info_hash": h} for h, _ in torrents]
    try:
        cached_map = _tm._cache_fn(cache_input)
    except Exception:
        cached_map = {}

    for hash_, name in torrents:
        existing = _tm.get_transfer(hash_)

        if existing and existing["state"] in ("cached", "downloading", "complete"):
            # Update name if it was stored as the raw hash
            stored_name = existing.get("name", "")
            if (not stored_name or stored_name == hash_) and name and name != hash_:
                _tm._set(hash_, name=name)
            continue

        is_cached = cached_map.get(hash_, False)

        if is_cached:
            _log.info(f"[{hash_[:8]}] qbt add: cached on Premiumize — marking ready immediately")
            _tm._set(hash_, name=name, state="cached", category=category, added_at=time.time())
        else:
            _log.info(f"[{hash_[:8]}] qbt add: not cached — queuing for download")
            _tm._set(hash_, name=name, state="queued", category=category, added_at=time.time())
            _threading.Thread(target=_tm._process, args=(hash_,), daemon=True).start()

    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/delete", methods=["POST"])
def torrents_delete():
    if _tm is None:
        return Response("Ok.", mimetype="text/plain")
    hashes        = request.form.get("hashes", "")
    delete_files  = request.form.get("deleteFiles", "false").lower() == "true"
    for h in hashes.split("|"):
        h = h.strip().lower()
        if h:
            _tm.delete(h)
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/pause", methods=["POST"])
def torrents_pause():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/resume", methods=["POST"])
def torrents_resume():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/files")
def torrents_files():
    if _tm is None:
        return jsonify([])
    hash_ = request.args.get("hash", "").lower()
    files = _tm.get_files(hash_)
    result = []
    for i, f in enumerate(files):
        # FIX: use basename so paths with slashes don't confuse Sonarr/Radarr
        name = os.path.basename(f.get("name", "") or f.get("path", ""))
        result.append({
            "index":        i,
            "name":         name,
            "size":         int(f.get("size", 0)),
            "progress":     1.0,
            "priority":     1,
            "is_seed":      True,
            "piece_range":  [0, 0],
            "availability": 1.0,
        })
    return jsonify(result)

@qbt.route("/torrents/properties")
def torrents_properties():
    if _tm is None:
        return jsonify({})
    hash_ = request.args.get("hash", "").lower()
    t     = _tm.get_transfer(hash_)
    if not t:
        return jsonify({}), 404
    qbt_t = _torrent_to_qbt(t)
    return jsonify({
        "save_path":         qbt_t["save_path"],
        "creation_date":     int(t.get("added_at", time.time())),
        "piece_size":        262144,
        "comment":           "",
        "total_wasted":      0,
        "total_uploaded":    0,
        "total_downloaded":  qbt_t["completed"],
        "up_limit":          -1,
        "dl_limit":          -1,
        "time_elapsed":      0,
        "seeding_time":      0,
        "nb_connections":    0,
        "share_ratio":       0.0,
        "addition_date":     int(t.get("added_at", time.time())),
        "completion_date":   qbt_t["completion_on"],
        "created_by":        "premiumize-web",
        "dl_speed_avg":      0,
        "up_speed_avg":      0,
        "eta":               qbt_t["eta"],
        "last_seen":         int(time.time()),
        "peers":             0,
        "peers_total":       0,
        "pieces_have":       1,
        "pieces_num":        1,
        "reannounce":        0,
        "seeds":             0,
        "seeds_total":       0,
        "total_size":        qbt_t["size"],
    })

@qbt.route("/torrents/setCategory", methods=["POST"])
def set_category():
    hashes   = request.form.get("hashes", "")
    category = request.form.get("category", "")
    for h in hashes.split("|"):
        h = h.strip().lower()
        if h and _tm:
            _tm._set(h, category=category)
    return Response("Ok.", mimetype="text/plain")

# ── Categories ────────────────────────────────────────────────────────────────
# Sonarr calls GET /torrents/categories on connection test and expects a 200
# with a JSON object of {name: {name, savePath}}.  It also POSTs createCategory
# and editCategory when setting up the download client category.

_CATEGORIES: dict = {
    "tv-sonarr":  {"name": "tv-sonarr",  "savePath": MOUNTPOINT},
    "radarr":     {"name": "radarr",     "savePath": MOUNTPOINT},
}

@qbt.route("/torrents/categories")
def get_categories():
    return jsonify(_CATEGORIES)

@qbt.route("/torrents/createCategory", methods=["POST"])
def create_category():
    name      = request.form.get("category", "").strip()
    save_path = request.form.get("savePath", MOUNTPOINT).strip() or MOUNTPOINT
    if name:
        _CATEGORIES[name] = {"name": name, "savePath": save_path}
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/editCategory", methods=["POST"])
def edit_category():
    name      = request.form.get("category", "").strip()
    save_path = request.form.get("savePath", MOUNTPOINT).strip() or MOUNTPOINT
    if name:
        _CATEGORIES[name] = {"name": name, "savePath": save_path}
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/removeCategories", methods=["POST"])
def remove_categories():
    cats = request.form.get("categories", "")
    for c in cats.splitlines():
        _CATEGORIES.pop(c.strip(), None)
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/addTags", methods=["POST"])
def add_tags():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/setAutoManagement", methods=["POST"])
def set_auto_mgmt():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/sync/maindata")
def sync_maindata():
    if _tm is None:
        return jsonify({"rid": 0, "full_update": True, "torrents": {}, "categories": {}})
    all_t = _tm.all_transfers()
    torrents = {t["hash"]: _torrent_to_qbt(t) for t in all_t}
    return jsonify({
        "rid":         int(time.time()),
        "full_update": True,
        "torrents":    torrents,
        "categories":  {},
        "tags":        [],
        "trackers":    {},
    })


# ── Torrent hash extraction ───────────────────────────────────────────────────

def _hash_from_torrent(data: bytes) -> str | None:
    """Very basic bencode info-hash extractor."""
    try:
        idx = data.find(b"4:info")
        if idx == -1:
            return None
        info_start = idx + 6
        info_data = data[info_start:-1]
        return hashlib.sha1(info_data).hexdigest()
    except Exception:
        return None


def _name_from_torrent(data: bytes) -> str:
    """Extract torrent name from bencode info dict."""
    try:
        # Try '4:name' key inside info dict
        for key in (b"4:name.utf-8", b"6:name.8", b"4:name"):
            idx = data.find(key)
            if idx != -1:
                rest = data[idx + len(key):]
                m = re.match(rb'(\d+):', rest)
                if m:
                    length = int(m.group(1))
                    start  = idx + len(key) + len(m.group(0))
                    return data[start:start + length].decode("utf-8", errors="replace")
    except Exception:
        pass
    return ""

"""
qBittorrent Web API v2 mock.

Implements the endpoints Sonarr and Radarr use:
  GET  /qbt/api/v2/auth/login
  GET  /qbt/api/v2/app/version
  GET  /qbt/api/v2/app/webapiVersion
  GET  /qbt/api/v2/torrents/info
  POST /qbt/api/v2/torrents/add
  POST /qbt/api/v2/torrents/delete
  GET  /qbt/api/v2/torrents/files
  GET  /qbt/api/v2/torrents/properties

qBittorrent state mapping:
  queued      → "checkingResumeData"
  cached      → "uploading"   (already on CDN — treat as complete so Sonarr/Radarr imports)
  downloading → "downloading"
  complete    → "uploading"   (seeding = complete in qbt terms)
  error       → "error"
"""

import hashlib
import os
import re
import time
import urllib.parse

from flask import Blueprint, jsonify, request, Response

qbt = Blueprint("qbt", __name__, url_prefix="/qbt/api/v2")

# Injected by app.py on startup
_tm = None

def init(transfer_manager):
    global _tm
    _tm = transfer_manager


# ── State helpers ─────────────────────────────────────────────────────────────

QBT_STATE = {
    "queued":      "checkingResumeData",
    "cached":      "uploading",    # FIX: was "checkingResumeData" — Sonarr never imports from that state
    "downloading": "downloading",
    "complete":    "uploading",
    "error":       "error",
}

MOUNTPOINT = "/docker/premiumize-web/mnt"

# Fake-file download folder.
# When a transfer becomes ready, we create a real folder containing a tiny
# placeholder .mkv file named after the torrent. Radarr/Sonarr import this
# file (it's just a few bytes), register the movie/show in their database,
# then call /torrents/delete. We delete the fake folder — done.
# Plex streams the real file from the FUSE mount independently.
#
#   /docker/premiumize-web/downloads/
#     radarr/
#       Movie.Name.2024/
#         Movie.Name.2024.mkv    ← 1KB placeholder, gets imported then deleted
#     sonarr/
#       Show.Name.S01E01/
#         Show.Name.S01E01.mkv   ← same

DOWNLOADS_ROOT = os.environ.get("DOWNLOADS_ROOT", "/docker/premiumize-web/downloads")
RADARR_DL_DIR  = os.path.join(DOWNLOADS_ROOT, "radarr")
SONARR_DL_DIR  = os.path.join(DOWNLOADS_ROOT, "sonarr")

# Minimal valid MKV header (EBML magic bytes). Just enough for ffprobe to
# identify the container — Radarr/Sonarr won't reject it as "not a video file".
_MKV_HEADER = bytes([
    0x1A, 0x45, 0xDF, 0xA3,  # EBML magic
    0x9F,                     # EBML element size (31 bytes)
    0x42, 0x86, 0x81, 0x01,  # EBMLVersion = 1
    0x42, 0xF7, 0x81, 0x01,  # EBMLReadVersion = 1
    0x42, 0xF2, 0x81, 0x04,  # EBMLMaxIDLength = 4
    0x42, 0xF3, 0x81, 0x08,  # EBMLMaxSizeLength = 8
    0x42, 0x82, 0x84,        # DocType string, length 4
    0x6D, 0x61, 0x74, 0x72, 0x6F, 0x73, 0x6B, 0x61,  # "matroska"
    0x42, 0x87, 0x81, 0x04,  # DocTypeVersion = 4
    0x42, 0x85, 0x81, 0x02,  # DocTypeReadVersion = 2
])  # just the header — file size set via sparse seek in _make_fake_file

import logging as _qbt_log
_log = _qbt_log.getLogger(__name__)

def _ensure_dl_dirs():
    os.makedirs(RADARR_DL_DIR, exist_ok=True)
    os.makedirs(SONARR_DL_DIR, exist_ok=True)

def _dl_dir(subdir: str) -> str:
    return SONARR_DL_DIR if subdir == "series" else RADARR_DL_DIR

def _fake_folder(subdir: str, folder_name: str) -> str:
    return os.path.join(_dl_dir(subdir), folder_name)

def _pick_fake_filename(name: str, files: list) -> str:
    """
    Choose the best filename for the fake file.
    Prefer the largest video file's name from the real file list so Radarr
    parses it correctly (resolution, codec, group tags all come from the name).
    Falls back to <folder_name>.mkv.
    """
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
                  ".wmv", ".flv", ".webm", ".m2ts", ".mpg", ".mpeg"}
    best, best_size = None, 0
    for f in files:
        raw   = f.get("name") or f.get("path") or ""
        fname = os.path.basename(raw)
        _, ext = os.path.splitext(fname)
        fsize = int(f.get("size", 0))
        if ext.lower() in video_exts and fsize > best_size:
            best, best_size = fname, fsize
    if best:
        return best
    # Fallback: sanitise the torrent name and add .mkv
    safe = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(". ")[:180]
    return f"{safe}.mkv"

def _make_fake_file(subdir: str, folder_name: str, filename: str) -> str:
    """
    Create a download folder containing a tiny placeholder video file.
    Returns the path to the fake file (content_path for Radarr/Sonarr).
    """
    _ensure_dl_dirs()
    folder = _fake_folder(subdir, folder_name)
    fpath  = os.path.join(folder, filename)
    if os.path.exists(fpath):
        return fpath
    try:
        os.makedirs(folder, exist_ok=True)
        with open(fpath, "wb") as f:
            # Write the real MKV header so Radarr accepts it as a video file
            f.write(_MKV_HEADER)
            # Seek to 250MB - 1 and write one byte to create a sparse file.
            # The file reports as 250MB to pass Radarr minimum size checks
            # but uses almost no real disk space.
            f.seek(250 * 1024 * 1024 - 1)
            f.write(b"\x00")
        _log.info(f"Fake file created: {fpath}")
    except OSError as e:
        _log.warning(f"Could not create fake file {fpath}: {e}")
    return fpath

def _remove_fake_folder(subdir: str, folder_name: str):
    """Remove the fake download folder after Radarr/Sonarr have imported."""
    import shutil
    folder = _fake_folder(subdir, folder_name)
    if os.path.isdir(folder):
        try:
            shutil.rmtree(folder)
            _log.info(f"Fake folder removed: {folder}")
        except OSError as e:
            _log.warning(f"Could not remove fake folder {folder}: {e}")

# Matches S01, S01E01, S01E01-E03, Season 1, etc.
_SERIES_RE = re.compile(
    r'\bS\d{1,2}(?:E\d{1,2})?(?:-?E\d{1,2})?\b'   # S01 / S01E02 / S01E02-E04
    r'|\bSeason\s*\d+\b'                             # Season 1
    r'|\b\d{1,2}x\d{2}\b',                          # 1x02 (older naming)
    re.IGNORECASE
)

def _is_series(name: str) -> bool:
    return bool(_SERIES_RE.search(name or ""))

def _category_subdir(name: str, category: str = "") -> str:
    """Return 'series' or 'movies' based on torrent name patterns."""
    if _is_series(name):
        return "series"
    # Fall back to category keyword if name gives no signal
    cat = (category or "").lower()
    if any(k in cat for k in ("sonarr", "tv", "series", "show")):
        return "series"
    return "movies"

# Lazy import so fuse_mount.py doesn't have to be importable at module load
def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"


def _torrent_to_qbt(t: dict) -> dict:
    hash_  = t["hash"]
    name   = t.get("name") or hash_
    state  = t.get("state", "queued")

    # FIX: the transfers table has no "files" column, so the previous
    # json.loads(t.get("files")) always yielded [] and every cached torrent was
    # reported to Sonarr/Radarr as 0 bytes — which made them skip the import and
    # never import the file. For streamable states, pull the real
    # file list from the (cached, 30-min-TTL) directdl call instead.
    files = []
    if state in ("cached", "complete") and _tm is not None:
        try:
            files = _tm.get_files(hash_) or []
        except Exception:
            files = []

    size         = sum(int(f.get("size", 0)) for f in files)
    completed    = size if state in ("complete", "cached") else 0
    progress     = 1.0 if state in ("complete", "cached") else 0.0

    fuse_dir  = _safe_name(name)
    subdir    = _category_subdir(name, t.get("category", ""))
    save_path = _dl_dir(subdir)

    # content_path points at a real tiny placeholder file inside a real folder.
    # Radarr/Sonarr import this file (register in their DB), then call
    # /torrents/delete — we delete the fake folder. The FUSE mount is untouched.
    fake_filename = _pick_fake_filename(name, files)
    if state in ("cached", "complete"):
        content_path = _make_fake_file(subdir, fuse_dir, fake_filename)
    else:
        content_path = os.path.join(_fake_folder(subdir, fuse_dir), fake_filename)

    return {
        "hash":           hash_,
        "name":           name,
        "state":          QBT_STATE.get(state, "unknown"),
        "size":           size,
        "completed":      completed,
        "progress":       progress,
        "save_path":      save_path,
        "content_path":   content_path,
        "category":       t.get("category") or "",
        "tags":           "",
        "added_on":       int(t.get("added_at", time.time())),
        "completion_on":  int(t.get("updated_at", time.time())) if state in ("complete", "cached") else -1,
        "dl_speed":       0,
        "up_speed":       0,
        "eta":            8640000 if state == "downloading" else 0,
        "num_seeds":      0,
        "num_leechs":     0,
        "ratio":          0.0,
        "tracker":        "",
        "seq_dl":         False,
        "f_l_piece_prio": False,
        "force_start":    False,
        "super_seeding":  False,
        "auto_tmm":       False,
        "availability":   1.0 if state in ("complete", "cached") else 0.0,
    }


def _extract_hash(src: str) -> str | None:
    """Extract info hash from magnet URI or raw hash string."""
    if src.startswith("magnet:"):
        m = re.search(r'urn:btih:([0-9a-fA-F]{40})', src, re.IGNORECASE)
        if m:
            return m.group(1).lower()
        # base32 btih
        m = re.search(r'urn:btih:([A-Z2-7]{32})', src, re.IGNORECASE)
        if m:
            import base64
            try:
                b = base64.b32decode(m.group(1).upper())
                return b.hex()
            except Exception:
                pass
    if re.fullmatch(r'[0-9a-fA-F]{40}', src):
        return src.lower()
    return None


def _extract_name(src: str) -> str:
    """Extract torrent name from the dn= parameter of a magnet URI."""
    m = re.search(r'[?&]dn=([^&]+)', src)
    if m:
        return urllib.parse.unquote_plus(m.group(1))
    return ""


# ── Routes ────────────────────────────────────────────────────────────────────

@qbt.route("/auth/login", methods=["GET", "POST"])
def login():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/auth/logout", methods=["POST"])
def logout():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/app/version")
def app_version():
    return Response("v4.6.0", mimetype="text/plain")

@qbt.route("/app/webapiVersion")
def webapi_version():
    return Response("2.8.3", mimetype="text/plain")

@qbt.route("/app/preferences")
def preferences():
    return jsonify({
        "save_path":                  DOWNLOADS_ROOT,
        "temp_path":                  DOWNLOADS_ROOT,
        "temp_path_enabled":          False,
        "autorun_enabled":            False,
        "queueing_enabled":           False,
        "max_active_downloads":       5,
        "max_active_torrents":        5,
        "max_active_uploads":         5,
        "incomplete_files_ext":       False,
        "add_to_top_of_queue":        False,
    })

@qbt.route("/torrents/info")
def torrents_info():
    if _tm is None:
        return jsonify([])
    filter_   = request.args.get("filter", "all")
    hashes    = request.args.get("hashes", "")
    category  = request.args.get("category", "")
    hash_set  = set(h.lower() for h in hashes.split("|") if h) if hashes else None

    all_t  = _tm.all_transfers()
    result = []
    for t in all_t:
        # Only expose cached/complete torrents — Sonarr/Radarr should never
        # see queued/downloading/error states as they can't stream them
        if t.get("state") not in ("cached", "complete"):
            continue
        if hash_set and t["hash"] not in hash_set:
            continue
        if category and t.get("category", "") != category:
            continue
        result.append(_torrent_to_qbt(t))

    return jsonify(result)

@qbt.route("/torrents/add", methods=["POST"])
def torrents_add():
    import logging
    import threading as _threading
    _log = logging.getLogger(__name__)

    if _tm is None:
        return Response("fails", mimetype="text/plain")

    # Log everything Sonarr/Radarr sends so we can see what fields are available
    _log.info(f"[torrents/add] form fields: { {k: v for k, v in request.form.items()} }")
    _log.info(f"[torrents/add] files: { [f.filename for f in request.files.getlist('torrents')] }")

    # Accept magnet URLs or torrent files
    magnets = request.form.getlist("urls") or []
    raw     = request.form.get("urls", "")
    if raw and not magnets:
        magnets = [u.strip() for u in raw.splitlines() if u.strip()]

    # Sonarr/Radarr sends the release title in 'rename', fall back to
    # extracting from the magnet dn= or torrent metadata, never use raw hash
    rename   = (request.form.get("rename", "")
                or request.form.get("name", "")).strip()
    category = request.form.get("category", "").strip()

    _log.info(f"[torrents/add] rename='{rename}' category='{category}' magnets={len(magnets)}")

    # Collect all hashes + names from magnets
    torrents = []
    for src in magnets:
        hash_ = _extract_hash(src)
        if not hash_:
            continue
        torrent_name = rename or _extract_name(src) or hash_
        _log.info(f"[torrents/add] magnet hash={hash_[:8]} name='{torrent_name}'")
        torrents.append((hash_, torrent_name))

    # Also handle uploaded .torrent files
    for f in request.files.getlist("torrents"):
        data  = f.read()
        hash_ = _hash_from_torrent(data)
        if hash_:
            meta_name    = _name_from_torrent(data)
            torrent_name = rename or meta_name or os.path.splitext(f.filename)[0] or hash_
            _log.info(f"[torrents/add] torrent file hash={hash_[:8]} filename='{f.filename}' meta_name='{meta_name}' final='{torrent_name}'")
            torrents.append((hash_, torrent_name))

    if not torrents:
        return Response("fails", mimetype="text/plain")

    # Check Premiumize cache for all hashes in one API call — cached torrents
    # are set to state="cached" immediately so the very first /torrents/info
    # poll from Sonarr/Radarr already sees them as complete (state="uploading").
    # Uncached torrents fall through to background _process() which creates a
    # Premiumize transfer and polls until done.
    cache_input = [{"info_hash": h} for h, _ in torrents]
    try:
        cached_map = _tm._cache_fn(cache_input)
    except Exception:
        cached_map = {}

    for hash_, name in torrents:
        existing = _tm.get_transfer(hash_)

        if existing and existing["state"] in ("cached", "downloading", "complete"):
            # Update name if it was stored as the raw hash
            stored_name = existing.get("name", "")
            if (not stored_name or stored_name == hash_) and name and name != hash_:
                _tm._set(hash_, name=name)
            continue

        is_cached = cached_map.get(hash_, False)

        if is_cached:
            _log.info(f"[{hash_[:8]}] qbt add: cached on Premiumize — marking ready immediately")
            _tm._set(hash_, name=name, state="cached", category=category, added_at=time.time())
            # Create fake file immediately with the correct filename.
            # Fetch real file list now so the name matches what _torrent_to_qbt
            # will report — avoids Radarr getting two different content_paths.
            subdir = _category_subdir(name, category)
            try:
                real_files = _tm.get_files(hash_) or []
            except Exception:
                real_files = []
            fake_fn = _pick_fake_filename(name, real_files)
            _make_fake_file(subdir, _safe_name(name), fake_fn)
        else:
            _log.info(f"[{hash_[:8]}] qbt add: not cached — queuing for download")
            _tm._set(hash_, name=name, state="queued", category=category, added_at=time.time())
            _threading.Thread(target=_tm._process, args=(hash_,), daemon=True).start()

    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/delete", methods=["POST"])
def torrents_delete():
    if _tm is None:
        return Response("Ok.", mimetype="text/plain")
    hashes = request.form.get("hashes", "")
    for h in hashes.split("|"):
        h = h.strip().lower()
        if not h:
            continue
        # Remove the fake download folder — do NOT delete the transfer from
        # the DB. The FUSE mount must keep serving the file after Radarr/Sonarr
        # import it. Deleting from DB would unmount the file and break playback.
        t = _tm.get_transfer(h)
        if t:
            name   = t.get("name") or h
            subdir = _category_subdir(name, t.get("category", ""))
            _remove_fake_folder(subdir, _safe_name(name))
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/pause", methods=["POST"])
def torrents_pause():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/resume", methods=["POST"])
def torrents_resume():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/files")
def torrents_files():
    if _tm is None:
        return jsonify([])
    hash_ = request.args.get("hash", "").lower()
    files = _tm.get_files(hash_)
    result = []
    for i, f in enumerate(files):
        # FIX: use basename so paths with slashes don't confuse Sonarr/Radarr
        name = os.path.basename(f.get("name", "") or f.get("path", ""))
        result.append({
            "index":        i,
            "name":         name,
            "size":         int(f.get("size", 0)),
            "progress":     1.0,
            "priority":     1,
            "is_seed":      True,
            "piece_range":  [0, 0],
            "availability": 1.0,
        })
    return jsonify(result)

@qbt.route("/torrents/properties")
def torrents_properties():
    if _tm is None:
        return jsonify({})
    hash_ = request.args.get("hash", "").lower()
    t     = _tm.get_transfer(hash_)
    if not t:
        return jsonify({}), 404
    qbt_t = _torrent_to_qbt(t)
    return jsonify({
        "save_path":         qbt_t["save_path"],
        "creation_date":     int(t.get("added_at", time.time())),
        "piece_size":        262144,
        "comment":           "",
        "total_wasted":      0,
        "total_uploaded":    0,
        "total_downloaded":  qbt_t["completed"],
        "up_limit":          -1,
        "dl_limit":          -1,
        "time_elapsed":      0,
        "seeding_time":      0,
        "nb_connections":    0,
        "share_ratio":       0.0,
        "addition_date":     int(t.get("added_at", time.time())),
        "completion_date":   qbt_t["completion_on"],
        "created_by":        "premiumize-web",
        "dl_speed_avg":      0,
        "up_speed_avg":      0,
        "eta":               qbt_t["eta"],
        "last_seen":         int(time.time()),
        "peers":             0,
        "peers_total":       0,
        "pieces_have":       1,
        "pieces_num":        1,
        "reannounce":        0,
        "seeds":             0,
        "seeds_total":       0,
        "total_size":        qbt_t["size"],
    })

@qbt.route("/torrents/setCategory", methods=["POST"])
def set_category():
    hashes   = request.form.get("hashes", "")
    category = request.form.get("category", "")
    for h in hashes.split("|"):
        h = h.strip().lower()
        if h and _tm:
            _tm._set(h, category=category)
    return Response("Ok.", mimetype="text/plain")

# ── Categories ────────────────────────────────────────────────────────────────
# Sonarr calls GET /torrents/categories on connection test and expects a 200
# with a JSON object of {name: {name, savePath}}.  It also POSTs createCategory
# and editCategory when setting up the download client category.

_CATEGORIES: dict = {
    "tv-sonarr":  {"name": "tv-sonarr",  "savePath": SONARR_DL_DIR},
    "radarr":     {"name": "radarr",     "savePath": RADARR_DL_DIR},
}

@qbt.route("/torrents/categories")
def get_categories():
    return jsonify(_CATEGORIES)

@qbt.route("/torrents/createCategory", methods=["POST"])
def create_category():
    name      = request.form.get("category", "").strip()
    save_path = request.form.get("savePath", DOWNLOADS_ROOT).strip() or DOWNLOADS_ROOT
    if name:
        _CATEGORIES[name] = {"name": name, "savePath": save_path}
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/editCategory", methods=["POST"])
def edit_category():
    name      = request.form.get("category", "").strip()
    save_path = request.form.get("savePath", DOWNLOADS_ROOT).strip() or DOWNLOADS_ROOT
    if name:
        _CATEGORIES[name] = {"name": name, "savePath": save_path}
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/removeCategories", methods=["POST"])
def remove_categories():
    cats = request.form.get("categories", "")
    for c in cats.splitlines():
        _CATEGORIES.pop(c.strip(), None)
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/addTags", methods=["POST"])
def add_tags():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/setAutoManagement", methods=["POST"])
def set_auto_mgmt():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/sync/maindata")
def sync_maindata():
    if _tm is None:
        return jsonify({"rid": 0, "full_update": True, "torrents": {}, "categories": {}})
    all_t = _tm.all_transfers()
    torrents = {t["hash"]: _torrent_to_qbt(t) for t in all_t}
    return jsonify({
        "rid":         int(time.time()),
        "full_update": True,
        "torrents":    torrents,
        "categories":  {},
        "tags":        [],
        "trackers":    {},
    })


# ── Torrent hash extraction ───────────────────────────────────────────────────

def _hash_from_torrent(data: bytes) -> str | None:
    """Very basic bencode info-hash extractor."""
    try:
        idx = data.find(b"4:info")
        if idx == -1:
            return None
        info_start = idx + 6
        info_data = data[info_start:-1]
        return hashlib.sha1(info_data).hexdigest()
    except Exception:
        return None


def _name_from_torrent(data: bytes) -> str:
    """Extract torrent name from bencode — tries name.utf-8 then name."""
    try:
        for key in (b"12:name.utf-8", b"4:name"):
            idx = data.find(key)
            if idx == -1:
                continue
            rest = data[idx + len(key):]
            m = re.match(rb'(\d+):', rest)
            if m:
                length = int(m.group(1))
                start  = len(m.group(0))
                name   = rest[start:start + length].decode("utf-8", errors="replace").strip()
                if name:
                    return name
    except Exception:
        pass
    return ""

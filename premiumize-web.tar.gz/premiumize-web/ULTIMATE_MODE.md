# Premiumize Web Ultimate Mode

This build is designed for a Plex + FUSE library where Plex only scans tiny stub files and real Premiumize CDN bytes are served only on playback.

## Flow

1. Sonarr/Radarr finds cached content.
2. Premiumize Web creates/updates the FUSE stub entry.
3. Premiumize Web queues one debounced Plex path refresh for that item folder only.
4. Plex adds the movie/show from the stub without a full library scan.
5. No media bandwidth is used during the add-time scan.
6. When Plex actually reads the file for playback, FUSE unlocks that exact file and serves CDN ranges.

## Important settings

Set Plex settings in Premiumize Web:

- Plex URL
- Plex token
- Movie section ID
- TV section ID
- Plex-visible mount path
- Auto scan enabled: ON
- Partial/path scan: ON
- Full fallback: OFF
- Scan on unlock: OFF

Recommended Plex server library settings:

- Generate video preview thumbnails: Never
- Generate intro markers: Never
- Generate credits markers: Never
- Analyze audio tracks: Never

## Tautulli

Tautulli is no longer needed. The old webhook endpoint still returns HTTP 200 so old Tautulli configs do not spam errors, but it does not unlock anything.

## Reset stubs

```bash
curl -X POST http://premiumize-web:5000/api/fuse/stubs/reset
```

## Logs to watch

```text
[plex-add] path refresh triggered: ...
[auto-unlock] unlocked hash=... file=...
```

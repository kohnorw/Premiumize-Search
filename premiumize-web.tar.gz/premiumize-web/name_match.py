"""
name_match.py — shared release-name parsing and fuzzy matching for
premiumize-web sync/reconcile.

All matching is done by normalising both sides to a comparable token set,
then doing graded comparison (exact → year+title → title-only → partial).
"""

import re
from difflib import SequenceMatcher

# ---------------------------------------------------------------------------
# Common noise tokens that appear in release names but not in Arr titles
# ---------------------------------------------------------------------------
_NOISE = re.compile(
    r'\b(?:'
    r'1080[ip]|720[ip]|2160[ip]|480[ip]|576[ip]'
    r'|4k|uhd|hdr|hdr10|hdr10\+|dv|dolbyvision'
    r'|bluray|blu.?ray|bdrip|bdremux|bdrip'
    r'|web.?dl|webrip|web|hmax|nf|atvp|dsnp|amzn|peacock|max'
    r'|hdtv|pdtv|dsr|dvdrip|dvd'
    r'|x264|x265|h264|h265|hevc|avc|av1|xvid|divx'
    r'|10bit|8bit|hi10p'
    r'|aac|dts|truehd|atmos|dd5?\.?1|ac3|eac3|flac|mp3|opus'
    r'|remux|repack|proper|extended|theatrical|directors?cut|final\.?cut'
    r'|imax|open\.?matte|hfr'
    r'|complete|season|collection|trilogy|series|mini.?series'
    r'|tgx|yts|yify|rarbg|ethel|ntb|cakes|nahom|rav1ne|edge2020|pahe'
    r')\b',
    re.IGNORECASE,
)

_SERIES_RE = re.compile(
    r'\bS(0?[1-9]|[1-5]\d|60)(?:E\d{1,3})?(?:[-–]E?\d{1,3})?\b(?![a-zA-Z])'  # S01-S60, S01E01
    r'|\bSeasons?[\s._-]*\d+\b'                                     # Season 1, Seasons 1
    r'|\bSeasons?[\s._-]*(?:One|Two|Three|Four|Five|Six|Seven|Eight|Nine|Ten)\b'  # Season One
    r'|\bSeasons?[\s._-]*\d+[\s._-]*(?:to|and|&|[-–])[\s._-]*\d+\b'  # Seasons 1 to 6
    r'|\bSeasons?[\s._-]*\d+(?:[\s._-]*[+]\s*\d+)+\b'          # Seizoen 1+2+3
    r'|\b\d{1,2}x\d{2}\b'                                          # 1x01
    r'|\bEpisode[\s._-]*\d+\b'                                      # Episode 1
    r'|\bComplete[\s._-]*Series\b'                                   # Complete Series
    r'|\bFull[\s._-]*Series\b'                                       # Full Series
    r'|\bMini[\s._-]*Series\b'                                       # Mini Series
    r'|\bPart[\s._-]*\d+\s+of\s+\d+\b'                          # Part 1 of 3
    r'|\bSeizoen[\s._-]*\d+\b'                                      # Dutch: Seizoen 1
    r'|\bSeizoen[\s._-]*\d+(?:[+\s]*\d+)+\b'                     # Dutch: Seizoen 1+2+3
    r'|\bStagione[\s._-]*\d+\b'                                     # Italian
    r'|\bTemporada[\s._-]*\d+\b'                                    # Spanish
    r'|\bSaison[\s._-]*\d+\b'                                       # French
    r'|\bStaffel[\s._-]*\d+\b'                                      # German
    r'|\bSeries[\s._-]*\d+\b'                                       # British: Series 1
    r'|\((?:19|20)\d{2}[-–](?:19|20)\d{2}\)'               # (1999-2015) TV run in parens
    r'|\[Complete\]'                                                   # [Complete] tag
    r'|\bComplete\b'                                                   # bare Complete (anime packs etc)
    # ── anime-specific patterns ───────────────────────────────────────────────
    r'|\bS(\d{1,2})\b(?![\w/])'                                    # bare S2, S3 (no E following)
    r'|(?<![\w\d])-\s+(\d{1,3})\b(?!\s*(?:bit|fps|hz|p\b))'   # anime ep separator: - 05, - 138
    r'|\((\d{2,3})-(\d{2,3})\)'                                    # episode range in parens: (01-25)
    r'|\b(\d{2,3})\s*~\s*(\d{2,3})\b'                           # tilde range: 01 ~ 14
    r'|\(Batch\)'                                                      # (Batch)
    r'|\bBatch\b'                                                      # bare Batch
    r'|\bOVAs?\b'                                                      # OVA, OVAs
    r'|\bSpecials?\b',                                                  # Special, Specials
    re.IGNORECASE,
)

_YEAR_RE   = re.compile(r'\b((?:19|20)\d{2})\b')
_SEASON_RE = re.compile(
    r'(?i)\bS(\d{1,2})(?:[-–]S?\d{1,2})?\b'        # S01 / S01-S10
    r'|\bSeason[\s._-]*(\d{1,2})\b'                  # Season 1
    r'|\bEpisode[\s._-]*\d+'                          # Episode N (season unknown)
)
_EPISODE_RE = re.compile(
    r'(?i)\bS(\d{1,2})E(\d{1,3})(?:[-–]E?(\d{1,3}))?\b'
)

# 4K detection: 2160p, 4K, UHD
_4K_RE = re.compile(r'(?i)(2160p|\b4k\b|\buhd\b|3840[\s._x]?2160|4096[\s._x]?2160)')


def _norm(s: str) -> str:
    """Collapse to lowercase alphanumeric only."""
    return re.sub(r'[^a-z0-9]', '', (s or '').lower())


def _clean_title(name: str) -> str:
    """
    Strip release noise from a folder/torrent name to get the bare title.
    Also strips leading/trailing articles for comparison.
    """
    n = (name or '').replace('.', ' ').replace('_', ' ')
    # Remove series markers and everything after
    n = _SERIES_RE.sub('', n)
    # Remove year and everything after first year
    m = _YEAR_RE.search(n)
    if m:
        n = n[:m.start()]
    # Remove noise tokens
    n = _NOISE.sub('', n)
    # Strip group tags in brackets/parens at end
    n = re.sub(r'[\[\(][^\]\)]{1,20}[\]\)]', ' ', n)
    # Strip any dangling opening bracket
    n = re.sub(r'[\[\(]\s*$', '', n)
    # Collapse whitespace and strip
    n = re.sub(r'\s+', ' ', n).strip(' -–()')
    return n


def parse_movie(name: str):
    """
    Returns (clean_title, year|None) from a movie release name.
    """
    n = (name or '').replace('.', ' ').replace('_', ' ')
    m = _YEAR_RE.search(n)
    year  = m.group(1) if m else None
    title = n[:m.start()].strip() if m else n
    title = _NOISE.sub('', title).strip()
    title = re.sub(r'\s+', ' ', title).strip(' -–')
    return title, year


def parse_episode(name: str):
    """
    Returns (series_title, season, [episode_nums]) from a release name.
    episode_nums=None means season pack (matches all episodes in season).
    season=None means no season info found.
    """
    n = (name or '').replace('.', ' ').replace('_', ' ')

    m = _EPISODE_RE.search(n)
    if m:
        season = int(m.group(1))
        e1     = int(m.group(2))
        e2     = int(m.group(3)) if m.group(3) else e1
        if e2 < e1 or e2 - e1 > 60:
            e2 = e1
        title  = _clean_title(n[:m.start()])
        return title, season, list(range(e1, e2 + 1))

    m2 = _SEASON_RE.search(n)
    if m2:
        season = int(m2.group(1) or m2.group(2) or 1)
        title  = _clean_title(n[:m2.start()])
        return title, season, None   # pack

    # No episode/season info — try to salvage a title anyway
    title = _clean_title(n)
    return title, None, None


def _get_overrides_safe() -> dict:
    """Get overrides without importing app — reads from fuse_mount's shared ref."""
    try:
        import fuse_mount as _fm
        return _fm._overrides
    except Exception:
        return {}

def _override_key_safe(name: str) -> str:
    try:
        import fuse_mount as _fm
        return _fm._override_key(name)
    except Exception:
        return re.sub(r'[^a-z0-9]', '', (name or '').lower())


def is_series(name: str) -> bool:
    ov  = _get_overrides_safe()
    key = _override_key_safe(name)
    if key in ov:
        return ov[key]["kind"] == "series"
    return bool(_SERIES_RE.search(name or ''))


# ── File-path based classification ───────────────────────────────────────────
# Patterns that definitively identify series content in actual file paths.
# These are checked against the real paths returned by Premiumize directdl,
# not just the torrent name — giving 100% accuracy for cached transfers.
_PATH_SERIES_RE = re.compile(
    r'S\d{1,2}E\d{1,3}'                              # S01E01
    r'|\bSeason[\s._-]*\d+'                           # Season 1/ or Season.1
    r'|\b\d{1,2}x\d{2}\b'                            # 1x01
    r'|\bEp(?:isode)?[\s._-]*\d+'                    # Episode 5 / Ep.05
    r'|(?:^|[\\/._\s-])E(\d{2,3})(?:[._\s-]|$)',    # bare .E01. (2+ digits, bounded)
    re.IGNORECASE
)

def classify_from_files(files: list) -> str | None:
    """Classify as 'series' or 'movie' from actual directdl file paths.
    Returns None if files list is empty or inconclusive.
    This is the most reliable classification method — uses ground truth
    from the actual file structure, not the torrent name.
    """
    if not files:
        return None
    for f in files:
        path = f.get("path") or f.get("name") or ""
        if _PATH_SERIES_RE.search(path):
            return "series"
    # No episode markers found in any file path → movie
    # Only conclude 'movie' if we actually have files (empty = inconclusive)
    return "movie"


def classify(name: str, files: list | None = None,
             stored_kind: str = "") -> str:
    """
    Single authoritative classification function. Returns 'series' or 'movie'.

    Priority order:
      1. Manual override (user-set, stored in config)
      2. stored_kind from DB (set from file paths on first directdl)
      3. File paths from directdl (ground truth)
      4. Name pattern matching (fallback for uncached transfers)
    """
    # Tier 1: manual override — via fuse_mount shared ref, no app import
    ov  = _get_overrides_safe()
    key = _override_key_safe(name)
    if key in ov:
        return ov[key]["kind"]  # 'movie' or 'series'

    # Tier 2: stored kind from DB (already classified from file paths)
    if stored_kind in ("movie", "series"):
        return stored_kind

    # Tier 3: classify from actual file paths (ground truth)
    if files:
        result = classify_from_files(files)
        if result:
            return result

    # Tier 4: name pattern fallback (for transfers not yet fetched)
    return "series" if bool(_SERIES_RE.search(name or "")) else "movie"

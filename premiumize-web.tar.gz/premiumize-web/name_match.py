"""
name_match.py — shared release-name parsing and fuzzy matching for
premiumize-web sync/reconcile.

All matching is done by normalising both sides to a comparable token set,
then doing graded comparison (exact → year+title → title-only → partial).
"""

import re
from difflib import SequenceMatcher

# ---------------------------------------------------------------------------
# Common noise tokens that appear in release names but not in Arr titles
# ---------------------------------------------------------------------------
_NOISE = re.compile(
    r'\b(?:'
    r'1080[ip]|720[ip]|2160[ip]|480[ip]|576[ip]'
    r'|4k|uhd|hdr|hdr10|hdr10\+|dv|dolbyvision'
    r'|bluray|blu.?ray|bdrip|bdremux|bdrip'
    r'|web.?dl|webrip|web|hmax|nf|atvp|dsnp|amzn|peacock|max'
    r'|hdtv|pdtv|dsr|dvdrip|dvd'
    r'|x264|x265|h264|h265|hevc|avc|av1|xvid|divx'
    r'|10bit|8bit|hi10p'
    r'|aac|dts|truehd|atmos|dd5?\.?1|ac3|eac3|flac|mp3|opus'
    r'|remux|repack|proper|extended|theatrical|directors?cut|final\.?cut'
    r'|imax|open\.?matte|hfr'
    r'|complete|season|collection|trilogy|series|mini.?series'
    r'|tgx|yts|yify|rarbg|ethel|ntb|cakes|nahom|rav1ne|edge2020|pahe'
    r')\b',
    re.IGNORECASE,
)

_SERIES_RE = re.compile(
    r'\bS(0?[1-9]|[1-5]\d|60)(?:E\d{1,3})?(?:[-–]E?\d{1,3})?\b(?![a-zA-Z])'  # S01-S60, S01E01
    r'|\bSeasons?[\s._-]*\d+\b'                                     # Season 1, Seasons 1
    r'|\bSeasons?[\s._-]*(?:One|Two|Three|Four|Five|Six|Seven|Eight|Nine|Ten)\b'  # Season One
    r'|\bSeasons?[\s._-]*\d+[\s._-]*(?:to|and|&|[-–])[\s._-]*\d+\b'  # Seasons 1 to 6
    r'|\bSeasons?[\s._-]*\d+(?:[\s._-]*[+]\s*\d+)+\b'          # Seizoen 1+2+3
    r'|\b\d{1,2}x\d{2}\b'                                          # 1x01
    r'|\bEpisode[\s._-]*\d+\b'                                      # Episode 1
    r'|\bComplete[\s._-]*Series\b'                                   # Complete Series
    r'|\bFull[\s._-]*Series\b'                                       # Full Series
    r'|\bMini[\s._-]*Series\b'                                       # Mini Series
    r'|\bPart[\s._-]*\d+\s+of\s+\d+\b'                          # Part 1 of 3
    r'|\bSeizoen[\s._-]*\d+\b'                                      # Dutch: Seizoen 1
    r'|\bSeizoen[\s._-]*\d+(?:[+\s]*\d+)+\b'                     # Dutch: Seizoen 1+2+3
    r'|\bStagione[\s._-]*\d+\b'                                     # Italian
    r'|\bTemporada[\s._-]*\d+\b'                                    # Spanish
    r'|\bSaison[\s._-]*\d+\b'                                       # French
    r'|\bStaffel[\s._-]*\d+\b'                                      # German
    r'|\bSeries[\s._-]*\d+\b'                                       # British: Series 1
    r'|\((?:19|20)\d{2}[-–](?:19|20)\d{2}\)'               # (1999-2015) TV run in parens
    r'|\[Complete\]'                                                   # [Complete] tag
    r'|\bComplete\b',                                                  # bare Complete (anime packs etc)
    re.IGNORECASE,
)

_YEAR_RE   = re.compile(r'\b((?:19|20)\d{2})\b')
_SEASON_RE = re.compile(
    r'(?i)\bS(\d{1,2})(?:[-–]S?\d{1,2})?\b'        # S01 / S01-S10
    r'|\bSeason[\s._-]*(\d{1,2})\b'                  # Season 1
    r'|\bEpisode[\s._-]*\d+'                          # Episode N (season unknown)
)
_EPISODE_RE = re.compile(
    r'(?i)\bS(\d{1,2})E(\d{1,3})(?:[-–]E?(\d{1,3}))?\b'
)

# 4K detection: 2160p, 4K, UHD
_4K_RE = re.compile(r'(?i)(2160p|\b4k\b|\buhd\b|3840[\s._x]?2160|4096[\s._x]?2160)')


def _norm(s: str) -> str:
    """Collapse to lowercase alphanumeric only."""
    return re.sub(r'[^a-z0-9]', '', (s or '').lower())


def _clean_title(name: str) -> str:
    """
    Strip release noise from a folder/torrent name to get the bare title.
    Also strips leading/trailing articles for comparison.
    """
    n = (name or '').replace('.', ' ').replace('_', ' ')
    # Remove series markers and everything after
    n = _SERIES_RE.sub('', n)
    # Remove year and everything after first year
    m = _YEAR_RE.search(n)
    if m:
        n = n[:m.start()]
    # Remove noise tokens
    n = _NOISE.sub('', n)
    # Strip group tags in brackets/parens at end
    n = re.sub(r'[\[\(][^\]\)]{1,20}[\]\)]', ' ', n)
    # Strip any dangling opening bracket
    n = re.sub(r'[\[\(]\s*$', '', n)
    # Collapse whitespace and strip
    n = re.sub(r'\s+', ' ', n).strip(' -–()')
    return n


def parse_movie(name: str):
    """
    Returns (clean_title, year|None) from a movie release name.
    """
    n = (name or '').replace('.', ' ').replace('_', ' ')
    m = _YEAR_RE.search(n)
    year  = m.group(1) if m else None
    title = n[:m.start()].strip() if m else n
    title = _NOISE.sub('', title).strip()
    title = re.sub(r'\s+', ' ', title).strip(' -–')
    return title, year


def parse_episode(name: str):
    """
    Returns (series_title, season, [episode_nums]) from a release name.
    episode_nums=None means season pack (matches all episodes in season).
    season=None means no season info found.
    """
    n = (name or '').replace('.', ' ').replace('_', ' ')

    m = _EPISODE_RE.search(n)
    if m:
        season = int(m.group(1))
        e1     = int(m.group(2))
        e2     = int(m.group(3)) if m.group(3) else e1
        if e2 < e1 or e2 - e1 > 60:
            e2 = e1
        title  = _clean_title(n[:m.start()])
        return title, season, list(range(e1, e2 + 1))

    m2 = _SEASON_RE.search(n)
    if m2:
        season = int(m2.group(1) or m2.group(2) or 1)
        title  = _clean_title(n[:m2.start()])
        return title, season, None   # pack

    # No episode/season info — try to salvage a title anyway
    title = _clean_title(n)
    return title, None, None


def is_series(name: str) -> bool:
    # Check manual override first
    try:
        from app import _get_overrides, _override_key
        ov = _get_overrides()
        key = _override_key(name)
        if key in ov:
            return ov[key]["kind"] == "series"
    except Exception:
        pass
    return bool(_SERIES_RE.search(name or ''))


# ---------------------------------------------------------------------------
# Similarity scoring
# ---------------------------------------------------------------------------

def _title_sim(a: str, b: str) -> float:
    """Normalised similarity 0-1 between two titles."""
    na, nb = _norm(a), _norm(b)
    if not na or not nb:
        return 0.0
    if na == nb:
        return 1.0
    # One contains the other
    if na in nb or nb in na:
        return 0.92
    return SequenceMatcher(None, na, nb).ratio()


# ---------------------------------------------------------------------------
# Fuse-mount index
# ---------------------------------------------------------------------------

class FuseIndex:
    """
    Pre-built index of what's in the FUSE mount.
    Supports fuzzy lookup by movie title+year or series+season+episode.
    """

    def __init__(self, fuse_items: dict):
        """fuse_items: {folder_name: transfer_dict}"""
        self.movies  = []   # [(clean_title, year, norm_title, transfer)]
        self.series  = []   # [(clean_title, season, episodes, norm_title, transfer)]

        for fname, tr in fuse_items.items():
            raw = tr.get('name') or fname
            if is_series(raw):
                title, season, eps = parse_episode(raw)
                self.series.append((title, season, eps, _norm(title), tr))
            else:
                title, year = parse_movie(raw)
                self.movies.append((title, year, _norm(title), tr))

    # -- Movie lookup -------------------------------------------------------

    def find_movie(self, radarr_movie: dict):
        """
        Match a Radarr movie dict against the fuse index.
        Returns the transfer dict or None.
        """
        year = str(radarr_movie.get('year') or '')
        # Collect all candidate titles Radarr knows for this movie
        titles = []
        for key in ('title', 'originalTitle', 'sortTitle'):
            t = radarr_movie.get(key) or ''
            if t:
                titles.append(t)
        for alt in (radarr_movie.get('alternateTitles') or []):
            t = alt.get('title') or ''
            if t:
                titles.append(t)

        best_tr, best_score = None, 0.0
        for fuse_title, fuse_year, fuse_norm, tr in self.movies:
            for arr_title in titles:
                sim = _title_sim(fuse_title, arr_title)
                if sim < 0.80:
                    continue
                # Year bonus/penalty
                score = sim
                if year and fuse_year:
                    score = score * 1.1 if fuse_year == year else score * 0.75
                elif year and not fuse_year:
                    score *= 0.95   # slight penalty — no year to confirm
                if score > best_score:
                    best_score, best_tr = score, tr

        return best_tr if best_score >= 0.80 else None

    # -- Series lookup -------------------------------------------------------

    def find_episode(self, sonarr_series: dict, season: int, episode: int):
        """
        Match a Sonarr series+episode against the fuse index.
        Returns the transfer dict or None.
        """
        titles = [sonarr_series.get('title') or '']
        for alt in (sonarr_series.get('alternateTitles') or []):
            t = alt.get('title') or ''
            if t:
                titles.append(t)

        best_tr, best_score = None, 0.0
        for fuse_title, fuse_season, fuse_eps, fuse_norm, tr in self.series:
            if fuse_season is not None and fuse_season != season:
                continue
            if fuse_eps is not None and episode not in fuse_eps:
                continue
            for arr_title in titles:
                sim = _title_sim(fuse_title, arr_title)
                if sim > best_score:
                    best_score, best_tr = sim, tr

        return best_tr if best_score >= 0.75 else None

    def find_series(self, sonarr_series: dict):
        """Check if any episode/pack in the fuse matches this series."""
        titles = [sonarr_series.get('title') or '']
        for alt in (sonarr_series.get('alternateTitles') or []):
            t = alt.get('title') or ''
            if t:
                titles.append(t)

        for fuse_title, fuse_season, fuse_eps, fuse_norm, tr in self.series:
            for arr_title in titles:
                if _title_sim(fuse_title, arr_title) >= 0.75:
                    return tr
        return None

    def log_index(self) -> str:
        lines = []
        for t, y, n, _ in self.movies[:5]:
            lines.append(f"  movie: {t!r} ({y})")
        for t, s, e, n, _ in self.series[:5]:
            ep = f"S{s:02d}" if s else "?"
            ep += f" eps={e}" if e else " (pack)"
            lines.append(f"  series: {t!r} {ep}")
        return '\n'.join(lines)

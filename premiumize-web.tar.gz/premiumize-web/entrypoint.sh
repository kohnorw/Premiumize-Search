#!/bin/sh
set -e

FUSE_MOUNT="${FUSE_MOUNTPOINT:-/docker/premiumize-web/mnt}"

# Clean up any stale FUSE mount left over from a previous crash.
if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
    echo "[entrypoint] Unmounting stale FUSE mount at $FUSE_MOUNT"
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null || umount -l "$FUSE_MOUNT" 2>/dev/null || true
fi

mkdir -p "$FUSE_MOUNT"

exec python /app/app.py

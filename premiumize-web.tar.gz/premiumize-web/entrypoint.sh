#!/bin/sh
set -e

SHARE_ROOT="/docker/premiumize-web"
FUSE_MOUNT="${FUSE_MOUNTPOINT:-/docker/premiumize-web/mnt}"

# Ensure the parent bind-mount is marked shared so the FUSE mount we create
# below propagates back to the host (and to Plex/other containers).
# This is safe to run on every start — it is idempotent.
# Requires the container to run with --privileged (already set in compose).
if mountpoint -q "$SHARE_ROOT" 2>/dev/null; then
    mount --make-rshared "$SHARE_ROOT" 2>/dev/null && \
        echo "[entrypoint] $SHARE_ROOT marked rshared" || \
        echo "[entrypoint] WARNING: could not mark $SHARE_ROOT rshared (FUSE propagation may not work)"
else
    # Not a mountpoint yet — bind it to itself first, then mark shared.
    mount --bind "$SHARE_ROOT" "$SHARE_ROOT" 2>/dev/null && \
        mount --make-rshared "$SHARE_ROOT" 2>/dev/null && \
        echo "[entrypoint] $SHARE_ROOT bind-mounted and marked rshared" || \
        echo "[entrypoint] WARNING: could not bind/share $SHARE_ROOT (running without SYS_ADMIN?)"
fi

# Clean up any stale FUSE mount from a previous crash.
# Loop because multiple layers can stack if the container was force-killed
# while a previous stale mount was already present.
i=0
while mountpoint -q "$FUSE_MOUNT" 2>/dev/null; do
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null || umount -l "$FUSE_MOUNT" 2>/dev/null || true
    i=$((i + 1))
    if [ $i -ge 10 ]; then
        echo "[entrypoint] WARNING: could not fully unmount $FUSE_MOUNT after 10 attempts"
        break
    fi
done

mkdir -p "$FUSE_MOUNT"
mkdir -p "${FUSE_CACHE_DIR:-/docker/premiumize-web/cache}"

exec python /app/app.py

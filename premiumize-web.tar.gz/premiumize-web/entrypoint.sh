#!/bin/sh
set -e

FUSE_MOUNT="${FUSE_MOUNTPOINT:-/docker/premiumize-web/mnt}"

# Clean up any stale FUSE mount from a previous crash.
# Loop because multiple layers can stack if the container was force-killed
# while a previous stale mount was already present.
i=0
while mountpoint -q "$FUSE_MOUNT" 2>/dev/null; do
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null || umount -l "$FUSE_MOUNT" 2>/dev/null || true
    i=$((i + 1))
    if [ $i -ge 10 ]; then
        echo "[entrypoint] WARNING: could not fully unmount $FUSE_MOUNT after 10 attempts"
        break
    fi
done

mkdir -p "$FUSE_MOUNT"
mkdir -p "${LIBRARY_PATH:-/docker/premiumize-web/library}"

exec python /app/app.py

#!/bin/sh
set -e

SHARE_ROOT="/docker/premiumize-web"
FUSE_MOUNT="${FUSE_MOUNTPOINT:-/docker/premiumize-web/mnt}"
CACHE_DIR="${FUSE_CACHE_DIR:-/docker/premiumize-web/cache}"

log() { echo "[entrypoint] $*"; }

# ── Step 1: ensure SHARE_ROOT is a shared bind-mount ─────────────────────────
# On container restart the host bind is already in place, just re-mark shared.
# On first deploy it may not be a mountpoint yet so we bind it first.
if mountpoint -q "$SHARE_ROOT" 2>/dev/null; then
    mount --make-rshared "$SHARE_ROOT" 2>/dev/null \
        && log "$SHARE_ROOT marked rshared" \
        || log "WARNING: could not mark $SHARE_ROOT rshared"
else
    mount --bind "$SHARE_ROOT" "$SHARE_ROOT" 2>/dev/null \
        && mount --make-rshared "$SHARE_ROOT" 2>/dev/null \
        && log "$SHARE_ROOT bind-mounted and marked rshared" \
        || log "WARNING: could not bind/share $SHARE_ROOT (running without SYS_ADMIN?)"
fi

# ── Step 2: aggressively tear down any stale FUSE mount ──────────────────────
# On container restart the previous FUSE process is dead but the mount entry
# can survive in both the container and host mount namespaces, leaving the
# directory in a "Transport endpoint is not connected" state.
# We must clean it up before trying to re-mount, otherwise FUSE will fail or
# stack on top of the broken mount.

_unmount_fuse() {
    # Try fusermount first (graceful), then lazy umount (force)
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null && return 0
    umount -l   "$FUSE_MOUNT"   2>/dev/null && return 0
    umount      "$FUSE_MOUNT"   2>/dev/null && return 0
    return 1
}

i=0
while true; do
    # Check both mountpoint and the broken "Transport endpoint" case
    if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
        log "Stale FUSE mount detected at $FUSE_MOUNT — unmounting (attempt $((i+1)))..."
        _unmount_fuse || true
    elif ls "$FUSE_MOUNT" 2>&1 | grep -q "Transport endpoint"; then
        log "Broken transport endpoint at $FUSE_MOUNT — forcing unmount (attempt $((i+1)))..."
        umount -l "$FUSE_MOUNT" 2>/dev/null || true
    else
        break  # clean
    fi

    i=$((i + 1))
    if [ $i -ge 15 ]; then
        log "WARNING: could not fully clear $FUSE_MOUNT after 15 attempts — proceeding anyway"
        break
    fi
    sleep 0.2
done

# ── Step 3: ensure directories exist ─────────────────────────────────────────
mkdir -p "$FUSE_MOUNT"
mkdir -p "$CACHE_DIR"

log "Startup complete — launching app"
exec python /app/app.py

#!/bin/bash
#
# host-setup.sh — one-time host preparation for FUSE mount propagation.
#
# Mount model: the container bind-mounts /docker/premiumize-web with :rshared
# and creates its FUSE mount at the subdirectory /docker/premiumize-web/mnt.
# For that to be visible on the host, the PARENT (/docker/premiumize-web) must
# be a shared bind-mount before the container starts. The /mnt subdirectory
# must be a plain empty directory — never a mountpoint — so the container's
# FUSE propagates into it cleanly without stacking.
#
# Run as root:  sudo ./host-setup.sh
#
set -euo pipefail

SHARE_ROOT="/docker/premiumize-web"
MNT_DIR="$SHARE_ROOT/mnt"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [[ $EUID -ne 0 ]]; then
    echo "Must run as root: sudo $0" >&2
    exit 1
fi

echo "==> Stopping the container so it releases mount references..."
( cd "$SCRIPT_DIR" && (docker compose down 2>/dev/null || docker-compose down 2>/dev/null) ) || \
    echo "    (compose down skipped — bring the container down manually if it's still up)"

cd /

# ── Step 1: clear EVERYTHING mounted at or under $MNT_DIR ────────────────────
# This removes stale FUSE mounts AND any accidental ext4 self-binds of /mnt
# that previous runs may have created. We loop because layers must be removed
# one at a time, innermost first.
echo "==> Clearing any mounts at $MNT_DIR ..."
for _ in $(seq 1 20); do
    if mountpoint -q "$MNT_DIR" 2>/dev/null; then
        umount "$MNT_DIR" 2>/dev/null || umount -l "$MNT_DIR" 2>/dev/null || true
    else
        break
    fi
done
if mountpoint -q "$MNT_DIR" 2>/dev/null; then
    echo "ERROR: could not unmount $MNT_DIR after 20 attempts" >&2
    exit 1
fi
echo "    $MNT_DIR is now a plain directory."

# ── Step 2: clear stacked self-binds on the PARENT ───────────────────────────
# Keep exactly ONE bind so we can mark it shared. Remove extras first.
echo "==> Normalising $SHARE_ROOT to a single bind-mount..."
for _ in $(seq 1 10); do
    count=$(findmnt -nr -o TARGET "$SHARE_ROOT" 2>/dev/null | grep -c "^${SHARE_ROOT}$" || true)
    if [ "${count:-0}" -gt 1 ]; then
        umount "$SHARE_ROOT" 2>/dev/null || umount -l "$SHARE_ROOT" 2>/dev/null || true
    else
        break
    fi
done

# Create the bind if the directory isn't a mountpoint at all
if ! mountpoint -q "$SHARE_ROOT"; then
    mount --bind "$SHARE_ROOT" "$SHARE_ROOT"
fi

# Mark it shared so Docker :rshared can propagate back to the host
mount --make-rshared "$SHARE_ROOT"

# ── Step 3: ensure /mnt exists as a plain empty directory ─────────────────────
mkdir -p "$MNT_DIR"

echo ""
echo "==> Current state:"
findmnt -o TARGET,PROPAGATION,SOURCE "$SHARE_ROOT"
mountpoint "$MNT_DIR" && echo "ERROR: $MNT_DIR is still a mountpoint!" || echo "    $MNT_DIR — plain directory (correct)"

# ── Step 4: install systemd unit ──────────────────────────────────────────────
echo ""
echo "==> Installing systemd unit for persistence across reboots..."
cat > /etc/systemd/system/premiumize-web-sharedmount.service <<'UNIT'
[Unit]
Description=Shared mount propagation for premiumize-web FUSE
DefaultDependencies=no
Before=docker.service
After=local-fs.target
ConditionPathIsDirectory=/docker/premiumize-web

[Service]
Type=oneshot
RemainAfterExit=yes
# Ensure the subdirectory exists as a plain directory (never mount it)
ExecStart=/bin/mkdir -p /docker/premiumize-web/mnt
# Bind-mount the parent only if it isn't already a mountpoint
ExecStart=/bin/sh -c 'mountpoint -q /docker/premiumize-web || mount --bind /docker/premiumize-web /docker/premiumize-web'
# Mark shared so the container's FUSE propagates back to the host
ExecStart=/bin/mount --make-rshared /docker/premiumize-web

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable premiumize-web-sharedmount.service

echo ""
echo "==> Done. Bring the container back up:"
echo "      cd $SCRIPT_DIR && docker compose up -d"
echo ""
echo "    Then verify (always run from /, never cd into the mount):"
echo "      cd /"
echo "      ls /docker/premiumize-web/mnt"
echo "      cat /proc/self/mountinfo | grep '/docker/premiumize-web/mnt'"
echo ""
echo "    You should see ONE fuse line with shared:N on the host."
echo "    The container should show the same shared:N peer group:"
echo "      docker exec premiumize-web cat /proc/self/mountinfo | grep '/docker/premiumize-web/mnt'"

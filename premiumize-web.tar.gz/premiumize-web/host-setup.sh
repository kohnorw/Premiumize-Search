#!/bin/bash
#
# host-setup.sh — one-time host preparation for FUSE mount propagation.
#
# Mount model (same idea as decypharr/DUMB): the container bind-mounts the
# parent /docker/premiumize-web with :rshared and creates its FUSE mount in the
# subdirectory /docker/premiumize-web/mnt. Cached torrents appear there as
# browsable folders/files that Plex, Sonarr, Radarr (etc.) can read.
#
# For the mount created INSIDE the container to be visible on the HOST,
# /docker/premiumize-web must be a SHARED mount point on the host BEFORE the
# container starts. Docker's :rshared only propagates outward when the host
# source is already shared at container-create time, and the container must
# inherit the host's mount peer group (clean bind, no re-marking).
#
# This script:
#   1. Stops the container so it releases mount references
#   2. Unwinds any stacked/duplicate self-binds from earlier manual attempts
#   3. Establishes exactly ONE shared bind on /docker/premiumize-web
#   4. Installs a systemd unit (Before=docker.service) so it persists on reboot
#
# Run as root:  sudo ./host-setup.sh
#
set -euo pipefail

SHARE_ROOT="/docker/premiumize-web"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [[ $EUID -ne 0 ]]; then
    echo "Must run as root: sudo $0" >&2
    exit 1
fi

echo "==> Stopping the container so it releases mount references..."
( cd "$SCRIPT_DIR" && (docker compose down 2>/dev/null || docker-compose down 2>/dev/null) ) || \
    echo "    (compose down skipped — bring the container down manually if it's still up)"

echo "==> Leaving any mounted directory (cannot unmount our own cwd)..."
cd /

echo "==> Unwinding any existing stacked self-binds at $SHARE_ROOT ..."
for _ in $(seq 1 10); do
    dups=$(findmnt -nr -o TARGET "$SHARE_ROOT" 2>/dev/null | grep -c "^$SHARE_ROOT$" || true)
    if [ "${dups:-0}" -ge 1 ]; then
        # Lazily unmount any FUSE child first, then the bind layer
        if mountpoint -q "$SHARE_ROOT/mnt" 2>/dev/null; then
            fusermount -uz "$SHARE_ROOT/mnt" 2>/dev/null || umount -l "$SHARE_ROOT/mnt" 2>/dev/null || true
        fi
        # Only unmount if there's more than one stacked layer OR to reset cleanly
        if [ "${dups:-0}" -gt 1 ]; then
            umount "$SHARE_ROOT" 2>/dev/null || umount -l "$SHARE_ROOT" 2>/dev/null || true
        else
            break
        fi
    else
        break
    fi
done

echo "==> Ensuring $SHARE_ROOT exists and creating a single shared bind..."
mkdir -p "$SHARE_ROOT/mnt"

if ! mountpoint -q "$SHARE_ROOT"; then
    mount --bind "$SHARE_ROOT" "$SHARE_ROOT"
fi
mount --make-rshared "$SHARE_ROOT"

echo "==> Current state:"
findmnt -o TARGET,PROPAGATION,SOURCE "$SHARE_ROOT"

echo "==> Installing systemd unit for persistence across reboots..."
cat > /etc/systemd/system/premiumize-web-sharedmount.service <<'EOF'
[Unit]
Description=Shared mount propagation for premiumize-web FUSE
DefaultDependencies=no
Before=docker.service
After=local-fs.target
ConditionPathIsDirectory=/docker/premiumize-web

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/mkdir -p /docker/premiumize-web/mnt
ExecStart=/bin/sh -c 'mountpoint -q /docker/premiumize-web || mount --bind /docker/premiumize-web /docker/premiumize-web'
ExecStart=/bin/mount --make-rshared /docker/premiumize-web

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable premiumize-web-sharedmount.service

echo ""
echo "==> Done. Now (re)create the container so it binds the shared mount:"
echo "      cd $SCRIPT_DIR && docker-compose up -d"
echo ""
echo "    Verify (run from / , never cd into the mount):"
echo "      cd /"
echo "      ls -la /docker/premiumize-web/mnt"
echo "      cat /proc/self/mountinfo | grep ' /docker/premiumize-web '"
echo "      docker exec premiumize-web cat /proc/self/mountinfo | grep ' /docker/premiumize-web '"
echo "    The two 'shared:N' peer-group numbers must MATCH."

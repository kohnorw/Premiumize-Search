#!/bin/bash
#
# host-setup.sh — one-time host preparation for FUSE mount propagation.
#
# This mirrors the decypharr / DUMB approach: the container bind-mounts the
# parent /mnt with :rshared and creates its FUSE mount in a subdirectory
# (/mnt/premiumize). For that submount to be visible on the HOST (and to Plex,
# Sonarr, Radarr, etc.), /mnt must be a SHARED mount point on the host BEFORE
# the container starts. Docker's :rshared only propagates outward if the host
# source is already shared at container-create time, and the container must
# inherit the host's mount peer group (which only happens with a clean bind).
#
# This script:
#   1. Stops the container so it releases any mount references
#   2. Unwinds any stacked/duplicate self-binds from earlier manual attempts
#   3. Establishes exactly ONE shared bind on /mnt
#   4. Installs a systemd unit so it is re-established on every boot, ordered
#      BEFORE docker.service so the container always inherits the shared group
#
# Run as root:  sudo ./host-setup.sh
#
set -euo pipefail

SHARE_ROOT="/mnt"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [[ $EUID -ne 0 ]]; then
    echo "Must run as root: sudo $0" >&2
    exit 1
fi

echo "==> Stopping the container so it releases mount references..."
( cd "$SCRIPT_DIR" && (docker compose down 2>/dev/null || docker-compose down 2>/dev/null) ) || \
    echo "    (compose down skipped — bring the container down manually if it's still up)"

echo "==> Leaving any mounted directory (cannot unmount our own cwd)..."
cd /

echo "==> Unwinding any existing stacked binds at $SHARE_ROOT ..."
# /mnt is often legitimately a mount already on some systems; we only unwind
# duplicate self-binds that previous manual attempts may have stacked. We detect
# a self-bind by source==target on the same device. Unmount up to 10 layers.
for _ in $(seq 1 10); do
    # Count how many times SHARE_ROOT appears as a self-bind target
    cnt=$(grep -c " $SHARE_ROOT $SHARE_ROOT " /proc/self/mountinfo 2>/dev/null || true)
    # mountinfo format differs; fall back to findmnt duplicate detection
    dups=$(findmnt -nr -o TARGET "$SHARE_ROOT" 2>/dev/null | grep -c "^$SHARE_ROOT$" || true)
    if [ "${dups:-0}" -gt 1 ]; then
        umount "$SHARE_ROOT" 2>/dev/null || umount -l "$SHARE_ROOT" 2>/dev/null || break
    else
        break
    fi
done

echo "==> Ensuring $SHARE_ROOT exists and creating the shared bind..."
mkdir -p "$SHARE_ROOT/premiumize"

# Make /mnt a shared mount. If it is already its own mountpoint we just re-mark
# it shared; otherwise we self-bind it first so it becomes a mountpoint.
if ! mountpoint -q "$SHARE_ROOT"; then
    mount --bind "$SHARE_ROOT" "$SHARE_ROOT"
fi
mount --make-rshared "$SHARE_ROOT"

echo "==> Current state:"
findmnt -o TARGET,PROPAGATION,SOURCE "$SHARE_ROOT"

echo "==> Installing systemd unit for persistence across reboots..."
cat > /etc/systemd/system/mnt-shared-propagation.service <<'EOF'
[Unit]
Description=Make /mnt a shared mount for FUSE propagation (premiumize-web / decypharr style)
DefaultDependencies=no
Before=docker.service
After=local-fs.target
ConditionPathIsDirectory=/mnt

[Service]
Type=oneshot
RemainAfterExit=yes
# Ensure /mnt is a mountpoint, then mark it rshared so container submounts
# propagate to the host. The '|| true' on the bind handles the case where /mnt
# is already a mountpoint (re-binding would be redundant/harmless).
ExecStart=/bin/sh -c 'mountpoint -q /mnt || mount --bind /mnt /mnt'
ExecStart=/bin/mount --make-rshared /mnt

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable mnt-shared-propagation.service

echo ""
echo "==> Done. Now (re)create the container so it binds the shared /mnt:"
echo "      cd $SCRIPT_DIR && docker compose up -d   # or docker-compose up -d"
echo ""
echo "    Then verify (run from / , never cd into the mount):"
echo "      ls -la /mnt/premiumize"
echo "      findmnt -R /mnt | grep premiumize"
echo ""
echo "    The container's /mnt bind and the host /mnt should share the SAME"
echo "    'shared:N' peer-group number — check with:"
echo "      cat /proc/self/mountinfo | grep ' /mnt '"
echo "      docker exec premiumize-web cat /proc/self/mountinfo | grep ' /mnt '"

#!/bin/bash
#
# host-setup.sh — one-time host preparation for FUSE mount propagation.
#
# Why this is needed:
#   The container creates a FUSE mount at /docker/premiumize-web/mnt *inside*
#   its own mount namespace. For that mount to be visible on the host, the
#   host directory /docker/premiumize-web must be a SHARED mount point BEFORE
#   the container starts. Docker's ":rshared" volume flag only propagates if
#   the host source is already shared at container-create time.
#
# This script:
#   1. Unwinds any stacked/duplicate self-binds from previous manual attempts
#   2. Establishes exactly ONE self-bind marked shared
#   3. Installs a systemd unit so it persists across reboots
#
# Run as root:  sudo ./host-setup.sh
#
set -euo pipefail

MNT_PARENT="/docker/premiumize-web"

if [[ $EUID -ne 0 ]]; then
    echo "Must run as root: sudo $0" >&2
    exit 1
fi

echo "==> Stopping the container so it releases mount references..."
# Try compose v1 then v2; ignore failure if not running
(docker-compose -f "$(dirname "$0")/docker-compose.yml" down 2>/dev/null) || \
(docker compose -f "$(dirname "$0")/docker-compose.yml" down 2>/dev/null) || \
echo "    (compose down skipped — bring the container down manually if it's still up)"

echo "==> Making sure we are not standing inside the mount..."
cd /

echo "==> Unwinding any existing binds at $MNT_PARENT ..."
# Unmount repeatedly until it's no longer a bind (max 10 attempts to avoid infinite loop)
for i in $(seq 1 10); do
    if mountpoint -q "$MNT_PARENT"; then
        # If a child FUSE mount is stuck under it, lazy-unmount that first
        if mountpoint -q "$MNT_PARENT/mnt" 2>/dev/null; then
            fusermount -uz "$MNT_PARENT/mnt" 2>/dev/null || umount -l "$MNT_PARENT/mnt" 2>/dev/null || true
        fi
        umount "$MNT_PARENT" 2>/dev/null || umount -l "$MNT_PARENT" 2>/dev/null || true
    else
        break
    fi
done

if mountpoint -q "$MNT_PARENT"; then
    echo "    WARNING: $MNT_PARENT is still a mountpoint after 10 attempts." >&2
    echo "    Check 'fuser -vm $MNT_PARENT' for processes holding it open." >&2
fi

echo "==> Ensuring directory exists..."
mkdir -p "$MNT_PARENT/mnt"

echo "==> Creating single shared self-bind..."
mount --bind "$MNT_PARENT" "$MNT_PARENT"
mount --make-rshared "$MNT_PARENT"

echo "==> Current state:"
findmnt -o TARGET,PROPAGATION,SOURCE "$MNT_PARENT"

echo "==> Installing systemd unit for persistence across reboots..."
cat > /etc/systemd/system/premiumize-web-sharedmount.service <<'EOF'
[Unit]
Description=Shared mount propagation for premiumize-web FUSE
DefaultDependencies=no
Before=docker.service
After=local-fs.target
ConditionPathIsDirectory=/docker/premiumize-web

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/mkdir -p /docker/premiumize-web/mnt
ExecStart=/bin/mount --bind /docker/premiumize-web /docker/premiumize-web
ExecStart=/bin/mount --make-rshared /docker/premiumize-web
ExecStop=/bin/umount -l /docker/premiumize-web

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable premiumize-web-sharedmount.service

echo ""
echo "==> Done. Now (re)create the container so it binds the shared mount:"
echo "      docker-compose up -d"
echo ""
echo "    Then verify:"
echo "      ls -la /docker/premiumize-web/mnt"
echo "      findmnt -R /docker/premiumize-web"
